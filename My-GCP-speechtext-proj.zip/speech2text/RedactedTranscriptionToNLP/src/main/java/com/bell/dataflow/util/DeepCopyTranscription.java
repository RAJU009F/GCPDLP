/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.dataflow.util;

import com.bell.dataflow.model.LoggerModel;
import com.bell.stt.proto.TranscriptionMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This Copy is responsible for the creating a DeepCopy and add NLP responses to the Proto File.
 */

public class DeepCopyTranscription {
    static final Logger LOG = LoggerFactory.getLogger(DeepCopyTranscription.class);

    /**
     * This DeepCopy method take the response from NLP and creates a Copy to add provided values below.
     * @param incomingEvent
     * @param sentimentResponse
     * @param entityAnalysisResponse
     * @param nlpStartTime
     * @param logModel
     * @return TranscriptionMessage.ConversationEvent
     */

    public static TranscriptionMessage.ConversationEvent deepCopy(TranscriptionMessage.ConversationEvent incomingEvent,
                                                                  TranscriptionMessage.NLPSentimentAnalysisResponse sentimentResponse,
                                                                  TranscriptionMessage.NLPEntityAnalysisResponse entityAnalysisResponse,
                                                                 long nlpStartTime,
                                                                  LoggerModel logModel) {


        TranscriptionMessage.ConversationEvent.Builder transcription = TranscriptionMessage.ConversationEvent.newBuilder();

        try {
            long startTime= System.currentTimeMillis();
            LogUtil.log("Entering in the DeepCopy method to merge responses from API with input payload ",
                    logModel,"start time ", startTime,LOG);
            transcription.setConversation(incomingEvent.getConversation());
            transcription.setType(incomingEvent.getType());

            TranscriptionMessage.Message.Builder msg = TranscriptionMessage.Message.newBuilder();
            msg.setLanguageCode(incomingEvent.getNewMessagePayload().getLanguageCode());
            msg.setParticipant(incomingEvent.getNewMessagePayload().getParticipant());
            msg.setName(incomingEvent.getNewMessagePayload().getName());
            msg.setCreateTime(incomingEvent.getNewMessagePayload().getCreateTime());
            msg.setContent(incomingEvent.getNewMessagePayload().getContent());
            msg.setSpeechToTextInfo(incomingEvent.getNewMessagePayload().getSpeechToTextInfo());
            msg.setWordCount(String.valueOf(logModel.getUtteranceCount()));
            msg.setNLPAPIStartTime(String.valueOf(nlpStartTime));

            TranscriptionMessage.Message.SpeechToTextInfo.Builder s2tInfo = TranscriptionMessage.Message.SpeechToTextInfo.newBuilder();
            s2tInfo.setUtteranceStartOffset(incomingEvent.getNewMessagePayload().getSpeechToTextInfo().getUtteranceStartOffset());
            s2tInfo.setUtteranceEndOffset(incomingEvent.getNewMessagePayload().getSpeechToTextInfo().getUtteranceEndOffset());
            s2tInfo.setStreamStartTime(incomingEvent.getNewMessagePayloadOrBuilder().getSpeechToTextInfo().getStreamStartTime());
            s2tInfo.setConfidence(incomingEvent.getNewMessagePayload().getSpeechToTextInfo().getConfidence());
            s2tInfo.addAllSpeechWordInfo(incomingEvent.getNewMessagePayload().getSpeechToTextInfo().getSpeechWordInfoList());
            s2tInfo.build();
            msg.setSpeechToTextInfo(s2tInfo);

            if(sentimentResponse!= null){
                TranscriptionMessage.NLPSentimentAnalysisResponse.Builder sentimentResponseProto = TranscriptionMessage.NLPSentimentAnalysisResponse.newBuilder();
                sentimentResponseProto.setLanguage(sentimentResponse.getLanguage());
                TranscriptionMessage.Document.Builder docResponse = TranscriptionMessage.Document.newBuilder();
                docResponse.setMagnitude(docResponse.getMagnitude());
                docResponse.setScore(docResponse.getScore());
                docResponse.build();
                sentimentResponseProto.setDocument(sentimentResponse.getDocument());
                sentimentResponseProto.addAllSentences(sentimentResponse.getSentencesList());
                msg.setNLPSentimentAnalysisResponse(sentimentResponseProto);
            }

            if(entityAnalysisResponse != null){
                TranscriptionMessage.NLPEntityAnalysisResponse.Builder entityResponseProto = TranscriptionMessage.NLPEntityAnalysisResponse.newBuilder();
                entityResponseProto.setLanguage(entityAnalysisResponse.getLanguage());
                entityResponseProto.addAllEntities(entityAnalysisResponse.getEntitiesList());
                msg.setNLPEntityAnalysisResponse(entityResponseProto);
            }

            transcription.setNewMessagePayload(msg.build());
            long endTime= System.currentTimeMillis();
            LogUtil.log("The sentiment and Entity DeepCopy method successfully merge responses from API with input payload ",
                    logModel,"tme taken",(endTime-startTime),LOG);

        } catch (Exception e) {

            LogUtil.logError("ERRNLP108-Unable to copy the response",e,logModel,LOG);

        }
        return transcription.build();
    }

}

