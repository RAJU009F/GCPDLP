package com.bell.stt;


import com.bell.stt.avro.Transcription;

import com.bell.stt.kafka.KafkaHelper;
import com.bell.stt.transformers.KafkaToAvroParDo;
import com.bell.stt.options.PubSubToKafkaOptions;
import com.bell.stt.proto.TranscriptionMessage.*;


import io.confluent.kafka.serializers.KafkaAvroSerializer;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.kafka.KafkaIO;
import org.apache.beam.sdk.metrics.MetricNameFilter;
import org.apache.beam.sdk.metrics.MetricQueryResults;
import org.apache.beam.sdk.metrics.MetricResult;
import org.apache.beam.sdk.metrics.MetricsFilter;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Class for reading the Transcription from pubsub
 * Transform to Avro
 * Write to Output Kafka
 */
public class PubSubToKafka {

    //private static final String TYPENAME = "type_name";
    private static final Logger LOG = LoggerFactory.getLogger(PubSubToKafka.class);


    /**
     * Entry point for the data flow job
     * @param args pipeline arguments
     */
    public static void main(String[] args) {

        // Parse the user options passed from the command-line
        PubSubToKafkaOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(PubSubToKafkaOptions.class);
        options.setStreaming(true);
        PipelineResult result = run(options);
        //result.waitUntilFinish();

        // request the metric called "counter1" in namespace called "namespace"
        MetricQueryResults metrics =
                result
                        .metrics()
                        .queryMetrics(
                                MetricsFilter.builder()
                                        .addNameFilter(MetricNameFilter.named("STT-PubsubToKafka", "PUBSUBTOKAFKA_STT_SUCCESS"))
                                        .addNameFilter(MetricNameFilter.named("STT-PubsubToKafka", "PUBSUBTOKAFKA_STT_FAILURE"))
                                        .build());


        for (MetricResult<Long> counter : metrics.getCounters()) {
            System.out.println(counter.getName() + ":" + counter.getAttempted());
        }
    }
    /**
     * The pipeline run method containing the DAG.
     * @param options pipeline options
     * @return pipeline result
     */
    public static PipelineResult run(PubSubToKafkaOptions options) {
        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);

        /**
         * Steps:
         *      1) Read PubSubMessage from input PubSub subscription.
         *      2) Build Key value pair of conversationId, Transcription
         *      3) Write each PubSubMessage to output PubSub topic.
         */
        try {
            PubsubIO.Read<ConversationEvent> messages =
                    PubsubIO.readProtos((Class) ConversationEvent.class).fromSubscription(options.getInputSubscription());
            PCollection<KV<String, Transcription>> stringMessages = pipeline.apply(messages).apply(ParDo.of(new KafkaToAvroParDo()));
            stringMessages.apply("Write to Kafka Topic", KafkaIO.<String, Transcription>write().
                    withProducerFactoryFn(KafkaHelper.serializationBuilder(options).createKafkaProducer())
                    .withBootstrapServers(options.getBootstrapServers().get())
                    .withTopic(options.getOutputTopic().get())
                    .withKeySerializer(StringSerializer.class)
                    .withValueSerializer((Class) KafkaAvroSerializer.class)
            );
        } catch (Exception e) {
            LOG.error("S2T-ERR201 - Error processing the pipeline ", e);
        }
        // Execute the pipeline and return the result.
        return pipeline.run();
    }
}