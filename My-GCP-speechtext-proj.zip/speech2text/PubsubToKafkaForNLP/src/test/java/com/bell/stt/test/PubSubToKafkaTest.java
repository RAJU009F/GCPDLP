/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.stt.test;

import com.bell.stt.avro.Entities;
import com.bell.stt.avro.ErrorStatus;
import com.bell.stt.avro.NLPSentimentAndEntityAnalysisTranscriptionOutput;
import com.bell.stt.avro.Transcription;
import com.bell.stt.converters.ProtoToAvro;
import com.bell.stt.proto.TranscriptionMessage;
import com.bell.stt.transformers.KafkaToAvroParDo;
import com.google.protobuf.Message;
import com.google.protobuf.util.Durations;
import com.google.protobuf.util.Timestamps;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.metrics.MetricNameFilter;
import org.apache.beam.sdk.metrics.MetricQueryResults;
import org.apache.beam.sdk.metrics.MetricResult;
import org.apache.beam.sdk.metrics.MetricsFilter;
import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.*;
import org.jetbrains.annotations.NotNull;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;

import javax.naming.Context;
import java.util.*;

import static org.checkerframework.checker.units.UnitsTools.s;

public class PubSubToKafkaTest {
    @Rule
    public TestPipeline pipeline = TestPipeline.create();


    public void testProtoToAvroParDoFunction() {
        final TupleTag<TranscriptionMessage.ConversationEvent> DLQ = new TupleTag<TranscriptionMessage.ConversationEvent>() {
        };
        final TupleTag<KV<String, NLPSentimentAndEntityAnalysisTranscriptionOutput>> SUCCESS = new TupleTag<KV<String, NLPSentimentAndEntityAnalysisTranscriptionOutput>>() {
        };

        List<TranscriptionMessage.ConversationEvent> testProtos = new ArrayList<TranscriptionMessage.ConversationEvent>();
        testProtos.add(createProtoRecordInput());
        KV<String, NLPSentimentAndEntityAnalysisTranscriptionOutput> avroLists = KV.of("Test Conversation", createAvroRecord());
        //avroLists.putAll(createAvroRecord());

        PCollection<TranscriptionMessage.ConversationEvent> input = pipeline.apply(Create.of(testProtos));
        PCollectionTuple output = input.apply(ParDo.of(new KafkaToAvroParDo(DLQ, SUCCESS)).withOutputTags(SUCCESS, TupleTagList.of(DLQ)));
        PAssert.that(output.get(SUCCESS)).containsInAnyOrder(avroLists);
        PipelineResult result = pipeline.run();
        result.waitUntilFinish();

        MetricQueryResults metrics =
                result
                        .metrics()
                        .queryMetrics(
                                MetricsFilter.builder()
                                        .addNameFilter(MetricNameFilter.named("NLP-PubsubToKafka", "PUBSUBTOKAFKA_NLP_SUCCESS"))
                                        .addNameFilter(MetricNameFilter.named("NLP-PubsubToKafka", "PUBSUBTOKAFKA_NLP_FAILURE"))
                                        .build());

        for (MetricResult<Long> counter : metrics.getCounters()) {
            System.out.println(counter.getName() + ":" + counter.getAttempted());
        }
    }


    private TranscriptionMessage.ConversationEvent createProtoRecordInput() {
        TranscriptionMessage.ConversationEvent.Builder transcription = TranscriptionMessage.ConversationEvent.newBuilder();
        try {
            transcription.setConversation("Test Conversation");
            transcription.setType(TranscriptionMessage.ConversationEvent.Type.CONVERSATION_STARTED);

            TranscriptionMessage.Message.Builder msg = TranscriptionMessage.Message.newBuilder();
            msg.setLanguageCode("en-US");
            msg.setParticipant("participant");
            msg.setName("project1/message1/");
            msg.setCreateTime(Timestamps.parse("1969-12-31T23:59:59Z"));
            msg.setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");

            TranscriptionMessage.Message.SpeechToTextInfo.Builder s2tInfo = TranscriptionMessage.Message.SpeechToTextInfo.newBuilder();

            s2tInfo.setUtteranceEndOffset(Durations.parse("12345.1s"));
            s2tInfo.setUtteranceStartOffset(Durations.parse("12345.1s"));
            s2tInfo.setStreamStartTime(Timestamps.parse("1969-12-31T23:59:59Z"));

            String content = "Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back";
            String[] txtWords = content.split(" ");
            for (int i = 0; i < txtWords.length; i++) {
                TranscriptionMessage.Message.SpeechWordInfo.Builder wordInfo = TranscriptionMessage.Message.SpeechWordInfo.newBuilder();
                wordInfo.setWord(txtWords[i]).setEndOffset(Durations.parse("12345.1s")).setStartOffset(Durations.parse("12345.1s")).setConfidence(1f);
                s2tInfo.addSpeechWordInfo(wordInfo.build());
            }
            msg.setSpeechToTextInfo(s2tInfo);

            TranscriptionMessage.NLPSentimentAnalysisResponse.Builder sr = TranscriptionMessage.NLPSentimentAnalysisResponse.newBuilder();
            TranscriptionMessage.Document.Builder doc = TranscriptionMessage.Document.newBuilder();
            doc.setScore(-0.3f);
            doc.setMagnitude(0.3f);
            sr.setLanguage("en");
            sr.setDocument(doc.build());
            List<TranscriptionMessage.Sentences> sentencesList = new ArrayList<TranscriptionMessage.Sentences>();
            TranscriptionMessage.Sentences.Builder sentenceTest = TranscriptionMessage.Sentences.newBuilder();
            TranscriptionMessage.Sentences_Sentiment.Builder sentences_sentiment_test = TranscriptionMessage.Sentences_Sentiment.newBuilder();
            TranscriptionMessage.Text.Builder text = TranscriptionMessage.Text.newBuilder();
            sentences_sentiment_test.setScore(-0.3f);
            sentences_sentiment_test.setMagnitude(0.3f);
            text.setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");
            text.setBeginoffset("-1");
            sentenceTest.setSentencesSentiment(sentences_sentiment_test.build());
            sentenceTest.setText(text.build());
            sentencesList.add(sentenceTest.build());
            sr.addAllSentences(sentencesList);
            sr.build();
            msg.setNLPSentimentAnalysisResponse(sr);

            TranscriptionMessage.NLPEntityAnalysisResponse.Builder er = TranscriptionMessage.NLPEntityAnalysisResponse.newBuilder();
            er.setLanguage("en");
            List<TranscriptionMessage.Entities> entitiesList = new ArrayList<TranscriptionMessage.Entities>();
            TranscriptionMessage.Entities.Builder entitiesTest = TranscriptionMessage.Entities.newBuilder();
            TranscriptionMessage.Mentions.Builder mentionsTest = TranscriptionMessage.Mentions.newBuilder();
            TranscriptionMessage.Mentiontext.Builder mention_text = TranscriptionMessage.Mentiontext.newBuilder();
            TranscriptionMessage.Metadata.Builder metadata_text = TranscriptionMessage.Metadata.newBuilder();
            mention_text.setContent("TV Box");
            mention_text.setBeginoffset("27");
            mention_text.build();
            mentionsTest.setText(mention_text);
            mentionsTest.setType("COMMON");
            metadata_text.setValue("20");
            entitiesTest.setName("TV Box");
            entitiesTest.setSalience(0.7559768f);
            entitiesTest.setTypeNlp("OTHER");
            entitiesTest.setMentions(mentionsTest.build());
            entitiesTest.setMetadata(metadata_text.build());
            entitiesList.add(entitiesTest.build());
            er.addAllEntities(entitiesList);
            msg.setNLPEntityAnalysisResponse(er.build());
            msg.setNLPAPIStartTime("12345");
            msg.setWordCount("19");
            transcription.setNewMessagePayload(msg.build());
        } catch (Exception exception) {
            System.out.println("Unable to test" + exception);
        }
        return transcription.build();
    }

    private NLPSentimentAndEntityAnalysisTranscriptionOutput createAvroRecord() {


        com.bell.stt.avro.NLPSentimentAndEntityAnalysisTranscriptionOutput avroOutput = new com.bell.stt.avro.NLPSentimentAndEntityAnalysisTranscriptionOutput();
        try {
            List<com.bell.stt.avro.Transcription> avroRecordList = new ArrayList<com.bell.stt.avro.Transcription>();
            com.bell.stt.avro.Transcription avroRecord =new com.bell.stt.avro.Transcription();
            avroRecord.setConversation("Test Conversation");
            avroRecord.setType("Test type");
            com.bell.stt.avro.NewMessagePayload msg = new com.bell.stt.avro.NewMessagePayload();
            msg.setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");
            msg.setCreateTime(Timestamps.parse("1969-12-31T23:59:59Z").getSeconds());
            msg.setName("project1/message1/");
            msg.setParticipant("participant");
            msg.setUtteranceEndOffset(Durations.parse("12345.1s").getSeconds());
            List<com.bell.stt.avro.Words> avroWordsList = new ArrayList<com.bell.stt.avro.Words>();
            String content = "Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back";
            String[] txtWords = content.split(" ");
            for (int i = 0; i < txtWords.length; i++) {
                com.bell.stt.avro.Words words = new com.bell.stt.avro.Words();
                words.setWord(txtWords[i]);
                words.setConfidence(1f);
                words.setStartOffset(Durations.parse("12345.1s").getSeconds());
                words.setEndOffset(Durations.parse("12345.1s").getSeconds());
                avroWordsList.add(words);
            }
            msg.setWords(avroWordsList);
            msg.setStreamStartTime(Durations.parse("12345.1s").getSeconds());
            msg.setUtteranceEndOffset(Durations.parse("12345.1s").getSeconds());
            msg.setUtteranceStartOffset(Durations.parse("12345.1s").getSeconds());
            avroRecord.setNewMessagePayload(msg);

            avroRecordList.add(avroRecord);

            com.bell.stt.avro.DocumentSentiment ds = new com.bell.stt.avro.DocumentSentiment();
            ds.setScore(0.3f);
            ds.setMagnitude(-03.f);
            List<com.bell.stt.avro.Sentences> ssList = new ArrayList<com.bell.stt.avro.Sentences>();
            com.bell.stt.avro.Sentences ss = new com.bell.stt.avro.Sentences();
            com.bell.stt.avro.Sentiment sentencesSentiment = new com.bell.stt.avro.Sentiment();
            sentencesSentiment.setMagnitude(0.3f);
            sentencesSentiment.setScore(-0.3f);
            com.bell.stt.avro.Text text = new com.bell.stt.avro.Text();
            text.setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");
            text.setBeginOffset(-1);
            ss.setSentiment(sentencesSentiment);
            ss.setText(text);
            ssList.add(ss);

            List<com.bell.stt.avro.Entities> entitiesList = new ArrayList<com.bell.stt.avro.Entities>();
            com.bell.stt.avro.Entities entity = new com.bell.stt.avro.Entities();
            com.bell.stt.avro.Mentions mentions = new com.bell.stt.avro.Mentions();
            mentions.setType("COMMON");
            com.bell.stt.avro.MentionsText mentionsText = new com.bell.stt.avro.MentionsText();
            mentionsText.setContent("TV Box");
            mentionsText.setBeginOffset(27);
            com.bell.stt.avro.Metadata metadataAvro = new com.bell.stt.avro.Metadata();
            metadataAvro.setAreaCode("");
            metadataAvro.setBroadRegion("");
            metadataAvro.setCountry("");
            metadataAvro.setCurrency("");
            metadataAvro.setDay("");
            metadataAvro.setExtension("");
            metadataAvro.setLocality("");
            metadataAvro.setMid("");
            metadataAvro.setMonth("");
            metadataAvro.setNarrowRegion("");
            metadataAvro.setNationalPrefix("");
            metadataAvro.setNumber("");
            metadataAvro.setPhoneNumber("");
            metadataAvro.setPostalCode("");
            metadataAvro.setStreetName("");
            metadataAvro.setStreetNumber("");
            metadataAvro.setSublocality("");
            metadataAvro.setWikipediaUrl("");
            metadataAvro.setYear("");
            metadataAvro.setValue("20");
            entity.setName("TV Box");
            entity.setSalience(0.7559768f);
            entity.setType("OTHER");
            entity.setMentions(mentions);
            entity.setMetadata(metadataAvro);
            entitiesList.add(entity);

            List<com.bell.stt.avro.NLPEntityAnalysis> entityList = new ArrayList<com.bell.stt.avro.NLPEntityAnalysis>();
            com.bell.stt.avro.NLPEntityAnalysis entityAnalysis = new com.bell.stt.avro.NLPEntityAnalysis();
            entityAnalysis.setLanguage("en");
            entityAnalysis.setEntities(entitiesList);
            entityList.add(entityAnalysis);

            List<com.bell.stt.avro.NLPSentimentAnalysis> sentimentList = new ArrayList<com.bell.stt.avro.NLPSentimentAnalysis>();
            com.bell.stt.avro.NLPSentimentAnalysis sentimentAnalysis = new com.bell.stt.avro.NLPSentimentAnalysis();
            sentimentAnalysis.setDocumentSentiment(ds);
            sentimentAnalysis.setLanguage("en");
            sentimentAnalysis.setSentences(ssList);


            com.bell.stt.avro.S2TNLPAPIAnalysisResponse s2TNLPAPIAnalysisResponses = new com.bell.stt.avro.S2TNLPAPIAnalysisResponse();
            s2TNLPAPIAnalysisResponses.setNLPSentimentAnalysis(sentimentAnalysis);
            s2TNLPAPIAnalysisResponses.setNLPEntityAnalysis(entityAnalysis);


            com.bell.stt.avro.NLPconversation nlpConversation = new com.bell.stt.avro.NLPconversation();
            nlpConversation.setConversationID("Test Conversation");
            nlpConversation.setParticipant("participant");
            nlpConversation.setStreamStartTime(Durations.parse("12345.1s").getSeconds());
            nlpConversation.setUtteranceStartOffset(Durations.parse("12345.1s").getSeconds());
            nlpConversation.setNoOfUtterances(1);

            List<com.bell.stt.avro.NLPSentimentAndEntityAnalysisTranscriptionOutput> avroOutputList = new ArrayList<com.bell.stt.avro.NLPSentimentAndEntityAnalysisTranscriptionOutput>();


            avroOutput.setWordCount(19);
            avroOutput.setNLPAPIStartTime(12345l);
            avroOutput.setGCPEndTime(12345l);
            avroOutput.setS2TNLPAPIAnalysisResponse(s2TNLPAPIAnalysisResponses);
            avroOutput.setTranscription(avroRecord);
            avroOutput.setNLPconversation(nlpConversation);
            avroOutputList.add(avroOutput);

        } catch (Exception e) {
            System.out.println("Unable to test" + e);
        }

        return avroOutput;
    }


    @Test
    public void prototoavrotset() {

        NLPSentimentAndEntityAnalysisTranscriptionOutput  avroExpected =this.createAvroRecord();
        TranscriptionMessage.ConversationEvent protoRecord=this.createProtoRecordInput();
        NLPSentimentAndEntityAnalysisTranscriptionOutput avroactual =new ProtoToAvro().convertToAvroManually(protoRecord);

    }

}