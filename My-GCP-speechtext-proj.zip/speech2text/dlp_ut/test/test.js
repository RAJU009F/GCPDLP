const dlp = require('./dlp');

const parentId = process.argv.filter((x) => x.startsWith('--parentId='))[0];
const inspectTemplate = process.argv.filter((x) => x.startsWith('--inspectTemplate='))[0];
const deIdentificationTemplate = process.argv.filter((x) => x.startsWith('--deIdentificationTemplate='))[0];

let metaObj = {
    parentId: parentId && parentId.split('=')[1],
    inspectTemplate: inspectTemplate && inspectTemplate.split('=')[1],
    deIdentificationTemplate: deIdentificationTemplate && deIdentificationTemplate.split('=')[1]
};

test('RULE: MULTI LINE', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "You can find it in the bottom of your cheque, 001225887634" }] },
                { "values": [{ "stringValue": "Can I use it for the bill payment? 4505897655430102" }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("You can find it in the bottom of your cheque, ############");
        expect(data.rows[1].values[0].stringValue).toBe("Can I use it for the bill payment? ################");
    });
});

test('RULE: CUSTOM-RR-01', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "terminator_267" }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("##############");
    });
});

test('RULE: CUSTOM-RR-02 :: CUSTOM-RR-02-01', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "dollar 34567 test 456 dollar amount, 6 calls" }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("dollar ##### test 456 dollar amount, 6 calls");
    });
});

test('RULE: CUSTOM-RR-02 :: CUSTOM-RR-02-02', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "numeric sequence ten digits 6131234564 2231234564" }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("numeric sequence ten digits 6131234564 ##########");
    });
});

test('RULE: CUSTOM-RR-02 :: CUSTOM-RR-02-03', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "numeric sequence eleven digits 18331234564 18221234564" }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("numeric sequence eleven digits 18331234564 ###########");
    });
});

test('RULE: CUSTOM-RR-05', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "test amount $34.56" }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("test amount $34.56");
    });
});

test('RULE: CANADA_BANK_ACCOUNT', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "Canadian bank account number 12345-001-12345678." }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("Canadian bank account number ##################.");
    });
});

test('RULE: CANADA_BC_PHN', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "Personal Health Number 9876-543-214" }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("Personal Health Number ############");
    });
});

test('RULE: CANADA_DRIVERS_LICENSE_NUMBER', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "Driver's licence PO-LL-AJ-M-304PR" }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("Driver's licence ################");
    });
});

test('RULE: CANADA_OHIP', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "Ontario 9876-543-217" }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("Ontario ############");
    });
});

test('RULE: CANADA_PASSPORT', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "Numéro de passeport WJ123456." }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("Numéro de passeport ########.");
    });
});

test('RULE: CREDIT_CARD_NUMBER', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "He paid with 4012-8888-8888-1881." }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("He paid with $$$$$$$$$$$$$$$$$$$.");
    });
});

test('RULE: PASSWORD', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "my password is timothy98" }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("my password is #########");
    });
});

test('RULE: DATE', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "Tony turned 10 on 05/05/2022." }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("Tony turned ## on ##########.");
    });
});

test('RULE: DATE_OF_BIRTH', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "His dob is 05/05/2022." }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("His dob is ##########.");
    });
});

test('RULE: AGE', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "The player turns 32 years old in the fall." }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("The player turns 55 in the fall.");
    });
});

test('RULE: PASSPORT', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "The agency issued US passport number 017384251." }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("The agency issued US passport number #########.");
    });
});

test('RULE: CREDIT_CARD_TRACK_NUMBER', async () => {
    const table = {
        table: {
            headers: [{ "name": 'content' }],
            rows: [
                { "values": [{ "stringValue": "Card track %B4444333322221111^TEST CARD/VISA^4907101?" }] }
            ]
        }
    };
    await dlp(table, metaObj, function (err, data) {
        expect(data.rows[0].values[0].stringValue).toBe("Card track ##########################################$$$$$$$$$$$$$$$$");
    });
});