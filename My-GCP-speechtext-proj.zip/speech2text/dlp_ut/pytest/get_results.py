import google.cloud.dlp
import csv


def deindentify(data, project_id, deidentify_template_id, inspect_template_id):
    headers = [{"name": val} for val in data["header"]]
    rows = []
    for row in data["rows"]:
        rows.append({"values": [{"string_value": cell_val}
                                for cell_val in row]})
    table = {}
    table["headers"] = headers
    table["rows"] = rows
    item = {"table": table}
    dlp = google.cloud.dlp_v2.DlpServiceClient()
    parent = dlp.project_path(project_id)
    deidentify_template = f"projects/{project_id}/deidentifyTemplates/{deidentify_template_id}"
    inspect_template = f"projects/{project_id}/inspectTemplates/{inspect_template_id}"

    response = dlp.deidentify_content(
        parent, deidentify_template_name=deidentify_template, inspect_template_name=inspect_template, item=item)
    return response


cases = []
title = []
with open('./testcases.csv', "r") as file:
    for line in file:
        cases.append(line.rstrip())

deidentify_template_id = "CUSTOM_DEID_RULES"
inspect_template_id = "CUSTOM_MASKING_RULES"
project = "itcx-bi-ccast-dev-01"

with open("output.csv", 'w') as outfile:
    for case in cases:
        if case.startswith("#"):
            outfile.write("\n" + case + "\n")
        else:
            data = {
                "header": [
                    "Value"
                ],
                "rows": [[case]]
            }
            response = deindentify(
                data, project, deidentify_template_id, inspect_template_id)
            i = 0
            for r in response.item.table.rows:
                print(r.values[0].string_value)
                outfile.write(case+" | "+r.values[0].string_value + "\n")
                i = i+1
