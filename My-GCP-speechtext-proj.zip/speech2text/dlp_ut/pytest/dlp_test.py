from pytest import mark
import google.cloud.dlp


@mark.smoke
class DeIdentifyDLPTest:
    @classmethod
    def setup_class(self):
        self.deidentify_template_id = "S2T_CUSTOM_DEID_RULES"
        self.inspect_template_id = "S2T_CUSTOM_INSPECT_RULES"

    def test_deIdentification_For_Currency(self, project):
        data = {
            "header": [
                "Value"
            ],
            "rows": [
                ["terminator_267"],
                ["The player turns 32 years old in the fall."],
                ["numeric sequence eleven digits 18331234564 18221234564"],
                ["Personal Health Number 9876-543-214s"],
                ["456 dollars and 6 call 123 transaction"],
                ["456 débâcle and 8 réussite and 234 centimètre"],
                ["it is 001 dash 22 dash 5887634"],
                ["well I record 3 to 4 shows every week day"],
                ["56 dollars for just 2 mb?"],
                ["are you sure I used  260 long distance minutes?"],
                ["My card is 4514011812960281, is it ok?"],
                ["245f 234 yes that is 24 25 245k"],
                ["we 2123 let`s do it"],
                ["it is 2144 right?"],
				["your bill is $23.34"],
				["your bill is $12,223.34"],
				["my credit card number is 4519025305017090"],
				["my credit card number is 4519-0253-0501-7090"],				
				["my cvs is 345"],
				["20"]
            ]
        }
        exected_output = [
            "##############",
            "The player turns 45 in the fall.",
            "numeric sequence eleven digits 18331234564 ###########",
            "Personal Health Number #############",
            "456 dollars and 6 call 123 transaction",
            "456 débâcle and 8 réussite and 234 centimètre",
            "it is ### dash ## dash #######",
            "well I record # to # shows every week day",
            "56 dollars for just # mb?",
            "are you sure I used  ### long distance minutes?",
            "My card is ################, is it ok?",
            "#### ### yes that is ## ## ####",
            "we #### let`s do it",
            "it is #### right?",
			"your bill is $23.34",
			"your bill is $12,223.34",
			"my credit card number is ################",
			"my credit card number is ###################",
			"my cvs is ###",
			"##"
        ]
        response = self.deindentify(
            data, project, self.deidentify_template_id, self.inspect_template_id)
        i = 0
        for r in response.item.table.rows:
            assert r.values[0].string_value == exected_output[i]
            print(r.values[0].string_value)
            print(exected_output[i])

            i = i + 1

    def deindentify(self, data, project_id, deidentify_template_id, inspect_template_id):
        headers = [{"name": val} for val in data["header"]]
        rows = []
        for row in data["rows"]:
            rows.append(
                {"values": [{"string_value": cell_val} for cell_val in row]})
        table = {}
        table["headers"] = headers
        table["rows"] = rows
        item = {"table": table}
        dlp = google.cloud.dlp_v2.DlpServiceClient()
        #parent = dlp.project_path(project_id)
		#parent = dlp.location_path(project_id, "northamerica-northeast1")
        deidentify_template = f"projects/{project_id}/locations/northamerica-northeast1/deidentifyTemplates/{deidentify_template_id}"
        inspect_template = f"projects/{project_id}/locations/northamerica-northeast1/inspectTemplates/{inspect_template_id}"

        response = dlp.deidentify_content(
            parent="projects/"+project_id+"/locations/northamerica-northeast1", deidentify_template_name=deidentify_template, inspect_template_name=inspect_template, item=item)
        return response
