/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.CallContexttoBQ.dataflow.transforms;



import com.bell.CallContexttoBQ.dataflow.util.BQTableRow;
import com.bell.stt.proto.ContextOuterClass;
import com.google.api.services.bigquery.model.TableRow;
import com.google.protobuf.Duration;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.beam.sdk.metrics.Distribution;
import org.apache.beam.sdk.metrics.Metrics;

/**
 * This BQ pardo function will do the transformation from event to table row.
 */

public class BQParDo extends DoFn<ContextOuterClass.Context,TableRow> {

    static final Logger LOG = LoggerFactory.getLogger(BQParDo.class);
    private final Counter Success_counter = Metrics.counter("CALLCONTEXT-PubsubToBigquery", "PUBSUBTOBIGQUERY_CALLCONTEXT_SUCCESS");
    private final Counter failure_counter = Metrics.counter("CALLCONTEXT-PubsubToBigquery", "PUBSUBTOBIGQUERY_CALLCONTEXT_FAILURE");

    final TupleTag<ContextOuterClass.Context> DLQ;
    final TupleTag<TableRow> SUCCESS;

    public BQParDo(TupleTag<ContextOuterClass.Context> DLQ, TupleTag<TableRow> SUCCESS) {
        this.DLQ = DLQ;
        this.SUCCESS = SUCCESS;
    }


    @ProcessElement
    public void processElement(ProcessContext c,MultiOutputReceiver out) {

        ContextOuterClass.Context event = c.element();

        String eventType =event.getEventType().toString();
        String acdId =event.getAcdId();
        String uui = event.getUui();
        String ucid =  event.getUcid();
        String callId = event.getCallId();
        String agentLoginId = event.getAgentLoginId();
        String agentExtension = event.getAgentExtension();
        com.google.protobuf.Timestamp eventTimeStamp =event.getEventTimeStamp();
        long contextStartTime = System.currentTimeMillis();
        try{
            long startTime= System.currentTimeMillis();
            log("The BQPardo calling for  callcontext :", eventType, acdId, uui, eventTimeStamp, ucid, callId, agentLoginId, agentExtension,"Start Time ", contextStartTime);

             TableRow table =BQTableRow.buildTableRows(event,System.currentTimeMillis());

              c.output(SUCCESS,table) ;

            long endTime= System.currentTimeMillis();
            log("The BQPardo calling successfully completed for  callcontext :",eventType, acdId, uui, eventTimeStamp, ucid, callId, agentLoginId, agentExtension,"Time taken ", (endTime-contextStartTime));

            Success_counter.inc();

    } catch (Exception e) {
	    System.out.println("==================="+e.getMessage());
	    e.printStackTrace();
            LOG.error("ERRCALLCONTEXT102 - Unable to Write into BigQuery and publish the failed message into DLQ topics"
                    + " eventType: " + eventType + ", acdId: " + acdId +
                    ", uui: " + uui + ", eventTimeStamp: " + eventTimeStamp +
                    ", ucid: " + ucid + ", callId: "
                    + callId + ", agentLoginId: " + agentLoginId + ", agentExtension: "
                    + agentExtension+e.getMessage().toString());
        c.output(DLQ,c.element());
            failure_counter.inc();

        }
    }
//eventType, acdId, uui, eventTimeStamp, ucid, callId, agentLoginId, agentExtension,
    private void log(String prefix,
                     String eventType, String acdId,
                     String uui, com.google.protobuf.Timestamp eventTimeStamp,
                     String ucid, String callId, String agentLoginId, String agentExtension, String time , long timeTakenMs) {

        String logMessage=prefix + " eventType: " + eventType + ", acdId: " + acdId +
                ", uui: " + uui + ", eventTimeStamp: " + eventTimeStamp +
                ", ucid: " + ucid + ", callId: "
                + callId + ", agentLoginId: " + agentLoginId + ", agentExtension: "
                + agentExtension +  ", "+time + timeTakenMs+"ms";

        LOG.debug(logMessage.replace("\r","").replace("\n",""));
    }

}

