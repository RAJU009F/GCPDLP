/*
 * Copyright (C) 2018 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package com.bell.stt.dataflow;

import com.bell.stt.dataflow.options.Options;
import com.bell.stt.dataflow.transformers.PartitionParDo;
import com.bell.stt.dataflow.transformers.DLPParDo;
import com.bell.stt.dataflow.transformers.PubSubToParDo;
import com.bell.stt.proto.TranscriptionMessage.*;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.metrics.*;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.SimpleFunction;
import org.apache.beam.sdk.transforms.Values;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Random;
import java.util.UUID;


public class PubsubToPubsub {
    /**
     * Main entry point for executing the pipeline.
     *
     * @param args The command-line arguments to the pipeline.
     */
    private static final Logger LOG = LoggerFactory.getLogger(PubsubToPubsub.class);

    public static void main(String[] args) {
        // Parse the user options passed from the command-line
        final String METRIC_NAMESPACE = "STT-PubsubToPubsub";
        Options options = PipelineOptionsFactory.fromArgs(args).withValidation().as(Options.class);
        options.setStreaming(true);
        PipelineResult result = run(options);
        //result.waitUntilFinish();
        MetricQueryResults metrics =
                result
                        .metrics()
                        .queryMetrics(
                                MetricsFilter.builder()
                                        .addNameFilter(MetricNameFilter.named(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_STT_BAGSTATE"))
                                        .addNameFilter(MetricNameFilter.named(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_STT_NUMBER_OF_ROWS_TOKENIZED_DISTRO"))
                                        .addNameFilter(MetricNameFilter.named(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_STT_TIMER"))
                                        .addNameFilter(MetricNameFilter.named(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_STT_NUMBER_OF_BYTES_TOKENIZED_DISTRO"))
                                        .addNameFilter(MetricNameFilter.named(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_STT_BATCH_FLUSH_COUNTER"))
                                        .build());
    }

    /**
     * Runs the pipeline with the supplied options.
     * Below is the sequence of operations
     * 1. Read from pubsub and convert into transcription objects.
     * 2. Batch the transcription objects
     * 3. Trigger the batch based on the timer
     * 4. Send request to DLP
     * 5. Capture the redacted response from DLP and merge with the input.
     * 6. Write to pubsub with the redacted output
     *
     * @param options The execution parameters to the pipeline.
     * @return The result of the pipeline execution.
     */
    public static PipelineResult run(Options options) {
        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);

        try{
            PCollection<ConversationEvent> pubsubMessageRedacted = pipeline
                    .apply(PubsubIO.readProtos(ConversationEvent.class)
                            .fromSubscription(options.getInputSubscription()));
            PCollection<KV<String, ConversationEvent>> pKVals = pubsubMessageRedacted
                    .apply("Partition for batching", ParDo.of(new PartitionParDo(options.getBatchNum().get())))

    //                .apply(MapElements.via(new SimpleFunction<ConversationEvent, KV<String, ConversationEvent>>() {
    //                                           @Override
    //                                           public KV<String, ConversationEvent> apply(ConversationEvent input) {
    //                                               KV<String, ConversationEvent> kv = KV.of(String.valueOf((new Random()).nextInt(options.getBatchNum().get())), input);
    //                                               return kv;
    //                                           }
    //                                       }
    //                ))

                    .apply("Batching for DLP", ParDo.of(new PubSubToParDo(options.getTimer().get(),options.getBatchSize().get())))
                    .apply("Redacting in DLP", ParDo.of(new DLPParDo(options.getDLPProjectId(), options.getIdentifyTemplateName(), options.getInspectTemplateName(), options.getDLPBatchSizeThreshold())));
            PCollection<ConversationEvent> pVals = pKVals.apply(Values.create());
            pVals.apply("Write PubSub Events", PubsubIO.writeProtos(ConversationEvent.class).to(options.getOutputTopic()));
            // Execute the pipeline and return the result.
        } catch (Exception e) {
            LOG.error("S2T-ERR101 - Error processing the pipeline", e);
        }
        return pipeline.run();
    }
}