package com.bell.stt.dataflow.transformers;

import com.bell.stt.proto.TranscriptionMessage.*;
import com.google.common.base.MoreObjects;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.state.*;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * <h1>The ParDo class</h1>
 * The class is responsible for batching the transcription inputs and emitting to
 * the output as an iterable.
 */
public class PubSubToParDo extends DoFn<KV<String, ConversationEvent>, KV<String, List<ConversationEvent>>> {
    private static final Logger LOG = LoggerFactory.getLogger(PubSubToParDo.class);
    private static final String METRICS_NAMESPACE = "STT-PubsubToPubsub";

    @StateId("state")
    private final StateSpec<BagState<KV<String, ConversationEvent>>> transciptionElements = StateSpecs.bag();
    @StateId("batchCounter")
    private final StateSpec<ValueState<Integer>> batchCounter =StateSpecs.value();
    @StateId("isTimerSet")
    private final StateSpec<ValueState<Boolean>> isTimerSet = StateSpecs.value();
    private final Long timerValueToEmitBatch;
    private final Integer batchSize;
    private final Counter bagCounter = Metrics.counter(METRICS_NAMESPACE, "PUBSUBTOPUBSUB_STT_BAGSTATE");
    private final Counter batchFlushCounter = Metrics.counter(METRICS_NAMESPACE, "PUBSUBTOPUBSUB_STT_BATCH_FLUSH_COUNTER");
    private final Counter timerCounter = Metrics.counter(METRICS_NAMESPACE, "PUBSUBTOPUBSUB_STT_TIMER");

    public PubSubToParDo(Long timerValueToEmitBatch,Integer batchSize) {
        this.timerValueToEmitBatch = timerValueToEmitBatch;
        this.batchSize=batchSize;
    }

    // The processing-time timer user to publish the DLP.
    @TimerId("outputState")
    private final TimerSpec timer = TimerSpecs.timer(TimeDomain.PROCESSING_TIME);

    /**
     * The process element method batches the transcription inputs
     * in a bag state.
     *
     * @param transcriptionElement
     * @param elementsState
     * @param isTimerSetState
     * @param timer
     */

    @ProcessElement
    public void process(ProcessContext context,@Element KV<String, ConversationEvent> transcriptionElement,
                        @StateId("batchCounter") ValueState<Integer> batchCounter,
                        @StateId("state") BagState<KV<String, ConversationEvent>> elementsState,
                        @StateId("isTimerSet") ValueState<Boolean> isTimerSetState,
                        @TimerId("outputState") Timer timer) {

        try {
            int batchCounterValue = MoreObjects.firstNonNull(batchCounter.read(), 0) + 1;
            //int batchCounterValue = Optional.ofNullable(batchCounter.read()).orElse(0);

            //!MoreObjects.firstNonNull(isTimerSetState.read(), false)
            if (batchCounterValue == 1) {
                timer.offset(Duration.standardSeconds(timerValueToEmitBatch)).setRelative();
                isTimerSetState.write(true);
            }

            batchCounter.write(batchCounterValue);
            elementsState.add(transcriptionElement);

            if (batchCounterValue >= batchSize) {
                List<ConversationEvent> trows = flushElementState(elementsState.read());
                context.output(KV.of(UUID.randomUUID().toString(), trows));
                elementsState.clear();
                isTimerSetState.clear();
                batchCounter.clear();
                batchFlushCounter.inc();
            }
            bagCounter.inc();
        }
        catch (Exception e){
            LOG.error("S2T-ERR104 - Unable to batch input", e);
        }
    }

    /**
     * The timer method triggers after every X seconds.
     * X is the number specified while launching the data flow job.
     *
     * @param context
     * @param elementsState
     * @param isTimerSetState
     */

    @OnTimer("outputState")
    public void onTimer(OnTimerContext context,
                        @StateId("state") BagState<KV<String, ConversationEvent>> elementsState,
                        @StateId("isTimerSet") ValueState<Boolean> isTimerSetState,@StateId("batchCounter") ValueState<Integer> batchCounter) {
        List<ConversationEvent> trows = flushElementState(elementsState.read());
        context.output(KV.of(UUID.randomUUID().toString(), trows));
        elementsState.clear();
        isTimerSetState.clear();
        batchCounter.clear();
        timerCounter.inc();
    }

    private  List<ConversationEvent> flushElementState(Iterable<KV<String, ConversationEvent>> elementsState){
        List<ConversationEvent> trows = new ArrayList<>();
        elementsState.forEach(element -> trows.add(element.getValue()));
        return trows;
    }
}
