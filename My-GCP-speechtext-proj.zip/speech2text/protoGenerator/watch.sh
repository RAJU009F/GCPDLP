#!/bin/bash
env=$1
if [ ${env} == "dev" ]; then

echo "running dev mock producer"

while(true); do
  OUTPUT=`java -cp target/ProtoGenerator-0.1.jar com.bell.stt.dataflow.TranscriptionGenerator --runner=DirectRunner --tempLocation=gs://itcx-bi-ccast-dev-01-dataflow-temp-bucket/temp --region=northamerica-northeast1 --stagingLocation=gs://itcx-bi-ccast-dev-01-dataflow-temp-bucket/temp --serviceAccount=master-svc-dev@itcx-bi-ccast-dev-01.iam.gserviceaccount.com --usePublicIps=false --subnetwork=https://www.googleapis.com/compute/alpha/projects/hyc-shrd-svc-01/regions/northamerica-northeast1/subnetworks/itcx-bi-ccast-svc-subnet-dev --projectId=itcx-bi-ccast-dev-01 --outputTopic=projects/itcx-bi-ccast-dev-01/topics/dev-s2t-raw-transcription-topic --inputFile="C:\Users\xiaolshi\IdeaProjects\s2t\speech2text\ProtoGenerator\src\main\resources\text\testTrans.csv"`
  clear
  echo -e "${OUTPUT[@]}"
  sleep 2
done

fi


if [ ${env} == "uat" ]; then

echo "running uat mock producer"

while(true); do
  OUTPUT=`java -cp target/ProtoGenerator-0.1.jar com.bell.stt.dataflow.TranscriptionGenerator --runner=DirectRunner --tempLocation=gs://uat-s2t-producer-bucket/temp --region=northamerica-northeast1 --stagingLocation=gs://uat-s2t-producer-bucket/temp --serviceAccount=uat-s2t-pubsub-mock-producer@itcx-bi-ccast-uat-01.iam.gserviceaccount.com --usePublicIps=false --subnetwork=https://www.googleapis.com/compute/alpha/projects/hyc-shrd-svc-01/regions/northamerica-northeast1/subnetworks/itcx-bi-ccast-svc-subnet-uat --project=itcx-bi-ccast-uat-01 --outputTopic=projects/itcx-bi-ccast-uat-01/topics/uat-s2t-raw-transcription-topic --inputFile="C:\Users\xiaolshi\IdeaProjects\s2t\speech2text\ProtoGenerator\src\main\resources\text\testTrans.csv"`
  clear
  echo -e "${OUTPUT[@]}"
  sleep 3
done

fi
