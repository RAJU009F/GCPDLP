package com.bell.stt.dataflow.Transformer;

import com.google.protobuf.Any;
import com.google.protobuf.ByteString;
import com.google.protobuf.util.Durations;
import com.google.protobuf.util.Timestamps;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.bell.stt.proto.TranscriptionMessage.*;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;


public class TranscriptionTransformer extends DoFn<String, ConversationEvent> {

    private ConversationEvent createProtoRecord(String id, String type,
                                                                    String content, String participant,
                                                                    String st, long soff, long eoff) {
        ConversationEvent.Builder transcription = ConversationEvent.newBuilder();

        try{
            transcription.setConversation(id);
            transcription.setType(ConversationEvent.Type.CONVERSATION_STARTED);

            Message.Builder msg = Message.newBuilder();
            msg.setContent(content);

//            Message.Sentiment.Builder senti = Message.Sentiment.newBuilder();
//            senti.setMagnitude(1f);
//            senti.setScore(1f);
//            Message.SentimentAnalysisResult.Builder sa = Message.SentimentAnalysisResult.newBuilder();
//            sa.setQueryTextSentiment(senti.build());
//            Message.AnnotatedMessagePart.Builder am = Message.AnnotatedMessagePart.newBuilder();
//            am.setEntityType("EntityX");
//            am.setText("TextX");
//            Message.MessageAnnotation.Builder ma = Message.MessageAnnotation.newBuilder();
//            ma.addParts(am.build());
//            ma.setContainEntities(true);
//            msg.setSentimentAnalysis(sa.build());
//            msg.setMessageAnnotation(ma.build());


            msg.setLanguageCode("en-US");
            msg.setParticipant(participant);
            msg.setParticipantRole(Role.END_USER);
            msg.setName("project1/message1/X");
            msg.setCreateTime(Timestamps.parse(st));

            Message.SpeechToTextInfo.Builder s2tInfo = Message.SpeechToTextInfo.newBuilder();

            s2tInfo.setUtteranceStartOffset(Durations.fromMillis(soff));
            s2tInfo.setUtteranceEndOffset(Durations.fromMillis(eoff));
            s2tInfo.setStreamStartTime(Timestamps.parse(st));


            String[] txtWords = content.split(" ");
            for (int i = 0; i < txtWords.length; i++) {
                Message.SpeechWordInfo.Builder wordInfo = Message.SpeechWordInfo.newBuilder();
                Random r = new Random();
                float random = 0.5f + r.nextFloat() * 0.5f;
                wordInfo.setWord(txtWords[i]).setEndOffset(Durations.fromMillis(3000)).setStartOffset(Durations.fromMillis(3000)).setConfidence(random);
                s2tInfo.addSpeechWordInfo(wordInfo.build());
            }
            msg.setSpeechToTextInfo(s2tInfo);

            transcription.setNewMessagePayload(msg.build());
        }catch(Exception e){
            e.printStackTrace();
        }


        return transcription.build();
    }


    @ProcessElement
    public void processElement(ProcessContext c) {
        try {

            String t = c.element();
            String[] values = t.split(",", -1);

            String id = values[0];
            String type = values[1];

            String content;
            String participant;
            String st = values[4];
            long soff;
            long eoff;


            if(!type.equals("NEW_MESSAGE")){
                content = "";
                participant = "";
                soff = 0L;
                eoff = 0L;
            }
            else{
                content = values[2];
                participant = values[3];
                soff = Long.parseLong(values[5]);
                eoff = Long.parseLong(values[6]);
            }

            ConversationEvent pt = createProtoRecord(id,type,content,participant,st,soff,eoff);
            System.out.print(pt.toString());
            c.output(pt);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

