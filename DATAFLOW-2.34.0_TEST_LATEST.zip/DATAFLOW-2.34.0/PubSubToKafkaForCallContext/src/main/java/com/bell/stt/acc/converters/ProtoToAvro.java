package com.bell.stt.acc.converters;

import com.bell.stt.proto.ContextOuterClass;
import com.google.protobuf.util.Timestamps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

/**
 * Class converts the Context in proto format to Context in Avro format
 */
public class ProtoToAvro {


    private static final Logger LOG = LoggerFactory.getLogger(ProtoToAvro.class);

    /**
     * Method converts the proto to Avro payload
     * @param payload incoming context payload in proto format
     * @return Context data in Avro format
     * @throws Exception received when converting proto to avro
     */
    public static com.bell.stt.avro.Context convertToAvroManually(ContextOuterClass.Context payload) throws Exception {

        com.bell.stt.avro.Context.Builder avroRecord = com.bell.stt.avro.Context.newBuilder();
        avroRecord.setUcid(payload.getUcid());
        avroRecord.setEventType(payload.getEventType().name());
        try {
            avroRecord.setCallid(payload.getCallId());
            avroRecord.setEventTimeStamp(Timestamps.toMillis(payload.getEventTimeStamp()));
            avroRecord.setUui(payload.getUui());
            avroRecord.setAcdid(payload.getAcdId());
            avroRecord.setAgentExtension(payload.getAgentExtension());
            avroRecord.setAgentLoginId(payload.getAgentLoginId());
            if (payload.getExtraContextInfo() != null) {
                com.bell.stt.avro.ExtraContextInfo cxinfo = new com.bell.stt.avro.ExtraContextInfo();
                cxinfo.setValue(Optional.ofNullable(payload.getExtraContextInfo().getValue()).orElse("empty"));
                cxinfo.setKey(Optional.ofNullable(payload.getExtraContextInfo().getKey()).orElse("empty"));
                avroRecord.setExtraContextInfo(cxinfo);
            }
        }
        catch (Exception e){
            LOG.error("S2T-ERR306 - Unable to convert context proto to avro. ", e);
        }
        return avroRecord.build();
    }

}
