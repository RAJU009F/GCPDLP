package com.bell.stt.acc.options;

import org.apache.beam.sdk.options.*;

public interface AvayaCallContextOptions extends PipelineOptions, StreamingOptions {
    @Description(
            "The Cloud Pub/Sub subscription to consume from. "
                    + "The name should be in the format of "
                    + "projects/<project-id>/subscriptions/<subscription-name>.")
    @Validation.Required
    ValueProvider<String> getInputSubscription();

    void setInputSubscription(ValueProvider<String> inputSubscription);

    @Description("Pub/Sub topic to read the input from")
    ValueProvider<String> getInputTopic();

    void setInputTopic(ValueProvider<String> value);

    @Description("Kafka Bootstrap Servers")
    ValueProvider<String> getBootstrapServers();

    void setBootstrapServers(ValueProvider<String> value);

    @Description("Kafka topic to write the output")
    ValueProvider<String> getOutputTopic();

    void setOutputTopic(ValueProvider<String> value);

    @Description("The kerb5 configuration in secret Manager")
    ValueProvider<String> getKrb5ConfNameInSecretManager();

    void setKrb5ConfNameInSecretManager(ValueProvider<String> value);

    //getProjectIdForSecret

    @Description("Project Id of the secret manager")
    ValueProvider<String> getProjectIdForSecret();

    void setProjectIdForSecret(ValueProvider<String> value);

    @Description("secret Id for the trust store")
    ValueProvider<String> getTrustStoreNameInSecretManager();

    void setTrustStoreNameInSecretManager(ValueProvider<String> value);

    @Description("secret Id for the kerberos keytab name")
    ValueProvider<String> getKeytabNameInSecretManager();

    void setKeytabNameInSecretManager(ValueProvider<String> value);

    @Description("secret Id for the trust store password")
    ValueProvider<String> getTrustStorePasswordInSecretManager();

    void setTrustStorePasswordInSecretManager(ValueProvider<String> value);

    @Description("The kerberos principal")
    ValueProvider<String> getPrincipal();

    void setPrincipal(ValueProvider<String> value);

    @Description("The kafka service Name")
    ValueProvider<String> getKafkaServiceName();

    void setKafkaServiceName(ValueProvider<String> value);

    @Description("MSK Schema Registry URL")
    ValueProvider<String> getschemaRegistryUrl();

    void setschemaRegistryUrl(ValueProvider<String> value);

    @Description("MSK Protocol")
    ValueProvider<String> getSecurityProtocol();

    void setSecurityProtocol(ValueProvider<String> value);

}

