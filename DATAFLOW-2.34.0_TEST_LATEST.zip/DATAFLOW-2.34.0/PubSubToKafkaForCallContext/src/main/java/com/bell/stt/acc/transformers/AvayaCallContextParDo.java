package com.bell.stt.acc.transformers;

import com.bell.stt.avro.Context;
import com.bell.stt.acc.converters.ProtoToAvro;
import com.bell.stt.proto.ContextOuterClass;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The class is responsible for converting the call context in proto format to
 * Key value pair of call Id , Avro format of context.
 */
public class AvayaCallContextParDo extends DoFn<ContextOuterClass.Context, KV<String, Context>> {

    private static final Logger LOG = LoggerFactory.getLogger(AvayaCallContextParDo.class);
    private final Counter Success_counter = Metrics.counter("STT-AvayaPubsubToKafka", "PUBSUBTOKAFKA_STT_SUCCESS");
    private final Counter failure_counter = Metrics.counter("STT-AvayaPubsubToKafka", "PUBSUBTOKAFKA_STT_FAILURE");

    /**
     * The method converts each proto to avro and writes to output
     * in the key value format.
     * key - call Id
     * value - Context in Avro format
     * @param c - Incoming data
     */
    @ProcessElement
    public void processElement(ProcessContext c) {
        try {
            c.output(KV.of(c.element().getUcid(), ProtoToAvro.convertToAvroManually(c.element())));
            Success_counter.inc();
        } catch (Exception e) {
            LOG.error("S2T-ERR302 - Unable to publish call context to Kafka: "+c.element().getUcid() + "-" +c.element().getEventType(), e);
            failure_counter.inc();
        }
    }
}
