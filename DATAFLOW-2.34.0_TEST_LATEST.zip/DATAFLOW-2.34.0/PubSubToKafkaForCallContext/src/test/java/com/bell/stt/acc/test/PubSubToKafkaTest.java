package com.bell.stt.acc.test;
import com.google.protobuf.util.Timestamps;

import com.bell.stt.proto.ContextOuterClass;
import com.bell.stt.acc.transformers.AvayaCallContextParDo;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.metrics.MetricNameFilter;
import org.apache.beam.sdk.metrics.MetricQueryResults;
import org.apache.beam.sdk.metrics.MetricResult;
import org.apache.beam.sdk.metrics.MetricsFilter;
import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PubSubToKafkaTest {
    @Rule
    public TestPipeline pipeline = TestPipeline.create();

    @Test
    public void testProtoToAvroParDoFunction() {
        long time = System.currentTimeMillis();
        List<ContextOuterClass.Context> testProtos = new ArrayList<ContextOuterClass.Context>();
        testProtos.add(createProtoRecord(11,time));
        Map<String,com.bell.stt.avro.Context> avroLists = new HashMap<>();
        avroLists.putAll(createAvroRecord(11, time));

        PCollection<ContextOuterClass.Context> input = pipeline.apply(Create.of(testProtos));

        PCollection<KV<String,com.bell.stt.avro.Context>> output = input.apply(ParDo.of(new AvayaCallContextParDo()));


        PAssert.thatMap(output).isEqualTo(avroLists);
        PipelineResult result = pipeline.run();
        result.waitUntilFinish();

        MetricQueryResults metrics =
                result
                        .metrics()
                        .queryMetrics(
                                MetricsFilter.builder()
                                        .addNameFilter(MetricNameFilter.named("STT-AvayaPubsubToKafka", "PUBSUBTOKAFKA_STT_SUCCESS"))
                                        .addNameFilter(MetricNameFilter.named("STT-AvayaPubsubToKafka", "PUBSUBTOKAFKA_STT_FAILURE"))
                                        .build());

        for (MetricResult<Long> counter : metrics.getCounters()) {
            System.out.println(counter.getName() + ":" + counter.getAttempted());
        }

    }


    private ContextOuterClass.Context createProtoRecord(int i, long time) {

        ContextOuterClass.Context.Builder cinfo = ContextOuterClass.Context.newBuilder();
        cinfo.setCallId("Call ID " + i);
        cinfo.setEventTimeStamp(Timestamps.fromMillis(time));
        cinfo.setEventType(ContextOuterClass.Context.EventType.AGENT_DROPPED);
        cinfo.setUcid("Test UcId " + i);
        cinfo.setUui("Test UUI " + i);
        cinfo.setAcdId("Test Ac " + i);
        cinfo.setAgentLoginId("Test Agent Login " + i);
        cinfo.setAgentExtension("Test Agent Extension " + i);
        ContextOuterClass.Context.ExtraContextInfo.Builder ecinfo = ContextOuterClass.Context.ExtraContextInfo.newBuilder();
        ecinfo.setKey("Test-key "+i);
        ecinfo.setValue("Test-value "+i);
        cinfo.setExtraContextInfo(ecinfo.build());
        return cinfo.build();
    }


    private Map<String,com.bell.stt.avro.Context> createAvroRecord(int i, long time) {
        Map<String,com.bell.stt.avro.Context> map = new HashMap<>();
        com.bell.stt.avro.Context.Builder avroRecord = com.bell.stt.avro.Context.newBuilder();
        avroRecord.setCallid("Call ID " + i);
        avroRecord.setEventTimeStamp(time);
        avroRecord.setEventType("AGENT_DROPPED");
        avroRecord.setUcid("Test UcId " + i);
        avroRecord.setUui("Test UUI " + i);
        avroRecord.setAcdid("Test Ac " + i);
        avroRecord.setAgentLoginId("Test Agent Login " + i);
        avroRecord.setAgentExtension("Test Agent Extension " + i);
        com.bell.stt.avro.ExtraContextInfo ecinfo = new com.bell.stt.avro.ExtraContextInfo();
        ecinfo.setKey("Test-key "+i);
        ecinfo.setValue("Test-value "+i);
        avroRecord.setExtraContextInfo(ecinfo);
        map.put("Test UcId " + i,avroRecord.build());
        return map;
    }
}
