/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.dataflow.options;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.options.*;

    public interface LabelOptions extends PipelineOptions, StreamingOptions, DataflowPipelineOptions  {

        @Description(
                "The Cloud Pub/Sub subscription to consume from. "
                        + "The name should be in the format of "
                        + "projects/<project-id>/subscriptions/<subscription-name>.")
        //@Validation.Required
            ValueProvider<String> getInputSubscription ();
            void setInputSubscription (ValueProvider < String > inputSubscription);


        @Description(
                "The Cloud Pub/Sub topic to publish to. "
                        + "The name should be in the format of "
                        + "projects/<project-id>/topics/<topic-name>.")
        //@Validation.Required
        ValueProvider<String> getOutputTopic();

        void setOutputTopic(ValueProvider<String> outputTopic);

        @Description(
                "The Cloud Pub/Sub topic to publish to. "
                        + "The name should be in the format of "
                        + "projects/<project-id>/topics/<topic-name>.")
        //@Validation.Required
        ValueProvider<String> getDeadLetterTopic();

        void setDeadLetterTopic(ValueProvider<String> deadLetterTopic);


        // @Description(
        //         "This the sentiment word count"
        // )
        // //@Validation.Required
        // ValueProvider<Integer> getMinSentimentWordCount();

        // void setMinSentimentWordCount(ValueProvider<Integer> minSentimentWordCount);


        // @Description(
        //         "The method to call Analyze Sentiment")
        // //@Validation.Required
        // ValueProvider<Boolean> getAnalyzeSentiment();

        // void setAnalyzeSentiment(ValueProvider<Boolean> analyzeSentiment);

        // @Description(
        //         "This is the sentiment word count"
        // )
        // //@Validation.Required
        // ValueProvider<Integer> getMinEntitiesWordCount();

        // void setMinEntitiesWordCount(ValueProvider<Integer> minEntitiesWordCount);


        // @Description(
        //         "The method to call Analyze Sentiment")
        // //@Validation.Required

        // ValueProvider<Boolean> getAnalyzeEntities();

        // void setAnalyzeEntities(ValueProvider<Boolean> analyzeEntities);

        // @Description(
        //         "The method to call LABEL API according to the language")
        //     //@Validation.Required

        // ValueProvider<String> getLanguage();

        // void setLanguage(ValueProvider<String> language);

        @Validation.Required
        ValueProvider<String> getBucketName();
        void setBucketName(ValueProvider<String> bucketName);

        @Validation.Required
        ValueProvider<String> getConfigFileName();
        void setConfigFileName(ValueProvider<String> configFileName);

    }