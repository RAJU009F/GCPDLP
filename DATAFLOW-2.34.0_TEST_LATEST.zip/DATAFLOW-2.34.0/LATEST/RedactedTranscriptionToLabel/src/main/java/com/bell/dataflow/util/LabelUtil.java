/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.dataflow.util;

import com.bell.dataflow.model.LoggerModel;
import com.bell.stt.proto.TranscriptionMessage;
import com.google.cloud.language.v1.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.cloud.language.v1.Sentence;
import java.util.Map;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
/**
 *This Util class is responsible for the Following 3 methods.
 * a. Word count of the given content
 * b. The Label sentiment method to get the Sentiment Response.
 * c. The Label Entities method to get the Entities Response
 */


public class LabelUtil {

    /**
     * The UtteranceCount will calculate the counts of words in the Contents
     */

    static final Logger LOG = LoggerFactory.getLogger(LabelUtil.class);

    public static int UtteranceWordCount(TranscriptionMessage.ConversationEvent event) {
        String content =event.getNewMessagePayloadOrBuilder().getContent();
        if (content== null || content.isEmpty()) {
            return 0;
        }
        String[] words = content.split("\\s+");
        return words.length;
    }

    /**
     * It will Return the Deep copy value for the Participant Response.
     * @param event
     * @param entityResponse
     * @param labelStartTime
     * @param logModel
     * @return DeepCopyTranscription.deepCopy
     */

    public static TranscriptionMessage.ConversationEvent getParticipantResponseUtil(
            TranscriptionMessage.ConversationEvent event, String actor, String label,
            long labelStartTime,
            LoggerModel logModel) {


        return DeepCopyTranscription.deepCopy(event,actor,label,
                labelStartTime,logModel);
    }

    public static  boolean isNextDay(String previousDay, String currentDay )
    {

        try {
           LocalDate prevDate = LocalDate.parse(previousDay);
           LocalDate currentDate = LocalDate.parse(currentDay);

            if (prevDate.compareTo(currentDate) < 0)
                return true;
        }catch(Exception e){
            LOG.error("ERROR while comparing the dates"+e.getMessage());

        }

        return false;

    }
    

}

