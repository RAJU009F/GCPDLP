/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.dataflow.transformer;


import com.bell.dataflow.exception.BellDataFlowAppApplicationException;
import com.bell.dataflow.model.LoggerModel;
import com.bell.dataflow.util.LogUtil;
import com.bell.dataflow.util.LabelUtil;
import com.bell.stt.proto.TranscriptionMessage;
import com.google.cloud.dialogflow.v2.ParticipantsClient;
import com.google.cloud.dialogflow.v2.Participant;
import com.google.cloud.dialogflow.v2.stub.*;
import com.google.cloud.dialogflow.v2.*;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import com.bell.dataflow.util.LogUtil;

/**
 *The class is responsible for
 * a. Extract the Redacted Content.
 * b. Interact with Label API.
 * c. post and retrieve the Label and Actor from the Label response.
 * d.Merge the Response data with the Requests.
 */

public class LabelParDo extends DoFn<TranscriptionMessage.ConversationEvent,TranscriptionMessage.ConversationEvent> {
    final String METRIC_NAMESPACE = "LABELPubSubToPubSub";
    static final Logger LOG = LoggerFactory.getLogger(LabelParDo.class);
    private final Counter LabelCounter = Metrics.counter(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_LABEL_SUCCESS");
    private final Counter ErrorCounter =Metrics.counter(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_LABEL_ERROR");

    final TupleTag<TranscriptionMessage.ConversationEvent> DLQ;
    final TupleTag<TranscriptionMessage.ConversationEvent> SUCCESS;

    private transient ParticipantsClient participantsClient;
    static HashMap<String, String> inMemory =  new HashMap<>();
    static String previousDate = "2021-12-23";
    static String currentDate = "2021-12-23";

    /**
     * The Constructor of the ParDO
     * @param dlq
     * @param success
     */
    public LabelParDo(TupleTag<TranscriptionMessage.ConversationEvent> dlq,
                    TupleTag<TranscriptionMessage.ConversationEvent> success) {
        DLQ = dlq;
        SUCCESS = success;

    }

    /**
     * Template method to open any resources
     *
     * @throws IOException
     */

    @StartBundle
    public void startBundle() throws IOException
    {
        try
        {
            long startTime=System.currentTimeMillis();
            LOG.debug("Creating the ParticipantsClient service client");
            this.participantsClient = ParticipantsClient.create();
            long endTime=System.currentTimeMillis();
            LOG.debug("Time taken to create the ParticipantsClient client"  + (endTime -startTime)+"ms");

        } catch (IOException e)
        {
            LOG.error("ERRLABELRT101 - Unable to start ParticipantsClient Client ", e);
            throw  e;
        } catch (Exception e){
            LOG.error("ERRLABELRT101 - Unable to start participantsClient  ", e.getMessage());
            throw  e;
        }

    }

    /**
     * Template method to close any resources
     */

    @FinishBundle
    public void finishBundle()
    {
        if (this.participantsClient != null)
        {
            long startTime=System.currentTimeMillis();
            this.participantsClient.close();
            long endTime=System.currentTimeMillis();
            LOG.debug("Time taken to close the ParticipantsClient client " + (endTime -startTime)+"ms");
        }
    }

    /**
     * This LabelParDo will interact with Label API by following steps:
     * Step1:It check the condition of both Label API i.e Dialogflow service API.
     * Step 2:It will interact with LAbel API and provide the response  object.
     * Step 3:It will merge the Result with Input.
     * @param c,out
     */

    @ProcessElement
    public void processElement(ProcessContext c,MultiOutputReceiver out) throws Exception{

        TranscriptionMessage.ConversationEvent event = c.element();
        LoggerModel logModel = new LoggerModel(event.getConversation(),
                event.getNewMessagePayload().getParticipant(),
                event.getNewMessagePayload().
                        getSpeechToTextInfo().getStreamStartTime(),
                event.getNewMessagePayload().
                        getSpeechToTextInfo().getUtteranceStartOffset(),
                event.getNewMessagePayload().
                        getSpeechToTextInfo().getUtteranceEndOffset(),
                LabelUtil.UtteranceWordCount(event));
        String  participantId = event.getNewMessagePayload().getParticipant().toString();

        long labelStartTime = System.currentTimeMillis();
        String actor = "";
        String mediaLabel = "";

        try {
            

            if (participantId.isEmpty()==false && participantId.isBlank() == false && participantId != null && participantId != "") {

                if (inMemory.containsKey(participantId)){

                    LOG.debug("partcipantId: "+ participantId +" with label "+ inMemory.get(participantId)+"Already in memory and hence not proceed to get Label API again!");
                    String participantInMemoryResponse[] =  inMemory.get(participantId).split(":");
                    actor =  participantInMemoryResponse[0];
                    mediaLabel = participantInMemoryResponse[1];



                }else {

               Participant participantResponse  = getParticipantResponse(participantId, event, logModel,labelStartTime, true);
               actor =  participantResponse.getRole().toString();
               mediaLabel = participantResponse.getSipRecordingMediaLabel();
               inMemory.put(participantId,actor+":"+mediaLabel);
               TranscriptionMessage.ConversationEvent labelParticipantResponseOutput = LabelUtil.getParticipantResponseUtil(event, actor, mediaLabel, labelStartTime,logModel);
               c.output(SUCCESS, labelParticipantResponseOutput);
               LabelCounter.inc();    
               checkDatesAndClearInMemory();
                }

            }
             else {
                 LogUtil.log("The Participant" +participantId +"is null for the Label API Conversation"
                                 + "Putting the messages in DLQ topics Conversation Id: ",
                         logModel,"DLQ Time ",
                         System.currentTimeMillis(),LOG);
                     c.output(DLQ,c.element());
                }

        }catch (Exception e) {
            if(e instanceof BellDataFlowAppApplicationException) {
                LogUtil.logError("Putting the message in DLQ topic",e,
                        logModel,LOG);
                c.output(DLQ,c.element());
            } else
                {
                /*
                 * This is for the non - BellDataFlowAppApplicationException. Added mainly for
                 * the RESOURCE_EXHAUSTED case. Throwing the exception will ensure dataflow can retry
                 * processing the event.
                 */
                LogUtil.logError("ERRLABELRT102-Unable to process the Label API",e,
                        logModel,LOG);
                throw e;
               }
               ErrorCounter.inc();
        }
    }


  

    /**
     * This method is call when only entities Response is only need for analysis.
     * @param participantId
     * @param event
     * @param logModel
     * @param labelStartTime
     * @param log
     * @return participantResponse
     * @throws BellDataFlowAppApplicationException
     */
    private Participant getParticipantResponse( String participantId,
            TranscriptionMessage.ConversationEvent event, 
            LoggerModel logModel,
            long labelStartTime,
            boolean log)
            throws BellDataFlowAppApplicationException{
        
       Participant participantResponse = null;

        if(log)
        {LogUtil.log("Calling Label Entity analysis for conversation :",
                logModel,"Start Time ",
                labelStartTime,LOG);}

        try {
           // entityResponse = getAnalyzeEntitiesResponse(doc);
            participantResponse =  participantsClient.getParticipant(participantId);
        } catch (Exception e) {
            if (e.getMessage().contains("RESOURCE_EXHAUSTED")) {
                LogUtil.logError("The LABEL Quota get exhausted,retrying the process",e,logModel,LOG);
                throw e;
            } else {
                throw new BellDataFlowAppApplicationException("ERRLABELRT103-Unable to call LAbel Dataflow API " +
                        e.getMessage()+"for participant"+participantId, e);
            }
        }
        long gcpEndTime = System.currentTimeMillis();
        if(log) LogUtil.log("LABEL for participant successful for conversation: ",
                logModel,
                "Time taken ",
                gcpEndTime - labelStartTime,LOG);
        return participantResponse;
    }

    // This method compares the two dates and  re-fresh the in memory
    private void checkDatesAndClearInMemory(){

        TimeZone timeZone = TimeZone.getTimeZone("US/Eastern");
        String dateFormat = "yyyy-MM-dd";
        DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd").withZone(ZoneId.of("America/New_York"));

        /* Specifying the format */
        try{
       // DateFormat requiredFormat = new SimpleDateFormat(dateFormat);
        /* Setting the Timezone */
        //requiredFormat.setTimeZone(timeZone);
        long epoch =  Instant.now().toEpochMilli();
        LocalDate current_ld = Instant.ofEpochMilli(epoch).atZone(ZoneId.of("America/New_York")).toLocalDate();
       // Date date =  new Date();
        currentDate = DATE_FORMATTER.format(current_ld);
        // compare predate and current date
        LOG.debug("LABELRT Comparing the dates ");
        if (LabelUtil.isNextDay(previousDate, currentDate))
        {
            inMemory.clear();
            LOG.debug("LABELRT InMemory cleared with CurrentDate:"+currentDate+"previousDate:"+previousDate);
            previousDate = currentDate;


        }}
        catch (Exception e)
        {
            LOG.error("ERRLABELRT102 - Unable proceed to clear the inMemory:  ERROR: "+e.getMessage() +" Trace: "+e.getStackTrace());


        }

    }


}