// /*
//  * Copyright 2021 Google LLC
//  *
//  * Licensed under the Apache License, Version 2.0 (the "License");
//  * you may not use this file except in compliance with the License.
//  * You may obtain a copy of the License at
//  *
//  *     http://www.apache.org/licenses/LICENSE-2.0
//  *
//  * Unless required by applicable law or agreed to in writing, software
//  * distributed under the License is distributed on an "AS IS" BASIS,
//  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  * See the License for the specific language governing permissions and
//  * limitations under the License.
//  */
// package com.bell.stt.test;

// import com.bell.dataflow.model.LoggerModel;
// import com.bell.dataflow.transformer.NLPParDo;
// import com.bell.dataflow.util.NlpUtil;
// import com.bell.stt.proto.TranscriptionMessage;
// import com.bell.stt.proto.TranscriptionMessage.*;
// import com.google.cloud.language.v1.*;
// import com.google.cloud.language.v1.Document;
// import com.google.cloud.language.v1.Sentiment;
// import com.google.protobuf.util.Durations;
// import com.google.protobuf.util.Timestamps;
// import org.apache.beam.vendor.grpc.v1p26p0.org.bouncycastle.asn1.cms.MetaData;
// import org.junit.Assert;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.junit.runners.JUnit4;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;

// import java.text.ParseException;
// import java.util.ArrayList;
// import java.util.HashMap;
// import java.util.List;
// import java.util.Map;

// import static com.google.cloud.language.v1.Entity.Type.OTHER;
// import static com.google.cloud.language.v1.EntityMention.Type.COMMON;


// @RunWith(JUnit4.class)
// public class PubSubNLPToPubSubTest {

//     static final Logger LOG = LoggerFactory.getLogger(PubSubNLPToPubSubTest.class);


//     private LoggerModel getLoggerModel() throws ParseException {
//         //try{
//             LoggerModel logModel = new LoggerModel("Test Conversation",
//                     "participant",
//                     Timestamps.parse("1969-12-31T23:59:59Z"),
//                     Durations.parse("12345.1s"),
//                     Durations.parse("12345.1s"),
//                     19);
//         /*}catch (Exception e){

//             LOG.error("Error creating logger model");
//         }*/

//         return logModel;
//     }


//     private TranscriptionMessage.ConversationEvent createProtoRecordInput() {
//         TranscriptionMessage.ConversationEvent.Builder transcription = TranscriptionMessage.ConversationEvent.newBuilder();
//         try {
//             transcription.setConversation("Test Conversation");
//             transcription.setType(TranscriptionMessage.ConversationEvent.Type.CONVERSATION_STARTED);

//             Message.Builder msg = Message.newBuilder();
//             msg.setLanguageCode("en-US");
//             msg.setParticipant("participant");
//             msg.setName("project1/message1/");
//             msg.setCreateTime(Timestamps.parse("1969-12-31T23:59:59Z"));
//             msg.setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");

//             Message.SpeechToTextInfo.Builder s2tInfo = Message.SpeechToTextInfo.newBuilder();

//             s2tInfo.setUtteranceEndOffset(Durations.parse("12345.1s"));
//             s2tInfo.setUtteranceStartOffset(Durations.parse("12345.1s"));
//             s2tInfo.setStreamStartTime(Timestamps.parse("1969-12-31T23:59:59Z"));

//             String content = "Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back";
//             String[] txtWords = content.split(" ");
//             for (int i = 0; i < txtWords.length; i++) {
//                 Message.SpeechWordInfo.Builder wordInfo = Message.SpeechWordInfo.newBuilder();
//                 wordInfo.setWord(txtWords[i]).setEndOffset(Durations.parse("12345.1s")).setStartOffset(Durations.parse("12345.1s")).setConfidence(1f);
//                 s2tInfo.addSpeechWordInfo(wordInfo.build());
//             }
//             msg.setSpeechToTextInfo(s2tInfo);
//             transcription.setNewMessagePayload(msg.build());
//         } catch (Exception exception) {
//             System.out.println("Unable to test" + exception);
//         }
//         return transcription.build();

//     }

//     private TranscriptionMessage.ConversationEvent createProtoRecordOutput() {
//         TranscriptionMessage.ConversationEvent.Builder transcription = TranscriptionMessage.ConversationEvent.newBuilder();
//         try {
//             transcription.setConversation("Test Conversation");
//             transcription.setType(TranscriptionMessage.ConversationEvent.Type.CONVERSATION_STARTED);

//             Message.Builder msg = Message.newBuilder();
//             msg.setLanguageCode("en-US");
//             msg.setParticipant("participant");
//             msg.setName("project1/message1/");
//             msg.setCreateTime(Timestamps.parse("1969-12-31T23:59:59Z"));
//             msg.setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");

//             Message.SpeechToTextInfo.Builder s2tInfo = Message.SpeechToTextInfo.newBuilder();

//             s2tInfo.setUtteranceEndOffset(Durations.parse("12345.1s"));
//             s2tInfo.setUtteranceStartOffset(Durations.parse("12345.1s"));
//             s2tInfo.setStreamStartTime(Timestamps.parse("1969-12-31T23:59:59Z"));

//             String content = "Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back";
//             String[] txtWords = content.split(" ");
//             for (int i = 0; i < txtWords.length; i++) {
//                 Message.SpeechWordInfo.Builder wordInfo = Message.SpeechWordInfo.newBuilder();
//                 wordInfo.setWord(txtWords[i]).setEndOffset(Durations.parse("12345.1s")).setStartOffset(Durations.parse("12345.1s")).setConfidence(1f);
//                 s2tInfo.addSpeechWordInfo(wordInfo.build());
//             }
//             msg.setSpeechToTextInfo(s2tInfo);

//             TranscriptionMessage.NLPSentimentAnalysisResponse.Builder sr = TranscriptionMessage.NLPSentimentAnalysisResponse.newBuilder();
//             TranscriptionMessage.Document.Builder doc = TranscriptionMessage.Document.newBuilder();
//             doc.setScore(-0.3f);
//             doc.setMagnitude(0.3f);
//             sr.setLanguage("en");
//             sr.setDocument(doc.build());
//             List<TranscriptionMessage.Sentences> sentencesList = new ArrayList<Sentences>();
//             TranscriptionMessage.Sentences.Builder sentenceTest = TranscriptionMessage.Sentences.newBuilder();
//             TranscriptionMessage.Sentences_Sentiment.Builder sentences_sentiment_test=TranscriptionMessage.Sentences_Sentiment.newBuilder();
//             TranscriptionMessage.Text.Builder text =TranscriptionMessage.Text.newBuilder();
//             sentences_sentiment_test.setScore(-0.3f);
//             sentences_sentiment_test.setMagnitude(0.3f);
//             text.setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");
//             text.setBeginoffset("-1");
//             sentenceTest.setSentencesSentiment(sentences_sentiment_test.build());
//             sentenceTest.setText(text.build());
//             sentencesList.add(sentenceTest.build());
//             sr.addAllSentences(sentencesList);
//             sr.build();
//             msg.setNLPSentimentAnalysisResponse(sr);

//             TranscriptionMessage.NLPEntityAnalysisResponse.Builder er = TranscriptionMessage.NLPEntityAnalysisResponse.newBuilder();
//             er.setLanguage("en");
//             List<TranscriptionMessage.Entities> entitiesList = new ArrayList<Entities>();
//             TranscriptionMessage.Entities.Builder entitiesTest = TranscriptionMessage.Entities.newBuilder();
//             TranscriptionMessage.Mentions.Builder mentionsTest = TranscriptionMessage.Mentions.newBuilder();
//             TranscriptionMessage.Mentiontext.Builder mention_text = TranscriptionMessage.Mentiontext.newBuilder();
//             TranscriptionMessage.Metadata.Builder metadata_text = TranscriptionMessage.Metadata.newBuilder();
//             mention_text.setContent("TV Box");
//             mention_text.setBeginoffset("27");
//             mention_text.build();
//             mentionsTest.setText(mention_text);
//             mentionsTest.setType("COMMON");
//             metadata_text.setValue("20");
//             entitiesTest.setName("TV Box");
//             entitiesTest.setSalience(0.7559768f);
//             entitiesTest.setTypeNlp("OTHER");
//             entitiesTest.setMentions(mentionsTest.build());
//             entitiesTest.setMetadata(metadata_text.build());
//             entitiesList.add(entitiesTest.build());
//             er.addAllEntities(entitiesList);
//             msg.setNLPEntityAnalysisResponse(er.build());
//             msg.setNLPAPIStartTime("12345");
//             msg.setWordCount("19");
//             transcription.setNewMessagePayload(msg.build());
//         } catch (Exception exception) {

//             System.out.println("Unable to test" + exception);

//         }
//         return transcription.build();
//     }

//     private TranscriptionMessage.ConversationEvent createProtoRecordSentimentOutput() {
//         TranscriptionMessage.ConversationEvent.Builder transcription = TranscriptionMessage.ConversationEvent.newBuilder();
//         try {
//             transcription.setConversation("Test Conversation");
//             transcription.setType(TranscriptionMessage.ConversationEvent.Type.CONVERSATION_STARTED);

//             Message.Builder msg = Message.newBuilder();
//             msg.setLanguageCode("en-US");
//             msg.setParticipant("participant");
//             msg.setName("project1/message1/");
//             msg.setCreateTime(Timestamps.parse("1969-12-31T23:59:59Z"));
//             msg.setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");

//             Message.SpeechToTextInfo.Builder s2tInfo = Message.SpeechToTextInfo.newBuilder();

//             s2tInfo.setUtteranceEndOffset(Durations.parse("12345.1s"));
//             s2tInfo.setUtteranceStartOffset(Durations.parse("12345.1s"));
//             s2tInfo.setStreamStartTime(Timestamps.parse("1969-12-31T23:59:59Z"));

//             String content = "Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back";
//             String[] txtWords = content.split(" ");
//             for (int i = 0; i < txtWords.length; i++) {
//                 Message.SpeechWordInfo.Builder wordInfo = Message.SpeechWordInfo.newBuilder();
//                 wordInfo.setWord(txtWords[i]).setEndOffset(Durations.parse("12345.1s")).setStartOffset(Durations.parse("12345.1s")).setConfidence(1f);
//                 s2tInfo.addSpeechWordInfo(wordInfo.build());
//             }
//             msg.setSpeechToTextInfo(s2tInfo);

//             TranscriptionMessage.NLPSentimentAnalysisResponse.Builder sr = TranscriptionMessage.NLPSentimentAnalysisResponse.newBuilder();
//             TranscriptionMessage.Document.Builder doc = TranscriptionMessage.Document.newBuilder();
//             doc.setScore(-0.3f);
//             doc.setMagnitude(0.3f);
//             sr.setLanguage("en");
//             sr.setDocument(doc.build());
//             List<TranscriptionMessage.Sentences> sentencesList = new ArrayList<Sentences>();
//             TranscriptionMessage.Sentences.Builder sentenceTest = TranscriptionMessage.Sentences.newBuilder();
//             TranscriptionMessage.Sentences_Sentiment.Builder sentences_sentiment_test=TranscriptionMessage.Sentences_Sentiment.newBuilder();
//             TranscriptionMessage.Text.Builder text =TranscriptionMessage.Text.newBuilder();
//             sentences_sentiment_test.setScore(-0.3f);
//             sentences_sentiment_test.setMagnitude(0.3f);
//             text.setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");
//             text.setBeginoffset("-1");
//             sentenceTest.setSentencesSentiment(sentences_sentiment_test.build());
//             sentenceTest.setText(text.build());
//             sentencesList.add(sentenceTest.build());
//             sr.addAllSentences(sentencesList);
//             sr.build();
//             msg.setNLPSentimentAnalysisResponse(sr);
//             msg.setNLPAPIStartTime("12345");
//             msg.setWordCount("19");
//             transcription.setNewMessagePayload(msg.build());
//         } catch (Exception exception) {

//             System.out.println("Unable to test" + exception);

//         }
//         return transcription.build();
//     }

//     private TranscriptionMessage.ConversationEvent createProtoRecordEntitesOutput() {
//         TranscriptionMessage.ConversationEvent.Builder transcription = TranscriptionMessage.ConversationEvent.newBuilder();
//         try {
//             transcription.setConversation("Test Conversation");
//             transcription.setType(TranscriptionMessage.ConversationEvent.Type.CONVERSATION_STARTED);

//             Message.Builder msg = Message.newBuilder();
//             msg.setLanguageCode("en-US");
//             msg.setParticipant("participant");
//             msg.setName("project1/message1/");
//             msg.setCreateTime(Timestamps.parse("1969-12-31T23:59:59Z"));
//             msg.setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");

//             Message.SpeechToTextInfo.Builder s2tInfo = Message.SpeechToTextInfo.newBuilder();

//             s2tInfo.setUtteranceEndOffset(Durations.parse("12345.1s"));
//             s2tInfo.setUtteranceStartOffset(Durations.parse("12345.1s"));
//             s2tInfo.setStreamStartTime(Timestamps.parse("1969-12-31T23:59:59Z"));

//             String content = "Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back";
//             String[] txtWords = content.split(" ");
//             for (int i = 0; i < txtWords.length; i++) {
//                 Message.SpeechWordInfo.Builder wordInfo = Message.SpeechWordInfo.newBuilder();
//                 wordInfo.setWord(txtWords[i]).setEndOffset(Durations.parse("12345.1s")).setStartOffset(Durations.parse("12345.1s")).setConfidence(1f);
//                 s2tInfo.addSpeechWordInfo(wordInfo.build());
//             }
//             msg.setSpeechToTextInfo(s2tInfo);

//             TranscriptionMessage.NLPEntityAnalysisResponse.Builder er = TranscriptionMessage.NLPEntityAnalysisResponse.newBuilder();
//             er.setLanguage("en");
//             List<TranscriptionMessage.Entities> entitiesList = new ArrayList<Entities>();
//             TranscriptionMessage.Entities.Builder entitiesTest = TranscriptionMessage.Entities.newBuilder();
//             TranscriptionMessage.Mentions.Builder mentionsTest = TranscriptionMessage.Mentions.newBuilder();
//             TranscriptionMessage.Mentiontext.Builder mention_text = TranscriptionMessage.Mentiontext.newBuilder();
//             TranscriptionMessage.Metadata.Builder metadata_text = TranscriptionMessage.Metadata.newBuilder();
//             mention_text.setContent("TV Box");
//             mention_text.setBeginoffset("27");
//             mention_text.build();
//             mentionsTest.setText(mention_text);
//             mentionsTest.setType("COMMON");
//             metadata_text.setValue("20");
//             entitiesTest.setName("TV Box");
//             entitiesTest.setSalience(0.7559768f);
//             entitiesTest.setTypeNlp("OTHER");
//             entitiesTest.setMentions(mentionsTest.build());
//             entitiesTest.setMetadata(metadata_text.build());
//             entitiesList.add(entitiesTest.build());
//             er.addAllEntities(entitiesList);
//             msg.setNLPEntityAnalysisResponse(er.build());
//             msg.setNLPAPIStartTime("12345");
//             msg.setWordCount("19");
//             transcription.setNewMessagePayload(msg.build());
//         } catch (Exception exception) {

//             System.out.println("Unable to test" + exception);

//         }
//         return transcription.build();
//     }


//     private AnalyzeSentimentResponse sentimentResponseTest() {
        
//         AnalyzeSentimentResponse.Builder sr = AnalyzeSentimentResponse.newBuilder();
//         Document.Builder doc=Document.newBuilder();
//         Document doc1 = Document.newBuilder().setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back").setType(Document.Type.PLAIN_TEXT).build();
//         Sentiment.Builder sentimentTest = Sentiment.newBuilder();
//         sr.setDocumentSentiment(sentimentTest.setMagnitude(0.3f));
//         sr.setDocumentSentiment(sentimentTest.setScore(-0.3f));
//         sr.setLanguage("en");
//         List<Sentence> sentenceList =new ArrayList<Sentence>();
//         Sentence.Builder sentencesResponse =Sentence.newBuilder();
//         TextSpan.Builder TextResponse =TextSpan.newBuilder();
//         TextResponse.setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");
//         TextResponse.setBeginOffset(-1);
//         sentimentTest.setMagnitude(0.3f);
//         sentimentTest.setScore(-0.3f);
//         sentencesResponse.setText(TextResponse.build());
//         sentencesResponse.setSentiment(sentimentTest.build());
//         sentenceList.add(sentencesResponse.build());
//         sr.addAllSentences(sentenceList);
//         return sr.build();
//        }


//        private AnalyzeEntitiesResponse entitiesResponseTest()
//        {
//            AnalyzeEntitiesResponse.Builder entities=AnalyzeEntitiesResponse.newBuilder();
//            entities.setLanguage("en");
//            List<Entity.Builder> entitiesList=new ArrayList<Entity.Builder>();
//            Entity.Builder entitiesResponse =Entity.newBuilder();
//            entitiesResponse.setName("TV Box");
//            entitiesResponse.setType(OTHER);
//            entitiesResponse.setSalience(0.7559768f);
//            EntityMention.Builder mentions = EntityMention.newBuilder();
//            TextSpan.Builder mention_text = TextSpan.newBuilder();
//            mention_text.setContent("TV Box");
//            mention_text.setBeginOffset(27);
//            mention_text.build();
//            mentions.setText(mention_text);
//            mentions.setType(COMMON);
//            mentions.build();
//            entitiesResponse.addMentions(mentions);
//            entitiesResponse.putAllMetadata(metaDataTest());
//            entities.addEntities(entitiesResponse);
           
//            entities.build();

//            return  entities.build();

//            }

//     private static Map<String, String> metaDataTest() {
//         Map<String, String> metadata = new HashMap<>();
//         metadata.put("value", "20");
//         return metadata;
//     }
    
//     @Test
//     public  void  verifyEntitiesAndSentimentAnalysis() throws ParseException{
//         long NLPAPIStartTime = 12345;
//         int wordCountExpected = 19;

//         AnalyzeSentimentResponse ar = this.sentimentResponseTest();
//         AnalyzeEntitiesResponse er =this.entitiesResponseTest();
//         int wordCountActual = 19;
//         TranscriptionMessage.ConversationEvent inputEvent = this.createProtoRecordInput();
//         TranscriptionMessage.ConversationEvent expectedOutput = this.createProtoRecordOutput();
//         TranscriptionMessage.ConversationEvent ActualOutput = new NlpUtil().getEntitiesAndSentimentAnalysis(
//                 inputEvent, ar,er, NLPAPIStartTime,getLoggerModel());
//         Assert.assertEquals(expectedOutput, ActualOutput);
//     }

// @Test
//     public  void  verifySentimentAnalysis() throws ParseException{
//         long NLPAPIStartTime = 12345;
//         int wordCount= 19;
//         AnalyzeSentimentResponse ar = this.sentimentResponseTest();
//         TranscriptionMessage.ConversationEvent inputEvent = this.createProtoRecordInput();
//         TranscriptionMessage.ConversationEvent expectedOutput = this.createProtoRecordSentimentOutput();
//         TranscriptionMessage.ConversationEvent ActualOutput = new NlpUtil().getSentimentAnalysis(inputEvent,ar,
//                 NLPAPIStartTime,getLoggerModel());
//         Assert.assertEquals(expectedOutput, ActualOutput);

//     }

//     @Test
//     public  void  verifyEntitiesAnalysis() throws ParseException{
//         long NLPAPIStartTime = 12345;
//         int wordCount = 19;

//         AnalyzeEntitiesResponse er =this.entitiesResponseTest();
//         TranscriptionMessage.ConversationEvent inputEvent = this.createProtoRecordInput();
//         TranscriptionMessage.ConversationEvent expectedOutput = this.createProtoRecordEntitesOutput();
//         TranscriptionMessage.ConversationEvent ActualOutput =
//                 new NlpUtil().getEntitiesAnalysis(inputEvent, er, NLPAPIStartTime,getLoggerModel());
//         Assert.assertEquals(expectedOutput, ActualOutput);

//     }

//         @Test
//          public  void verifyWordCount(){
//             TranscriptionMessage.ConversationEvent inputEvent = this.createProtoRecordInput();
//             int wordCountExpected =new NlpUtil().UtteranceWordCount(inputEvent);
//             Assert.assertEquals(19,wordCountExpected);
//         }

//         @Test
//          public  void verifyNLlpFlagTrue()
//         {
//             boolean isNlp =true;
//             int WordCount=10;
//             int UtteranceWordCount=19;
//             boolean isCallableExpected=new NlpUtil().isCallable(isNlp,WordCount,UtteranceWordCount);
//             Assert.assertEquals(true,isCallableExpected);
//         }

//     @Test
//     public  void verifyNlpFlagFalse()
//     {
//         boolean isNlp =false;
//         int WordCount=19;
//         int UtteranceWordCount=10;
//         boolean isCallableExpected=new NlpUtil().isCallable(isNlp,WordCount,UtteranceWordCount);
//         Assert.assertEquals(false,isCallableExpected);
//     }
// }