package com.bell.stt.options;

import org.apache.beam.sdk.options.*;

public interface PubSubToKafkaOptions extends PipelineOptions, StreamingOptions {
    @Description(
            "The Cloud Pub/Sub subscription to consume from. "
                    + "The name should be in the format of "
                    + "projects/<project-id>/subscriptions/<subscription-name>.")
    @Validation.Required
    ValueProvider<String> getInputSubscription();

    void setInputSubscription(ValueProvider<String> inputSubscription);

    @Description("Pub/Sub topic to read the input from")
    ValueProvider<String> getInputTopic();

    void setInputTopic(ValueProvider<String> value);

    @Description("Kafka Bootstrap Servers")
    ValueProvider<String> getBootstrapServers();

    void setBootstrapServers(ValueProvider<String> value);

    @Description("Kafka topic to write the output")
    ValueProvider<String> getOutputTopic();

    void setOutputTopic(ValueProvider<String> value);

    @Description("secret id of the kerberos configuration from secret manager")
    ValueProvider<String> getKrb5ConfNameInSecretManager();

    void setKrb5ConfNameInSecretManager(ValueProvider<String> value);

    //getProjectIdForSecret

    @Description("secret manager project id")
    ValueProvider<String> getProjectIdForSecret();

    void setProjectIdForSecret(ValueProvider<String> value);

    @Description("secret id of the trust store name configuration from secret manager")
    ValueProvider<String> getTrustStoreNameInSecretManager();

    void setTrustStoreNameInSecretManager(ValueProvider<String> value);

    @Description("secret id of the keytab name configuration from secret manager")
    ValueProvider<String> getKeytabNameInSecretManager();

    void setKeytabNameInSecretManager(ValueProvider<String> value);

    @Description("secret id of the trust store password configuration from secret manager")
    ValueProvider<String> getTrustStorePasswordInSecretManager();

    void setTrustStorePasswordInSecretManager(ValueProvider<String> value);

    @Description("Kerberos principal")
    ValueProvider<String> getPrincipal();

    void setPrincipal(ValueProvider<String> value);

    @Description("Kafka service name")
    ValueProvider<String> getKafkaServiceName();

    void setKafkaServiceName(ValueProvider<String> value);

    @Description("MSK Schema Registry URL")
    ValueProvider<String> getschemaRegistryUrl();

    void setschemaRegistryUrl(ValueProvider<String> value);

    @Description("MSK Protocol")
    ValueProvider<String> getSecurityProtocol();

    void setSecurityProtocol(ValueProvider<String> value);

}