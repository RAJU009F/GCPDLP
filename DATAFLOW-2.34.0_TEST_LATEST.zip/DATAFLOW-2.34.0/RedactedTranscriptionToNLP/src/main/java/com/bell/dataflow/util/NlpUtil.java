/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.dataflow.util;

import com.bell.dataflow.model.LoggerModel;
import com.bell.stt.proto.TranscriptionMessage;
import com.google.cloud.language.v1.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.cloud.language.v1.Sentence;
import java.util.Map;

/**
 *This Util class is responsible for the Following 3 methods.
 * a. Word count of the given content
 * b. The NLP sentiment method to get the Sentiment Response.
 * c. The NLP Entities method to get the Entities Response
 */


public class NlpUtil {

    /**
     * The UtteranceCount will calculate the counts of words in the Contents
     */

    static final Logger LOG = LoggerFactory.getLogger(NlpUtil.class);

    public static int UtteranceWordCount(TranscriptionMessage.ConversationEvent event) {
        String content =event.getNewMessagePayloadOrBuilder().getContent();
        if (content== null || content.isEmpty()) {
            return 0;
        }
        String[] words = content.split("\\s+");
        return words.length;
    }

    /**
     * It will check the condition to Call the NLP API.
     * @param isNLP
     * @param wordCount
     * @param utteranceWordCount
     * @return
     */
    public static boolean isCallable(boolean isNLP , int wordCount ,int utteranceWordCount){
        if(isNLP){
            if(utteranceWordCount >= wordCount)  return true;
            else return false;
        }else return false;
    }

    /**
     * It will return the Deep Copy value for both Sentiment and Entities analysis Response
     * @param event
     * @param sentimentResponse
     * @param entityResponse
     * @param nlpStartTime
     * @param logModel
     * @return DeepCopyTranscription.deepCopy
     */


    public static TranscriptionMessage.ConversationEvent getEntitiesAndSentimentAnalysis(
            TranscriptionMessage.ConversationEvent event,AnalyzeSentimentResponse sentimentResponse,
            AnalyzeEntitiesResponse entityResponse,
            long nlpStartTime,LoggerModel logModel) {


        return DeepCopyTranscription.deepCopy(event,analyzeSentimentText(sentimentResponse,event,logModel),
                analyzeEntitiesText(entityResponse,event,logModel),
                nlpStartTime,logModel);

    }

    /**
     * It will Return the Deep copy value for the Entities Response.
     * @param event
     * @param entityResponse
     * @param nlpStartTime
     * @param logModel
     * @return DeepCopyTranscription.deepCopy
     */

    public static TranscriptionMessage.ConversationEvent getEntitiesAnalysis(
            TranscriptionMessage.ConversationEvent event,AnalyzeEntitiesResponse entityResponse,
            long nlpStartTime,
            LoggerModel logModel) {


        return DeepCopyTranscription.deepCopy(event,null,analyzeEntitiesText(entityResponse,event,logModel),
                nlpStartTime,logModel);
    }

    /**
     *It will return the DeepCopy value of the The sentiment Response.
     * @param event
     * @param sentimentResponse
     * @param nlpStartTime
     * @param logModel
     * @return DeepCopyTranscription.deepCopy
     */

    public static TranscriptionMessage.ConversationEvent getSentimentAnalysis(
            TranscriptionMessage.ConversationEvent event,AnalyzeSentimentResponse  sentimentResponse,
            long nlpStartTime,
            LoggerModel logModel) {


        return DeepCopyTranscription.deepCopy(event,analyzeSentimentText(sentimentResponse,event,logModel),null,
                nlpStartTime, logModel);
    }

    /**
     * This NLPSentiment will take request from the Input and it will return the Sentiment Response
     * @param sentimentResponse
     * @return sentimentResponseProto
     */

    private static TranscriptionMessage.NLPSentimentAnalysisResponse
    analyzeSentimentText(AnalyzeSentimentResponse sentimentResponse,
                         TranscriptionMessage.ConversationEvent event,
                         LoggerModel logModel)  {


        TranscriptionMessage.NLPSentimentAnalysisResponse.Builder sentimentResponseProto =
                TranscriptionMessage.NLPSentimentAnalysisResponse.newBuilder();
        try {
            long startTime= System.currentTimeMillis();
            LogUtil.log("Entering the sentiment util method for processing the conversation for ",
                    logModel,"start time ", startTime,LOG);
            TranscriptionMessage.Document.Builder documentProto = TranscriptionMessage.Document.newBuilder();
            Sentiment sentiment = sentimentResponse.getDocumentSentiment();
            if (sentiment == null) {
                LogUtil.log("No Sentiment found for conversation",  logModel,"start time ", startTime,LOG);
            } else {
                documentProto.setScore(sentiment.getScore());
                documentProto.setMagnitude(sentiment.getMagnitude());
            }
            documentProto.build();
            for (Sentence sentences : sentimentResponse.getSentencesList()) {
                TranscriptionMessage.Sentences.Builder sentencesProto = TranscriptionMessage.Sentences.newBuilder();
                TranscriptionMessage.Sentences_Sentiment.Builder sentenceSentimentProto = sentencesProto.
                        getSentencesSentiment().newBuilderForType();
                sentenceSentimentProto.setScore(sentences.getSentiment().getScore());
                sentenceSentimentProto.setMagnitude(sentences.getSentiment().getMagnitude());
                sentencesProto.setSentencesSentiment(sentenceSentimentProto);
                sentencesProto.build();

                TranscriptionMessage.Text.Builder text = sentencesProto.getText().newBuilderForType();
                text.setContent(sentences.getText().getContent());
                text.setBeginoffset(String.valueOf(sentences.getText().getBeginOffset()));
                text.build();
                sentencesProto.setText(text);
                sentencesProto.build();
                sentimentResponseProto.addSentences(sentencesProto);
            }
            sentimentResponseProto.setDocument(documentProto);
            sentimentResponseProto.setLanguage(sentimentResponse.getLanguage());
            long endTime= System.currentTimeMillis();

            LogUtil.log("Sentiment util method processing successfully completed for conversation ",
                    logModel,"time taken ", startTime - endTime,LOG);
        }catch (Exception e)
        {
            LogUtil.logError("ERRNLP106-Unable to process the NLP util Sentiment response method",e, logModel,LOG);
        }
        return sentimentResponseProto.build();
    }

    /**
     * This NLPEntity will take the request for the Input and return the Entity Response
     * @param entityResponse
     * @return entityResponseProto
     */

    private static TranscriptionMessage.NLPEntityAnalysisResponse
    analyzeEntitiesText(AnalyzeEntitiesResponse entityResponse,
                        TranscriptionMessage.ConversationEvent event,
                        LoggerModel logModel) {

        TranscriptionMessage.NLPEntityAnalysisResponse.Builder entityResponseProto =
                TranscriptionMessage.NLPEntityAnalysisResponse.newBuilder();

        try {
            long startTime= System.currentTimeMillis();
            LogUtil.log("Entering the Entity util method for processing the conversation for ", logModel,"start time", startTime,LOG);
            for (Entity entity : entityResponse.getEntitiesList()) {
                TranscriptionMessage.Entities.Builder entitiesProto = TranscriptionMessage.Entities.newBuilder();
                entitiesProto.setName(entity.getName());
                entitiesProto.setSalience(entity.getSalience());
                entitiesProto.setTypeNlp(String.valueOf(entity.getType()));

                for (Map.Entry<String, String> entry : entity.getMetadataMap().entrySet()) {
                    TranscriptionMessage.Metadata.Builder metadata = TranscriptionMessage.Metadata.newBuilder();

                    if (entry.getKey().equals(EntityMetadata.MID))
                            metadata.setMid(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.WIKIPEDIA_URL))
                             metadata.setWikipediaUrl(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.PHONE_NUMBER))
                             metadata.setPhoneNumber(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.NATIONAL_PREFIX))
                             metadata.setNationalPrefix(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.AREA_CODE)) metadata.setAreaCode(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.EXTENSION)) metadata.setExtension(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.STREET_NUMBER))
                           metadata.setStreetNumber(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.LOCALITY)) metadata.setLocality(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.STREET_NAME))
                           metadata.setStreetName(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.POSTAL_CODE))
                          metadata.setPostalCode(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.COUNTRY))
                           metadata.setPostalCode(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.BROAD_REGION))
                           metadata.setBroadRegion(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.NARROW_REGION))
                           metadata.setNarrowRegion(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.SUBLOCALITY))
                            metadata.setSublocality(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.NUMBER)) metadata.setNumber(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.YEAR)) metadata.setYear(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.MONTH)) metadata.setMonth(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.DAY)) metadata.setDay(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.CURRENCY)) metadata.setCurrency(entry.getValue());
                    else if (entry.getKey().equals(EntityMetadata.VALUE)) metadata.setValue(entry.getValue());
                    else
                        LOG.debug("No metadata found");
                    metadata.build();
                    entitiesProto.setMetadata(metadata);
                }

                for (EntityMention mention : entity.getMentionsList()) {

                    TranscriptionMessage.Mentions.Builder mentions = TranscriptionMessage.Mentions.newBuilder();
                    TranscriptionMessage.Mentiontext.Builder text = TranscriptionMessage.Mentiontext.newBuilder();
                    text.setBeginoffset(String.valueOf(mention.getText().getBeginOffset()));
                    text.setContent(mention.getText().getContent());
                    text.build();
                    mentions.setType(String.valueOf(mention.getType()));
                    mentions.setText(text);
                    mentions.build();
                    entitiesProto.setMentions(mentions);
                }
                entityResponseProto.addEntities(entitiesProto);
            }
            entityResponseProto.setLanguage(entityResponse.getLanguage());
            long endTime= System.currentTimeMillis();
            LogUtil.log("Entity util method processing successfully completed for conversation ",
                    logModel,"time taken", startTime - endTime,LOG);
        }catch (Exception e)
        {
            LogUtil.logError("ERRNLP107-Unable to process the NLP util Entity response method",e,logModel,LOG);
        }
        return entityResponseProto.build();
    }

}

