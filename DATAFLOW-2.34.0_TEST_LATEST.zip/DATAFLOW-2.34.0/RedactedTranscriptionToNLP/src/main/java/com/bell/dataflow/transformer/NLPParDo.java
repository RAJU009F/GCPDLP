/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.dataflow.transformer;


import com.bell.dataflow.exception.BellDataFlowAppApplicationException;
import com.bell.dataflow.model.LoggerModel;
import com.bell.dataflow.util.LogUtil;
import com.bell.dataflow.util.NlpUtil;
import com.bell.stt.proto.TranscriptionMessage;
import com.google.cloud.language.v1.*;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import com.bell.dataflow.util.LogUtil;

/**
 *The class is responsible for
 * a. Extract the Redacted Content.
 * b. Interact with NLP API.
 * c. post and retrieve the sentiment and entities response from the NLP.
 * d.Merge the Response data with the Requests.
 */

public class NLPParDo extends DoFn<TranscriptionMessage.ConversationEvent,TranscriptionMessage.ConversationEvent> {
    final String METRIC_NAMESPACE = "NLPPubSubToPubSub";
    static final Logger LOG = LoggerFactory.getLogger(NLPParDo.class);
    private final Counter entityCounter = Metrics.counter(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_NLP_ENTITY");
    private final Counter sentimentCounter = Metrics.counter(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_NLP_SENTIMENT");
    private final Counter entitySentimentCounter = Metrics.counter(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_NLP_ENTITY_SENTIMENT");
    private final Counter imgCounter =Metrics.counter(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_NLP_ERROR");

    final TupleTag<TranscriptionMessage.ConversationEvent> DLQ;
    final TupleTag<TranscriptionMessage.ConversationEvent> SUCCESS;

    private transient LanguageServiceClient languageServiceClient;
    private Integer minSentimentWordCount;
    private Boolean analyzeSentiment;
    private Integer minEntitiesWordCount;
    private Boolean analyzeEntities;
    private String  language;

    /**
     * The Constructor of the ParDO
     * @param dlq
     * @param success
     * @param minSentimentWordCount
     * @param analyzeSentiment
     * @param minEntitiesWordCount
     * @param analyzeEntities
     */
    public NLPParDo(TupleTag<TranscriptionMessage.ConversationEvent> dlq,
                    TupleTag<TranscriptionMessage.ConversationEvent> success,
                    Integer minSentimentWordCount,
                    Boolean analyzeSentiment,
                    Integer minEntitiesWordCount,
                    Boolean analyzeEntities,String  language) {
        DLQ = dlq;
        SUCCESS = success;
        this.minSentimentWordCount = minSentimentWordCount;
        this.analyzeSentiment = analyzeSentiment;
        this.minEntitiesWordCount = minEntitiesWordCount;
        this.analyzeEntities = analyzeEntities;
        this.language=language;
    }

    /**
     * Template method to open any resources
     *
     * @throws IOException
     */

    @StartBundle
    public void startBundle() throws IOException
    {
        try
        {
            long startTime=System.currentTimeMillis();
            LOG.debug("Creating the Language service client");
            this.languageServiceClient = LanguageServiceClient.create();
            long endTime=System.currentTimeMillis();
            LOG.debug("Time taken to create the language client"  + (endTime -startTime)+"ms");

        } catch (IOException e)
        {
            LOG.error("ERRNLP101 - Unable to start NLP Client ", e);
            throw  e;
        }
    }

    /**
     * Template method to close any resources
     */

    @FinishBundle
    public void finishBundle()
    {
        if (this.languageServiceClient != null)
        {
            long startTime=System.currentTimeMillis();
            this.languageServiceClient.close();
            long endTime=System.currentTimeMillis();
            LOG.debug("Time taken to close the language client " + (endTime -startTime)+"ms");
        }
    }

    /**
     * This NLPParDo will interact with NLP by following steps:
     * Step1:It check the condition of both NLP API i.e Sentiment and Entities API.
     * IF Sentiment API is true and WordCount is greater than Parameter ,only Sentiment API run ,Similarly Entities API run.
     * IF both API condition is true,It will provide for the  Result of both API.
     * Step 2:It will interact with NLP API and provide the response of each object.
     * Step 3:It will merge the Result with Input.
     * @param c,out
     */

    @ProcessElement
    public void processElement(ProcessContext c,MultiOutputReceiver out) throws Exception{

        TranscriptionMessage.ConversationEvent event = c.element();
        LoggerModel logModel = new LoggerModel(event.getConversation(),
                event.getNewMessagePayload().getParticipant(),
                event.getNewMessagePayload().
                        getSpeechToTextInfo().getStreamStartTime(),
                event.getNewMessagePayload().
                        getSpeechToTextInfo().getUtteranceStartOffset(),
                event.getNewMessagePayload().
                        getSpeechToTextInfo().getUtteranceEndOffset(),
                NlpUtil.UtteranceWordCount(event));


        long nlpStartTime = System.currentTimeMillis();


        try {
            boolean isCallableSentiment = NlpUtil.isCallable(analyzeSentiment,
                    minSentimentWordCount, logModel.getUtteranceCount());
            boolean isCallableEntities = NlpUtil.isCallable(analyzeEntities,
                    minEntitiesWordCount, logModel.getUtteranceCount());

            List<String> language = Arrays.asList(this.language.split("\\s*,\\s*"));
            if (language.contains(event.getNewMessagePayload().getLanguageCode())) {
                Document doc = getSentimentRequest(event);

                if (isCallableSentiment && isCallableEntities) {
                    c.output(SUCCESS, getEntityAndSentimentAnalysis(event,doc,logModel,nlpStartTime));
                    entitySentimentCounter.inc();
                } else if (isCallableSentiment) {
                        AnalyzeSentimentResponse sentimentResponse = getSentimentAnalysis(event,
                                doc,logModel,nlpStartTime,true);
                        TranscriptionMessage.ConversationEvent nlpSentimentOutput = NlpUtil.getSentimentAnalysis(event,
                                sentimentResponse,
                                nlpStartTime,
                                logModel);
                        c.output(SUCCESS, nlpSentimentOutput);
                        sentimentCounter.inc();
                } else if (isCallableEntities) {
                    AnalyzeEntitiesResponse entityResponse = getEntityAnalysis(event,
                            doc,logModel,nlpStartTime,true);
                        TranscriptionMessage.ConversationEvent entitiesOutput = NlpUtil.getEntitiesAnalysis(event,
                                entityResponse, nlpStartTime,logModel);
                        c.output(SUCCESS, entitiesOutput);
                        entityCounter.inc();
                } else {
                    LOG.debug("The word count is less than provided count or both API are turned off," +
                            "No need to process the data");
                    }
            }
            else {
                LogUtil.log("The Language" +language +"is not supported for the NLP API Conversation"
                                + "Putting the messages in DLQ topics Conversation Id: ",
                        logModel,"DLQ Time ",
                        System.currentTimeMillis(),LOG);
                    c.output(DLQ,c.element());
                }
        }catch (Exception e) {
            if(e instanceof BellDataFlowAppApplicationException) {
                LogUtil.logError("Putting the message in DLQ topic",e,
                        logModel,LOG);
                c.output(DLQ,c.element());
            } else
                {
                /*
                 * This is for the non - BellDataFlowAppApplicationException. Added mainly for
                 * the RESOURCE_EXHAUSTED case. Throwing the exception will ensure dataflow can retry
                 * processing the event.
                 */
                LogUtil.logError("ERRNLP102-Unable to process the NLP API",e,
                        logModel,LOG);
                throw e;
               }
            imgCounter.inc();
        }
    }


    /**
     * This method is use to get the request and return the document value for NLP Responses
     * @param event
     * @return doc
     */
    private Document getSentimentRequest(TranscriptionMessage.ConversationEvent event) {
        Document doc = Document.newBuilder().setContent(event.getNewMessagePayloadOrBuilder()
                .getContent()).setType(Document.Type.PLAIN_TEXT).build();
        return doc;
    }

    /**
     * This method is use to get the entities request and  return the entities Response
     * @param doc
     * @return entityResponse
     */

    private AnalyzeEntitiesResponse getAnalyzeEntitiesResponse(Document doc) {
        AnalyzeEntitiesResponse entityResponse;
        AnalyzeEntitiesRequest request =
                AnalyzeEntitiesRequest.newBuilder()
                        .setDocument(doc)
                        .setEncodingType(EncodingType.UTF16)
                        .build();

        entityResponse = languageServiceClient.analyzeEntities(request);
        return entityResponse;
    }

    /**
     * This method is call when only Sentiment Response is needed for analysis.
     * @param event
     * @param doc
     * @param logModel
     * @param nlpStartTime
     * @param log
     * @return sentimentResponse
     * @throws BellDataFlowAppApplicationException
     */



    private AnalyzeSentimentResponse getSentimentAnalysis(TranscriptionMessage.ConversationEvent event,
                                   Document doc,
                                   LoggerModel logModel,
                                                          long nlpStartTime,boolean log)
            throws BellDataFlowAppApplicationException{
        if(log) LogUtil.log("Calling NLP sentiment analysis for conversation :", logModel,"Start Time ",
                nlpStartTime,LOG);
        AnalyzeSentimentResponse sentimentResponse = null;
        try {
            sentimentResponse = languageServiceClient.analyzeSentiment(doc);

        } catch (Exception e) {
            if (e.getMessage().contains("RESOURCE_EXHAUSTED")) {
                LogUtil.logError("The NLP Quota get exhausted,retrying the process",e,logModel,LOG);
                throw e;
            } else {
                throw new BellDataFlowAppApplicationException("ERRNLP113-Unable to call Sentiment " +
                        "analysis API " +
                        e.getMessage(), e);
            }
        }
        long gcpEndTime = System.currentTimeMillis();
        if(log) LogUtil.log("NLP Sentiment analysis successful for conversation: ",
                logModel,
                "Time taken ",
                gcpEndTime - nlpStartTime,LOG);
        return sentimentResponse;
    }


    /**
     * This method is call when only entities Response is only need for analysis.
     * @param event
     * @param doc
     * @param logModel
     * @param nlpStartTime
     * @param log
     * @return entityResponse
     * @throws BellDataFlowAppApplicationException
     */
    private AnalyzeEntitiesResponse getEntityAnalysis(
            TranscriptionMessage.ConversationEvent event,
                                                          Document doc,
                                                          LoggerModel logModel,
            long nlpStartTime,
            boolean log)
            throws BellDataFlowAppApplicationException{
        if(log) LogUtil.log("Calling NLP Entity analysis for conversation :",
                logModel,"Start Time ",
                nlpStartTime,LOG);
        AnalyzeEntitiesResponse entityResponse = null;
        try {
            entityResponse = getAnalyzeEntitiesResponse(doc);
        } catch (Exception e) {
            if (e.getMessage().contains("RESOURCE_EXHAUSTED")) {
                LogUtil.logError("The NLP Quota get exhausted,retrying the process",e,logModel,LOG);
                throw e;
            } else {
                throw new BellDataFlowAppApplicationException("ERRNLP103-Unable to call Entity API " +
                        e.getMessage(), e);
            }
        }
        long gcpEndTime = System.currentTimeMillis();
        if(log) LogUtil.log("NLP Entity analysis successful for conversation: ",
                logModel,
                "Time taken ",
                gcpEndTime - nlpStartTime,LOG);
        return entityResponse;
    }


    /**
     * This Method is call when when both the Sentiment and entities method is only need for analysis.
     * @param event
     * @param doc
     * @param logModel
     * @param nlpStartTime
     * @return NLPSentimentandentitiesoutput
     * @throws BellDataFlowAppApplicationException
     */
    private TranscriptionMessage.ConversationEvent getEntityAndSentimentAnalysis(
            TranscriptionMessage.ConversationEvent event,
                                                Document doc,
                                                LoggerModel logModel,
                                                long nlpStartTime)
            throws BellDataFlowAppApplicationException{
        LogUtil.log("The Sentiment and Entity conversation :", logModel,"Start Time ",
                nlpStartTime,LOG);

        AnalyzeSentimentResponse sentimentResponse = getSentimentAnalysis(event,doc,logModel,nlpStartTime,false);
        AnalyzeEntitiesResponse entityResponse = getEntityAnalysis(event,doc,logModel,nlpStartTime,false);
        TranscriptionMessage.ConversationEvent NLPSentimentandentitiesoutput = NlpUtil.getEntitiesAndSentimentAnalysis(event,
                sentimentResponse, entityResponse, nlpStartTime,logModel);
        long gcpEndTime = System.currentTimeMillis();

        LogUtil.log("Sentiment and Entity Processing time for conversation:", logModel,
                            "Time taken ",
                            gcpEndTime - nlpStartTime,LOG);

        return NLPSentimentandentitiesoutput;
    }

}