package com.economical.sdp;
import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jms.JmsException;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.objenesis.strategy.SingleInstantiatorStrategy;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.jms.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

@SpringBootApplication
@RestController
@EnableJms
public class MqMessageGenApplication {
    //dtbd1
//    private static final String HOST = "10.208.220.201";
//    private static final String QUEUE_MANAGER = "DTBD1";
//    private static final Integer PORT = 14500;

  // DT7D1 Sandhya's test env
//
//    private static final String HOST = "10.208.220.199";
//    private static final String QUEUE_MANAGER = "DT7D1";
//    private static final Integer PORT = 14500;


    // STD1   Pranaya's test env

//    private static final String HOST = "dbar1uxib25.economicalinsurance.com";
//    private static final String QUEUE_MANAGER = "STAD1";
//    private static final Integer PORT = 24500;

// RSP event

    private static final String HOST = "10.208.221.207";
    private static final String QUEUE_MANAGER = "EDHOD70";
    private static final Integer PORT = 10270;


    private static final String USERNAME = "edhflu01";
    private static final String PASSWORD = "welcome1";

    // VSEDH 1 and two envs
    //private static final String QUEUE_MANAGER = "VSEDH2";
    //private static final String HOST = "dbar1uxmb19.economicalinsurance.com";
    //private static final Integer PORT = 13202;


    private static final String CHANNEL = "SYSTEM.ADMIN.SVRCONN";
    //private static final String QUEUE = "ICM.COMMISSIONS_CHQ_PAYMENT.DATAHUB.DGM.Q";//"PC.POLICY_EVENT.DATAHUB.DGM.Q";
   //private static final String QUEUE = "ICM.COMMISSIONS_EFT_PAYMENT.DATAHUB.DGM.Q";
  //private static final String QUEUE = "BC.BILLING_EVENT.DATAHUB.DGM.Q";
    //private static final String QUEUE = "BC.INITICHRG_EVENT.DATAHUB.DGM.Q";
   //private static final String QUEUE ="BC.CTRL_EVENT.DATAHUB.DGM.Q";
    //private static final String QUEUE ="PC.CTRL_EVENT.DATAHUB.DGM.Q";
   //private static final String QUEUE = "BC.BILLING_EVENT.DATAHUB.DGM.Q";
  // private static final String QUEUE = "MS.QUEUE_REPO.DATAHUB.Q";
    private static final String QUEUE = "PC.POLICY_EVENT.DATAHUB.DGM.Q";
   // private static final String QUEUE = "BC.SCD_EVENT.DATAHUB.DGM.Q";
    //private static final String QUEUE = "MS.NEWSUBMISSION_REPO.DATAHUB.Q";
  // private static final String QUEUE ="EFT.COMMISSIONS_PAYMENT_RESPONSE.DATAHUB.DGM.Q";
   // private static final String QUEUE ="EFT.EFT_STL_RESPONSE.DATAHUB.DGM.Q";
   //private static final String QUEUE ="EFT.EFT_RESPONSE.DATAHUB.DGM.Q";
   // private static final String QUEUE ="CHQ.COMMISSIONS_PAYMENT_RESPONSE_2.DATAHUB.DGM.Q";
  //  private static final String QUEUE = "CHQ.CHQ_DISBURSEMENTS_VERSION_2.DATAHUB.DGM.Q";  // TODO : RETEST WITH DTBD1
    //private static final String QUEUE = "ICM.COMMISSIONS_EFT_PAYMENT.DATAHUB.DGM.Q";
    //private static final String QUEUE = "ICM.COMMISSIONS_CHQ_PAYMENT.DATAHUB.DGM.Q";
   // private static final String QUEUE = "PAYPAL.PAYPAL_TRANSACTIONS.DATAHUB.DGM.Q";
//    private static final String QUEUE =  "MONERIS.CC_CUSTOMREPORT_PAYMENTS.DATAHUB.DGM.Q";
    //private static final String QUEUE =      "MONERIS.CC_DISBURSEMENTS.DATAHUB.DGM.Q";  // TODO : RETEST with new dag
   // private static final String QUEUE =      "MONERIS.CC_PAYMENTS.DATAHUB.DGM.Q";
    //private static final String QUEUE = "LOCKBOX.LOCKBOX_PAYMENTS.DATAHUB.DGM.Q";
  //  private static final String QUEUE = "FARCS.AUDIT.GW.API.XML.Q";
//    private static final String QUEUE  =
   // private static final String QUEUE  ="BC.CREDITCARD_EXPIRY.DATAHUB.DGM.Q";
    //private static final String QUEUE  ="BC.CHQ_DISBURSEMENTS.DATAHUB.DGM.Q";
    //private static final String QUEUE  = "BC.DEL_COLLECTIONS.DATAHUB.DGM.Q";
    //private static final String QUEUE  = "BC.NEW_COLLECTIONS.DATAHUB.DGM.Q";

    //private static final String QUEUE  = "BC.UPD_COLLECTIONS.DATAHUB.DGM.Q";

//    private static final String QUEUE  = "STANDARDBANKING.STD_PAYMENTS.DATAHUB.DGM.Q";
   // private static final String QUEUE  = "BC.ABCYCLE_EVENT.DATAHUB.DGM.Q";
   // private static final String QUEUE  = "BC.EFT_PAYMENTS.DATAHUB.DGM.Q";


//    private static final String QUEUE  = "BC.EFT_DISBURSEMENTS.DATAHUB.DGM.Q";

//    private static final String QUEUE = "BC.CC_PAYMENTS.DATAHUB.DGM.Q";



    //private static final String QUEUE = "BC.CC_DISBURSEMENTS.DATAHUB.DGM.Q";//"ICM.COMMISSIONS_CHQ_PAYMENT.DATAHUB.DGM.Q";
   // private static final String QUEUE = "BC.ABCMSN_EVENT.DATAHUB.DGM.Q";//"ICM.COMMISSIONS_EFT_PAYMENT.DATAHUB.DGM.Q";
    //private static final String QUEUE = "BC.ABCMSNCTRL_EVENT.DATAHUB.DGM.Q";//"ICM.COMMISSIONS_EFT_PAYMENT.DATAHUB.DGM.Q";
   // private static final String QUEUE = "CDS.REGISTRATION.DATAHUB_CLAIM.DGM.Q";//"ICM.COMMISSIONS_EFT_PAYMENT.DATAHUB.DGM.Q";

    private static MQConnectionFactory connectionFactory;

    @Autowired
    private JmsTemplate jmsTemplate;

    public static void main(String[] args) throws IOException, JMSException {

        SpringApplication.run(MqMessageGenApplication.class, args);
        System.out.println("Hello World!!");
        sendMessages();
    }

    public static void init() throws JMSException {
        connectionFactory = new MQConnectionFactory();
        connectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
        connectionFactory.setHostName(HOST);
        connectionFactory.setPort(PORT);
        connectionFactory.setQueueManager(QUEUE_MANAGER);
        connectionFactory.setChannel(CHANNEL);
        connectionFactory.setStringProperty(WMQConstants.USERID, USERNAME);
        connectionFactory.setStringProperty(WMQConstants.PASSWORD, PASSWORD);
    }

    public  static void sendMessages() throws JMSException, IOException {
        init();
        Connection connection = connectionFactory.createConnection();
        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        Queue q2 = session.createQueue(QUEUE);
        System.out.println("Queue:" + q2.toString());
        MessageProducer producer = session.createProducer(q2);
        for (int i = 1; i <= 2; i++) {
            Path fileName
                    = Path.of("C:\\Users\\njs\\GIT_REPO\\MQ_INGESTION_DATAFLOW\\MqMessageProducer\\src\\main\\resources\\test_xml.xml");
            String str;
            str = Files.readString(fileName);

           // sending JMSTextMessage
           TextMessage message = session.createTextMessage(str);
           producer.send(message);

            // sending JMSBytMessage
//          BytesMessage bytesMessage = session.createBytesMessage();
//            bytesMessage.writeBytes(str.getBytes());
//            producer.send(bytesMessage);

            System.out.println("sent");
        }
    }

    @GetMapping("send")
    String send() {
        try {
            //jmsTemplate.convertAndSend(QUEUE, "Hello World!");
            init();
            sendMessages();
            return "OK";
        } catch (JmsException ex) {
            ex.printStackTrace();
            return "FAIL";
        } catch (Exception e) {
            e.printStackTrace();
            return "FAIL";
        }
    }

    @GetMapping("recv")
    String recv() {
        try {
            return jmsTemplate.receiveAndConvert(QUEUE).toString();
        } catch (JmsException ex) {
            ex.printStackTrace();
            return "FAIL";
        }
    }
}
