package com.bell.stt.acc.builders;

import com.bell.stt.avro.Context;
import com.bell.stt.acc.serialization.KafkaSerializationFunction;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.kafka.clients.producer.Producer;

import java.util.Map;

/**
 * A builder class to build Kafka serialization
 */
public class KafkaSerializationBuilder {

    private String keytabSecretId;
    private String trustStoreSecretId;
    private String trustStorePassword;
    private String krbFilePath;
    private String krbPrincipal;
    private String secretProjectId;
    private String kerberosServiceNameForKafka;
    private String schemaRegistryUrl;
    private String securityProtocol;

    public KafkaSerializationBuilder setKeytabSecretId(String keytabSecretId) {
        this.keytabSecretId = keytabSecretId;
        return this;
    }

    public KafkaSerializationBuilder setTrustStoreSecretId(String trustStoreSecretId) {
        this.trustStoreSecretId = trustStoreSecretId;
        return this;
    }

    public KafkaSerializationBuilder setTrustStorePassword(String trustStorePassword) {
        this.trustStorePassword = trustStorePassword;
        return this;
    }

    public KafkaSerializationBuilder setKrbFilePath(String krbFilePath) {
        this.krbFilePath = krbFilePath;
        return this;
    }

    public KafkaSerializationBuilder setKrbPrincipal(String krbPrincipal) {
        this.krbPrincipal = krbPrincipal;
        return this;
    }

    public KafkaSerializationBuilder setSecretProjectId(String secretProjectId) {
        this.secretProjectId = secretProjectId;
        return this;
    }

    public KafkaSerializationBuilder setKerberosServiceNameForKafka(String kerberosServiceNameForKafka) {
        this.kerberosServiceNameForKafka = kerberosServiceNameForKafka;
        return this;
    }

    public KafkaSerializationBuilder setSchemaRegistryUrl(String schemaRegistryUrl) {
        this.schemaRegistryUrl = schemaRegistryUrl;
        return this;
    }

    public KafkaSerializationBuilder setSecurityProtocol(String securityProtocol) {
        this.securityProtocol = securityProtocol;
        return this;
    }

    public SerializableFunction<Map<String, Object>, Producer<String, Context>> createKafkaProducer() {
        return new KafkaSerializationFunction(keytabSecretId, trustStoreSecretId,
                trustStorePassword, krbPrincipal,
                secretProjectId, kerberosServiceNameForKafka, schemaRegistryUrl, securityProtocol);
    }
}