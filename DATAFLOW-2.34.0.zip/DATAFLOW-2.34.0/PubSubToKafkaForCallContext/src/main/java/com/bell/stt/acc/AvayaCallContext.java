package com.bell.stt.acc;

import com.bell.stt.acc.kafka.KafkaHelper;
import com.bell.stt.acc.options.AvayaCallContextOptions;
import com.bell.stt.proto.ContextOuterClass;
import com.bell.stt.acc.transformers.AvayaCallContextParDo;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.kafka.KafkaIO;
import org.apache.beam.sdk.metrics.MetricNameFilter;
import org.apache.beam.sdk.metrics.MetricQueryResults;
import org.apache.beam.sdk.metrics.MetricResult;
import org.apache.beam.sdk.metrics.MetricsFilter;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class for reading the call context from pubsub
 * Transform to Avro
 * Write to Output Kafka
 */
public class AvayaCallContext {


    //private static final String TYPENAME = "type_name";
    private static final Logger LOG = LoggerFactory.getLogger(AvayaCallContext.class);

    /**
     * Entry point for the data flow job
     * @param args pipeline arguments
     */
    public static void main(String[] args) {

        // Parse the user options passed from the command-line
        AvayaCallContextOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(AvayaCallContextOptions.class);

        options.setStreaming(true);
        PipelineResult result = run(options);

// request the metric called "counter1" in namespace called "namespace"
        MetricQueryResults metrics =
                result
                        .metrics()
                        .queryMetrics(
                                MetricsFilter.builder()
                                        .addNameFilter(MetricNameFilter.named("STT-AvayaPubsubToKafka", "PUBSUBTOKAFKA_STT_SUCCESS"))
                                        .addNameFilter(MetricNameFilter.named("STT-AvayaPubsubToKafka", "PUBSUBTOKAFKA_STT_FAILURE"))
                                        .build());


        for (MetricResult<Long> counter : metrics.getCounters()) {
            System.out.println(counter.getName() + ":" + counter.getAttempted());
        }
    }

    /**
     * The pipeline run method containing the DAG.
     * @param options pipeline options
     * @return pipeline result
     */
    public static PipelineResult run(AvayaCallContextOptions options) {
        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);

        /**
         * Steps:
         *      1) Read PubSubMessage from input PubSub subscription.
         *      2) Apply any filters if an attribute=value pair is provided.
         *      3) Write each PubSubMessage to output PubSub topic.
         */
        try {
            PubsubIO.Read<ContextOuterClass.Context> messages =
                    PubsubIO.readProtos((Class) ContextOuterClass.Context.class).fromSubscription(options.getInputSubscription());
            PCollection<KV<String, com.bell.stt.avro.Context>> stringMessages = pipeline.apply(messages).apply(ParDo.of(new AvayaCallContextParDo()));
            stringMessages.apply("Write to Kafka Topic", KafkaIO.<String, com.bell.stt.avro.Context>write().
                    withProducerFactoryFn(KafkaHelper.serializationBuilder(options).createKafkaProducer())
                    .withBootstrapServers(options.getBootstrapServers().get())
                    .withTopic(options.getOutputTopic().get())
                    .withValueSerializer((Class) KafkaAvroSerializer.class)
                    .withKeySerializer(StringSerializer.class)
            );
        } catch (Exception e) {
            LOG.error("S2T-ERR301 - Error processing the pipeline ", e);
        }
        // Execute the pipeline and return the result.
        return pipeline.run();

    }
}
