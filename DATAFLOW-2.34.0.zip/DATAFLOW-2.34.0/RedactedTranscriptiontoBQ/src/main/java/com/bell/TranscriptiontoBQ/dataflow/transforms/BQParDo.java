/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.TranscriptiontoBQ.dataflow.transforms;



import com.bell.TranscriptiontoBQ.dataflow.util.BQTableRow;
import com.bell.stt.proto.TranscriptionMessage;
import com.google.api.services.bigquery.model.TableRow;
import com.google.protobuf.Duration;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.beam.sdk.metrics.Distribution;
import org.apache.beam.sdk.metrics.Metrics;

/**
 * This BQ pardo function will do the transformation from event to table row.
 */

public class BQParDo extends DoFn<TranscriptionMessage.ConversationEvent,TableRow> {

    static final Logger LOG = LoggerFactory.getLogger(BQParDo.class);
    private final Counter Success_counter = Metrics.counter("Transcription-PubsubToBigquery", "PUBSUBTOBIGQUERY_Transcription_SUCCESS");
    private final Counter failure_counter = Metrics.counter("Transcription-PubsubToBigquery", "PUBSUBTOBIGQUERY_Transcription_FAILURE");

    final TupleTag<TranscriptionMessage.ConversationEvent> DLQ;
    final TupleTag<TableRow> SUCCESS;

    public BQParDo(TupleTag<TranscriptionMessage.ConversationEvent> DLQ, TupleTag<TableRow> SUCCESS) {
        this.DLQ = DLQ;
        this.SUCCESS = SUCCESS;
    }


    @ProcessElement
    public void processElement(ProcessContext c,MultiOutputReceiver out) {

        TranscriptionMessage.ConversationEvent event = c.element();

        String conversationId =event.getConversation();
        String type =  event.getType().toString();
        String ParticipantId =event.getNewMessagePayload().getParticipant();
       // String utteranceWordCount = event.getNewMessagePayload().getWordCount();
        com.google.protobuf.Timestamp stream_start_time =event.getNewMessagePayload().getSpeechToTextInfo().getStreamStartTime();
        com.google.protobuf.Duration utterance_start_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceStartOffset();
        com.google.protobuf.Duration utterance_end_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceEndOffset();
        long bqStartTime = System.currentTimeMillis();

        try{
            long startTime= System.currentTimeMillis();
            log("The BQPardo calling for  conversation :", conversationId, ParticipantId,
                    stream_start_time, utterance_start_offset, utterance_end_offset,"Start Time ",
                    bqStartTime);
            if (type == "NEW_MESSAGE" || type.equalsIgnoreCase("NEW_MESSAGE" )|| type.contains("NEW_MESSAGE") ){
             TableRow table =BQTableRow.buildTableRows(event,System.currentTimeMillis());

              c.output(SUCCESS,table) ;

            long endTime= System.currentTimeMillis();
            log("The BQPardo calling successfully completed for  conversation :",
                    conversationId, ParticipantId, stream_start_time,
                    utterance_start_offset, utterance_end_offset,"Time taken ", (endTime-bqStartTime));

            Success_counter.inc();

            }else{
                
                log("The BQPardo calling for  conversation is skipped as the type is :"+type, conversationId, ParticipantId,
                    stream_start_time, utterance_start_offset, utterance_end_offset,"Start Time ",
                    bqStartTime);
    
            }

    } catch (Exception e) {
            LOG.error("ERRBQ102 - Unable to Write into BigQuery and publish the failed message into DLQ topics"
                    +" Conversation id: " + conversationId + " Participantid: " +ParticipantId + ", Stream_Start_Time: "+ stream_start_time + ", Utterance_start_offset: "
                    +utterance_start_offset+  ", Utterance_end_offset: " + utterance_end_offset,e);
        LOG.error(e.getMessage());

        c.output(DLQ,c.element());
            failure_counter.inc();

        }
    }

    private void log(String prefix,
                     String conversationId, String participantId,
                      com.google.protobuf.Timestamp stream_start_time,
                     Duration utterance_start_offset, Duration utterance_end_offset, String time , long timeTakenMs) {

        String logMessage=prefix + " ConversationId: " + conversationId + ", ParticipantId: " + participantId  + ", Stream_Start_Time: " + stream_start_time +
                ", Utterance_start_offset: " + utterance_start_offset + ", utterance_end_offset: "
                + utterance_end_offset + ", "+time + timeTakenMs+"ms";

        LOG.debug(logMessage.replace("\r","").replace("\n",""));
    }

}

