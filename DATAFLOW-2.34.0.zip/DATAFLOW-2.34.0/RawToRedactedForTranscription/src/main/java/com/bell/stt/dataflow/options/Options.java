package com.bell.stt.dataflow.options;

import org.apache.beam.sdk.options.*;

public interface Options extends PipelineOptions, StreamingOptions {

    @Description(
            "The Cloud Pub/Sub subscription to consume from. "
                    + "The name should be in the format of "
                    + "projects/<project-id>/subscriptions/<subscription-name>.")
    @Validation.Required
    ValueProvider<String> getInputSubscription();

    void setInputSubscription(ValueProvider<String> inputSubscription);

    @Description(
            "The Cloud Pub/Sub topic to publish to. "
                    + "The name should be in the format of "
                    + "projects/<project-id>/topics/<topic-name>.")
    @Validation.Required
    ValueProvider<String> getOutputTopic();

    void setOutputTopic(ValueProvider<String> outputTopic);

    @Description(
            "The timer to batch the pubsub messages.")
    @Validation.Required
    ValueProvider<Long> getTimer();

    void setTimer(ValueProvider<Long> timer);

    @Description(
            "The project id of the DLP service.")
    @Validation.Required
    ValueProvider<String> getDLPProjectId();

    void setDLPProjectId(ValueProvider<String> projectId);

    @Description(
            "The path to inspect template")
    @Validation.Required
    ValueProvider<String> getInspectTemplateName();

    void setInspectTemplateName(ValueProvider<String> inspectTemplateName);

    @Description(
            "The path to deidentify template")
    @Validation.Required
    ValueProvider<String> getIdentifyTemplateName();

    void setIdentifyTemplateName(ValueProvider<String> identifyTemplateName);

    @Description(
            "The request batch size for DLP.")
    @Validation.Required
    ValueProvider<Integer> getDLPBatchSizeThreshold();

    void setDLPBatchSizeThreshold(ValueProvider<Integer> batchSizeThreshold);

    @Description(
            "The batch size for batching transcriptions ")
    @Validation.Required
    ValueProvider<Integer> getBatchSize();

    void setBatchSize(ValueProvider<Integer> batchSize);

    @Description(
            "Number of batches (partitions), each batch will be processed by 1 worker")
    @Validation.Required
    ValueProvider<Integer> getBatchNum();

    void setBatchNum(ValueProvider<Integer> batchNum);
}
