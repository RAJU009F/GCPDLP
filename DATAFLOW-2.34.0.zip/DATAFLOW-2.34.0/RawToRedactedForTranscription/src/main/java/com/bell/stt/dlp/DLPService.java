package com.bell.stt.dlp;


import com.bell.stt.proto.TranscriptionMessage.*;
import com.google.privacy.dlp.v2.*;
import com.google.protobuf.util.Durations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class DLPService {

    private static final Logger LOG = LoggerFactory.getLogger(DLPService.class);

    /**
     * Method builds the payload for DLP from incoming iterable of transcription
     *
     * @param pubSubMessages
     * @return
     */
    public static ContentItem buildDLPPayload(List<ConversationEvent> pubSubMessages) {
        List<Table.Row> rows = new ArrayList<>();
        List<ConversationEvent> transList = pubSubMessages;
        for (ConversationEvent tr : transList) {
            rows.add(Table.Row.newBuilder().addValues(Value.newBuilder().setStringValue(tr.getNewMessagePayload().getContent()).build()).build());
        }
        Table tableToDeIdentify = Table.newBuilder()
                .addHeaders(FieldId.newBuilder().setName("CONTENT").build())
                .addAllRows(rows)
                .build();
        ContentItem contentItem = ContentItem.newBuilder().setTable(tableToDeIdentify).build();
        return contentItem;
    }

    /**
     * Method merges the redacted content with the transcription payload
     * from input
     *
     * @param pubSubMessages
     * @param dlpResp
     * @return
     */
    public static List<ConversationEvent> buildDLPRedactedPayload(List<ConversationEvent> pubSubMessages, DeidentifyContentResponse dlpResp) {
        // This is where you merge the DLP response with the request.
        // Also there is a words array where you have to sort based on timeline.
        List<Table.Row> dlpRespObj = dlpResp.getItem().getTable().getRowsList();
        List<ConversationEvent> responseList = new ArrayList<>();
        for (int i = 0; i < pubSubMessages.size(); i++) {
            ConversationEvent transcription = pubSubMessages.get(i);
            ConversationEvent.Builder clonedTranscription = ConversationEvent.newBuilder();
            clonedTranscription.setConversation(transcription.getConversation());
            clonedTranscription.setErrorStatus(transcription.getErrorStatus());
            clonedTranscription.setType(transcription.getType());
            Message.Builder msg = Message.newBuilder();
            msg.setCreateTime(transcription.getNewMessagePayload().getCreateTime());
            msg.setParticipantRole(transcription.getNewMessagePayload().getParticipantRole());
            msg.setParticipant(transcription.getNewMessagePayload().getParticipant());
            msg.setContent(dlpRespObj.get(i).getValues(0).getStringValue());
            msg.setLanguageCode(transcription.getNewMessagePayload().getLanguageCode());
            msg.setMessageAnnotation(transcription.getNewMessagePayload().getMessageAnnotation());
            msg.setSentimentAnalysis(transcription.getNewMessagePayload().getSentimentAnalysis());

            Message.SpeechToTextInfo.Builder s2tInfo = Message.SpeechToTextInfo.newBuilder();

            s2tInfo.setStreamStartTime(transcription.getNewMessagePayload().getSpeechToTextInfo().getStreamStartTime());
            s2tInfo.setUtteranceStartOffset(transcription.getNewMessagePayload().getSpeechToTextInfo().getUtteranceStartOffset());
            s2tInfo.setUtteranceEndOffset(transcription.getNewMessagePayload().getSpeechToTextInfo().getUtteranceEndOffset());

            int wordIndex = 0;
            ArrayList<Message.SpeechWordInfo> wlist = new ArrayList<>(transcription.getNewMessagePayload().getSpeechToTextInfo().getSpeechWordInfoList());
            wlist.sort(Comparator.comparing(w -> Durations.toMillis(w.getStartOffset())));

            for (Message.SpeechWordInfo originalWord : wlist) {

                try {
                    Message.SpeechWordInfo.Builder words = Message.SpeechWordInfo.newBuilder();
                    words.setConfidence(originalWord.getConfidence());
                    words.setStartOffset(originalWord.getStartOffset());
                    words.setEndOffset(originalWord.getEndOffset());
                    words.setWord(redactTexts(dlpRespObj.get(i).getValues(0).getStringValue(), originalWord.getWord(), wordIndex));
                    wordIndex++;
                    s2tInfo.addSpeechWordInfo(words.build());
                }
                catch (Exception e){
                    LOG.error("S2T-ERR105 - Error reassigning word list", e);
                }
            }
            msg.setSpeechToTextInfo(s2tInfo);

            clonedTranscription.setNewMessagePayload(msg.build());
            responseList.add(clonedTranscription.build());
        }
        return responseList;
    }

    public static String redactTexts(String redactedContent, String word, int wordIndex) {
        /**
         * Method to merge the redacted words only.
         * @param redactedContent
         * @param word
         * @param wordIndex
         * @return
         */
        String output = "";
        List<String> redactedWords = new ArrayList<String>();

        try{
            redactedWords = Arrays.asList(redactedContent.split(" "));

            if (redactedWords.size() <= wordIndex || !redactedWords.get(wordIndex).equals(word)) {
                for (int i = 0; i < word.length(); i++) {
                    output += "#";
                }
            }
            else {
                output = word;
            }

        }catch (Exception e){
            LOG.error("S2T-ERR106 - Error cleaning word list", e);
        }

        return output;
    }
}
