package com.bell.stt.test;

import com.bell.stt.dlp.DLPService;
import com.bell.stt.proto.TranscriptionMessage.*;
import com.google.privacy.dlp.v2.*;
import com.google.protobuf.Any;
import com.google.protobuf.ByteString;
import com.google.protobuf.util.Durations;
import com.google.protobuf.util.Timestamps;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RunWith(JUnit4.class)
public class PubsubToPubsubTest {
    private DeidentifyContentResponse buildRedactedPayload(String strVal) {
        DeidentifyContentResponse.Builder dr = DeidentifyContentResponse.newBuilder();
        List<Table.Row> rows = new ArrayList<Table.Row>();
        rows.add(Table.Row.newBuilder().addValues(Value.newBuilder().setStringValue(strVal).build()).build());
        Table tableToDeIdentify = Table.newBuilder()
                .addHeaders(FieldId.newBuilder().setName("CONTENT").build())
                .addAllRows(rows)
                .build();
        ContentItem contentItem = ContentItem.newBuilder().setTable(tableToDeIdentify).build();
        dr.setItem(contentItem);
        return dr.build();
    }

    private ConversationEvent createProtoRecord(int i, long time, String setCont) {
        ConversationEvent.Builder transcription = ConversationEvent.newBuilder();

        try {
            transcription.setConversation("Test Conversation" + i);
            transcription.setType(ConversationEvent.Type.CONVERSATION_STARTED);

            Message.Builder msg = Message.newBuilder();
            msg.setLanguageCode("en-US");
            msg.setParticipant("participant" + i);
            msg.setName("project1/message1/" + i);
            msg.setCreateTime(Timestamps.parse("1969-12-31T23:59:59Z"));
            msg.setContent(setCont);

            Message.SpeechToTextInfo.Builder s2tInfo = Message.SpeechToTextInfo.newBuilder();

            s2tInfo.setUtteranceEndOffset(Durations.parse("12345.1s"));
            s2tInfo.setUtteranceStartOffset(Durations.parse("12345.1s"));
            s2tInfo.setStreamStartTime(Timestamps.parse("1969-12-31T23:59:59Z"));


            String[] txtWords = setCont.split(" ");
            for (i = 0; i < txtWords.length; i++) {
                Message.SpeechWordInfo.Builder wordInfo = Message.SpeechWordInfo.newBuilder();
                wordInfo.setWord(txtWords[i]).setEndOffset(Durations.parse("12345.1s")).setStartOffset(Durations.parse("12345.1s")).setConfidence(1f);
                s2tInfo.addSpeechWordInfo(wordInfo.build());
            }
            msg.setSpeechToTextInfo(s2tInfo);

            transcription.setNewMessagePayload(msg.build());
        } catch (Exception exception) {

        }


        return transcription.build();
    }

    @Test
    public void verifybuildDLPPayload() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "Redact the password $123456#"));
        ContentItem item = new DLPService().buildDLPPayload(protoList);
        Assert.assertEquals(protoList.get(0).getNewMessagePayload().getContent(), item.getTable().getRows(0).getValues(0).getStringValue());
    }

    @Test
    public void verifybuildDLPRedactedPayload() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "Redact the password $123456#"));
        DeidentifyContentResponse dr = this.buildRedactedPayload("Redact the password ########");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void customRule01() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "terminator_267"));
        DeidentifyContentResponse dr = this.buildRedactedPayload("##############");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void customRule02_01() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "dollar 12321 test 456 dollar amount, 6 calls"));
        DeidentifyContentResponse dr = this.buildRedactedPayload("dollar ##### test 456 dollar ####### 6 calls");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void customRule02_02() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "numeric sequence ten digits 6131234564 2231234564"));
        DeidentifyContentResponse dr = this.buildRedactedPayload("numeric sequence ten digits 6131234564 ##########");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void customRule02_03() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "numeric sequence eleven digits 18331234564 18221234564"));
        DeidentifyContentResponse dr = this.buildRedactedPayload("numeric sequence eleven digits 18331234564 ###########");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void customRule05() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "test amount $34.56"));
        DeidentifyContentResponse dr = this.buildRedactedPayload("test amount $34.56");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void rule_CANADA_BANK_ACCOUNT() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "Canadian bank account number 12345-001-12345678."));
        DeidentifyContentResponse dr = this.buildRedactedPayload("Canadian bank account number ###################");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void rule_CANADA_BC_PHN() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "Personal Health Number 9876-543-214"));
        DeidentifyContentResponse dr = this.buildRedactedPayload("Personal Health Number ############");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void rule_CANADA_DRIVERS_LICENSE_NUMBER() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "Driver's licence PO-LL-AJ-M-304PR"));
        DeidentifyContentResponse dr = this.buildRedactedPayload("######## licence ################");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void rule_CANADA_OHIP() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "Ontario 9876-543-217"));
        DeidentifyContentResponse dr = this.buildRedactedPayload("Ontario ############");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void rule_CANADA_PASSPORT() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "Numéro de passeport WJ123456."));
        DeidentifyContentResponse dr = this.buildRedactedPayload("Numéro de passeport #################");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void rule_CREDIT_CARD_NUMBER() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "He paid with 4012-8888-8888-1881."));
        DeidentifyContentResponse dr = this.buildRedactedPayload("He paid with #######################################");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }


    @Test
    public void rule_FIRST_NAME() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "Bob"));
        DeidentifyContentResponse dr = this.buildRedactedPayload("###");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void rule_PASSWORD() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "my password is timothy98"));
        DeidentifyContentResponse dr = this.buildRedactedPayload("my password is #########");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void rule_DATE() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "Tony turned 10 on 05/05/2022."));
        DeidentifyContentResponse dr = this.buildRedactedPayload("#### turned ## on ###########");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void rule_DATE_OF_BIRTH() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "Bob"));
        DeidentifyContentResponse dr = this.buildRedactedPayload("###");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void rule_AGE() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "The player turns 32 years old in the fall."));
        DeidentifyContentResponse dr = this.buildRedactedPayload("The player turns ############## in the #####");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void rule_PASSPORT() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "The agency issued US passport number 017384251."));
        DeidentifyContentResponse dr = this.buildRedactedPayload("The agency issued US passport number ##########");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void rule_CREDIT_CARD_TRACK_NUMBER() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "Card track %B4444333322221111^TEST CARD/VISA^4907101?"));
        DeidentifyContentResponse dr = this.buildRedactedPayload("Card track #########################ARD/VISA^4907101?");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void rule_PERSON_NAME() {
        List<ConversationEvent> protoList = new ArrayList<>();
        long time = System.currentTimeMillis();
        protoList.add(createProtoRecord(1, time, "John Smith wore pink shoes to prom."));
        DeidentifyContentResponse dr = this.buildRedactedPayload("############## wore pink shoes to #####");
        List<ConversationEvent> redacted = new DLPService().buildDLPRedactedPayload(protoList, dr);
        Assert.assertEquals(dr.getItem().getTable().getRowsList().get(0).getValues(0).getStringValue(), redacted.get(0).getNewMessagePayload().getContent());
    }

    @Test
    public void redactTexts_Normal_Content() {
        String originalText = "John Smith wore pink shoes to prom.";
        String[] redactedWords = originalText.split(" ");
        List<String> postRedactionText = new ArrayList();
        for (int i = 0; i < redactedWords.length; i++) {
            postRedactionText.add(new DLPService().redactTexts(originalText, redactedWords[i], i));
        }
        String postRedactionString = String.join(" ", postRedactionText);
        Assert.assertEquals(originalText, postRedactionString);
    }

    @Test
    public void redactTexts_Redacted_Content_Not_Case() {
        String originalText = "John Smith wore pink shoes to prom.";
        String redactedText = "John Smith wore pink shoes to #####";
        String[] redactedWords = originalText.split(" ");
        List<String> postRedactionText = new ArrayList();
        for (int i = 0; i < redactedWords.length; i++) {
            postRedactionText.add(new DLPService().redactTexts(redactedText, redactedWords[i], i));
        }
        String postRedactionString = String.join(" ", postRedactionText);
        Assert.assertEquals(redactedText, postRedactionString);
    }

    @Test
    public void redactTexts_Redacted_Content_With_Duplicate_Words() {
        String originalText = "167 I have 167 dollars";
        String redactedText = "### I have 167 dollars";
        String[] redactedWords = originalText.split(" ");
        List<String> postRedactionText = new ArrayList();
        for (int i = 0; i < redactedWords.length; i++) {
            postRedactionText.add(new DLPService().redactTexts(redactedText, redactedWords[i], i));
        }
        String postRedactionString = String.join(" ", postRedactionText);
        Assert.assertEquals(redactedText, postRedactionString);
    }

    @Test
    public void redactTexts_Redacted_Content_SPEC() {
        String originalText = "Il est de 123456 qui est très élevé";
        String redactedText = "Il est de ###### qui est très élevé";
        String[] redactedWords = originalText.split(" ");
        List<String> postRedactionText = new ArrayList();
        for (int i = 0; i < redactedWords.length; i++) {
            postRedactionText.add(new DLPService().redactTexts(redactedText, redactedWords[i], i));
        }
        String postRedactionString = String.join(" ", postRedactionText);
        Assert.assertEquals(redactedText, postRedactionString);
    }

}
