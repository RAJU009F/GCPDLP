package com.bell.stt.converters;

import com.bell.stt.avro.*;
import com.bell.stt.proto.TranscriptionMessage.*;
import com.google.protobuf.util.Durations;
import com.google.protobuf.util.Timestamps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;


/**
 * Class converts the Context in proto format to Context in Avro format
 */
public class ProtoToAvro {
    /*public static ProtobufData protobufData = ProtobufData.get();
    //public static Schema protoSchema = protobufData.getSchema(TranscriptionOuterClass.class);

    public Transcription convertToAvro(TranscriptionOuterClass payload) throws Exception{
        Schema protoSchema = protobufData.getSchema(TranscriptionOuterClass.Transcription.class);
        Object o = protobufData.newRecord(payload, protoSchema);
        ProtobufDatumWriter<Transcription> protobufDatanumWriter = new ProtobufDatumWriter(protoSchema);
        OutputStream out = new ByteArrayOutputStream();
        Encoder encoder = EncoderFactory.get().binaryEncoder(out, null );
        protobufDatanumWriter.write((Transcription)o, encoder);
        return Transcription.fromByteBuffer(ByteBuffer.wrap(((ByteArrayOutputStream) out).toByteArray()));

    }*/

    /**
     * Method converts the proto to Avro payload
     * @param payload incoming context payload in proto format
     * @return Context data in Avro format
     * @throws Exception received when converting proto to avro
     */
    private static final Logger LOG = LoggerFactory.getLogger(ProtoToAvro.class);

    public static Transcription convertToAvroManually(ConversationEvent payload) throws Exception { //Static
        Transcription.Builder avroRecord = Transcription.newBuilder();
        avroRecord.setConversation(payload.getConversation());
        avroRecord.setType(payload.getType().name());

        try {
            Message protoMsg = payload.getNewMessagePayload();
            NewMessagePayload msg = new NewMessagePayload();
            if (protoMsg != null) {
                msg.setContent(protoMsg.getContent());
                msg.setName(protoMsg.getName());
                msg.setLanguageCode(protoMsg.getLanguageCode());
                msg.setParticipant(protoMsg.getParticipant());
                msg.setParticipantRole(protoMsg.getParticipantRole().name());

                msg.setCreateTime(protoMsg.getCreateTime().getSeconds());
                Message.SpeechToTextInfo s2tInfo = protoMsg.getSpeechToTextInfo();
                if (s2tInfo != null) {
                    msg.setStreamStartTime(Timestamps.toMillis(s2tInfo.getStreamStartTime()));
                    msg.setUtteranceStartOffset(Durations.toMillis(s2tInfo.getUtteranceStartOffset()));
                    msg.setUtteranceEndOffset(Durations.toMillis(s2tInfo.getUtteranceEndOffset()));
                }
                List<Words> avroWordsList = new ArrayList<Words>();
                for (Message.SpeechWordInfo words : s2tInfo.getSpeechWordInfoList()) {
                    Words avroWord = new Words();
                    avroWord.setWord(words.getWord());
                    avroWord.setConfidence(words.getConfidence());
                    avroWord.setStartOffset(Durations.toMillis(words.getStartOffset()));
                    avroWord.setEndOffset(Durations.toMillis(words.getEndOffset()));
                    avroWordsList.add(avroWord);
                }
                msg.setWords(avroWordsList);
            }
            avroRecord.setNewMessagePayload(msg);
            }
        catch (Exception e){
            LOG.error("S2T-ERR206 - Unable to convert transcription proto to avro", e);
        }

        avroRecord.setGcpEndTime(System.currentTimeMillis());
        return avroRecord.build();
    }

  /*  public static void main(String[] args) throws Exception{
        TranscriptionOuterClass.Transcription.Builder transcription = TranscriptionOuterClass.Transcription.newBuilder();
        transcription.setConversation("Test Conversation");
        transcription.setType("Test type");
        Transcription tr = new ProtoToAvro().convertToAvroManually(transcription.build());
        System.out.println(tr.getType());
    }*/
}
