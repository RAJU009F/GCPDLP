package com.bell.stt.transformers;

import com.bell.stt.avro.Transcription;
import com.bell.stt.converters.ProtoToAvro;
import com.bell.stt.proto.TranscriptionMessage.*;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The class is responsible for converting the transcription in proto format to
 * Key value pair of conversation Id , Avro format of transcription.
 */
public class KafkaToAvroParDo extends DoFn<ConversationEvent, KV<String,Transcription>> {
    private static final Logger LOG = LoggerFactory.getLogger(KafkaToAvroParDo.class);
    private final Counter Success_counter = Metrics.counter("STT-PubsubToKafka", "PUBSUBTOKAFKA_STT_SUCCESS");
    private final Counter failure_counter = Metrics.counter("STT-PubsubToKafka", "PUBSUBTOKAFKA_STT_FAILURE");

    /**
     * The method converts each proto to avro and writes to output
     * in the key value format.
     * key - conversation id
     * value - Transcription in Avro format
     * @param c - Incoming data
     */
    @ProcessElement
    public void processElement(ProcessContext c) {
        try {
            //LOG.info("Datalog - "+c.element().getConversation()+"-"+c.element().getNewMessagePayload().getUtterenceStartOffset());
            c.output(KV.of(c.element().getConversation(), ProtoToAvro.convertToAvroManually(c.element())));
            Success_counter.inc();
        } catch (Exception e) {
            LOG.error("S2T-ERR203 - Unable to publish to Kafka: " + c.element().getConversation(), e);
            failure_counter.inc();
        }
    }
}
