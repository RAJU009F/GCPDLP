import logging
from datetime import datetime
import pytz
from google.cloud import storage, bigquery
from airflow import DAG
from airflow.exceptions import AirflowException
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator


raw_project_name = Variable.get("raw_project_name")
raw_bucket_name = Variable.get("raw_bucket_name")
curated_project = Variable.get("curated_project_name")
derived_project = Variable.get("derived_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_bucket_name = Variable.get("derived_bucket_name")

policy_index_variables = Variable.get("policy_index_variables", deserialize_json=True)

base_folder_path = policy_index_variables["base_folder_path"]
derived_dataset_name = policy_index_variables["derived_dataset_name"]
local_root_path = policy_index_variables["local_root_path"]
remote_root_path = policy_index_variables["remote_root_path"]
source_file_remote_path = policy_index_variables["source_file_remote_path"]
local_file_path = policy_index_variables["local_file_path"]
remote_file_path = policy_index_variables["remote_file_path"]
legacy_remote_file_path = policy_index_variables["legacy_remote_file_path"]
ftp_conn_id = policy_index_variables["ftp_conn_id"]
filename = policy_index_variables["filename"]
framework_path = policy_index_variables["framework_path"]
job_book_path = policy_index_variables["job_book_path"]
troubleshooting_path = policy_index_variables["troubleshooting_path"]

# GCS client
storage_client = storage.Client(project=raw_project_name)

# Bigquery client
bigquery_client = bigquery.Client(project=curated_project)
est_tz = pytz.timezone("America/Toronto")


def move_files(src_bucket_name, src_blob_name, dest_bucket_name, dest_blob_name):
    """
    Function to move files from one folder to another
    """
    try:
        source_bucket = storage_client.get_bucket(src_bucket_name)
        source_blob = source_bucket.blob(src_blob_name)
        destination_bucket = storage_client.get_bucket(dest_bucket_name)
        dest_blob = source_bucket.copy_blob(
            source_blob, destination_bucket, dest_blob_name
        )
        logging.info(f"File moved from {source_blob} to {dest_blob}")
        if "runtime_" not in dest_blob_name:
            source_blob.delete()
            logging.info(f"File moved from {source_blob} to {dest_blob}")
    except Exception:
        logging.error(f"Error in copying/moving file {src_blob_name}")
        raise AirflowException(f"Error in copying/moving file {src_blob_name}")


def move_file_to_output_folder(**context):
    """
    function to move file from composer bucket to raw bucket
    """
    execution_date = context["dag_run"].conf.get("run_date")

    if execution_date:
        print("Execution date: ", execution_date)
    else:
        execution_date = (
            context["execution_date"].astimezone(est_tz).strftime("%Y-%m-%d")
        )
        print("Execution date: ", execution_date)

    execution_time = datetime.now().astimezone(est_tz).strftime("%Y%m%d%H%M%S%f")[:-3]
    print(execution_date, execution_time)
    output_path = f"{derived_dataset_name}/output/{filename}"
    runtime_output_path = f"{derived_dataset_name}/runtime_{execution_time}/output/{filename}"
    try:
        local_file = f"{derived_dataset_name}/output/{filename}.txt"
        bucket = storage_client.bucket(derived_bucket_name)
        if storage.Blob(bucket=bucket, name=local_file).exists(storage_client):
            move_files(
                derived_bucket_name,
                f"{output_path}.txt",
                derived_bucket_name,
                output_path,
            )
        else:
            if storage.Blob(bucket=bucket, name=output_path).exists(storage_client):
                logging.info(f"File present at: {output_path}")
            else:
                logging.info(f"File not present at: {output_path}")
                raise Exception("file not present")

        if storage.Blob(bucket=bucket, name=output_path).exists(storage_client):
            move_files(
                derived_bucket_name,
                output_path,
                derived_bucket_name,
                runtime_output_path,
            )
            logging.info(
                f"file copied from {output_path} to {runtime_output_path}"
            )

            # copy file to composer bucket
            move_files(
                derived_bucket_name,
                output_path,
                composer_bucket_name,
                f"{local_file_path}/{base_folder_path}/{filename}",
            )
    except Exception as error:
        logging.info(f"Error: {error}")
        raise AirflowException(f"Error: {error}")


with DAG(
    dag_id="ex_product_policy_idex_to_gcs",
    start_date=datetime(2023, 7, 11),
    tags=["daily"],
    schedule_interval=None,
    catchup=False,
) as dag:

    trigger_export_merge_policy_index_from_gw_and_legacy = TriggerDagRunOperator(
        task_id="trigger_export_merge_policy_index_from_gw_and_legacy",
        trigger_dag_id="export_merge_policy_index_from_gw_and_legacy",
        wait_for_completion=True,
        poke_interval=60,
        dag=dag,
    )

    move_file_to_output_folder = PythonOperator(
        task_id="move_file_to_output_folder",
        python_callable=move_file_to_output_folder,
        dag=dag,
    )

dag.doc_md = f"""
### DAG Documentation
- Job Description - Export to GCS job for Policy Index
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""

(
    trigger_export_merge_policy_index_from_gw_and_legacy
    >> move_file_to_output_folder
)
