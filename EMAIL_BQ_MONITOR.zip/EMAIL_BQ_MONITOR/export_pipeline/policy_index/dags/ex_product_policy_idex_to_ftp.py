import logging
from datetime import datetime
import pytz
from google.cloud import storage, bigquery
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.providers.databricks.operators.databricks import (
    DatabricksSubmitRunOperator,
)
from airflow.providers.ftp.operators.ftp import (
    FTPFileTransmitOperator,
    FTPOperation,
)


raw_project_name = Variable.get("raw_project_name")
raw_bucket_name = Variable.get("raw_bucket_name")
curated_project = Variable.get("curated_project_name")
derived_project = Variable.get("derived_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_bucket_name = Variable.get("derived_bucket_name")
policy_id = Variable.get("cdpm_policy_id")

policy_index_variables = Variable.get("policy_index_variables", deserialize_json=True)

base_folder_path = policy_index_variables["base_folder_path"]
derived_dataset_name = policy_index_variables["derived_dataset_name"]
local_root_path = policy_index_variables["local_root_path"]
remote_root_path = policy_index_variables["remote_root_path"]
source_file_remote_path = policy_index_variables["source_file_remote_path"]
local_file_path = policy_index_variables["local_file_path"]
remote_file_path = policy_index_variables["remote_file_path"]
legacy_remote_file_path = policy_index_variables["legacy_remote_file_path"]
ftp_conn_id = policy_index_variables["ftp_conn_id"]
filename = policy_index_variables["filename"]
framework_path = policy_index_variables["framework_path"]
job_book_path = policy_index_variables["job_book_path"]
troubleshooting_path = policy_index_variables["troubleshooting_path"]
databricks_conn_id = policy_index_variables["databricks_conn_id"]
google_service_account = policy_index_variables["google_service_account"]
notebook_path = policy_index_variables["notebook_path"]
node_type_id = policy_index_variables["node_type_id"]
driver_node_type_id = policy_index_variables["driver_node_type_id"]
min_workers = policy_index_variables["min_workers"]
max_workers = policy_index_variables["max_workers"]
num_workers = policy_index_variables["num_workers"]
max_active_runs = policy_index_variables["max_active_runs"]

output_path = f"{derived_dataset_name}/output/{filename}"

# GCS client
storage_client = storage.Client(project=raw_project_name)

# Bigquery client
bigquery_client = bigquery.Client(project=curated_project)
est_tz = pytz.timezone("America/Toronto")

new_cluster = {
    "name": "policy_index_cluster",
    "spark_version": "10.4.x-scala2.12",
    "node_type_id": node_type_id,
    "driver_node_type_id": driver_node_type_id,
    "policy_id": policy_id,
    "max_active_runs": max_active_runs,
    "autoscale": {"min_workers": min_workers, "max_workers": max_workers},
    "custom_tags": {"TeamName": "CDPM"},
    "gcp_attributes": {
        "google_service_account": google_service_account,
        "zone_id": "HA",
        "use_preemptible_executors": False,
    },
}


def update_encoding(**context):
    """
    function to convert.bin files to .csv files
    """

    base_parameters = {
        "composer_bucket_name": composer_bucket_name,
        "file_path": f"{local_file_path}/{base_folder_path}/",
        "file_name": f"{filename}"
    }

    encode_file = DatabricksSubmitRunOperator(
        task_id="encode_file",
        new_cluster=new_cluster,
        notebook_task={
            "notebook_path": notebook_path,
            "base_parameters": base_parameters,
        },
        wait_for_termination=True,
        databricks_conn_id=databricks_conn_id,
    )
    encode_file.execute(dict(context))


def export_file_to_ftp(**context):
    """
    function to export file to FTP
    """
    execution_date = context["dag_run"].conf.get("run_date")

    if execution_date:
        print("Execution date: ", execution_date)
    else:
        execution_date = (
            context["execution_date"].astimezone(est_tz).strftime("%Y-%m-%d")
        )
        print("Execution date: ", execution_date)
    local_file_path_ = f"{local_root_path}/{local_file_path}/{base_folder_path}"

    gcs_to_ftp = FTPFileTransmitOperator(
        task_id="gcs_to_ftp",
        ftp_conn_id=ftp_conn_id,
        local_filepath=f"{local_file_path_}/{filename}",
        remote_filepath=f"{remote_root_path}/{remote_file_path}/{filename}",
        operation=FTPOperation.PUT,
    )
    gcs_to_ftp.execute(dict(context))


def export_file_to_legal_ftp(**context):
    """
    function to export file to legal FTP
    """
    local_file_path_ = f"{local_root_path}/{local_file_path}/{base_folder_path}"
    gcs_to_legacy_ftp = FTPFileTransmitOperator(
        task_id="gcs_to_legacy_ftp",
        ftp_conn_id=ftp_conn_id,
        local_filepath=f"{local_file_path_}/{filename}",
        remote_filepath=f"{remote_root_path}/{legacy_remote_file_path}/{filename}",
        operation=FTPOperation.PUT,
    )
    gcs_to_legacy_ftp.execute(dict(context))
    source_bucket = storage_client.get_bucket(composer_bucket_name)
    if storage.Blob(bucket=source_bucket, name=f"{local_file_path}/{base_folder_path}/{filename}").exists(
            storage_client
    ):
        print(f"path: {local_file_path}/{base_folder_path}/{filename}")
        source_blob = source_bucket.blob(f"{local_file_path}/{base_folder_path}/{filename}")
        source_blob.delete()
        logging.info(f"{source_blob} File deleted")


with DAG(
    dag_id="ex_product_policy_idex_to_ftp",
    start_date=datetime(2023, 7, 11),
    tags=["daily", "export"],
    schedule_interval=None,
    catchup=False,
) as dag:

    update_encoding = PythonOperator(
        task_id="update_encoding",
        python_callable=update_encoding,
        dag=dag,
    )

    export_file_to_ftp = PythonOperator(
        task_id="export_file_to_ftp",
        python_callable=export_file_to_ftp,
        dag=dag,
    )

    export_file_to_legal_ftp = PythonOperator(
        task_id="export_file_to_legal_ftp",
        python_callable=export_file_to_legal_ftp,
        dag=dag,
    )


dag.doc_md = f"""
### DAG Documentation
- Job Description - Export to ftp job for Policy Index
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""

(
    update_encoding
    >> export_file_to_ftp
    >> export_file_to_legal_ftp
)
