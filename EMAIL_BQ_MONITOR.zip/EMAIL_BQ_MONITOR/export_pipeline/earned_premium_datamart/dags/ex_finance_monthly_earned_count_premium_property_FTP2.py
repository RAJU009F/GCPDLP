from google.cloud import storage
from airflow.operators.python_operator import PythonOperator
from airflow import DAG
from datetime import datetime
from airflow.models import Variable
from airflow.exceptions import AirflowException
import pytz
import calendar
from airflow.providers.google.cloud.transfers.gcs_to_gcs import (
    GCSToGCSOperator,
)
from airflow.providers.ftp.operators.ftp import (
    FTPFileTransmitOperator,
    FTPOperation,
)
from airflow.providers.google.cloud.operators.gcs import (
    GCSDeleteObjectsOperator,
)

#  Pulling Values from the Variables defined in Airflow
raw_project_name = Variable.get("raw_project_name")
raw_bucket_name = Variable.get("raw_bucket_name")
curated_project = Variable.get("curated_project_name")
derived_project = Variable.get("derived_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_bucket_name = Variable.get("derived_bucket_name")
earned_premium_gl_variables = Variable.get("earned_premium_gl_variables", deserialize_json=True)

dataset_name = earned_premium_gl_variables["dataset_name"]
destination_folder_1 = earned_premium_gl_variables["destination_folder_1_prop"]
destination_folder_2 = earned_premium_gl_variables["destination_folder_2_prop"]
destination_folder_3 = earned_premium_gl_variables["destination_folder_3_prop"]
file_name = earned_premium_gl_variables["file_name_prop"]
ftp_host_one = earned_premium_gl_variables["ftp_host_one"]
ftp_host_two = earned_premium_gl_variables["ftp_host_two"]
local_file_path = earned_premium_gl_variables["local_file_path"]
remote_file_path_sas = earned_premium_gl_variables["remote_file_path_prop_sas"]
remote_file_path_o_drive = earned_premium_gl_variables["remote_file_path_prop_o_drive"]
folder_path = earned_premium_gl_variables["folder_path"]
framework_path = earned_premium_gl_variables["framework_path"]
troubleshooting_path = earned_premium_gl_variables["troubleshooting_path"]
job_book_path = earned_premium_gl_variables["job_book_path"]

storage_client = storage.Client(project=raw_project_name)
deployment_bucket = storage_client.bucket(deployment_bucket_name)
est_tz = pytz.timezone("America/Toronto")


def get_execution_date_func(**context):
    execution_date = context["dag_run"].conf.get("run_date")
    if execution_date:
        print(execution_date)
    else:
        execution_date = context["execution_date"].astimezone(est_tz).strftime("%Y-%m-%d")
        print(execution_date)
    return str(execution_date)


def generate_suffix(**context):
    """
    Function to create date(MMMYYYY) suffix to add in the CSV filename
    """
    try:
        date = context["ti"].xcom_pull(task_ids=get_execution_date.task_id)
        month_number = str(date)[5:7]
        mon = calendar.month_name[int(month_number)]
        year = str(date)[:4]
        suffix = mon + year
        task_instance = context["task_instance"]
        task_instance.xcom_push(key="file_suffix", value=suffix)
        return suffix
    except Exception:
        raise AirflowException("Error while adding suffix")


with DAG(
    "ex_finance_monthly_earned_count_premium_property_FTP2",
    schedule_interval=None,
    start_date=datetime(2023, 7, 20),
    catchup=False,
    max_active_runs=1,
) as dag:
    get_execution_date = PythonOperator(
        task_id="get_execution_date", python_callable=get_execution_date_func, provide_context=True
    )

    generate_suffix = PythonOperator(
        task_id="generate_suffix",
        python_callable=generate_suffix,
        op_kwargs={"file_name": file_name},
        dag=dag,
    )

    # copy to composer bucket
    add_suffix = GCSToGCSOperator(
        task_id="add_suffix",
        source_bucket=composer_bucket_name,
        source_object=f"{folder_path}/{destination_folder_2}/{file_name}.csv",
        destination_bucket=composer_bucket_name,
        destination_object=(
            f"{folder_path}/{destination_folder_2}/{file_name}_"
            + "{{task_instance.xcom_pull(task_ids='generate_suffix',key='file_suffix')}}"
            + ".csv"
        ),
        move_object=True,
    )

    # Copy to FTP
    file2_gcs_to_SAS = FTPFileTransmitOperator(
        task_id="file2_gcs_to_SAS",
        ftp_conn_id=ftp_host_one,
        local_filepath=f"{local_file_path}/{folder_path}/{destination_folder_2}/{file_name}_"
        + "{{task_instance.xcom_pull(task_ids='generate_suffix',key='file_suffix')}}"
        + ".csv",
        remote_filepath=remote_file_path_sas
        + f"{file_name}_"
        + "{{task_instance.xcom_pull(task_ids='generate_suffix',key='file_suffix')}}"
        + ".csv",
        operation=FTPOperation.PUT,
    )

    # delete files from composer bucket
    delete_files_from_composer_bucket_output_2 = GCSDeleteObjectsOperator(
        task_id="delete_files_from_composer_bucket_output_2",
        bucket_name=composer_bucket_name,
        objects=[
            f"{folder_path}/{destination_folder_2}/{file_name}_"
            + "{{task_instance.xcom_pull(task_ids='generate_suffix',key='file_suffix')}}"
            + ".csv"
        ],
    )

dag.doc_md = f"""
### DAG Documentation
- Job Description - Ingestion job to ingest Policy_Event XML/.bin
files from GuideWire to BigQuery.
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""

(
    get_execution_date
    >> generate_suffix
    >> add_suffix
    >> file2_gcs_to_SAS
    >> delete_files_from_composer_bucket_output_2
)
