from datetime import datetime
import pytz
import csv
import logging
from google.cloud import storage, bigquery
from airflow import DAG
from airflow.models import Variable
from airflow.exceptions import AirflowException
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.transfers.gcs_to_gcs import (
    GCSToGCSOperator,
)
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.google.cloud.operators.gcs import (
    GCSDeleteObjectsOperator,
)

raw_project_name = Variable.get("raw_project_name")
raw_bucket_name = Variable.get("raw_bucket_name")
curated_project = Variable.get("curated_project_name")
derived_project = Variable.get("derived_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_bucket_name = Variable.get("derived_bucket_name")

earned_premium_gl_variables = Variable.get("earned_premium_gl_variables", deserialize_json=True)

dataset_name = earned_premium_gl_variables["dataset_name"]
file_name = earned_premium_gl_variables["file_name_auto"]
folder_path = earned_premium_gl_variables["folder_path"]
folder_name = earned_premium_gl_variables["folder_name"]
destination_folder_1 = earned_premium_gl_variables["destination_folder_1_auto"]
destination_folder_2 = earned_premium_gl_variables["destination_folder_2_auto"]
destination_folder_3 = earned_premium_gl_variables["destination_folder_3_auto"]
framework_path = earned_premium_gl_variables["framework_path"]
troubleshooting_path = earned_premium_gl_variables["troubleshooting_path"]
job_book_path = earned_premium_gl_variables["job_book_path"]

bigquery_client = bigquery.Client(project=derived_project)
storage_client = storage.Client(project=raw_project_name)
est_tz = pytz.timezone("America/Toronto")


def get_execution_date_func(**context):
    execution_date = context["dag_run"].conf.get("run_date")
    if execution_date:
        print(execution_date)
    else:
        execution_date = context["execution_date"].astimezone(est_tz).strftime("%Y-%m-%d")
        print(execution_date)
    return str(execution_date)


def set_execution_time(**context):
    execution_time = datetime.now().astimezone(est_tz).strftime("%Y%m%d%H%M%S%f")[:-3]
    task_instance = context["task_instance"]
    task_instance.xcom_push(key="timestamp", value=execution_time)


def header_to_upper_case(**context):
    try:
        bucket = storage_client.get_bucket(derived_bucket_name)
        blob = bucket.blob(f"{dataset_name}/{file_name}" + ".csv")
        # Read the file content
        with blob.open("r") as input:
            reader = csv.reader(input)
            header = next(reader)
            header = [header_value.upper() for header_value in header]
            rows = [row for row in reader]
        with blob.open("w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(header)
            writer.writerows(rows[0:])

    except Exception as exception:
        logging.info(exception)
        raise AirflowException("File does not exist in given location")


with DAG(
    "ex_finance_monthly_earned_count_premium_auto_GCS",
    schedule_interval=None,
    start_date=datetime(2023, 7, 20),
    max_active_runs=1,
    catchup=False,
) as dag:
    get_execution_date = PythonOperator(
        task_id="get_execution_date", python_callable=get_execution_date_func, provide_context=True
    )

    trigger_export_extract_earn_count_auto = TriggerDagRunOperator(
        task_id="trigger_export_extract_earn_count_auto",
        trigger_dag_id="export_extract_earn_count_auto",
        wait_for_completion=True,
        poke_interval=60,
        dag=dag,
    )

    set_execution_time = PythonOperator(
        task_id="set_execution_time",
        python_callable=set_execution_time,
        dag=dag,
    )

    header_to_upper_case = PythonOperator(
        task_id="header_to_upper_case",
        python_callable=header_to_upper_case,
        dag=dag,
    )

    # copy to runtime in derived
    copy_to_runtime_folder = GCSToGCSOperator(
        task_id="copy_to_runtime_folder",
        source_bucket=derived_bucket_name,
        source_object=f"{dataset_name}/{file_name}.csv",
        destination_bucket=derived_bucket_name,
        destination_object=f"{dataset_name}/{folder_name}/runtime_"
        + "{{task_instance.xcom_pull(task_ids='set_execution_time',key='timestamp')}}"
        + f"/output/{file_name}.csv",  # YYYYMMDDHHMMSS
    )

    # copy to composer bucket output folder
    copy_to_composer_bucket_output1 = GCSToGCSOperator(
        task_id="copy_to_composer_bucket_output1",
        source_bucket=derived_bucket_name,
        source_object=f"{dataset_name}/{file_name}.csv",
        destination_bucket=composer_bucket_name,
        destination_object=f"{folder_path}/{destination_folder_1}/{file_name}.csv",
    )

    copy_to_composer_bucket_output2 = GCSToGCSOperator(
        task_id="copy_to_composer_bucket_output2",
        source_bucket=derived_bucket_name,
        source_object=f"{dataset_name}/{file_name}.csv",
        destination_bucket=composer_bucket_name,
        destination_object=f"{folder_path}/{destination_folder_2}/{file_name}.csv",
    )

    copy_to_composer_bucket_output3 = GCSToGCSOperator(
        task_id="copy_to_composer_bucket_output3",
        source_bucket=derived_bucket_name,
        source_object=f"{dataset_name}/{file_name}.csv",
        destination_bucket=composer_bucket_name,
        destination_object=f"{folder_path}/{destination_folder_3}/{file_name}.csv",
    )

    # delete file generated from export framework
    delete_file_from_derived = GCSDeleteObjectsOperator(
        task_id="delete_file_from_derived",
        bucket_name=derived_bucket_name,
        objects=[f"{dataset_name}/{file_name}.csv"],
    )

dag.doc_md = f"""
### DAG Documentation
- Job Description - Ingestion job to ingest Policy_Event XML/.bin
files from GuideWire to BigQuery.
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""

(
    get_execution_date
    >> trigger_export_extract_earn_count_auto
    >> set_execution_time
    >> header_to_upper_case
    >> [
        copy_to_runtime_folder,
        copy_to_composer_bucket_output1,
        copy_to_composer_bucket_output2,
        copy_to_composer_bucket_output3,
    ]
    >> delete_file_from_derived
)
