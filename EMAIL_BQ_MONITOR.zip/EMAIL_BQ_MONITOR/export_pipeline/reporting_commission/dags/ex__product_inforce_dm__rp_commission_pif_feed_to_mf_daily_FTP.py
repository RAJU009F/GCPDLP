from datetime import datetime
import pytz
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.providers.ftp.operators.ftp import FTPFileTransmitOperator, FTPOperation
from airflow.providers.google.cloud.operators.gcs import GCSDeleteObjectsOperator

curated_project = Variable.get("curated_project_name")
derived_project = Variable.get("derived_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
america_toronto = pytz.timezone("America/Toronto")

# edit this completety according to our use case
rp_commission_pif_feed_to_mf_daily = Variable.get(
    "rp_commission_pif_feed_to_mf_daily", deserialize_json=True
)

local_path = rp_commission_pif_feed_to_mf_daily["local_path"]
file_name = rp_commission_pif_feed_to_mf_daily["file_name"]
remote_path = rp_commission_pif_feed_to_mf_daily["remote_path"]
folder_path = rp_commission_pif_feed_to_mf_daily["folder_path"]
framework_path = rp_commission_pif_feed_to_mf_daily["framework_path"]
job_book_path = rp_commission_pif_feed_to_mf_daily["job_book_path"]
destination_folder = rp_commission_pif_feed_to_mf_daily["destination_folder"]
troubleshooting_path = rp_commission_pif_feed_to_mf_daily["troubleshooting_path"]
dag_start_date = rp_commission_pif_feed_to_mf_daily["dag_start_date"]
# FTP connection id
ftp_conn_id = rp_commission_pif_feed_to_mf_daily["ftp_conn_id"]


def get_execution_date_time(**context):
    execution_date = context["dag_run"].conf.get("run_date")

    if execution_date:
        print("Execution date: ", execution_date)
    else:
        execution_date = context["execution_date"].astimezone(america_toronto).strftime("%Y-%m-%d")

    execution_time = datetime.now().astimezone(america_toronto).strftime("%Y%m%d%H%M%S%f")[:-3]
    return str(execution_date), str(execution_time)


with DAG(
    dag_id="ex__product_inforce_dm__rp_commission_pif_feed_to_mf_daily_FTP",
    schedule_interval=None,
    start_date=datetime.strptime(dag_start_date, "%Y-%m-%d"),
    tags=["product_inforce_dm", "daily", "ftp"],
    catchup=False,
) as dag:
    get_execution_date_time = PythonOperator(
        task_id="get_execution_date_time", python_callable=get_execution_date_time, dag=dag
    )

    # send files to ftp
    gcs_to_ftp = FTPFileTransmitOperator(
        task_id="gcs_to_ftp",
        ftp_conn_id=ftp_conn_id,
        local_filepath=f"{local_path}/{folder_path}/{destination_folder}/{file_name}.csv",
        remote_filepath=remote_path,
        operation=FTPOperation.PUT,
    )

    # delete files from composer bucket
    delete_files_from_composer_bucket = GCSDeleteObjectsOperator(
        task_id="delete_files_from_composer_bucket",
        bucket_name=composer_bucket_name,
        objects=[f"{folder_path}/{destination_folder}/{file_name}.csv"],
    )

dag.doc_md = f"""
### DAG Documentation
- Job Description - Processing job for Reporting job and sending file to FTP Mainframe
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""

(get_execution_date_time >> gcs_to_ftp >> delete_files_from_composer_bucket)
