from datetime import datetime
import pytz
from google.cloud import storage, bigquery
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator

raw_project_name = Variable.get("raw_project_name")
raw_bucket_name = Variable.get("raw_bucket_name")
curated_project = Variable.get("curated_project_name")
derived_project = Variable.get("derived_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_bucket_name = Variable.get("derived_bucket_name")

rp_commission_pif_feed_to_mf = Variable.get("rp_commission_pif_feed_to_mf", deserialize_json=True)
query_path = rp_commission_pif_feed_to_mf["query_path"]
file_name = rp_commission_pif_feed_to_mf["file_name"]
destination_folder = rp_commission_pif_feed_to_mf["destination_folder"]
derived_dataset_name = rp_commission_pif_feed_to_mf["derived_dataset_name"]
table_name = rp_commission_pif_feed_to_mf["table_name"]
folder_path = rp_commission_pif_feed_to_mf["folder_path"]
framework_path = rp_commission_pif_feed_to_mf["framework_path"]
troubleshooting_path = rp_commission_pif_feed_to_mf["troubleshooting_path"]
job_book_path = rp_commission_pif_feed_to_mf["job_book_path"]
dag_start_date = rp_commission_pif_feed_to_mf["dag_start_date"]
america_toronto = pytz.timezone("America/Toronto")

# GCS client
storage_client = storage.Client(project=derived_project)
# Bigquery client
bigquery_client = bigquery.Client(project=derived_project)
est_tz = pytz.timezone("America/Toronto")


def get_execution_date_time(**context):
    execution_date = context["dag_run"].conf.get("run_date")
    if execution_date:
        print("Execution date: ", execution_date)
    else:
        execution_date = context["execution_date"].astimezone(america_toronto).strftime("%Y-%m-%d")
    execution_time = datetime.now().astimezone(america_toronto).strftime("%Y%m%d%H%M%S%f")[:-3]
    return str(execution_date), str(execution_time)


def copy_files_to_runtime(**context):
    execution_time = context["task_output"][1]
    # copy files from raw bucket to raw bucket
    copy_file = GCSToGCSOperator(
        task_id="copy_files_to_runtime",
        source_bucket=derived_bucket_name,
        source_object=f"{derived_dataset_name}/{file_name}.csv",
        destination_bucket=derived_bucket_name,
        move_object=False,
        destination_object=(
            f"{derived_dataset_name}/runtime_{execution_time}/output/{file_name}.csv"
        ),
    )
    copy_file.execute(dict(context))


def change_encoding():
    source_bucket = derived_bucket_name
    blob_name = f"{derived_dataset_name}/{file_name}.csv"
    input_blob = storage_client.bucket(source_bucket).blob(blob_name)

    content = input_blob.download_as_text()
    contents = content.split("\n")
    encode = "\r\n".join(contents)

    output_bucket = derived_bucket_name
    output_blob = storage_client.bucket(output_bucket).blob(blob_name)
    output_blob.upload_from_string(encode)


def copy_files_to_composer_bucket(**context):
    # copy files from raw bucket to composer bucket
    copy_file = GCSToGCSOperator(
        task_id="copy_files_to_composer_bucket",
        source_bucket=derived_bucket_name,
        source_object=f"{derived_dataset_name}/{file_name}.csv",
        destination_bucket=composer_bucket_name,
        destination_object=f"{folder_path}/{destination_folder}/{file_name}.csv",
        move_object=False,
    )
    copy_file.execute(dict(context))


with DAG(
    dag_id="ex_rp_commission_pif_feed_to_mf_to_gcs",
    start_date=datetime.strptime(dag_start_date, "%Y-%m-%d"),
    tags=["monthly", "ftp", "product_inforce_dm"],
    schedule_interval=None,
    catchup=False,
) as dag:
    get_execution_date_time = PythonOperator(
        task_id="get_execution_date_time", python_callable=get_execution_date_time, dag=dag
    )
    trigger_ex_rp_commission_pif_feed_to_mf = TriggerDagRunOperator(
        task_id="trigger_ex_rp_commission_pif_feed_to_mf",
        trigger_dag_id="ex_rp_commission_pif_feed_to_mf",
        wait_for_completion=True,
        poke_interval=60,
        dag=dag,
    )
    change_encoding = PythonOperator(
        task_id="change_encoding", python_callable=change_encoding, dag=dag
    )
    # copy to runtime in derived
    copy_files_to_runtime = PythonOperator(
        task_id="copy_files_to_runtime",
        python_callable=copy_files_to_runtime,
        op_kwargs={"task_output": get_execution_date_time.output},
        dag=dag,
    )
    # copy files from derived bucket to composer bucket
    copy_files_to_composer_bucket = PythonOperator(
        task_id="copy_files_to_composer_bucket",
        python_callable=copy_files_to_composer_bucket,
        dag=dag,
    )

dag.doc_md = f"""
### DAG Documentation
- Job Description - Processing job for Reporting job and sending file to Mainframe FTP
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""
(
    get_execution_date_time
    >> trigger_ex_rp_commission_pif_feed_to_mf
    >> change_encoding
    >> copy_files_to_runtime
    >> copy_files_to_composer_bucket
)
