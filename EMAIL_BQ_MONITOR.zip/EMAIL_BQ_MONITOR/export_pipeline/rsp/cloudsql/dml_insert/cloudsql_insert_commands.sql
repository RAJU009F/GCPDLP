INSERT INTO export_framework.exf_ds_def VALUES (
	exf_ds_name,
	exf_ds_desc,
	exf_ds_type,
	exf_ds_location,
	exf_conn_type,
	exf_conn_details_variable
)(
	"dp-prod-derived-2072.product_rsp",
	"BQ dataset for RSP",
	"BigQuery",
	"northamerica-northeast1",
	"BigQuery",
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_premium_ceded_vyne_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_premium_ceded/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_uw_rsp_r8_premium`;",
	1,	
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_r8_premium_ceded_vyne", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_premium_ceded_sonnet_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_premium_ceded/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_uw_rsp_r8_premium`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_r8_premium_ceded_sonnet", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_premium_deceded_vyne_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_premium_deceded/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_uw_rsp_r8_premium`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_r8_premium_deceded_vyne", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_premium_deceded_sonnet_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_premium_deceded/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_uw_rsp_r8_premium`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_r8_premium_deceded_sonnet", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_premium_policy_change_vyne_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_premium_policy_change/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_uw_rsp_r8_premium`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_r8_premium_policy_change_vyne", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_premium_policy_change_sonnet_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_premium_policy_change/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_uw_rsp_r8_premium`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_r8_premium_policy_change_sonnet", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_audit_data_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_audit_data/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_uw_rsp_r8_audit`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_r8_audit_data", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
	exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_premium_ceded_qc_vyne_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_premium_ceded_qc/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_uw_rsp_r8_premium`;",
	1,	
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_r8_premium_ceded_qc_vyne", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
	exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_premium_ceded_qc_sonnet_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_premium_ceded_qc/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_uw_rsp_r8_premium`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_r8_premium_ceded_qc_sonnet", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_premium_deceded_qc_vyne_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_premium_deceded_qc/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_uw_rsp_r8_premium`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_r8_premium_deceded_qc_vyne", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_premium_deceded_qc_sonnet_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_premium_deceded_qc/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_uw_rsp_r8_premium`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_r8_premium_deceded_qc_sonnet", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_premium_policy_change_qc_vyne_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_premium_policy_change_qc/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_uw_rsp_r8_premium`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_r8_premium_policy_change_qc_vyne", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_premium_policy_change_qc_sonnet_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_premium_policy_change_qc/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_uw_rsp_r8_premium`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_r8_premium_policy_change_qc_sonnet", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_order_mvr_data_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/order_mvr_data/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_mvr_order`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_order_mvr_data", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_manual_bulk_recon_job_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/manual_bulk_recon_job/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_job_reconciliation`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "rsp_manual_bulk_recon_job", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
    exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
)(
	"ex_product_rsp_r8_gaa_clm_data_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-derived-2072.product_rsp'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/product_rsp/r8_gaa_clm_data/output/",
	"SELECT * FROM `$project_id.$dataset_id.export_gaa_clm`;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	"",
	"TXT",
	'{"filename": {"base": "rsp_r8_gaa_clm_data"}}',
	'{"Body": [{"colname": "clm_line", "coltype": "String", "colwidth": 300}]}',
	'',
	'',
	NULL
);