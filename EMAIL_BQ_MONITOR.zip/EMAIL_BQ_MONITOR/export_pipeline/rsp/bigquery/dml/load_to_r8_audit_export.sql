INSERT INTO `@derived_project_id.@product_rsp_dataset.export_uw_rsp_r8_audit` (
    SELECT
        batch_id,
        rec_type,
        company_number,
        state,
        rec_count,
        gl_dollar_amt,
        gl_reserve_amt,
        dollar_amt,
        reserve_amt,
        creation_dt,
        report_dt,
        process_dt,
        interface,
        filename,
        deleted_dt,
        error_desc
    FROM
        `@derived_project_id.@product_rsp_dataset.uw_rsp_r8_audit`
    WHERE
        report_dt = '@scheduler_date'
);