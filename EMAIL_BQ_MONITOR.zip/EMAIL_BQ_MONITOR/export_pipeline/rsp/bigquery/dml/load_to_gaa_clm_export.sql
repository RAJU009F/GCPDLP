INSERT INTO `@derived_project_id.@product_rsp_dataset.export_gaa_clm` (
    clm_line
)(
    SELECT
        CONCAT(
            SUBSTR(d.line_content, 1, 19), 
            LPAD(
                SUBSTR(
                    CAST(c.veh_num AS string), 
                    LENGTH(CAST(c.veh_num AS string))
                ),
                2, 
                '0'
            ),
            SUBSTR(d.line_content, 22, 182), 
            REPEAT(' ', 17), 
            SUBSTR(d.line_content, 221, 20)
        ) AS clm_line
    FROM
        `@derived_project_id.@product_rsp_dataset.dly_rsp_gaa_clm` d
    INNER JOIN
        `@derived_project_id.@product_rsp_dataset.gaa_clm` c
    ON
        TRIM(SUBSTR(d.line_content, 10, 9)) = c.policy_num
    AND 
        TRIM(SUBSTR(d.line_content, 204, 17)) = c.vin
    AND 
        TRIM(SUBSTR(d.line_content, 23, 10)) = c.claim_num
    AND 
        CAST(SUBSTR(d.line_content, 234, 5) AS int) = c.seq_rec_num
    WHERE
        SUBSTR(line_content, 239, 2) = 'SI'
    AND 
        DATE(c.dlh_batch_ts) = '@scheduler_date'
)