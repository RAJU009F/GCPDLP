INSERT INTO `@derived_project_id.@product_rsp_dataset.export_decision_logging`(

SELECT rsp_log.province_code, 
    rsp_log.policy_period_public_id, 
    rsp_log.period_start,
    rsp_log.policy_period_effective_date, 
    rsp_log.policy_number, 
    rsp_log.term_number_excl_rewrites as term_number, 
    rsp_log.vehicle_public_id,
    rsp_log.vehicle_fixed_id, 
    rsp_log.vin,
    false as old_rsp_ceded, 
    if(rsp_log.pool_decision = 'Cede', true, false) as rsp_ceded, 
    false as rsp_override, 
    rsp_log.pool_decision as pooling_decision, 
    rsp_log.processed_date as decision_timestamp,
    rsp_log.rsp_transfer_date
FROM `@derived_project_id.@product_rsp_dataset.decision_logging` rsp_log
WHERE DATE(rsp_log.scheduler_date) = DATE("@scheduler_date")
 AND rsp_log.pool_decision in ('Cede', 'Remove')
);