INSERT INTO `@derived_project_id.@product_rsp_dataset.export_mvr_order` (
    SELECT
        license_number AS LICENCE_NUM,
        license_province AS PROVINCE_CD,
        first_name AS FIRST_NAME,
        last_name AS LAST_NAME,
        date_of_birth AS DATE_OF_BIRTH,
        gender AS GENDER_CD,
        marital_status AS MARITAL_CD,
        policy_province_code AS POLICY_PROVINCE_CD,
        IF(company_code = '01', 'broker', 'nonBroker') AS BILLING_BUCKET
    FROM
        `@derived_project_id.@product_rsp_dataset.mvr_order`
    WHERE 
        dlh_batch_ts = CAST('@scheduler_date' AS DATETIME) AND
        dlh_process_ts = PARSE_DATETIME('%Y-%m-%d %H:%M:%S', '@process_ts')
);