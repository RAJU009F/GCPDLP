INSERT INTO `@derived_project_id.@product_rsp_dataset.export_job_reconciliation` (
    SELECT
        job_name              AS JOB_NAME,
        source                AS SOURCE,
        target                AS TARGET,
        source_count          AS SOURCE_COUNT,
        staging_count         AS STAGING_COUNT,
        target_count          AS TARGET_COUNT,
        execution_datetime    AS EXECUTION_DATETIME,
        reconciliation_status AS RECONCILATION_STATUS 
    FROM
        `@derived_project_id.@product_rsp_dataset.job_reconciliation`
    WHERE 
        dlh_batch_ts = CAST('@scheduler_date' AS DATETIME) AND
        dlh_process_ts = PARSE_DATETIME('%Y-%m-%d %H:%M:%S', '@process_ts')
);