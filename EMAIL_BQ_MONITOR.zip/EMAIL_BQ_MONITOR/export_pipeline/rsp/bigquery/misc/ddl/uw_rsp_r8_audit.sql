CREATE TABLE IF NOT EXISTS `@derived_project.product_rsp.uw_rsp_r8_audit`
(
  dlh_batch_ts DATETIME,
  dlh_process_ts DATETIME,
  batch_id STRING,
  rec_type STRING,
  company_number STRING,
  state INT64,
  rec_count INT64,
  gl_dollar_amt NUMERIC(10, 2),
  gl_reserve_amt NUMERIC(10, 2),
  dollar_amt NUMERIC(10, 2),
  reserve_amt NUMERIC(10, 2),
  creation_dt STRING,
  report_dt STRING,
  process_dt STRING,
  interface STRING,
  filename STRING,
  deleted_dt STRING,
  error_desc STRING,
  report_year INT64,
  report_month INT64
)
PARTITION BY RANGE_BUCKET(report_year, GENERATE_ARRAY(2000, 2300, 1))
CLUSTER BY report_month;