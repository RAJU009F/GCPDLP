CREATE TABLE IF NOT EXISTS `@derived_project.product_rsp.export_decision_logging`
(
  province_code STRING,
  policy_period_public_id STRING,
  period_start DATETIME,
  policy_period_effective_date DATETIME,
  policy_number STRING,
  term_number INT64,
  vehicle_public_id STRING,
  vehicle_fixed_id STRING,
  vin STRING,
  old_rsp_ceded BOOL,
  rsp_ceded BOOL,
  rsp_override BOOL,
  pooling_decision STRING,
  decision_timestamp DATETIME,
  rsp_transfer_date DATETIME
);