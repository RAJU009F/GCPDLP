CREATE TABLE IF NOT EXISTS `@derived_project.product_rsp.export_mvr_order`
(
  license_num STRING,
  province_cd STRING,
  first_name STRING,
  last_name STRING,
  date_of_birth STRING,
  gender_cd STRING,
  marital_cd STRING,
  policy_province_cd STRING,
  billing_bucket STRING,
);