CREATE TABLE IF NOT EXISTS `@derived_project.product_rsp.export_gaa_clm` (
    clm_line STRING
);