CREATE TABLE IF NOT EXISTS `@derived_project.product_rsp.export_uw_rsp_r8_audit` (
    batch_id STRING,
    rec_type STRING,
    company_number STRING,
    state INTEGER,
    rec_count INTEGER,
    gl_dollar_amt NUMERIC(10, 2),
    gl_reserve_amt NUMERIC(10, 2),
    dollar_amt NUMERIC(10, 2),
    reserve_amt NUMERIC(10, 2),
    creation_dt STRING,
    report_dt STRING,
    process_dt STRING,
    interface STRING,
    filename STRING,
    deleted_dt STRING,
    error_desc STRING
);