CREATE TABLE IF NOT EXISTS `@derived_project.product_rsp.export_job_reconciliation` (
    job_name STRING,
    source STRING,
    target STRING,
    source_count INTEGER,
    staging_count INTEGER,
    target_count INTEGER,
    execution_datetime DATETIME,
    reconciliation_status STRING
);