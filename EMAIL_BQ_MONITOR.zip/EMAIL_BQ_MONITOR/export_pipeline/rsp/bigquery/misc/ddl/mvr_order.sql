CREATE TABLE IF NOT EXISTS `@derived_project.product_rsp.mvr_order`
(
  dlh_batch_ts DATETIME,
  dlh_process_ts DATETIME,
  license_number STRING,
  license_province STRING,
  first_name STRING,
  last_name STRING,
  date_of_birth STRING,
  gender STRING,
  marital_status STRING,
  policy_province_code STRING,
  policy_number STRING,
  term_number_excl_rewrites STRING,
  processed_date DATETIME DEFAULT NULL,
  company_code STRING,
  processed_year INT64  DEFAULT NULL,
  processed_month INT64  DEFAULT NULL
)
PARTITION BY DATETIME_TRUNC(dlh_process_ts, MONTH);