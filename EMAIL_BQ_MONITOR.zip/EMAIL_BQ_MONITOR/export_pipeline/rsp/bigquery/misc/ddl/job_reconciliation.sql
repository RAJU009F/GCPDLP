CREATE TABLE IF NOT EXISTS `@derived_project.product_rsp.job_reconciliation`
(
  dlh_batch_ts DATETIME,
  dlh_process_ts DATETIME,
  job_name STRING OPTIONS(description="Name of the Job that executed this job"),
  source STRING OPTIONS(description="Name of the source function or functionality or feature"),
  target STRING OPTIONS(description="Name of the target function or functionality or feature"),
  source_count INT64 OPTIONS(description="Count of records in the source i.e. file or database"),
  staging_count INT64 OPTIONS(description="Count of records in the staging i.e. database (excluding duplicates if any)"),
  target_count INT64 OPTIONS(description="Count of records in target i.e. file or database"),
  execution_datetime DATETIME OPTIONS(description="Date and time when this job was executed"),
  reconciliation_status STRING OPTIONS(description="Status of reconciliation based on source_count and target_count"),
  processed_year INT64
)
PARTITION BY DATETIME_TRUNC(dlh_process_ts, YEAR);