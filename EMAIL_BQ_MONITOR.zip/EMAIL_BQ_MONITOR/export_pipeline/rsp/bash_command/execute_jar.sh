#!/bin/bash
# Bash Script to execute JAR which sends XML to IBM MQ

echo "INFO: Checking runtime arguments"
if (($# == 0)); then
    echo "No arguments provided,expected args: jarPath jarName mainClass host port channel queueManager queue username password xmlString"
    exit 1
fi

JAR_PATH=$1
JAR_NAME=$2
MAIN_CLASS=$3
HOSTNAME=$4
PORT=$5
CHANNEL=$6
QUEUE_MANAGER=$7
QUEUE=$8
USERNAME=$9
PASSWORD=$10
XML=$11

echo "INFO:#########  Initialized all runtime arguments ##########"
command="java -cp $JAR_PATH/$JAR_NAME $MAIN_CLASS $HOSTNAME $PORT $CHANNEL $QUEUE_MANAGER $QUEUE $USERNAME $PASSWORD $XML"
echo "INFO:#########  Running the JAR ##########"
eval $command
exit_code=$?
if [[ ${exit_code} != 0 ]]; then
   echo "INFO:######### ISSUE WHILE EXECUTING THE JAR - $the_job_name ##########"
   exit $exit_code
fi
echo "INFO:JAR EXECUTED SUCCESSFULY EXITED WITH EXECUTION CODE: $exit_code"
exit $exit_code