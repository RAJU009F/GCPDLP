import logging
import pytz
from datetime import datetime

from google.cloud import bigquery, storage

from airflow import DAG
from airflow.models import Variable
from airflow.exceptions import AirflowException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.google.cloud.transfers.gcs_to_sftp import GCSToSFTPOperator
from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator
from airflow.providers.google.cloud.operators.gcs import GCSDeleteObjectsOperator


derived_project_name = Variable.get("derived_project_name")
derived_bucket_name = Variable.get("derived_bucket_name")
processing_project_name = Variable.get("processing_project_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
composer_bucket_name = Variable.get("composer_bucket_name")

variables = Variable.get("rsp_export_variables", deserialize_json=True)

framework_path = variables["framework_path"]
troubleshooting_path = variables["troubleshooting_path"]
job_book_path = variables["job_book_path"]

export_to_ftp = variables["export_to_ftp"]
ftp_conn_id = variables["rsp_regul8_ftp_conn_id"]
ftp_path = variables["r8_gaa_clm_data_ftp_path"]
src_path = variables["src_path"]

product_rsp_dataset = variables["product_rsp_dataset"]

sql_base_path = variables["sql_base_path"]
load_to_export_query_path = sql_base_path + variables["r8_gaa_clm_data_load_to_export_query_path"]
truncate_export_table_query_path = sql_base_path + variables["r8_gaa_clm_data_truncate_export_table_query_path"]

ftp_file_name_pattern = variables["r8_gaa_clm_data_ftp_file_name"]
output_file_name = variables["r8_gaa_clm_data_output_file_name"]

derived_path = variables["r8_gaa_clm_data_derived_path"]
output_path = variables["r8_gaa_clm_data_output_path"].replace("@r8_gaa_clm_data_derived_path", derived_path)
runtime_path = variables["r8_gaa_clm_data_runtime_path"].replace("@r8_gaa_clm_data_derived_path", derived_path)

est_tz = pytz.timezone("America/Toronto")


def get_execution_date_func(**context):
    """
    Function to get execution date from Control-M
    """
    try:
        execution_date = (
            context['dag_run'].conf['run_date']
        )
        logging.info(f"Order date received from Scheduler: {execution_date}")

        runtime_timestamp = datetime.now(est_tz).strftime('%Y%m%d%H%M%S')

        logging.info(f"runtime timestamp: {runtime_timestamp}")

        runtime_dir_path = runtime_path.replace("@execution_datetime", runtime_timestamp)

        ftp_file_name = ftp_file_name_pattern.replace(
            "@execution_date",
            execution_date.replace("-", "")
        )

        runtime_details = [execution_date, runtime_dir_path, ftp_file_name]
        context['ti'].xcom_push(key='runtime_details', value=runtime_details)

        return export_r8_gaa_clm_data_to_gcs.task_id

    except Exception:
        logging.info(
            "Following parameter was not received as configuration paramter: run_date"
        )

        return end.task_id


def load_export_table(context):

    try:
        runtime_details = context['ti'].xcom_pull(task_ids=get_execution_date.task_id, key="runtime_details")
        execution_date = runtime_details[0]

        storage_client = storage.Client(project=processing_project_name)
        bq_client = bigquery.Client(project=derived_project_name)
        deployment_bucket = storage_client.get_bucket(deployment_bucket_name)

        logging.info(
            f"Fetching truncate query from gs://{deployment_bucket_name}/{truncate_export_table_query_path}"
        )

        truncate_query_blob = deployment_bucket.blob(truncate_export_table_query_path)
        truncate_query = truncate_query_blob.download_as_string().decode("utf-8") \
            .replace("@derived_project_id", derived_project_name) \
            .replace("@product_rsp_dataset", product_rsp_dataset)

        logging.info("Executing truncate query..")

        truncate_task = bq_client.query(truncate_query)
        truncate_task.result()

        logging.info(f"Fetching insert query from gs://{deployment_bucket_name}/{load_to_export_query_path}")

        query_blob = deployment_bucket.blob(load_to_export_query_path)
        load_to_export_query = query_blob.download_as_string().decode("utf-8") \
            .replace("@derived_project_id", derived_project_name) \
            .replace("@product_rsp_dataset", product_rsp_dataset) \
            .replace("@scheduler_date", execution_date)

        logging.info("Executing insert query..")

        insertion_task = bq_client.query(load_to_export_query)
        insertion_task.result()
        row_count = insertion_task.num_dml_affected_rows

        logging.info(
            f"The export table was truncated and {row_count} rows were successfully inserted into the export table."
        )

        return

    except Exception as error:
        raise AirflowException(f"Following error occurred while loading data to export table: {error}")


def export_r8_gaa_clm_data_to_gcs_func(**context):

    try:
        load_export_table(context)

        logging.info("Triggering 'ex_product_rsp_r8_gaa_clm_data_to_gcs' dag")

        trigger_ex_product_rsp_r8_gaa_clm_data_to_gcs = TriggerDagRunOperator(
            task_id="trigger_ex_product_rsp_r8_gaa_clm_data_to_gcs",
            trigger_dag_id="ex_product_rsp_r8_gaa_clm_data_to_gcs",
            wait_for_completion=True,
            poke_interval=60,
        )
        trigger_ex_product_rsp_r8_gaa_clm_data_to_gcs.execute(dict(context))

        logging.info("Dag 'ex_product_rsp_r8_gaa_clm_data_to_gcs' run successfully.")

        return move_file_to_runtime.task_id

    except Exception as error:
        raise AirflowException(f"Following error occurred while exporting audit data to GCS: {error}")


def move_file_to_runtime_func(**context):

    try:
        runtime_details = context['ti'].xcom_pull(task_ids=get_execution_date.task_id, key="runtime_details")
        ftp_file_name = runtime_details[2]
        runtime_dir_path = runtime_details[1]

        move_file = GCSToGCSOperator(
            task_id="move_file",
            source_bucket=derived_bucket_name,
            source_object=f"{output_path}{output_file_name}",
            destination_bucket=derived_bucket_name,
            destination_object=f"{runtime_dir_path}{ftp_file_name}",
            move_object=True,
        )
        move_file.execute(dict(context))

        if export_to_ftp:
            return copy_file_to_local.task_id
        else:
            return end.task_id

    except Exception as error:
        raise AirflowException(
            f"""Following error occurred while moving file from output path - {output_path} to
                runtime path - {runtime_dir_path}: {error}"""
        )


def copy_file_to_local_func(**context):

    try:
        runtime_details = context['ti'].xcom_pull(task_ids=get_execution_date.task_id, key="runtime_details")
        runtime_dir_path = runtime_details[1]
        ftp_file_name = runtime_details[2]

        copy_file = GCSToGCSOperator(
            task_id="copy_file",
            source_bucket=derived_bucket_name,
            source_object=f"{runtime_dir_path}{ftp_file_name}",
            destination_bucket=composer_bucket_name,
            destination_object=f"{src_path}{ftp_file_name}",
            move_object=False,
        )
        copy_file.execute(dict(context))

        return move_file_to_ftp.task_id

    except Exception as error:
        raise AirflowException(
            f"""Following error occurred while copying file from {runtime_dir_path} to
                composer src path - {src_path} : {error}"""
        )


def move_file_to_ftp_func(**context):

    try:
        runtime_details = context['ti'].xcom_pull(task_ids=get_execution_date.task_id, key="runtime_details")
        ftp_file_name = runtime_details[2]

        upload_file_to_ftp = GCSToSFTPOperator(
            task_id="upload_file_to_ftp",
            sftp_conn_id=ftp_conn_id,
            source_bucket=composer_bucket_name,
            source_object=f"{src_path}{ftp_file_name}",
            destination_path=ftp_path,
            keep_directory_structure=False
        )
        upload_file_to_ftp.execute(dict(context))

        return end.task_id
    except Exception as error:
        raise AirflowException(
            f"""Following error occurred while moving file from composer bucket path - {src_path} to
                FTP path - {ftp_path}: {error}"""
        )


def delete_file_from_local_func(**context):

    try:
        runtime_details = context['ti'].xcom_pull(task_ids=get_execution_date.task_id, key="runtime_details")
        ftp_file_name = runtime_details[2]

        delete_file = GCSDeleteObjectsOperator(
            task_id="delete_file",
            bucket_name=composer_bucket_name,
            objects=[f"{src_path}{ftp_file_name}"],
        )
        delete_file.execute(dict(context))

    except Exception as error:
        raise AirflowException(
            f"Following error occurred while deleting file from composer bucket path - {src_path}: {error}"
        )


with DAG(
    dag_id='ex_product_rsp_r8_gaa_clm_data_to_ftp',
    start_date=datetime(2023, 8, 1),
    tags=['rsp', 'regulatory', 'derived', 'csv', 'daily'],
    schedule_interval=None,
    catchup=False,
    max_active_runs=1,
) as dag:

    start = EmptyOperator(
        task_id='start',
    )

    get_execution_date = BranchPythonOperator(
        task_id="get_execution_date",
        python_callable=get_execution_date_func,
        provide_context=True
    )

    export_r8_gaa_clm_data_to_gcs = PythonOperator(
        task_id="export_r8_gaa_clm_data_to_gcs",
        python_callable=export_r8_gaa_clm_data_to_gcs_func,
        provide_context=True
    )

    move_file_to_runtime = BranchPythonOperator(
        task_id="move_file_to_runtime",
        python_callable=move_file_to_runtime_func,
        trigger_rule="all_success",
        provide_context=True
    )

    copy_file_to_local = PythonOperator(
        task_id="copy_file_to_local",
        python_callable=copy_file_to_local_func,
        provide_context=True
    )

    move_file_to_ftp = PythonOperator(
        task_id="move_file_to_ftp",
        python_callable=move_file_to_ftp_func,
        provide_context=True
    )

    delete_file_from_local = PythonOperator(
        task_id="delete_file_from_local",
        python_callable=delete_file_from_local_func,
        provide_context=True
    )

    end = EmptyOperator(
        task_id="end",
        trigger_rule="none_failed_min_one_success"
    )


dag.doc_md = f"""
### DAG Documentation
- Job Description - Extraction Jobs for RSP
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""


(
    start
    >> get_execution_date
    >> end
)

(
    start
    >> get_execution_date
    >> export_r8_gaa_clm_data_to_gcs
    >> move_file_to_runtime
    >> copy_file_to_local
    >> move_file_to_ftp
    >> delete_file_from_local
    >> end
)

(
    start
    >> get_execution_date
    >> export_r8_gaa_clm_data_to_gcs
    >> move_file_to_runtime
    >> end
)
