import logging
import pytz
import requests
import subprocess
from datetime import datetime

from google.cloud import storage

from airflow import models
from airflow.models import Variable
from airflow.exceptions import AirflowException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator
from airflow.providers.google.cloud.operators.gcs import GCSDeleteObjectsOperator
from airflow.providers.google.cloud.transfers.sftp_to_gcs import SFTPToGCSOperator


# Pulling values from the defined variables
raw_bucket_name = Variable.get("raw_bucket_name")
raw_project_name = Variable.get("raw_project_name")
derived_project_name = Variable.get("derived_project_name")
csv_ingestion_mysql_connection = Variable.get("csv_ingestion_mysql_connection")
deployment_bucket_name = Variable.get("deployment_bucket_name")
composer_bucket_name = Variable.get("composer_bucket_name")
processing_project_name = Variable.get("processing_project_name")

DAG_VARIABLES_KEY = "rsp_export_variables"
variables = Variable.get(DAG_VARIABLES_KEY, deserialize_json=True)

framework_path = variables["framework_path"]
troubleshooting_path = variables["troubleshooting_path"]
job_book_path = variables["job_book_path"]

ftp_conn_id = variables["rsp_regul8_ftp_conn_id"]
ftp_source_dir = variables["premium_file_ftp_source_dir"]

export_to_webservice = variables["export_to_webservice"]

premium_file_name_pattern = variables["premium_file_name_pattern"]

base64_output_file_name = variables["base64_output_file_name"]

fa_webservice_url = variables["fa_webservice_url"]
fa_webservice_username = variables["fa_webservice_username"]
fa_webservice_password = variables["fa_webservice_password"]
fa_webservice_request_xml_path = variables["fa_webservice_request_xml_path"]

src_path = variables["src_path"]
local_path = variables["local_src_path"]

est_tz = pytz.timezone("America/Toronto")


def get_runtime_dir(runtime_timestamp):
    """
    function to get current runtime directories
    """
    runtime_dir_path = (
        variables["premium_file_runtime_dir_path"]
        .replace("@timestamp", runtime_timestamp)
    )
    working_dir_path = variables["working_dir_path"].replace(
        "@runtime", runtime_dir_path
    )
    failed_dir_path = variables["failed_dir_path"].replace("@runtime", runtime_dir_path)
    success_dir_path = variables["success_dir_path"].replace(
        "@runtime", runtime_dir_path
    )

    return working_dir_path, failed_dir_path, success_dir_path


def get_execution_date_func(**context):
    """
    function to get execution date from conf
    """
    try:
        execution_date = context["dag_run"].conf["run_date"]
        logging.info(f"This is the order date from Scheduler: {execution_date}")

        runtime_timestamp = datetime.now(est_tz).strftime("%Y%m%d%H%M%S")

        logging.info(f"runtime timestamp: {runtime_timestamp}")

        runtime_details = [execution_date, runtime_timestamp]
        context['ti'].xcom_push(key='runtime_details', value=runtime_details)

        return get_job_details.task_id

    except Exception:
        logging.error(
            "Following parameter was not received as configuration paramter: run_date"
        )

        return end.task_id


def get_job_details_func(**context):
    """
    This function is use to assign variable values fetch from sql_connection
    """
    runtime_details = context["ti"].xcom_pull(task_ids=get_execution_date.task_id, key="runtime_details")
    execution_date = runtime_details[0]

    runtime_dir = get_runtime_dir(runtime_details[1])
    working_dir_path = runtime_dir[0]
    failed_dir_path = runtime_dir[1]
    success_dir_path = runtime_dir[2]

    try:

        job_details = {
            "execution_date": execution_date,
            "file_name_pattern": premium_file_name_pattern,
            "landing_dir_path": variables["premium_file_landing_dir_path"],
            "working_dir_path": working_dir_path,
            "failed_dir_path": failed_dir_path,
            "success_dir_path": success_dir_path,
        }

        return job_details

    except Exception as exception:
        raise AirflowException(
            f"Following error occurred while getting details for fdif: {exception}"
        )


def check_local_folder():

    try:
        storage_client = storage.Client(project=processing_project_name)
        composer_bucket = storage_client.bucket(composer_bucket_name)
        local_files = list(composer_bucket.list_blobs(prefix=src_path))

        if len(local_files) == 0:
            logging.info("Files not found on the FTP server")
            return False

        for file in local_files:
            file_name = file.name.split("/")[-1:][0]

            if file_name.startswith(premium_file_name_pattern.split("*")[0]):
                return True

        logging.info("Files not found on the FTP server")
        return False

    except Exception as exception:
        logging.error(f"Following error occurred while checking composer bucket folder: {exception}")


def get_from_ftp_func(**context):
    """
    This function is used to download csv's from the ftp server
    """

    job_details = context["ti"].xcom_pull(task_ids=get_job_details.task_id)
    file_name_pattern = variables["premium_file_name_pattern"]
    landing_dir_path = job_details["landing_dir_path"]
    file_path = f"{ftp_source_dir}{file_name_pattern}"

    try:
        get_files_from_ftp = SFTPToGCSOperator(
            task_id="get_files_from_ftp",
            sftp_conn_id=ftp_conn_id,
            source_path=file_path,
            destination_bucket=composer_bucket_name,
            destination_path=src_path[:-1],
            mime_type="text/plain"
        )
        get_files_from_ftp.execute(dict(context))

        files_exist = check_local_folder()
        if not files_exist:
            return file_not_found.task_id

        copy_files_to_landing = GCSToGCSOperator(
            task_id="copy_files_to_landing",
            source_bucket=composer_bucket_name,
            source_object=src_path,
            destination_bucket=raw_bucket_name,
            destination_object=landing_dir_path,
        )
        copy_files_to_landing.execute(dict(context))

        return landing_to_working.task_id

    except Exception as exception:
        logging.error(exception)
        context["ti"].xcom_push(key="regul8_ftp_server_exception", value=str(exception))
        return file_not_found.task_id


def landing_to_working_func(**context):
    """
    This function is use to move files working directory
    """

    job_details = context["ti"].xcom_pull(task_ids=get_job_details.task_id)
    landing_dir_path = job_details["landing_dir_path"]
    working_dir_path = job_details["working_dir_path"]

    move_files_landing_to_working = GCSToGCSOperator(
        task_id="move_files_landing_to_working",
        source_bucket=raw_bucket_name,
        source_object=landing_dir_path,
        destination_bucket=raw_bucket_name,
        destination_object=working_dir_path,
        move_object=True,
    )
    move_files_landing_to_working.execute(dict(context))


def convert_content_to_base64_func(**context):

    job_details = context["ti"].xcom_pull(task_ids=get_job_details.task_id)
    working_dir_path = job_details["working_dir_path"]

    try:
        storage_client = storage.Client()
        composer_bucket = storage_client.bucket(composer_bucket_name)
        local_files = list(composer_bucket.list_blobs(prefix=src_path))

        commands = [
            f"mkdir {local_path}",
            f'cd {local_path} \
                && base64 -w 0 @local_file > base64_@local_file',
        ]

        mkdir_result = subprocess.run(commands[0], shell=True, text=True, capture_output=True)
        logging.info(f"\n{mkdir_result.stderr}")

        ftp_to_base64_file_names_mapping = []

        for file in local_files:
            file_name = file.name.split("/")[-1:][0]

            logging.info(f"Converting content of {file_name} to Base64 encoding..")

            base64_cmd = commands[1].replace(
                "@local_file", file_name
            )

            result = subprocess.run(base64_cmd, shell=True, text=True, capture_output=True)
            logging.error(f"\n{result.stderr}")

            if result.returncode != 0:
                context["ti"].xcom_push(
                    key="base64_conversion_exception",
                    value=str(result.stderr)
                )

                delete_local_files = GCSDeleteObjectsOperator(
                    task_id="delete_local_files",
                    bucket_name=composer_bucket_name,
                    prefix=src_path,
                )
                delete_local_files.execute(dict(context))

                return base64_conversion_failed.task_id

            current_datetime = datetime.now()
            current_date = current_datetime.strftime("%Y%m%d")
            current_time = current_datetime.strftime("%H%M%S")

            output_file_name = base64_output_file_name.replace("@execution_date", current_date) \
                                                      .replace("@execution_time", current_time)
            output_file_path = f"{working_dir_path}{output_file_name}"

            move_file_from_local_to_working = GCSToGCSOperator(
                task_id="move_file_from_local_to_working",
                source_bucket=composer_bucket_name,
                source_object=f"{src_path}base64_{file_name}",
                destination_bucket=raw_bucket_name,
                destination_object=output_file_path,
                move_object=True,
            )
            move_file_from_local_to_working.execute(dict(context))

            delete_original_file_from_working_dir = GCSDeleteObjectsOperator(
                task_id="delete_original_file_from_working_dir",
                bucket_name=raw_bucket_name,
                objects=[f"{working_dir_path}{file_name}"],
            )
            delete_original_file_from_working_dir.execute(dict(context))

            delete_local_file = GCSDeleteObjectsOperator(
                task_id="delete_local_file",
                bucket_name=composer_bucket_name,
                objects=[file.name],
            )
            delete_local_file.execute(dict(context))

            ftp_to_base64_file_names_mapping.append([file_name, output_file_path])

        context["ti"].xcom_push(key="ftp_to_base64_file_names_mapping", value=ftp_to_base64_file_names_mapping)

        return export_data_to_webservice.task_id

    except Exception as exception:
        logging.error(
            f"Following error occurred while converting files to base64 encoding: {exception}"
        )

        context["ti"].xcom_push(key="base64_conversion_exception", value=str(exception))

        return base64_conversion_failed.task_id


def export_data_to_webservice_func(**context):

    try:
        if not export_to_webservice:
            logging.info("Airflow variable 'export_to_webservice' was set to 'false'. Skipping export task.")
            return working_to_success.task_id

        ftp_to_base64_file_names_mapping = context["ti"].xcom_pull(
            task_ids=convert_content_to_base64.task_id,
            key="ftp_to_base64_file_names_mapping"
        )

        raw_storage_client = storage.Client(project=raw_project_name)
        raw_bucket = raw_storage_client.get_bucket(raw_bucket_name)
        processing_storage_client = storage.Client(project=processing_project_name)
        deployment_bucket = processing_storage_client.get_bucket(deployment_bucket_name)

        fa_webservice_request_xml_blob = deployment_bucket.blob(fa_webservice_request_xml_path)
        fa_webservice_request_xml = fa_webservice_request_xml_blob.download_as_text()

        fa_webservice_request_xml = (
            fa_webservice_request_xml.replace("@fa_webservice_username", fa_webservice_username)
            .replace("@fa_webservice_password", fa_webservice_password)
        )

        for file in ftp_to_base64_file_names_mapping:

            ftp_file_name = file[0]
            base64_file_path = file[1]

            logging.info(f"Uploading base64 content of ftp file {ftp_file_name} to FA webservice.")
            logging.info(
                f"Base64 content of {ftp_file_name} file present in {raw_bucket_name}/{base64_file_path} path."
            )

            base64_file_blob = raw_bucket.blob(base64_file_path)
            base64_content = base64_file_blob.download_as_text()

            xml_body = (
                fa_webservice_request_xml.replace("@ftp_file_name", ftp_file_name)
                .replace("@base64_content", base64_content)
            )

            headers = {
                'Content-Type': 'application/soap+xml'
            }

            response = requests.post(
                url=fa_webservice_url,
                headers=headers,
                data=xml_body
            )

            logging.info(f"response_text: {response.text}")
            logging.info(f"response: {response}")

        return working_to_success.task_id

    except Exception as exception:
        logging.error(
            f"Following error occurred while exporting base64 file content to FA webservice: {exception}"
        )

        context["ti"].xcom_push(key="export_to_FA_webservice_exception", value=str(exception))

        return export_data_to_webservice_failed.task_id


def working_to_success_func(**context):
    """
    This function is use to move files to success folder if the loading operation is successful
    """

    job_details = context["ti"].xcom_pull(task_ids=get_job_details.task_id)
    working_dir_path = job_details["working_dir_path"]
    success_dir_path = job_details["success_dir_path"]
    failed_dir_path = job_details["failed_dir_path"]

    move_files_working_to_success = GCSToGCSOperator(
        task_id="move_files_working_to_success",
        source_bucket=raw_bucket_name,
        source_object=f"{working_dir_path}*",
        destination_bucket=raw_bucket_name,
        destination_object=success_dir_path,
        move_object=True,
    )
    move_files_working_to_success.execute(dict(context))

    try:
        storage_client = storage.Client()
        raw_bucket = storage_client.bucket(raw_bucket_name)
        failed_folder_files = list(raw_bucket.list_blobs(prefix=failed_dir_path))

        if len(failed_folder_files) != 0:
            delete_failed_folder = GCSDeleteObjectsOperator(
                task_id="delete_failed_folder",
                bucket_name=raw_bucket_name,
                objects=[file.name for file in failed_folder_files],
            )
            delete_failed_folder.execute(dict(context))

    except Exception as exception:
        logging.error(f"Following error occurred while deleting failed folder: {exception}")

    logging.info("Files successfully moved to success folder")


def working_to_failed_func(**context):
    """
    This function is use to move the file to failed folder if by any chance loading process interrupts
    """

    job_details = context["ti"].xcom_pull(task_ids=get_job_details.task_id)
    working_dir_path = job_details["working_dir_path"]
    failed_dir_path = job_details["failed_dir_path"]
    success_dir_path = job_details["success_dir_path"]

    move_files_working_to_failed = GCSToGCSOperator(
        task_id="move_files_working_to_failed",
        source_bucket=raw_bucket_name,
        source_object=f"{working_dir_path}*",
        destination_bucket=raw_bucket_name,
        destination_object=failed_dir_path,
        move_object=True,
    )
    move_files_working_to_failed.execute(dict(context))

    try:
        storage_client = storage.Client()
        raw_bucket = storage_client.bucket(raw_bucket_name)
        success_folder_files = list(raw_bucket.list_blobs(prefix=success_dir_path))

        if len(success_folder_files) != 0:
            delete_success_folder = GCSDeleteObjectsOperator(
                task_id="delete_success_folder",
                bucket_name=raw_bucket_name,
                objects=[file.name for file in success_folder_files],
            )
            delete_success_folder.execute(dict(context))

    except Exception as exception:
        logging.error(f"Following error occurred while deleting success folder: {exception}")

    logging.info("Files successfully moved to failed folder")


def end_func(**context):

    get_from_ftp_error = context["ti"].xcom_pull(
        task_ids=get_from_ftp.task_id, key="regul8_ftp_server_exception"
    )
    if get_from_ftp_error is not None:
        raise AirflowException(
            f"Job failed at {get_from_ftp.task_id} task with exception: {get_from_ftp_error}."
        )

    logging.info(f"{get_from_ftp.task_id} run was normal.")

    base64_conversion_error = context["ti"].xcom_pull(
        task_ids=convert_content_to_base64.task_id, key="base64_conversion_exception"
    )
    if base64_conversion_error is not None:
        raise AirflowException(
            f"Job failed at {convert_content_to_base64.task_id} task with exception: {base64_conversion_error}."
        )

    logging.info(f"{convert_content_to_base64.task_id} run was normal.")

    fa_webservice_exception = context["ti"].xcom_pull(
        task_ids=export_data_to_webservice.task_id, key="export_to_FA_webservice_exception"
    )
    if fa_webservice_exception is not None:
        raise AirflowException(
            f"Job failed at {export_data_to_webservice.task_id} task with exception: {fa_webservice_exception}."
        )

    logging.info(f"{export_data_to_webservice.task_id} run was normal.")


with models.DAG(
    dag_id="ex_product_rsp_prem_file_to_FA",
    start_date=datetime(2023, 8, 1),
    tags=["Quantiphi", "rsp_export", "txt", "daily"],
    schedule_interval=None,
    catchup=False,
    max_active_runs=1,
) as dag:

    start = EmptyOperator(
        task_id="start",
    )

    get_execution_date = BranchPythonOperator(
        task_id="get_execution_date",
        python_callable=get_execution_date_func,
        provide_context=True,
    )

    get_job_details = PythonOperator(
        task_id="get_job_details",
        python_callable=get_job_details_func,
        provide_context=True,
    )

    get_from_ftp = BranchPythonOperator(
        task_id="get_from_ftp",
        python_callable=get_from_ftp_func,
        provide_context=True
    )

    file_not_found = EmptyOperator(task_id="file_not_found")

    landing_to_working = PythonOperator(
        task_id="landing_to_working",
        python_callable=landing_to_working_func,
        provide_context=True,
    )

    convert_content_to_base64 = BranchPythonOperator(
        task_id="convert_content_to_base64",
        python_callable=convert_content_to_base64_func,
        provide_context=True,
    )

    base64_conversion_failed = EmptyOperator(
        task_id="base64_conversion_failed",
    )

    export_data_to_webservice = BranchPythonOperator(
        task_id="export_data_to_webservice",
        python_callable=export_data_to_webservice_func,
        provide_context=True,
    )

    export_data_to_webservice_failed = EmptyOperator(
        task_id="export_data_to_webservice_failed"
    )

    working_to_failed = PythonOperator(
        task_id="working_to_failed",
        python_callable=working_to_failed_func,
        trigger_rule="none_failed_min_one_success",
        provide_context=True,
    )

    working_to_success = PythonOperator(
        task_id="working_to_success",
        python_callable=working_to_success_func,
        provide_context=True,
    )

    end = PythonOperator(
        task_id="end",
        python_callable=end_func,
        provide_context=True,
        trigger_rule="none_failed_min_one_success"
    )


dag.doc_md = f"""
### DAG Documentation
- Job Description - Extaction Jobs for RSP
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""


(
    start
    >> get_execution_date
    >> end
)

(
    start
    >> get_execution_date
    >> get_job_details
    >> get_from_ftp
    >> file_not_found
    >> end
)

(
    start
    >> get_execution_date
    >> get_job_details
    >> get_from_ftp
    >> landing_to_working
    >> convert_content_to_base64
    >> export_data_to_webservice
    >> working_to_success
    >> end
)

(
    start
    >> get_execution_date
    >> get_job_details
    >> get_from_ftp
    >> landing_to_working
    >> convert_content_to_base64
    >> base64_conversion_failed
    >> working_to_failed
    >> end
)

(
    start
    >> get_execution_date
    >> get_job_details
    >> get_from_ftp
    >> landing_to_working
    >> convert_content_to_base64
    >> export_data_to_webservice
    >> export_data_to_webservice_failed
    >> working_to_failed
    >> end
)
