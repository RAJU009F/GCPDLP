import subprocess
from datetime import datetime, timedelta
import pytz
import logging
from airflow import DAG
from airflow.exceptions import AirflowException
from airflow.models import Variable
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from google.cloud import storage
from google.cloud import bigquery
import xml.etree.ElementTree as ET
from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator
from airflow.providers.google.cloud.operators.gcs import GCSDeleteObjectsOperator

processing_project_name = Variable.get("processing_project_name")
derived_project_name = Variable.get("derived_project_name")
derived_bucket_name = Variable.get("derived_bucket_name")
processing_project_name = Variable.get("processing_project_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
composer_bucket_name = Variable.get("composer_bucket_name")

export_variables = Variable.get("rsp_export_variables", deserialize_json=True)

product_rsp_dataset = export_variables["product_rsp_dataset"]
sql_base_path = export_variables["sql_base_path"]
send_gwpc_decision_insert_query_path = (
    sql_base_path + export_variables["send_gwpc_decision_load_query_path"]
)
send_gwpc_decision_truncate_query_path = (
    sql_base_path + export_variables["send_gwpc_decision_truncate_query_path"]
)
staging_table_name = export_variables["staging_table_name"]
jar_path = export_variables["jar_path"]
jar_name = export_variables["jar_name"]
main_class = export_variables["main_class"]
send_to_mq = export_variables["export_to_mq"]
bash_script_path = export_variables["script_path"]
bash_script_name = export_variables["script_name"]
composer_fs_base_path = export_variables["local_src_path"]
composer_mount_path = composer_fs_base_path.split("/")[4] + "/" + composer_fs_base_path.split("/")[5]
est_tz = pytz.timezone("America/Toronto")


def get_execution_date_func(**kwargs):
    """
    Function to get execution date from Control-M
    """
    try:
        execution_date = kwargs["dag_run"].conf["run_date"]
        runtime_timestamp = datetime.now(est_tz).strftime("%Y%m%d%H%M%S%f")[:-3]
        runtime_directory_path = export_variables["runtime_directory_path"].replace(
            "@execution_timestamp", runtime_timestamp
        )
        logging.info(
            "Execution date received from Control-M scheduler: ", execution_date
        )
        return execution_date, runtime_directory_path

    except Exception as exception:
        logging.info(exception)
        if export_variables["rsp_execution_date"] != "":
            execution_date = export_variables["rsp_execution_date"]
        else:
            execution_runtime = kwargs["data_interval_start"].astimezone(est_tz)
            execution_date = (execution_runtime - timedelta(days=1)).strftime(
                "%Y-%m-%d"
            )

        runtime_timestamp = datetime.now(est_tz).strftime("%Y%m%d%H%M%S%f")[:-3]
        runtime_directory_path = export_variables["runtime_directory_path"].replace(
            "@execution_timestamp", runtime_timestamp
        )
        return execution_date, runtime_directory_path


def get_runtime_timestamp_func():
    """
    function to get current runtime_timestamp
    """
    current_timestamp = datetime.now(est_tz)
    runtime_timestamp = current_timestamp.strftime("%Y%m%d%H%M%S%f")[:-3]
    file_name_timestamp = current_timestamp.strftime("%Y%m%d%H%M%S%f")

    #   logging.info(f'runtime_timestamp: {runtime_timestamp}')
    return runtime_timestamp, file_name_timestamp


def get_sql_query_from_gcs_func(**context):
    client = storage.Client()
    bucket = client.get_bucket(derived_bucket_name)
    blob = bucket.blob(context["query_path"])
    runtime_details = context["ti"].xcom_pull(
        task_ids=get_execution_details_task.task_id
    )
    execution_date = runtime_details[0]

    send_gwpc_decision_query = (
        blob.download_as_string()
        .decode("utf-8")
        .replace("@derived_project_name", derived_project_name)
        .replace("@product_rsp_dataset", product_rsp_dataset)
        .replace("@scheduler_date", execution_date)
    )

    return send_gwpc_decision_query


def generatePolicyChangeRequestXMLNode(row):
    rsp_transfer_date = ""
    policy_number = ""
    policy_change_request_element = ET.Element("PolicyRspChangeRequest")

    for col_name, col_value in row.iteritems():
        if col_name == "rsp_transfer_date":
            rsp_transfer_date = str(col_value)
        if col_name == "policy_number":
            policy_number = str(col_value)

    #   rsp_transfer_date -> rsp_transfer_date_adjusted
    rsp_transfer_date_iso_format = datetime.strptime(
        rsp_transfer_date, "%Y-%m-%d %H:%M:%S"
    )
    rsp_transfer_date_added_minute = rsp_transfer_date_iso_format + timedelta(minutes=1)
    en_ca = pytz.timezone("Canada/Eastern")
    rsp_transfer_date_adjusted_time_zone = en_ca.localize(
        rsp_transfer_date_added_minute
    )
    rsp_transfer_date_adjusted_formatted = (
        rsp_transfer_date_adjusted_time_zone.strftime("%Y-%m-%dT%H:%M:%S%z")
    )
    timezone_offset = (
        rsp_transfer_date_adjusted_formatted[-5:-2]
        + ":"
        + rsp_transfer_date_adjusted_formatted[-2:]
    )
    rsp_transfer_date_adjusted = (
        rsp_transfer_date_adjusted_formatted[:-5] + timezone_offset
    )

    # Construct PolicyChangeRequest Node
    effective_date_element = ET.SubElement(
        policy_change_request_element, "EffectiveDate"
    )
    effective_date_element.text = rsp_transfer_date_adjusted

    policy_number_element = ET.SubElement(policy_change_request_element, "PolicyNumber")
    policy_number_element.text = policy_number

    policy_change_reason_element = ET.SubElement(
        policy_change_request_element, "PolicyChangeReason"
    )
    policy_change_reason_element.text = "RSP"

    return policy_change_request_element


def generatePersonalVehicleXMLNode(root_element, row):
    vehicle_public_id = ""
    vin = ""
    rsp_ceded = ""
    rsp_override = ""

    for col_name, col_value in row.iteritems():
        if col_name == "vehicle_public_id":
            vehicle_public_id = str(col_value)
        if col_name == "vin":
            vin = str(col_value)
        if col_name == "rsp_ceded":
            rsp_ceded = str(col_value)
        if col_name == "rsp_override":
            rsp_override = str(col_value)

    #   Construct PersonalVehicle Node
    personal_vehicle_element = ET.SubElement(root_element, "PersonalVehicle")

    vehicle_public_id_element = ET.SubElement(personal_vehicle_element, "PublicID")
    vehicle_public_id_element.text = vehicle_public_id

    vin_element = ET.SubElement(personal_vehicle_element, "Vin")
    vin_element.text = vin

    rsp_ceded_element = ET.SubElement(personal_vehicle_element, "RspCeded")
    rsp_ceded_element.text = rsp_ceded.lower()

    rsp_override_element = ET.SubElement(personal_vehicle_element, "RspOverride")
    rsp_override_element.text = rsp_override.lower()

    drivers_element = ET.SubElement(personal_vehicle_element, "Drivers")
    entry_element = ET.SubElement(drivers_element, "Entry")
    policy_driver_element = ET.SubElement(entry_element, "PolicyDriver")

    account_contact_role_element = ET.SubElement(
        policy_driver_element, "AccountContactRole"
    )
    subtype_element = ET.SubElement(account_contact_role_element, "Subtype")
    code_element = ET.SubElement(subtype_element, "Code")
    code_element.text = "Driver"

    fixed_id_element = ET.SubElement(policy_driver_element, "FixedId")
    ET.SubElement(fixed_id_element, "Value")


def generatePolicyPeriodXMLNode(root_element, row):
    public_id = ""
    term_number = ""

    for col_name, col_value in row.iteritems():
        if col_name == "policy_period_public_id":
            public_id = str(col_value)
        if col_name == "term_number":
            term_number = str(col_value)

    #   Construst PolicyPeriod Node
    policy_period_element = ET.SubElement(root_element, "PolicyPeriod")
    public_id_element = ET.SubElement(policy_period_element, "PublicID")
    public_id_element.text = public_id
    term_number_element = ET.SubElement(policy_period_element, "TermNumber")
    term_number_element.text = term_number


def row_to_xml(row):
    policy_change_request_xml = generatePolicyChangeRequestXMLNode(row)
    generatePersonalVehicleXMLNode(policy_change_request_xml, row)
    generatePolicyPeriodXMLNode(policy_change_request_xml, row)

    return policy_change_request_xml


def get_policy_number(row):
    policy_number = ""
    for col_name, col_value in row.iteritems():
        if col_name == "policy_number":
            policy_number = str(col_value)
            break

    return policy_number


def check_if_export_table_is_empty():
    client = bigquery.Client()
    dataset_ref = bigquery.DatasetReference(derived_project_name, product_rsp_dataset)
    table_ref = dataset_ref.table(staging_table_name)
    table = client.get_table(table_ref)
    result_df = client.list_rows(table).to_dataframe()

    if result_df.empty:
        logging.info("export_decision_logging table is empty. No records !")
        return "end"

    return "convert_df_to_xml"


def convert_row_to_xml_func(**context):
    client = bigquery.Client()
    dataset_ref = bigquery.DatasetReference(derived_project_name, product_rsp_dataset)
    table_ref = dataset_ref.table(staging_table_name)
    table = client.get_table(table_ref)
    result_df = client.list_rows(table).to_dataframe()
    logging.info("No of rows :", result_df.shape[0])

    for _, row in result_df.iterrows():
        xml_element = row_to_xml(row)
        policy_number = get_policy_number(row)
        xml_string = ET.tostring(
            xml_element, xml_declaration=True, encoding="utf-8"
        ).decode()
        save_xml_to_gcs(context, xml_string, policy_number)


def save_xml_to_gcs(context, xml_string, policy_number):
    runtime_details = context["ti"].xcom_pull(
        task_ids=get_execution_details_task.task_id
    )
    runtime_directory_path = runtime_details[1]

    gcs_client = storage.Client()
    bucket = gcs_client.get_bucket(deployment_bucket_name)
    runtime_timestamp, file_name_timestamp = get_runtime_timestamp_func()
    xml_file_name = (
        export_variables["xml_file_name"]
        .replace("@execution_timestamp", file_name_timestamp)
        .replace("@policy_number", policy_number)
    )

    blob = bucket.blob(f"{runtime_directory_path}{xml_file_name}")
    blob.upload_from_string(xml_string)


def move_xmls_to_working_dir(**context):
    runtime_details = context["ti"].xcom_pull(
        task_ids=get_execution_details_task.task_id
    )
    runtime_directory_path = runtime_details[1]

    gcs_client = storage.Client()
    blobs = gcs_client.list_blobs(
        deployment_bucket_name, prefix=f"{runtime_directory_path}", delimiter="/"
    )
    for blob in blobs:
        move_file_within_gcs(blob.name, "working")
    logging.info("XML files moved to working dir")

    if send_to_mq:
        return "get_jar_file_from_gcs"

    return "end"


def move_file_within_gcs(src_blob_path, new_dir):
    gcs_client = storage.Client()
    bucket = gcs_client.get_bucket(deployment_bucket_name)
    src_blob = bucket.blob(src_blob_path)
    destination_blob_path = "/".join(src_blob_path.split("/")[:2] + [new_dir] + src_blob_path.split("/")[3:])
    destination_generation_match_precondition = 0

    bucket.copy_blob(
        src_blob, bucket, destination_blob_path, if_generation_match=destination_generation_match_precondition,
    )

    bucket.delete_blob(src_blob_path)
    logging.info(f"XML File moved to {new_dir}")


def send_xml_to_mq(**context):
    runtime_details = context["ti"].xcom_pull(
        task_ids=get_execution_details_task.task_id
    )
    runtime_directory_path = runtime_details[1]
    path_till_dir = runtime_directory_path.split("/")[:2]
    path_after_dir = runtime_directory_path.split("/")[3:]
    working_directory_path = "/".join(path_till_dir + ["working"] + path_after_dir)
    hostname = export_variables["hostname"]
    port = export_variables["port"]
    channel = export_variables["channel"]
    queue_manager = export_variables["queue_manager"]
    queue = export_variables["queue"]
    username = export_variables["username"]
    password = export_variables["password"]

    gcs_client = storage.Client()
    blobs = gcs_client.list_blobs(
        deployment_bucket_name, prefix=f"{working_directory_path}", delimiter="/"
    )

    for blob in blobs:
        xml = blob.download_as_string().decode("utf-8")
        jar = f"'{composer_fs_base_path}/{jar_path}' '{jar_name}'"
        args = f"{hostname} {port} {channel} {queue_manager} {queue} {username} {password} '{xml}'"
        command = f"""cd {bash_script_path} && bash execute_jar.sh {jar} {main_class} {args}"""

        try:
            result = subprocess.run(
                command,
                cwd=f"{composer_fs_base_path}",
                shell=True,
                text=True,
                capture_output=True,
            )
            logging.info(f"\n{result.stdout},\n{result.stderr}")
            if result.returncode == 0:
                move_file_within_gcs(blob.name, "success")
            else:
                move_file_within_gcs(blob.name, "failed")
        except Exception as e:
            logging.info(e)
            move_file_within_gcs(blob.name, "failed")


def truncate_staging_table_func(**context):
    fetch_and_execute_sql_in_bq(
        context["ti"],
        context["bucket_name"],
        context["sql_query_path"],
        context["operation"],
    )


def execute_decision_logging_query_func(**context):
    fetch_and_execute_sql_in_bq(
        context["ti"],
        context["bucket_name"],
        context["sql_query_path"],
        context["operation"],
    )


def fetch_and_execute_sql_in_bq(ti, bucket_name, sql_query_path, operation):
    if operation == "truncate":
        try:
            logging.info(
                f"Fetching sql query present in gs://{bucket_name}/{sql_query_path}"
            )

            client = storage.Client(project=processing_project_name)
            bucket = client.get_bucket(bucket_name)
            query_blob = bucket.blob(sql_query_path)
            load_to_export_query = (
                query_blob.download_as_string()
                .decode("utf-8")
                .replace("@derived_project_id", derived_project_name)
                .replace("@product_rsp_dataset", product_rsp_dataset)
            )

            logging.info("Executing the query..")

            bq_client = bigquery.Client(project=derived_project_name)
            insertion_task = bq_client.query(load_to_export_query)
            insertion_task.result()
            logging.info("The table was truncated successfully")
            return
        except Exception as error:
            raise AirflowException(
                f"Following error occurred while truncating table: {error}"
            )
    else:
        runtime_details = ti.xcom_pull(task_ids="get_execution_details")
        execution_date = runtime_details[0]
        try:
            logging.info(
                f"Fetching sql query present in gs://{bucket_name}/{sql_query_path}"
            )

            client = storage.Client(project=processing_project_name)
            bucket = client.get_bucket(bucket_name)
            query_blob = bucket.blob(sql_query_path)
            load_to_export_query = (
                query_blob.download_as_string()
                .decode("utf-8")
                .replace("@derived_project_id", derived_project_name)
                .replace("@product_rsp_dataset", product_rsp_dataset)
                .replace("@scheduler_date", execution_date)
            )

            logging.info("Executing the query..")

            bq_client = bigquery.Client(project=derived_project_name)
            insertion_task = bq_client.query(load_to_export_query)
            insertion_task.result()
            logging.info("The table was loaded with sql result successfully")
            return

        except Exception as error:
            raise AirflowException(
                f"Following error occurred while executing export table query: {error}"
            )


def end_func(**context):
    runtime_details = context["ti"].xcom_pull(
        task_ids=get_execution_details_task.task_id
    )
    runtime_directory_path = runtime_details[1]
    path_till_dir = runtime_directory_path.split("/")[:2]
    path_after_dir = runtime_directory_path.split("/")[3:]
    failed_blob_path = "/".join(path_till_dir + ["failed"] + path_after_dir)
    gcs_client = storage.Client()
    blobs = gcs_client.list_blobs(
        deployment_bucket_name, prefix=failed_blob_path, delimiter="/"
    )
    list_blobs = list(blobs)

    if len(list_blobs) > 0:
        raise AirflowException(f"""################ XML to MQ has failed ###################\n
        Failed directory found in deployment bucket for runtime_path : {failed_blob_path}
        """)


def delete_files_from_local_func(**context):

    try:
        delete_jar_file = GCSDeleteObjectsOperator(
            task_id="delete_jar_file",
            bucket_name=composer_bucket_name,
            objects=[f"{composer_mount_path}/{jar_path}/{jar_name}"],
        )
        delete_jar_file.execute(dict(context))

    except Exception:
        logging.info(
            f"Jar file not found in composer bucket path - {composer_mount_path}/{jar_path}/{jar_name}"
        )

    try:
        delete_bash_file = GCSDeleteObjectsOperator(
            task_id="delete_bash_file",
            bucket_name=composer_bucket_name,
            objects=[f"{composer_mount_path}/{bash_script_path}/{bash_script_name}"],
        )
        delete_bash_file.execute(dict(context))
    except Exception:
        logging.info(
            f"""Bash Script file not found in composer bucket path -
                {composer_mount_path}/{bash_script_path}/{bash_script_name}"""
        )


with DAG(
    dag_id="ex_product_rsp_gwpc_decision_xml_to_mq",
    description="Convert gwpc decision to xml and send it to IBM MQ",
    tags=["Quantiphi", "rsp_export", "xml", "daily"],
    schedule_interval=None,
    start_date=datetime(2023, 7, 24),
) as dag:

    start = EmptyOperator(
        task_id="start",
    )

    get_execution_details_task = PythonOperator(
        task_id="get_execution_details", python_callable=get_execution_date_func
    )

    truncate_staging_table_task = PythonOperator(
        task_id="truncate_decision_logging_staging_table",
        python_callable=truncate_staging_table_func,
        op_kwargs={
            "bucket_name": deployment_bucket_name,
            "sql_query_path": send_gwpc_decision_truncate_query_path,
            "operation": "truncate",
        },
        provide_context=True,
    )

    execute_decision_logging_query_task = PythonOperator(
        task_id="execute_decision_logging_query",
        python_callable=execute_decision_logging_query_func,
        op_kwargs={
            "bucket_name": deployment_bucket_name,
            "sql_query_path": send_gwpc_decision_insert_query_path,
            "operation": "insert",
        },
        provide_context=True,
    )

    check_if_export_table_is_empty_task = BranchPythonOperator(
        task_id="check_if_export_table_is_empty",
        python_callable=check_if_export_table_is_empty
    )

    convert_df_to_xml_task = PythonOperator(
        task_id="convert_df_to_xml",
        python_callable=convert_row_to_xml_func,
        provide_context=True,
    )

    move_xmls_to_working_dir_task = BranchPythonOperator(
        task_id="move_xmls_to_working_dir",
        python_callable=move_xmls_to_working_dir,
        provide_context=True
    )

    get_jar_file_from_gcs_task = GCSToGCSOperator(
        task_id="get_jar_file_from_gcs",
        source_bucket=deployment_bucket_name,
        source_objects=[f"{jar_path}/{jar_name}"],
        destination_bucket=composer_bucket_name,
        destination_object=f"{composer_mount_path}/{jar_path}/{jar_name}",
        exact_match=True,
    )

    get_bash_script_file_from_gcs_task = GCSToGCSOperator(
        task_id="get_bash_script_file_from_gcs",
        source_bucket=deployment_bucket_name,
        source_objects=[f"{bash_script_path}/{bash_script_name}"],
        destination_bucket=composer_bucket_name,
        destination_object=f"{composer_mount_path}/{bash_script_path}/{bash_script_name}",
        exact_match=True,
    )

    send_xml_to_mq_task = PythonOperator(
        task_id="send_xml_to_mq", python_callable=send_xml_to_mq, provide_context=True
    )

    delete_files_from_local_task = PythonOperator(
        task_id="delete_files_from_local",
        python_callable=delete_files_from_local_func,
        provide_context=True
    )

    end = PythonOperator(
        task_id="end",
        python_callable=end_func,
        provide_context=True,
        trigger_rule="none_failed_min_one_success"
    )

    (
        start
        >> get_execution_details_task
        >> truncate_staging_table_task
        >> execute_decision_logging_query_task
        >> check_if_export_table_is_empty_task
        >> [end, convert_df_to_xml_task]
    )

    (
        convert_df_to_xml_task
        >> move_xmls_to_working_dir_task
        >> [end, get_jar_file_from_gcs_task]
    )

    (
        get_jar_file_from_gcs_task
        >> get_bash_script_file_from_gcs_task
        >> send_xml_to_mq_task
        >> delete_files_from_local_task
        >> end
    )
