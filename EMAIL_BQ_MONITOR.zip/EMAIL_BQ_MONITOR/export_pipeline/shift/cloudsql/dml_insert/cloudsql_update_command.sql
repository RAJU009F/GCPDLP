UPDATE
    export_framework.exf_ds_def
SET
    exf_ds_name = 'dp-prod-derived-2072.product_fraud_shift'
where
    exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift';