INSERT INTO
	export_framework.exf_ds_def (
		exf_ds_name,
		exf_ds_desc,
		exf_ds_type,
		exf_ds_location,
		exf_conn_type,
		exf_conn_details_variable
	)
VALUES
	(
		"dp-prod-curated-b30b.product_fraud_shift",
		"BQ dataset for shift_tables table",
		"BigQuery",
		"northamerica-northeast1",
		"BigQuery",
		""
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_auto_policy_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/auto_policy/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_auto_policy`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_auto_policy", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_auto_sub_claim_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/auto_sub_claim/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_auto_sub_claim`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_auto_sub_claim", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_claim_financial_detail_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/claim_financial_detail/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_claim_financial_detail`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_claim_financial_detail", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_involved_covers_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/involved_covers/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_involved_covers`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_involved_covers", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_claim_involved_party_role_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/claim_involved_party_role/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_claim_involved_party_role`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_claim_involved_party_role", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_claim_involved_party_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/claim_involved_party/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_claim_involved_party`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_claim_involved_party", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_claim_involved_vehicle_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/claim_involved_vehicle/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_claim_involved_vehicle`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_claim_involved_vehicle", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_claim_note_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/claim_note/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_claim_note`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_claim_note", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_claim_party_address_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/claim_party_address/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_claim_party_address`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_claim_party_address", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_claim_payment_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/claim_payment/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_claim_payment`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_claim_payment", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_coverage_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/coverage/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_coverage`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_coverage", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_vendors_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/vendors/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_vendors`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_vendors", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_first_party_vehicle_external_data_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/first_party_vehicle_external_data/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_first_party_vehicle_external_data`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_first_party_vehicle_external_data", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_injury_detail_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/injury_detail/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_injury_detail`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_injury_detail", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_policy_party_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/policy_party/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_policy_party`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_policy_party", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_policy_vehicle_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/policy_vehicle/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_policy_vehicle`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_policy_vehicle", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_policy_version_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/policy_version/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_policy_version`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_policy_version", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_vehicle_driver_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/vehicle_driver/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_vehicle_driver`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_vehicle_driver", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_product_fraud_shift_auto_claim_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.product_fraud_shift'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/product_fraud_shift/auto_claim/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_auto_claim`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		"|",
		"CSV",
		'{"filename": {"base": "shift_auto_claim", "extension": "csv", "separator": "|"}}',
		NULL,
		NULL,
		NULL,
		NULL
	);