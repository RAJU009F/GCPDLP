update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_auto_policy`;'
where
    exf_job_name = 'ex_product_fraud_shift_auto_policy_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_auto_sub_claim`;'
where
    exf_job_name = 'ex_product_fraud_shift_auto_sub_claim_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_claim_financial_detail`;'
where
    exf_job_name = 'ex_product_fraud_shift_claim_financial_detail_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_involved_covers`;'
where
    exf_job_name = 'ex_product_fraud_shift_involved_covers_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_claim_involved_party_role`;'
where
    exf_job_name = 'ex_product_fraud_shift_claim_involved_party_role_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_claim_involved_party`;'
where
    exf_job_name = 'ex_product_fraud_shift_claim_involved_party_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_claim_involved_vehicle`;'
where
    exf_job_name = 'ex_product_fraud_shift_claim_involved_vehicle_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_claim_note`;'
where
    exf_job_name = 'ex_product_fraud_shift_claim_note_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_claim_party_address`;'
where
    exf_job_name = 'ex_product_fraud_shift_claim_party_address_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_claim_payment`;'
where
    exf_job_name = 'ex_product_fraud_shift_claim_payment_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_coverage`;'
where
    exf_job_name = 'ex_product_fraud_shift_coverage_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_vendors`;'
where
    exf_job_name = 'ex_product_fraud_shift_vendors_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_first_party_vehicle_external_data`;'
where
    exf_job_name = 'ex_product_fraud_shift_first_party_vehicle_external_data_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_injury_detail`;'
where
    exf_job_name = 'ex_product_fraud_shift_injury_detail_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_policy_party`;'
where
    exf_job_name = 'ex_product_fraud_shift_policy_party_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_policy_vehicle`;'
where
    exf_job_name = 'ex_product_fraud_shift_policy_vehicle_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_policy_version`;'
where
    exf_job_name = 'ex_product_fraud_shift_policy_version_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_vehicle_driver`;'
where
    exf_job_name = 'ex_product_fraud_shift_vehicle_driver_to_gcs';

update
    export_framework.exf_job_def
set
    exf_src_query = 'SELECT * EXCEPT(dlh_batch_ts, dlh_process_ts) FROM `$project_id.$dataset_id.export_auto_claim`;'
where
    exf_job_name = 'ex_product_fraud_shift_auto_claim_to_gcs';