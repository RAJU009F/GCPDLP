INSERT INTO
    `@derived_project_id.@derived_dataset.@export_table_name` (
        SELECT
            *
        FROM
            `@derived_project_id.@derived_dataset.@final_table_name`
        WHERE
            dlh_batch_ts = '@dlh_batch_ts' and dlh_process_ts = '@dlh_process_ts'
    );