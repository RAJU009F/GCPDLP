CREATE TABLE IF NOT EXISTS `dp-dev-derived-ea49.product_fraud_shift.export_vehicle_driver` (
    dlh_batch_ts DATETIME,
    dlh_process_ts DATETIME,
    policy_id STRING,
    version_number STRING,
    vehicle_id STRING,
    data_timestamp DATETIME,
    party_id STRING,
    driver_type STRING,
    driver_id STRING,
    etl_process_timestamp STRING DEFAULT NULL
);