CREATE TABLE IF NOT EXISTS `dp-dev-derived-ea49.product_fraud_shift.export_claim_involved_party_role` (
    dlh_batch_ts DATETIME,
    dlh_process_ts DATETIME,
    claim_number STRING,
    data_timestamp DATETIME,
    source_system STRING,
    involved_party_id STRING,
    role_code STRING,
    cds_claim_number STRING,
    claimant_number STRING,
    role_description STRING,
    role_involved_vehicle_id STRING,
    role_involved_property_id STRING,
    active_indicator STRING,
    comment STRING,
    etl_process_timestamp STRING DEFAULT NULL
);