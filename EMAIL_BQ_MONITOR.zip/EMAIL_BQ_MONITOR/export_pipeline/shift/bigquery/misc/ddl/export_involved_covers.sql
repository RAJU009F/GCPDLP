CREATE TABLE IF NOT EXISTS `dp-dev-derived-ea49.product_fraud_shift.export_involved_covers` (
    dlh_batch_ts DATETIME,
    dlh_process_ts DATETIME,
    claim_number STRING,
    data_timestamp DATETIME,
    source_system STRING,
    line_type_code STRING,
    cds_claim_number STRING,
    user_sub_map STRING,
    line_type_description STRING,
    coverage_lob STRING,
    subcoverage STRING,
    acturay_coverage_string STRING,
    etl_process_timestamp STRING DEFAULT NULL
);