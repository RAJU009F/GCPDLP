CREATE TABLE IF NOT EXISTS `dp-dev-derived-ea49.product_fraud_shift.export_claim_note` (
    dlh_batch_ts DATETIME,
    dlh_process_ts DATETIME,
    claim_number STRING,
    data_timestamp DATETIME,
    source_system STRING,
    note_id STRING,
    cds_claim_number STRING,
    note_creation_timestamp DATETIME,
    sub_claim_type STRING,
    note_text STRING,
    note_detail STRING,
    etl_process_timestamp STRING DEFAULT NULL
);