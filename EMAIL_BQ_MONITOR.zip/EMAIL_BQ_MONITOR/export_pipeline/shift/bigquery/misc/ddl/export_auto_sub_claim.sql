CREATE TABLE IF NOT EXISTS `dp-dev-derived-ea49.product_fraud_shift.export_auto_sub_claim` (
    dlh_batch_ts DATETIME,
    dlh_process_ts DATETIME,
    claim_number STRING,
    data_timestamp DATETIME,
    source_system STRING,
    sub_claim_number STRING,
    cds_claim_number STRING,
    coverage_lob STRING,
    sub_claim_status_code STRING,
    sub_claim_status_description STRING,
    sub_claim_loss_code STRING,
    sub_claim_loss_description STRING,
    etl_process_timestamp STRING DEFAULT NULL
);