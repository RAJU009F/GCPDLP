CREATE TABLE IF NOT EXISTS
    `dp-dev-derived-ea49.product_fraud_shift.export_injury_detail` (
        dlh_batch_ts DATETIME,
        dlh_process_ts DATETIME,
        claim_number STRING,
        involved_party_id STRING,
        data_timestamp DATETIME,
        source_system STRING,
        injury_id STRING,
        cds_claim_number STRING,
        injuries_class STRING,
        injuries_class_description STRING,
        injuries_detail STRING,
        permanent_partial_invalidity_percentage NUMERIC(6, 4),
        etl_process_timestamp STRING DEFAULT NULL
    );