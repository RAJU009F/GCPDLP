CREATE TABLE IF NOT EXISTS `dp-dev-derived-ea49.product_fraud_shift.export_policy_version` (
    dlh_batch_ts DATETIME,
    dlh_process_ts DATETIME,
    policy_id STRING,
    version_number STRING,
    data_timestamp DATETIME,
    version_effective_date DATETIME,
    version_end_date DATETIME,
    type_of_modification STRING,
    cover_formula STRING,
    bonus_penalty_level STRING,
    premium_amount NUMERIC(20, 4),
    etl_process_timestamp STRING DEFAULT NULL
);