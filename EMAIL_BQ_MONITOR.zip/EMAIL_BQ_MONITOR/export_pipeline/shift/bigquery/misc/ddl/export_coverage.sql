CREATE TABLE IF NOT EXISTS `dp-dev-derived-ea49.product_fraud_shift.export_coverage` (
    dlh_batch_ts DATETIME,
    dlh_process_ts DATETIME,
    policy_id STRING,
    version_number STRING,
    data_timestamp DATETIME,
    coverage_id STRING,
    coverage_category_name STRING,
    coverage_subtype STRING,
    set_of_subscribed_covers STRING,
    set_of_subscribed_cover_term STRING,
    coverage_term STRING,
    term_value STRING,
    insured_item_id STRING,
    etl_process_timestamp STRING DEFAULT NULL
);