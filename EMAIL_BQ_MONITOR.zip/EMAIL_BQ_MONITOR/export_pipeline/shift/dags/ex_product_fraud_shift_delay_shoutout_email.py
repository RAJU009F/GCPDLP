import logging
from datetime import datetime, timedelta
import pytz
import re

from airflow import models
from airflow.models import Variable
from airflow.operators.python import PythonOperator
from airflow.operators.email import EmailOperator
from airflow.operators.empty import EmptyOperator
from google.cloud import bigquery
from google.cloud import storage

est_tz = pytz.timezone("America/Toronto")

# Pulling values from the defined variables
deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_project_id = Variable.get("derived_project_name")
processing_project_name = Variable.get("processing_project_name")

DAG_VARIABLES_KEY = "shift_export_variables"
variables = Variable.get(DAG_VARIABLES_KEY, deserialize_json=True)

sql_base_path = variables["sql_base_path"]
max_dlh_process_ts = variables["shift_email_query_path"]
max_dlh_process_ts_query_path = sql_base_path + max_dlh_process_ts
derived_dataset = variables["derived_dataset"]
shift_delay_shoutout_email = variables["shift_delay_shoutout_email"]

shift_table_names = variables["shift_table_names"]
shift_table_names = shift_table_names.split(",")


def get_execution_date_func(**kwargs):
    """
    function to get execution date from conf
    """
    try:
        yesterday_date = kwargs["dag_run"].conf["run_date"]
        print("This is the order date from Scheduler", yesterday_date)
        execution_runtime = kwargs["logical_date"].astimezone(est_tz)

        current_date = execution_runtime.strftime("%Y-%m-%d")

        return yesterday_date, current_date

    except Exception as exception:
        logging.info(exception)
        execution_runtime = kwargs["logical_date"].astimezone(est_tz)
        yesterday_date = execution_runtime - timedelta(days=1)
        yesterday_date = yesterday_date.strftime("%Y-%m-%d")

        current_date = execution_runtime.strftime("%Y-%m-%d")

        return yesterday_date, current_date


def get_date_func(dlh_process_ts, tablename):
    date_pattern = re.compile(r"(\d\d\d\d)-(\d\d)-(\d\d)")
    pattern_object = date_pattern.search(dlh_process_ts)
    try:
        dlh_process_ts_date = pattern_object.group()
        return dlh_process_ts_date
    except Exception as exception:
        logging.info(
            f"Error occured while getting max_dlh_process_ts_date for {tablename} : {exception}"
        )


def feth_dlh_process_ts_func(sql, table_name):
    client = bigquery.Client(project=derived_project_id)
    query_job = client.query(sql)
    result = query_job.result()
    dlh_process_ts = None
    for row in result:
        dlh_process_ts = row[0]
        break
    logging.info(f"max_dlh_process_ts for {table_name} is :{dlh_process_ts}")
    return dlh_process_ts


def generate_email_fun(**context):
    execution_details = context["ti"].xcom_pull(task_ids=get_execution_date.task_id)
    yesterday_date = execution_details[0]
    current_date = execution_details[1]

    storage_client = storage.Client(project=processing_project_name)
    deployment_bucket = storage_client.get_bucket(deployment_bucket_name)
    max_dlh_process_ts_query_blob = deployment_bucket.blob(
        max_dlh_process_ts_query_path
    )
    max_dlh_process_ts_query = max_dlh_process_ts_query_blob.download_as_text()

    logging.info("JOb started....")

    email_body = "This email is to notify the status of SHIFT jobs as of 8:30 AM\n\n\n"

    for table_name in shift_table_names:
        query = max_dlh_process_ts_query.replace(
            "@derived_dataset", derived_dataset
        ).replace("@table_name", table_name)
        max_dlh_process_timestamp = str(feth_dlh_process_ts_func(query, table_name))
        dlh_process_date = get_date_func(max_dlh_process_timestamp, table_name)

        if (
            table_name == "involved_covers"
            or table_name == "claim_payment"
            or table_name == "claim_financial_detail"
        ):
            if dlh_process_date == current_date or dlh_process_date == yesterday_date:
                email_body += f"shift_{table_name} is COMPLETED\n"
            else:
                email_body += f"shift_{table_name} is delayed\n"
        else:
            if dlh_process_date != current_date:
                email_body += f"shift_{table_name} is delayed\n"
            else:
                email_body += f"shift_{table_name} is COMPLETED\n"

    email_body += "\n\n\n Thank You \n"

    task_instance = context["task_instance"]
    task_instance.xcom_push(key="email_body", value=email_body)

    logging.info("Email Body:", email_body)


def send_email_func(**context):
    try:
        email_body = context["ti"].xcom_pull(
            task_ids=generate_email_task.task_id, key="email_body"
        )

        email_content = email_body.replace("\n", "<br>")

        logging.info("Sending an email")

        email_task = EmailOperator(
            task_id="send_email",
            conn_id="sendgrid_default",
            to=[shift_delay_shoutout_email],
            subject="SHIFT Job Status 8:30 AM",
            html_content=email_content,
            mime_charset="utf-8",
        )
        email_task.execute(context)

        logging.info("Email sent")
    except Exception as e:
        logging.info(f"An error occurred: {str(e)}")


with models.DAG(
    dag_id="ex_product_fraud_shift_delay_shoutout_email",
    start_date=datetime(2023, 7, 17),
    tags=["shift", "fraud", "fraud_shift", "bq", "derived", "email", "daily", "notification"],
    schedule_interval=None,
    catchup=False,
    max_active_runs=1,
) as dag:
    start = EmptyOperator(
        task_id="start",
    )

    get_execution_date = PythonOperator(
        task_id="get_execution_date",
        python_callable=get_execution_date_func,
        provide_context=True,
    )

    generate_email_task = PythonOperator(
        task_id="generate_email_task",
        python_callable=generate_email_fun,
        provide_context=True,
    )

    send_email_task = PythonOperator(
        task_id="send_email_task",
        python_callable=send_email_func,
        provide_context=True,
    )

    end = EmptyOperator(task_id="End")

(start >> get_execution_date >> generate_email_task >> send_email_task >> end)
