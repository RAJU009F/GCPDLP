import logging
from datetime import datetime
import subprocess

from google.cloud import bigquery, storage

from airflow import DAG
from airflow.models import Variable
from airflow.exceptions import AirflowException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.google.cloud.transfers.gcs_to_sftp import GCSToSFTPOperator
from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator
from airflow.providers.google.cloud.operators.gcs import GCSDeleteObjectsOperator


derived_project_name = Variable.get("derived_project_name")
derived_bucket_name = Variable.get("derived_bucket_name")
processing_project_name = Variable.get("processing_project_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
composer_bucket_name = Variable.get("composer_bucket_name")

variables = Variable.get("shift_export_variables", deserialize_json=True)

framework_path = variables["framework_path"]
troubleshooting_path = variables["troubleshooting_path"]
job_book_path = variables["job_book_path"]

export_to_ftp = variables["export_to_ftp"]
ftp_conn_id = variables["shift_ftp_connection_id"]
ftp_path = variables["shift_archive_path"]
src_path = variables["src_path"]
local_src_path = variables["local_src_path"]

derived_dataset = variables["derived_dataset"]
export_table_name = variables["claim_party_address_export_table_name"]
final_table_name = variables["claim_party_address_final_table_name"]

bash_command_path = variables["bash_command_path"]

sql_base_path = variables["sql_base_path"]
load_to_export_query_path = sql_base_path + variables["load_to_export_query_path"]
truncate_export_table_query_path = (
    sql_base_path + variables["truncate_export_query_path"]
)

filename_pattern = variables["claim_party_address_file_name"]
output_filename = variables["claim_party_address_output_file"]

derived_path = variables["claim_party_address_derived_path"]
output_path = variables["claim_party_address_output_path"].replace(
    "@claim_party_address_derived_path", derived_path
)
runtime_path = variables["claim_party_address_runtime_path"].replace(
    "@claim_party_address_derived_path", derived_path
)


def get_execution_date_func(**kwargs):
    """
    Function to get execution date from Control-M
    """
    try:
        execution_date = kwargs["dag_run"].conf["run_date"]
        process_ts = kwargs["dag_run"].conf["process_ts"]

        logging.info("Order date received from scheduler: ", execution_date)

        runtime_timestamp = datetime.strptime(process_ts, "%Y-%m-%d %H:%M:%S")
        runtime_timestamp = runtime_timestamp.strftime("%Y%m%d%H%M%S")

        runtime_dir_path = runtime_path.replace(
            "@execution_datetime", runtime_timestamp
        )

        return execution_date, runtime_dir_path, runtime_timestamp, process_ts

    except Exception as exception:
        raise AirflowException(
            f"Following error occurred while getting run_date from transformation dag: {exception}"
        )


def get_ftp_filename(runtime_timestamp):
    ftp_filename = filename_pattern.replace("@execution_date", runtime_timestamp)
    return ftp_filename


def load_export_table_func(**context):
    runtime_details = context["ti"].xcom_pull(task_ids=get_execution_date.task_id)
    execution_date = runtime_details[0]
    dlh_process_ts = runtime_details[3]

    try:
        logging.info(
            f"Fetching sql query present in gs://{deployment_bucket_name}/{load_to_export_query_path}"
        )

        bq_client = bigquery.Client(project=derived_project_name)

        client = storage.Client(project=processing_project_name)
        bucket = client.get_bucket(deployment_bucket_name)
        truncate_query_blob = bucket.blob(truncate_export_table_query_path)
        truncate_export_query = (
            truncate_query_blob.download_as_string()
            .decode("utf-8")
            .replace("@derived_project_id", derived_project_name)
            .replace("@derived_dataset", derived_dataset)
            .replace("@export_table_name", export_table_name)
        )

        truncate_task = bq_client.query(truncate_export_query)
        truncate_task.result()

        logging.info("Data truncated successfully..")

        load_query_blob = bucket.blob(load_to_export_query_path)
        load_to_export_query = (
            load_query_blob.download_as_string()
            .decode("utf-8")
            .replace("@derived_project_id", derived_project_name)
            .replace("@derived_dataset", derived_dataset)
            .replace("@export_table_name", export_table_name)
            .replace("@dlh_batch_ts", execution_date)
            .replace("@dlh_process_ts", dlh_process_ts)
            .replace("@final_table_name", final_table_name)
        )

        insertion_task = bq_client.query(load_to_export_query)
        insertion_task.result()

        logging.info(
            "The table was truncated and the data was successfully inserted into the export table."
        )

    except Exception as error:
        raise AirflowException(
            f"Following error occurred while loading data to export table: {error}"
        )


def ex_product_fraud_shift_claim_party_address_to_gcs_func(**context):
    try:
        trigger_ex_product_fraud_shift_claim_party_address_to_gcs = TriggerDagRunOperator(
            task_id="trigger_ex_product_fraud_shift_claim_party_address_to_gcs",
            trigger_dag_id="ex_product_fraud_shift_claim_party_address_to_gcs",
            wait_for_completion=True,
            poke_interval=60,
        )
        trigger_ex_product_fraud_shift_claim_party_address_to_gcs.execute(
            dict(context)
        )

        return move_files_to_runtime.task_id

    except Exception as error:
        raise AirflowException(
            f"Following error occurred while exporting sonnet data to GCS: {error}"
        )


def move_files_to_runtime_func(**context):
    runtime_details = context["ti"].xcom_pull(task_ids=get_execution_date.task_id)
    runtime_dir_path = runtime_details[1]
    runtime_timestamp = runtime_details[2]

    ftp_filename = get_ftp_filename(runtime_timestamp)

    task_instance = context["task_instance"]
    task_instance.xcom_push(key="ftp_filename", value=ftp_filename)

    try:
        move_claim_party_address_file = GCSToGCSOperator(
            task_id="move_claim_party_address_file",
            source_bucket=derived_bucket_name,
            source_object=f"{output_path}{output_filename}",
            destination_bucket=derived_bucket_name,
            destination_object=f"{runtime_dir_path}{ftp_filename}",
            move_object=True,
        )
        move_claim_party_address_file.execute(dict(context))

        if export_to_ftp.lower() == "true":
            return copy_files_to_local.task_id
        else:
            return end.task_id

    except Exception as error:
        raise AirflowException(
            f"""Following error occurred while moving files from output path - {output_path} to
                runtime path - {runtime_dir_path}: {error}"""
        )


def append_count_lines_for_audit_purpose_func(**context):
    """
    fun used to add the row count in the csv
    """
    ftp_filename = context["ti"].xcom_pull(
        task_ids=move_files_to_runtime.task_id, key="ftp_filename"
    )

    client = storage.Client(project=processing_project_name)
    bucket = client.get_bucket(deployment_bucket_name)
    bash_command_blob = bucket.blob(bash_command_path)
    command = (
        bash_command_blob.download_as_string()
        .decode("utf-8")
        .replace("@file_name", ftp_filename)
    )

    result = subprocess.run(
        command, cwd=local_src_path, shell=True, text=True, capture_output=True
    )

    logging.info("audit record data successfully appended")

    if result.returncode != 0:
        raise AirflowException("Error occured while adding row_count in csv file")


def copy_files_to_local_func(**context):
    runtime_details = context["ti"].xcom_pull(task_ids=get_execution_date.task_id)
    runtime_dir_path = runtime_details[1]

    try:
        copy_files_to_local = GCSToGCSOperator(
            task_id="copy_files_to_local",
            source_bucket=derived_bucket_name,
            source_object=f"{runtime_dir_path}*.csv",
            destination_bucket=composer_bucket_name,
            destination_object=src_path,
            move_object=False,
        )
        copy_files_to_local.execute(dict(context))

        return move_files_to_ftp.task_id

    except Exception as error:
        raise AirflowException(
            f"""Following error occurred while copying files from {runtime_dir_path} to
                composer src path - {src_path} : {error}"""
        )


def move_files_to_ftp_func(**context):
    ftp_filename = context["ti"].xcom_pull(
        task_ids=move_files_to_runtime.task_id, key="ftp_filename"
    )

    try:
        upload_files_on_ftp = GCSToSFTPOperator(
            task_id="upload_files_on_ftp",
            sftp_conn_id=ftp_conn_id,
            source_bucket=composer_bucket_name,
            source_object=f"{src_path}{ftp_filename}",
            destination_path=ftp_path,
            keep_directory_structure=False,
        )
        upload_files_on_ftp.execute(dict(context))

        return end.task_id
    except Exception as error:
        raise AirflowException(
            f"""Following error occurred while moving files from composer bucket path - {src_path} to
                FTP path - {ftp_path}: {error}"""
        )


def delete_files_from_local_func(**context):
    ftp_filename = context["ti"].xcom_pull(
        task_ids=move_files_to_runtime.task_id, key="ftp_filename"
    )

    try:
        delete_files = GCSDeleteObjectsOperator(
            task_id="delete_files",
            bucket_name=composer_bucket_name,
            objects=[f"{src_path}{ftp_filename}"],
        )
        delete_files.execute(dict(context))

    except Exception as error:
        raise AirflowException(
            f"Following error occurred while deleting file from composer bucket path - {src_path}: {error}"
        )


with DAG(
    dag_id="ex_product_fraud_shift_claim_party_address_to_ftp",
    start_date=datetime(2023, 8, 1),
    tags=["csv", "daily", "derived", "fraud"],
    schedule_interval=None,
    catchup=False,
    max_active_runs=1,
) as dag:
    start = EmptyOperator(
        task_id="start",
    )

    get_execution_date = PythonOperator(
        task_id="get_execution_date",
        python_callable=get_execution_date_func,
        provide_context=True,
    )

    load_export_table = PythonOperator(
        task_id="load_export_table_func",
        python_callable=load_export_table_func,
        provide_context=True,
    )

    ex_product_fraud_shift_claim_party_address_to_gcs = PythonOperator(
        task_id="ex_product_fraud_shift_claim_party_address_to_gcs",
        python_callable=ex_product_fraud_shift_claim_party_address_to_gcs_func,
        provide_context=True,
    )

    move_files_to_runtime = BranchPythonOperator(
        task_id="move_files_to_runtime",
        python_callable=move_files_to_runtime_func,
        trigger_rule="all_success",
        provide_context=True,
    )

    append_count_lines_for_audit_purpose = PythonOperator(
        task_id="append_count_lines_for_audit_purpose",
        python_callable=append_count_lines_for_audit_purpose_func,
        provide_context=True,
    )

    copy_files_to_local = PythonOperator(
        task_id="copy_files_to_local",
        python_callable=copy_files_to_local_func,
        provide_context=True,
    )

    move_files_to_ftp = PythonOperator(
        task_id="move_files_to_ftp",
        python_callable=move_files_to_ftp_func,
        provide_context=True,
    )

    delete_files_from_local = PythonOperator(
        task_id="delete_files_from_local",
        python_callable=delete_files_from_local_func,
        provide_context=True,
    )

    end = EmptyOperator(task_id="end", trigger_rule="none_failed_min_one_success")


dag.doc_md = f"""
### DAG Documentation
- Job Description - Extraction Jobs for RSP
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""


(
    start
    >> get_execution_date
    >> load_export_table
    >> ex_product_fraud_shift_claim_party_address_to_gcs
    >> move_files_to_runtime
    >> copy_files_to_local
    >> append_count_lines_for_audit_purpose
    >> move_files_to_ftp
    >> delete_files_from_local
    >> end
)

(
    start
    >> get_execution_date
    >> load_export_table
    >> ex_product_fraud_shift_claim_party_address_to_gcs
    >> move_files_to_runtime
    >> end
)
