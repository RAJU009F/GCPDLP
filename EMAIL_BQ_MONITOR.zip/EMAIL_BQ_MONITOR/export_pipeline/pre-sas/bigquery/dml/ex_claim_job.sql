TRUNCATE TABLE `@curated_project.@curated_dataset_name.export_PreSAS`;
INSERT INTO `@curated_project.@curated_dataset_name.export_PreSAS`(
SELECT
    main.cl_int_claim_num,
    main.cl_last_process_date,
    main.cl_processed_date,
    main.pol_num,
    main.loss_dt,
    main.occur_num,
    main.term_eff_dt,
    main.cds_number,
    main.subscription_prefix,
    main.contr_id,
    main.cl_pol_type,
    main.cl_pol_type_division,
    main.cl_pol_type_desc,
    main.last_fin_dt,
    main.pay_and_close_ind,
    main.insured_fault_pct,
    main.branch,
    main.no_claimants_open,
    main.no_claimants_clsd,
    main.no_covg_line_open,
    main.no_covg_line_clsd,
    main.no_rein_line_open,
    main.no_cov_det_lines_open,
    main.no_fin_hist,
    main.in_suit_cnt,
    main.siu_ab_ind,
    main.siu_non_ab_ind,
    main.cl_co_cd,
    main.cl_prov_cd,
    main.juris_prov_cd,
    main.total_loss_ind,
    main.loss_event_id,
    main.glass_repl_ind AS glass_repl_ind,
    main.ibc_stat_ter_cd AS ibc_stat_ter_cd,
    main.auto_loss_chart_cd AS auto_loss_chart_cd,
    main.auto_desc_of_loss_cd AS auto_desc_of_loss_cd,
    main.prop_desc_of_loss_cd,
    main.risk_pool_ind AS risk_pool_ind,
    main.facility_ind AS facility_ind,
    main.type_of_use AS type_of_use,
    main.type_of_use_comm AS type_of_use_comm,
    main.car_code AS car_code,
    main.body_type AS body_type,
    main.cl_status_cd,
    main.cl_open_dt,
    main.first_closed_date,
    main.curr_brk_num,
    main.repid_001,
    main.repid_002,
    main.repid_003,
    main.repid_004,
    main.repid_sup,
    main.repid_ho,
    main.mga_number,
    main.hndlng_br_num,
    main.cl_vin AS cl_vin,
    main.car_year AS car_year,
    main.make AS make,
    main.model AS model,
    main.veh_loc_pstl_cd AS veh_loc_pstl_cd,
    main.trailer_ind AS trailer_ind,
    main.rate_class AS rate_class,
    main.int_veh_num AS int_veh_num,
    main.auto_ibc_code AS auto_ibc_code,
    main.loc_city,
    main.loc_prov,
    main.total_losses,
    main.total_expense,
    main.total_loss_reserve,
    main.total_expense_reserve,
    main.total_interest_reserve,
    main.subrogation_tot,
    main.salvage_tot,
    main.prev_total_losses,
    main.prev_total_expense,
    main.prev_total_loss_reserve,
    main.prev_total_expense_reserve,
    main.prev_total_interest_reserv,
    main.prev_subrogation_tot,
    main.prev_salvage_tot,
    main.total_losses_delta,
    main.total_expense_delta,
    main.total_loss_reserve_delta,
    main.total_expense_reserve_delta,
    main.total_interest_reserve_delta,
    main.subrogation_tot_delta,
    main.salvage_tot_delta,
    main.cvg_int_claim_num,
    main.cvg_last_process_date,
    main.cvg_processed_date,
    main.cl_line_type_cd,
    main.cl_line_type_desc,
    main.cvg_seg_type,
    main.ibc_kindof_loss_cd,
    main.cl_class_bus_cd,
    main.cl_ibc_cd,
    main.cvg_cd,
    main.rag_num,
    main.kind_of_loss,
    main.deductible_amount,
    main.deductible_type,
    main.deduct_basis_cd,
    main.cvg_status_desc,
    main.cvg_open_dt,
    main.cvg_orig_loss_est,
    main.cvg_orig_expn_est,
    main.cvg_orig_intr_est,
    main.cvg_loss_pd_amt,
    main.cvg_expn_pd_amt,
    main.cvg_loss_resr_amt,
    main.cvg_expn_resr_amt,
    main.cvg_intr_resr_amt,
    main.cvg_loss_subr_amt,
    main.cvg_expn_subr_amt,
    main.cvg_salv_tot_amt,
    main.cvg_payback_amt,
    main.prev_cvg_loss_pd_amt,
    main.prev_cvg_expn_pd_amt,
    main.prev_cvg_loss_resr_amt,
    main.prev_cvg_expn_resr_amt,
    main.prev_cvg_intr_resr_amt,
    main.prev_cvg_loss_subr_amt,
    main.prev_cvg_expn_subr_amt,
    main.prev_cvg_salv_tot_amt,
    main.cvg_loss_pd_amt_delta,
    main.cvg_expn_pd_amt_delta,
    main.cvg_loss_resr_amt_delta,
    main.cvg_expn_resr_amt_delta,
    main.cvg_intr_resr_amt_delta,
    main.cvg_loss_subr_amt_delta,
    main.cvg_expn_subr_amt_delta,
    main.cvg_salv_tot_amt_delta,
    main.cvg_net_pd_amt,
    main.cvg_resr_amt,
    main.cvg_incurred_amt,
    main.ccvg_int_claim_num,
    main.ccvg_cl_line_type,
    main.ccvg_claimant_num,
    main.ccvg_last_process_date,
    main.ccvg_processed_date,
    main.ccvg_status_desc,
    main.ccvg_open_dt,
    main.ccvg_reopen_dt,
    main.ccvg_closed_dt,
    main.ccvg_orig_loss_est,
    main.ccvg_orig_expn_est,
    main.ccvg_orig_intr_est,
    main.ccvg_loss_pd_amt,
    main.ccvg_expn_pd_amt,
    main.ccvg_loss_resr_amt,
    main.ccvg_expn_resr_amt,
    main.ccvg_intr_resr_amt,
    main.ccvg_loss_subr_amt,
    main.ccvg_expn_subr_amt,
    main.ccvg_salv_tot_amt,
    main.ccvg_payback_amt,
    main.prev_ccvg_loss_pd_amt,
    main.prev_ccvg_loss_resr_amt,
    main.prev_ccvg_expn_pd_amt,
    main.prev_ccvg_expn_resr_amt,
    main.prev_ccvg_intr_resr_amt,
    main.prev_ccvg_loss_subr_amt,
    main.prev_ccvg_expn_subr_amt,
    main.prev_ccvg_salv_tot_amt,
    main.ccvg_loss_pd_amt_delta,
    main.ccvg_expn_pd_amt_delta,
    main.ccvg_loss_resr_amt_delta,
    main.ccvg_expn_resr_amt_delta,
    main.ccvg_intr_resr_amt_delta,
    main.ccvg_loss_subr_amt_delta,
    main.ccvg_expn_subr_amt_delta,
    main.ccvg_salv_tot_amt_delta,
    main.ccvg_net_pd_amt,
    main.ccvg_resr_amt,
    main.ccvg_incurred_amt,
    main.ccvg_tablr_reserve_ind,
    main.ccvg_tablr_resr_chng_dt,
    -- 818   --clmtinfo.*
    clmt.int_claim_num_818 AS eclmclmt_int_claim_num,
    clmt.claimant_num_818 AS eclmclmt_claimant_num,
    clmt.name_category_818 AS eclmclmt_name_category,
    clmt.last_process_date_818 AS eclmclmt_last_process_date,
    clmt.processed_date_818 AS eclmclmt_processed_date,
    clmt.eclmclmt_creation_date,
    clmt.eclmclmt_status_desc,
    clmt.eclmclmt_clmt_type_desc,
    clmt.eclmclmt_last_name,
    clmt.eclmclmt_first_name,
    clmt.eclmclmt_middle_name,
    clmt.eclmclmt_company_name,
    clmt.eclmclmt_cmpny_or_indvd_ind,
    clmt.eclmclmt_lic_num,
    clmt.eclmclmt_lic_prov,
    coalesce(CAST(clmt.eclmclmt_clmt_dob as STRING), '') AS eclmclmt_dob,
    clmt.eclmclmt_bi_code_orig,
    clmt.eclmclmt_bi_code_curr,
    clmt.eclmclmt_loss_trnsfr_code,
    clmt.eclmclmt_tp_vehic_type_desc
  FROM
    (SELECT
          clsum.int_claim_num_813 AS cl_int_claim_num,
          clsum.last_process_date_813 AS cl_last_process_date,
          clsum.processed_date_813 AS cl_processed_date,
          clsum.pol_num,
          clsum.loss_dt,
          clsum.occur_num,
          clsum.term_eff_dt,
          clsum.cds_number,
          clsum.subscription_prefix,
          clsum.contr_id,
          clsum.cl_pol_type,
          clsum.cl_pol_type_division,
          clsum.cl_pol_type_desc,
          clsum.last_fin_dt,
          clsum.pay_and_close_ind,
          clsum.insured_fault_pct,
          clsum.branch,
          clsum.no_claimants_open,
          clsum.no_claimants_clsd,
          clsum.no_covg_line_open,
          clsum.no_covg_line_clsd,
          clsum.no_rein_line_open,
          clsum.no_cov_det_lines_open,
          clsum.no_fin_hist,
          clsum.in_suit_cnt,
          clcom.siu_ab_ind,
          clcom.siu_non_ab_ind,
          clcom.cl_co_cd,
          clcom.cl_prov_cd,
          clcom.juris_prov_cd,
          clcom.total_loss_ind,
          clcom.loss_event_id,
          clcom.glass_repl_ind,
          clcom.ibc_stat_ter_cd,
          clcom.loss_chart AS auto_loss_chart_cd,
          clcom.loss_desc_code1 AS auto_desc_of_loss_cd,
          '' AS prop_desc_of_loss_cd,
          clcom.risk_pool_ind,
          clcom.facility_ind,
          clcom.type_of_use,
          clcom.type_of_use_comm,
          clcom.car_code,
          clcom.body_type,
          clsum.cl_status_desc_813 AS cl_status_cd,
          coalesce(CAST(clcom.cl_open_dt as STRING), '') AS cl_open_dt,
          coalesce(CAST(clcom.first_closed_date as STRING), '') AS first_closed_date,
          clcom.curr_brk_num,
          clcom.repid_001,
          clcom.repid_002,
          clcom.repid_003,
          clcom.repid_004,
          clcom.repid_sup,
          clcom.repid_ho,
          clcom.mga_number,
          clcom.hndlng_br_num,
          clcom.cl_vin,
          clcom.car_year,
          clcom.make,
          clcom.model,
          clcom.veh_loc_pstl_cd,
          clcom.trailer_ind,
          clcom.rate_class,
          clcom.int_veh_num,
          clcom.auto_ibc_code,
          '' AS loc_city,
          '' AS loc_prov,
          clsum.total_losses,
          clsum.total_expense,
          clsum.total_loss_reserve,
          clsum.total_expense_reserve,
          clsum.total_interest_reserve,
          clsum.subrogation_tot,
          clsum.salvage_tot,
          clsum.prev_total_losses,
          clsum.prev_total_expense,
          clsum.prev_total_loss_reserve,
          clsum.prev_total_expense_reserve,
          clsum.prev_total_interest_reserv,
          clsum.prev_subrogation_tot,
          clsum.prev_salvage_tot,
          clsum.total_losses_delta,
          clsum.total_expense_delta,
          clsum.total_loss_reserve_delta,
          clsum.total_expense_reserve_delta,
          clsum.total_interest_reserve_delta,
          clsum.subrogation_tot_delta,
          clsum.salvage_tot_delta,
          -- 822   --cvgsum.*
          cvgsum.int_claim_num_822 AS cvg_int_claim_num,
          cvgsum.last_process_date_822 AS cvg_last_process_date,
          cvgsum.processed_date_822 AS cvg_processed_date,
          cvgsum.cl_line_type_cd,
          cvgsum.cl_line_type_desc,
          cvgsum.cvg_seg_type,
          cvgsum.ibc_kindof_loss_cd,
          cvgsum.cl_class_bus_cd,
          cvgsum.cl_ibc_cd,
          cvgsum.cvg_cd,
          cvgsum.rag_num,
          cvgsum.kind_of_loss,
          cvgsum.deductible_amount,
          cvgsum.deductible_type,
          cvgsum.deduct_basis_cd,
          cvgsum.cvg_status_desc,
          CASE
            WHEN cvgsum.date_open_sum > origopncvsm.orig_cvg_open_dt THEN origopncvsm.orig_cvg_open_dt
            ELSE cvgsum.date_open_sum
          END AS cvg_open_dt,
          --  estacc.*
          estacc.cvg_orig_loss_est,
          estacc.cvg_orig_expn_est,
          estacc.cvg_orig_intr_est,
          cvgsum.cvg_loss_pd_amt,
          cvgsum.cvg_expn_pd_amt,
          cvgsum.cvg_loss_resr_amt,
          cvgsum.cvg_expn_resr_amt,
          cvgsum.cvg_intr_resr_amt,
          cvgsum.cvg_loss_subr_amt,
          cvgsum.cvg_expn_subr_amt,
          cvgsum.cvg_salv_tot_amt,
          cvgsum.cvg_payback_amt,
          cvgsum.prev_cvg_loss_pd_amt,
          cvgsum.prev_cvg_expn_pd_amt,
          cvgsum.prev_cvg_loss_resr_amt,
          cvgsum.prev_cvg_expn_resr_amt,
          cvgsum.prev_cvg_intr_resr_amt,
          cvgsum.prev_cvg_loss_subr_amt,
          cvgsum.prev_cvg_expn_subr_amt,
          cvgsum.prev_cvg_salv_tot_amt,
          cvgsum.cvg_loss_pd_amt_delta,
          cvgsum.cvg_expn_pd_amt_delta,
          cvgsum.cvg_loss_resr_amt_delta,
          cvgsum.cvg_expn_resr_amt_delta,
          cvgsum.cvg_intr_resr_amt_delta,
          cvgsum.cvg_loss_subr_amt_delta,
          cvgsum.cvg_expn_subr_amt_delta,
          cvgsum.cvg_salv_tot_amt_delta,
          cvgsum.cvg_net_pd_amt,
          cvgsum.cvg_resr_amt,
          cvgsum.cvg_incurred_amt,
          -- 826   --cvgdtl.*
          cvgdtl.int_claim_num_826 AS ccvg_int_claim_num,
          cvgdtl.line_type_826 AS ccvg_cl_line_type,
          cvgdtl.claimant_num_826 AS ccvg_claimant_num,
          cvgdtl.last_process_date_826 AS ccvg_last_process_date,
          cvgdtl.processed_date_826 AS ccvg_processed_date,
          cvgdtl.ccvg_status_desc,
          CASE
            WHEN cvgdtl.date_det_open > origopncvdt.orig_ccvg_open_dt THEN origopncvdt.orig_ccvg_open_dt
            ELSE cvgdtl.date_det_open
          END AS ccvg_open_dt,
          coalesce(CAST(cvgdtl.ccvg_reopen_dt as STRING), '') AS ccvg_reopen_dt,
          coalesce(CAST(cvgdtl.ccvg_closed_dt as STRING), '') AS ccvg_closed_dt,
          cvgdtl.ccvg_orig_loss_est,
          cvgdtl.ccvg_orig_expn_est,
          cvgdtl.ccvg_orig_intr_est,
          cvgdtl.ccvg_loss_pd_amt,
          cvgdtl.ccvg_expn_pd_amt,
          cvgdtl.ccvg_loss_resr_amt,
          cvgdtl.ccvg_expn_resr_amt,
          cvgdtl.ccvg_intr_resr_amt,
          cvgdtl.ccvg_loss_subr_amt,
          cvgdtl.ccvg_expn_subr_amt,
          cvgdtl.ccvg_salv_tot_amt,
          cvgdtl.ccvg_payback_amt,
          cvgdtl.prev_ccvg_loss_pd_amt,
          cvgdtl.prev_ccvg_loss_resr_amt,
          cvgdtl.prev_ccvg_expn_pd_amt,
          cvgdtl.prev_ccvg_expn_resr_amt,
          cvgdtl.prev_ccvg_intr_resr_amt,
          cvgdtl.prev_ccvg_loss_subr_amt,
          cvgdtl.prev_ccvg_expn_subr_amt,
          cvgdtl.prev_ccvg_salv_tot_amt,
          cvgdtl.ccvg_loss_pd_amt_delta,
          cvgdtl.ccvg_expn_pd_amt_delta,
          cvgdtl.ccvg_loss_resr_amt_delta,
          cvgdtl.ccvg_expn_resr_amt_delta,
          cvgdtl.ccvg_intr_resr_amt_delta,
          cvgdtl.ccvg_loss_subr_amt_delta,
          cvgdtl.ccvg_expn_subr_amt_delta,
          cvgdtl.ccvg_salv_tot_amt_delta,
          cvgdtl.ccvg_net_pd_amt,
          cvgdtl.ccvg_resr_amt,
          cvgdtl.ccvg_incurred_amt,
          cvgdtl.tabular_reserve_ind AS ccvg_tablr_reserve_ind,
          coalesce(CAST(cvgdtl.tabular_resr_chng_dt as STRING), '') AS ccvg_tablr_resr_chng_dt
        FROM
          --  mainxtr - table list of keys for joining to the eclm tables --
          --  813 - Claim Summary ----------------------------------------------------
          (SELECT
                tbl813.int_claim_num_mxtr,
                tbl813.lpd_mxtr,
                tbl813.pd_mxtr,
                tbl813.lpd_813,
                tbl813.pd_813,
                tbl817.lpd_817,
                tbl817.pd_817,
                tbl822.lpd_822,
                tbl822.pd_822,
                tbl826.lpd_826,
                tbl826.pd_826
              FROM (
                  SELECT
                      x.*
                    FROM
                      (
                        SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl813.int_claim_num AS int_claim_num_813,
                            DATE(cl813.last_process_date) AS lpd_813,
                            DATE(cl813.processed_date) AS pd_813,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date ORDER BY cl813.int_claim_num DESC, cl813.processed_date DESC, cl813.last_process_date DESC) AS rownum
                          FROM
                            --  main extract -----------------------------------------------------------
                            (
                              SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type IN(
                                        1, 3, 5, 6, 7, 8
                                      )
                                  ) AS ec813
                                  LEFT OUTER JOIN -- ec817
                                  (
                                    SELECT
                                        claim_common_auto.int_claim_num,
                                        DATE(claim_common_auto.last_process_date) AS last_process_date,
                                        DATE(claim_common_auto.processed_date) AS processed_date,
                                        claim_common_auto.file_status,
                                        claim_common_auto.company,
                                        concat(claim_common_auto.loss_chart, claim_common_auto.loss_desc_code1) AS loss_chart_desc_code
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_auto` AS claim_common_auto
                                      WHERE DATE(claim_common_auto.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_auto.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_auto.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.loss_chart_desc_code NOT IN(
                                  '1901', '1902', '1903', '1904', '1905', '1906'
                                )
                            ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_claim_summary` AS cl813 ON cl813.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl813.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl813.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl813.last_process_date) <= CAST('@execution_date' as DATE)
                      ) AS x
                    WHERE x.rownum = 1
                ) AS tbl813 
                LEFT OUTER JOIN --  817 - Claim Common ------------------------------------------------
                (SELECT
                      x.*
                    FROM
                      (SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl817.int_claim_num AS int_claim_num_817,
                            DATE(cl817.last_process_date) AS lpd_817,
                            DATE(cl817.processed_date) AS pd_817,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date ORDER BY cl817.int_claim_num DESC, cl817.processed_date DESC, cl817.last_process_date DESC) AS rownum
                          FROM
                            --  main extract ------------------------------------------------------------
                            (SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type IN(
                                        1, 3, 5, 6, 7, 8
                                      )
                                  ) AS ec813
                                  LEFT OUTER JOIN -- ec817
                                  (
                                    SELECT
                                        claim_common_auto.int_claim_num,
                                        DATE(claim_common_auto.last_process_date) AS last_process_date,
                                        DATE(claim_common_auto.processed_date) AS processed_date,
                                        claim_common_auto.file_status,
                                        claim_common_auto.company,
                                        concat(claim_common_auto.loss_chart, claim_common_auto.loss_desc_code1) AS loss_chart_desc_code
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_auto` AS claim_common_auto
                                      WHERE DATE(claim_common_auto.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_auto.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_auto.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.loss_chart_desc_code NOT IN(
                                  '1901', '1902', '1903', '1904', '1905', '1906'
                                )
                                 ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_common_auto` AS cl817 ON cl817.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl817.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl817.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl817.last_process_date) <= CAST('@execution_date' as DATE)
                            ) AS x
                    WHERE x.rownum = 1
                     ) AS tbl817 ON tbl817.int_claim_num_mxtr = tbl813.int_claim_num_mxtr
                 AND tbl817.pd_mxtr = tbl813.pd_mxtr
                 LEFT OUTER JOIN --  822 - Coverage Summary -------------------------------------------
                (
                  SELECT
                      x.*
                    FROM
                      (
                        SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl822.int_claim_num AS int_claim_num_822,
                            DATE(cl822.last_process_date) AS lpd_822,
                            DATE(cl822.processed_date) AS pd_822,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date ORDER BY cl822.int_claim_num, cl822.processed_date DESC, cl822.last_process_date DESC) AS rownum
                          FROM
                            --  main extract ------------------------------------------------------------
                            (
                              SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type IN(
                                        1, 3, 5, 6, 7, 8
                                      )
                                  ) AS ec813
                                  LEFT OUTER JOIN -- ec817
                                  (
                                    SELECT
                                        claim_common_auto.int_claim_num,
                                        DATE(claim_common_auto.last_process_date) AS last_process_date,
                                        DATE(claim_common_auto.processed_date) AS processed_date,
                                        claim_common_auto.file_status,
                                        claim_common_auto.company,
                                        concat(claim_common_auto.loss_chart, claim_common_auto.loss_desc_code1) AS loss_chart_desc_code
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_auto` AS claim_common_auto
                                      WHERE DATE(claim_common_auto.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_auto.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_auto.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.loss_chart_desc_code NOT IN(
                                  '1901', '1902', '1903', '1904', '1905', '1906'
                                )
                            ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_coverage_summary_auto` AS cl822 ON cl822.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl822.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl822.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl822.last_process_date) <= CAST('@execution_date' as DATE)
                      ) AS x
                    WHERE x.rownum = 1
                ) AS tbl822 ON tbl822.int_claim_num_mxtr = tbl813.int_claim_num_mxtr
                 AND tbl822.pd_mxtr = tbl813.pd_mxtr
                 LEFT OUTER JOIN --  826 - Coverage Detail ------------------------------------------------
                (
                  SELECT
                      x.*
                    FROM
                      (
                        SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl826.int_claim_num AS int_claim_num_826,
                            DATE(cl826.last_process_date) AS lpd_826,
                            DATE(cl826.processed_date) AS pd_826,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date ORDER BY cl826.int_claim_num, cl826.processed_date DESC, cl826.last_process_date DESC) AS rownum
                          FROM
                            --  main extract -----------------------------------------------------------
                            (
                              SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type IN(
                                        1, 3, 5, 6, 7, 8
                                      )
                                  ) AS ec813
                                  LEFT OUTER JOIN -- ec817
                                  (
                                    SELECT
                                        claim_common_auto.int_claim_num,
                                        DATE(claim_common_auto.last_process_date) AS last_process_date,
                                        DATE(claim_common_auto.processed_date) AS processed_date,
                                        claim_common_auto.file_status,
                                        claim_common_auto.company,
                                        concat(claim_common_auto.loss_chart, claim_common_auto.loss_desc_code1) AS loss_chart_desc_code
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_auto` AS claim_common_auto
                                      WHERE DATE(claim_common_auto.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_auto.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_auto.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.loss_chart_desc_code NOT IN(
                                  '1901', '1902', '1903', '1904', '1905', '1906'
                                )
                            ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_coverage_detail` AS cl826 ON cl826.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl826.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl826.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl826.last_process_date) <= CAST('@execution_date' as DATE)
                      ) AS x
                    WHERE x.rownum = 1
                ) AS tbl826 ON tbl826.int_claim_num_mxtr = tbl813.int_claim_num_mxtr
                 AND tbl826.pd_mxtr = tbl813.pd_mxtr
              WHERE tbl813.int_claim_num_mxtr = tbl813.int_claim_num_813
               AND tbl813.pd_mxtr = tbl813.pd_mxtr
               AND tbl813.int_claim_num_mxtr = tbl817.int_claim_num_817
               AND tbl813.pd_mxtr = tbl817.pd_mxtr
               AND tbl813.int_claim_num_mxtr = tbl822.int_claim_num_822
               AND tbl813.pd_mxtr = tbl822.pd_mxtr
               AND tbl813.int_claim_num_mxtr = tbl826.int_claim_num_826
               AND tbl813.pd_mxtr = tbl826.pd_mxtr
               ) AS sel
          INNER JOIN --  end of mainxtr - table list of keys for joining to the eclm tables --
          --  813 / claim summary
          (
            SELECT
                claim_claim_summary.int_claim_num AS int_claim_num_813,
                DATE(claim_claim_summary.last_process_date) AS last_process_date_813,
                DATE(claim_claim_summary.processed_date) AS processed_date_813,
                claim_claim_summary.policy_type AS cl_pol_type,
                CASE
                  WHEN claim_claim_summary.policy_type IN(
                    1, 7, 8
                  ) THEN 'PAUTO'
                  WHEN claim_claim_summary.policy_type IN(
                    3, 5, 6
                  ) THEN 'CAUTO'
                  ELSE CAST(claim_claim_summary.policy_type AS STRING)
                END AS cl_pol_type_division,
                CASE
                  WHEN claim_claim_summary.policy_type = 1 THEN 'Std-Auto'
                  WHEN claim_claim_summary.policy_type = 3 THEN 'Comm-Auto'
                  WHEN claim_claim_summary.policy_type = 5 THEN 'Fleets'
                  WHEN claim_claim_summary.policy_type = 6 THEN 'Dealers-Non-Owned'
                  WHEN claim_claim_summary.policy_type = 7 THEN 'Non-Owned-Auto'
                  WHEN claim_claim_summary.policy_type = 8 THEN 'Driver'
                  ELSE CAST(claim_claim_summary.policy_type AS STRINg)
                END AS cl_pol_type_desc,
                claim_claim_summary.claim_status AS cl_status_cd_813,
                CASE
                  WHEN claim_claim_summary.claim_status = 2 THEN 'OPN'
                  WHEN claim_claim_summary.claim_status = 3 THEN 'CLS'
                  WHEN claim_claim_summary.claim_status = 6 THEN 'REO'
                  WHEN claim_claim_summary.claim_status = 4 THEN 'STR'
                  ELSE CAST(claim_claim_summary.claim_status AS STRING)
                END AS cl_status_desc_813,
                DATE(claim_claim_summary.last_financial_date) AS last_fin_dt,
                claim_claim_summary.pc_indicator AS pay_and_close_ind,
                claim_claim_summary.cds_claim_num AS cds_number,
                claim_claim_summary.policy_num AS pol_num,
                DATE(claim_claim_summary.loss_date) AS loss_dt,
                claim_claim_summary.occurrence AS occur_num,
                DATE(claim_claim_summary.policy_efdt) AS term_eff_dt,
                claim_claim_summary.prefix AS subscription_prefix,
                claim_claim_summary.contr_id,
                claim_claim_summary.percent_fault AS insured_fault_pct,
                claim_claim_summary.branch,
                claim_claim_summary.no_claimants_open,
                claim_claim_summary.no_claimants_clsd,
                claim_claim_summary.no_covg_line_open,
                claim_claim_summary.no_covg_line_clsd,
                claim_claim_summary.no_rein_line_open,
                claim_claim_summary.no_cov_det_lines_open,
                claim_claim_summary.no_fin_hist,
                coalesce(claim_claim_summary.in_suit_cnt, 0) AS in_suit_cnt,
                claim_claim_summary.total_losses,
                claim_claim_summary.total_expense,
                claim_claim_summary.total_loss_reserve,
                claim_claim_summary.total_expense_reserve,
                claim_claim_summary.total_interest_reserve,
                claim_claim_summary.subrogation_tot,
                claim_claim_summary.salvage_tot,
                claim_claim_summary.prev_total_losses,
                claim_claim_summary.prev_total_expense,
                claim_claim_summary.prev_total_loss_reserve,
                claim_claim_summary.prev_total_expense_reserve,
                claim_claim_summary.prev_total_interest_reserv,
                claim_claim_summary.prev_subrogation_tot,
                claim_claim_summary.prev_salvage_tot,
                (claim_claim_summary.total_losses-claim_claim_summary.prev_total_losses) AS total_losses_delta,
                (claim_claim_summary.total_expense-claim_claim_summary.prev_total_expense) AS total_expense_delta,
                (claim_claim_summary.total_loss_reserve-claim_claim_summary.prev_total_loss_reserve) AS total_loss_reserve_delta,
                (claim_claim_summary.total_expense_reserve-claim_claim_summary.prev_total_expense_reserve) AS total_expense_reserve_delta,
                (claim_claim_summary.total_interest_reserve-claim_claim_summary.prev_total_interest_reserv) AS total_interest_reserve_delta,
                (claim_claim_summary.subrogation_tot-claim_claim_summary.prev_subrogation_tot) AS subrogation_tot_delta,
                (claim_claim_summary.salvage_tot-claim_claim_summary.prev_salvage_tot) AS salvage_tot_delta
              FROM
                `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
              WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_claim_summary.claim_status <> 1
               AND claim_claim_summary.policy_type IN(
                1, 3, 5, 6, 7, 8
              )
          ) AS clsum ON clsum.int_claim_num_813 = sel.int_claim_num_mxtr
           AND clsum.processed_date_813 = sel.pd_813
           INNER JOIN -- 817 / claim common
          (
            SELECT
                claim_common_auto.int_claim_num AS int_claim_num_817,
                DATE(claim_common_auto.last_process_date) AS last_process_date_817,
                DATE(claim_common_auto.processed_date) AS processed_date_817,
                claim_common_auto.serial_num AS cl_vin,
                claim_common_auto.agent_num AS curr_brk_num,
                claim_common_auto.siu_ind_ab AS siu_ab_ind,
                claim_common_auto.siu_ind AS siu_non_ab_ind,
                claim_common_auto.replace_repair_ind AS glass_repl_ind,
                claim_common_auto.clm_jurisdiction AS juris_prov_cd,
                claim_common_auto.stat_terr AS ibc_stat_ter_cd,
                claim_common_auto.company AS cl_co_cd,
                claim_common_auto.prov_cd AS cl_prov_cd,
                claim_common_auto.claim_status AS cl_status_cd_817,
                claim_common_auto.file_status AS file_status_cd_817,
                CASE
                  WHEN claim_common_auto.total_loss_ind = 'Z' THEN ''
                  WHEN claim_common_auto.total_loss_ind = 'P' THEN 'N'
                  WHEN claim_common_auto.total_loss_ind = 'T' THEN 'Y'
                  ELSE ''
                END AS total_loss_ind,
                DATE(claim_common_auto.first_closed_dt) AS first_closed_date,
                DATE(claim_common_auto.open_dt) AS cl_open_dt,
                claim_common_auto.rep_code_1 AS repid_001,
                claim_common_auto.rep_code_2 AS repid_002,
                claim_common_auto.rep_code_3 AS repid_003,
                claim_common_auto.rep_code_4 AS repid_004,
                claim_common_auto.sup_rep_code AS repid_sup,
                claim_common_auto.rep_code_ho AS repid_ho,
                claim_common_auto.mga_number,
                claim_common_auto.cat_loss_id AS loss_event_id,
                CASE
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'HO'
                   AND claim_common_auto.company = 8 THEN 28
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'UK' THEN 0
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'HB' THEN 1
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'OT' THEN 2
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'TO' THEN 3
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'HA' THEN 4
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'LO' THEN 5
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'ST' THEN 6
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'MI' THEN 7
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'WS' THEN 8
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'VN' THEN 11
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'ED' THEN 12
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'CA' THEN 13
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'WG' THEN 14
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'MO' THEN 15
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'MN' THEN 16
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'HX' THEN 17
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'HO' THEN 19
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'MO' THEN 20
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'FR' THEN 21
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'MH' THEN 22
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'ST' THEN 23
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'PR' THEN 24
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'WA' THEN 25
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'WH' THEN 26
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'QU' THEN 27
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'SO' THEN 28
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'PE' THEN 31
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'PW' THEN 32
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'PO' THEN 33
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'WE' THEN 34
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'WW' THEN 35
                  WHEN substr(claim_common_auto.rep_code_1, 1, 2) = 'WO' THEN 36
                  ELSE 0
                END AS hndlng_br_num,
                claim_common_auto.car_year_ccyy AS car_year,
                claim_common_auto.make,
                claim_common_auto.model,
                claim_common_auto.veh_loc_pstl_cd,
                claim_common_auto.trailer_ind,
                claim_common_auto.loss_chart,
                claim_common_auto.loss_desc_code1,
                claim_common_auto.rate_class,
                claim_common_auto.int_veh_num,
                claim_common_auto.auto_ibc_code,
                claim_common_auto.risk_pool_ind,
                claim_common_auto.facility_ind,
                claim_common_auto.type_of_use,
                claim_common_auto.type_of_use_comm,
                claim_common_auto.car_code,
                claim_common_auto.body_type
              FROM
                `@curated_project.@curated_dataset_name.claim_common_auto` AS claim_common_auto
              WHERE DATE(claim_common_auto.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_common_auto.file_status <> 1
          ) AS clcom ON clcom.int_claim_num_817 = sel.int_claim_num_mxtr
           AND clcom.processed_date_817 = sel.pd_817
           INNER JOIN -- 822 / cvg summary
          (
            SELECT
                claim_coverage_summary_auto.int_claim_num AS int_claim_num_822,
                claim_coverage_summary_auto.line_type AS line_type_822,
                DATE(claim_coverage_summary_auto.last_process_date) AS last_process_date_822,
                DATE(claim_coverage_summary_auto.processed_date) AS processed_date_822,
                claim_coverage_summary_auto.line_type AS cl_line_type_cd,
                claim_coverage_summary_auto.line_type_desc AS cl_line_type_desc,
                claim_coverage_summary_auto.status_cov_sum AS cvg_status_cd,
                claim_coverage_summary_auto.status_desc AS cvg_status_desc_geo,
                CASE
                  WHEN claim_coverage_summary_auto.status_cov_sum = 2 THEN 'OPN'
                  WHEN claim_coverage_summary_auto.status_cov_sum = 3 THEN 'CLS'
                  WHEN claim_coverage_summary_auto.status_cov_sum = 6 THEN 'REO'
                  WHEN claim_coverage_summary_auto.status_cov_sum = 4 THEN 'STR'
                  ELSE CAST(claim_coverage_summary_auto.status_cov_sum AS STRING)
                END AS cvg_status_desc,
                claim_coverage_summary_auto.ibc_kind_of_loss_cd AS ibc_kindof_loss_cd,
                claim_coverage_summary_auto.class_of_bus AS cl_class_bus_cd,
                claim_coverage_summary_auto.ibc_code AS cl_ibc_cd,
                claim_coverage_summary_auto.coverage_code AS cvg_cd,
                DATE(claim_coverage_summary_auto.date_open_sum) AS date_open_sum,
                CASE
                  WHEN claim_coverage_summary_auto.item_type IN(
                    1, 2, 10
                  ) THEN 'AUT'
                  WHEN claim_coverage_summary_auto.item_type = 3 THEN 'LOC'
                  WHEN claim_coverage_summary_auto.item_type = 4 THEN 'LIA'
                  WHEN claim_coverage_summary_auto.item_type = 5 THEN 'MIS'
                  WHEN claim_coverage_summary_auto.item_type = 6 THEN 'SAF'
                  WHEN claim_coverage_summary_auto.item_type = 7 THEN 'BOM'
                  WHEN claim_coverage_summary_auto.item_type = 8 THEN 'CLI'
                  WHEN claim_coverage_summary_auto.item_type = 9 THEN 'CMP'
                  ELSE CAST(claim_coverage_summary_auto.item_type AS STRING)
                END AS cvg_seg_type,
                claim_coverage_summary_auto.rag_num,
                claim_coverage_summary_auto.kind_of_loss,
                claim_coverage_summary_auto.deductible_amount,
                claim_coverage_summary_auto.deductible_type,
                claim_coverage_summary_auto.deduct_basis_cd,
                claim_coverage_summary_auto.loss_pay_to_dt AS cvg_loss_pd_amt,
                claim_coverage_summary_auto.exp_pay_to_dt AS cvg_expn_pd_amt,
                claim_coverage_summary_auto.loss_reser_to_dt AS cvg_loss_resr_amt,
                claim_coverage_summary_auto.exp_reser_to_dt AS cvg_expn_resr_amt,
                claim_coverage_summary_auto.int_reser_to_dt AS cvg_intr_resr_amt,
                claim_coverage_summary_auto.subrogation_loss AS cvg_loss_subr_amt,
                claim_coverage_summary_auto.subrogation_exp AS cvg_expn_subr_amt,
                claim_coverage_summary_auto.salvage_tot AS cvg_salv_tot_amt,
                claim_coverage_summary_auto.pay_back AS cvg_payback_amt,
                claim_coverage_summary_auto.prev_loss_pay_to_dt AS prev_cvg_loss_pd_amt,
                claim_coverage_summary_auto.prev_exp_pay_to_dt AS prev_cvg_expn_pd_amt,
                claim_coverage_summary_auto.prev_loss_reser_to_dt AS prev_cvg_loss_resr_amt,
                claim_coverage_summary_auto.prev_exp_reser_to_dt AS prev_cvg_expn_resr_amt,
                claim_coverage_summary_auto.prev_int_reser_to_dt AS prev_cvg_intr_resr_amt,
                claim_coverage_summary_auto.prev_subrogation_loss AS prev_cvg_loss_subr_amt,
                claim_coverage_summary_auto.prev_subrogation_exp AS prev_cvg_expn_subr_amt,
                claim_coverage_summary_auto.prev_salvage_tot AS prev_cvg_salv_tot_amt,
                (claim_coverage_summary_auto.loss_pay_to_dt-claim_coverage_summary_auto.prev_loss_pay_to_dt) AS cvg_loss_pd_amt_delta,
                (claim_coverage_summary_auto.exp_pay_to_dt-claim_coverage_summary_auto.prev_exp_pay_to_dt) AS cvg_expn_pd_amt_delta,
                (claim_coverage_summary_auto.loss_reser_to_dt-claim_coverage_summary_auto.prev_loss_reser_to_dt) AS cvg_loss_resr_amt_delta,
                (claim_coverage_summary_auto.exp_reser_to_dt-claim_coverage_summary_auto.prev_exp_reser_to_dt) AS cvg_expn_resr_amt_delta,
                (claim_coverage_summary_auto.int_reser_to_dt-claim_coverage_summary_auto.prev_int_reser_to_dt) AS cvg_intr_resr_amt_delta,
                (claim_coverage_summary_auto.subrogation_loss-claim_coverage_summary_auto.prev_subrogation_loss) AS cvg_loss_subr_amt_delta,
                (claim_coverage_summary_auto.subrogation_exp-claim_coverage_summary_auto.prev_subrogation_exp) AS cvg_expn_subr_amt_delta,
                (claim_coverage_summary_auto.salvage_tot-claim_coverage_summary_auto.prev_salvage_tot) AS cvg_salv_tot_amt_delta,
                (claim_coverage_summary_auto.loss_reser_to_dt+claim_coverage_summary_auto.exp_reser_to_dt+claim_coverage_summary_auto.int_reser_to_dt+claim_coverage_summary_auto.loss_pay_to_dt+claim_coverage_summary_auto.exp_pay_to_dt-claim_coverage_summary_auto.subrogation_loss-claim_coverage_summary_auto.subrogation_exp-claim_coverage_summary_auto.salvage_tot) AS cvg_incurred_amt,
                (claim_coverage_summary_auto.loss_pay_to_dt+claim_coverage_summary_auto.exp_pay_to_dt-claim_coverage_summary_auto.subrogation_loss-claim_coverage_summary_auto.subrogation_exp-claim_coverage_summary_auto.salvage_tot) AS cvg_net_pd_amt,
                (claim_coverage_summary_auto.loss_reser_to_dt+claim_coverage_summary_auto.exp_reser_to_dt+claim_coverage_summary_auto.int_reser_to_dt) AS cvg_resr_amt
              FROM
                `@curated_project.@curated_dataset_name.claim_coverage_summary_auto` AS claim_coverage_summary_auto
              WHERE DATE(claim_coverage_summary_auto.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_coverage_summary_auto.status_cov_sum <> 1
          ) AS cvgsum ON cvgsum.int_claim_num_822 = sel.int_claim_num_mxtr
           AND cvgsum.processed_date_822 = sel.pd_822
           INNER JOIN -- 826 / cvg detail
          (
            SELECT
                claim_coverage_detail.int_claim_num AS int_claim_num_826,
                claim_coverage_detail.line_type AS line_type_826,
                claim_coverage_detail.claimant_num AS claimant_num_826,
                DATE(claim_coverage_detail.last_process_date) AS last_process_date_826,
                DATE(claim_coverage_detail.processed_date) AS processed_date_826,
                claim_coverage_detail.status_det_cov AS ccvg_status_cd,
                claim_coverage_detail.status_desc AS ccvg_status_desc_geo,
                CASE
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NOT NULL THEN 'REO'
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NULL THEN 'OPN'
                  WHEN claim_coverage_detail.status_det_cov = 3 THEN 'CLS'
                  WHEN claim_coverage_detail.status_det_cov = 4 THEN 'STR'
                  ELSE CAST(claim_coverage_detail.status_det_cov AS STRING)
                END AS ccvg_status_desc,
                DATE(claim_coverage_detail.date_det_open) AS date_det_open,
                DATE(claim_coverage_detail.date_det_clsd) AS date_det_clsd,
                CASE
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NULL THEN DATE(claim_coverage_detail.date_det_open)
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NOT NULL THEN DATE(claim_coverage_detail.date_det_open)
                  WHEN claim_coverage_detail.status_det_cov IN(
                    3, 4
                  ) THEN DATE(claim_coverage_detail.date_det_open)
                  ELSE CAST(NULL as DATE)
                END AS ccvg_open_dt,
                CASE
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NULL THEN CAST(NULL as DATE)
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NOT NULL THEN DATE(claim_coverage_detail.date_det_open)
                  WHEN claim_coverage_detail.status_det_cov IN(
                    3, 4
                  ) THEN CAST(NULL as DATE)
                  ELSE CAST(NULL as DATE)
                END AS ccvg_reopen_dt,
                CASE
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NULL THEN CAST(NULL as DATE)
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NOT NULL THEN CAST(NULL as DATE)
                  WHEN claim_coverage_detail.status_det_cov IN(
                    3, 4
                  ) THEN DATE(claim_coverage_detail.date_det_clsd)
                  ELSE CAST(NULL as DATE)
                END AS ccvg_closed_dt,
                claim_coverage_detail.loss_pay_to_date AS ccvg_loss_pd_amt,
                claim_coverage_detail.cur_loss_est AS ccvg_loss_resr_amt,
                claim_coverage_detail.expense_pay_to_date AS ccvg_expn_pd_amt,
                claim_coverage_detail.cur_exp_est AS ccvg_expn_resr_amt,
                claim_coverage_detail.cur_int_est AS ccvg_intr_resr_amt,
                claim_coverage_detail.subrogation_loss AS ccvg_loss_subr_amt,
                claim_coverage_detail.subrogation_exp AS ccvg_expn_subr_amt,
                claim_coverage_detail.salvage_tot AS ccvg_salv_tot_amt,
                claim_coverage_detail.prev_loss_pay_to_date AS prev_ccvg_loss_pd_amt,
                claim_coverage_detail.prev_cur_loss_est AS prev_ccvg_loss_resr_amt,
                claim_coverage_detail.prev_expense_pay_to_date AS prev_ccvg_expn_pd_amt,
                claim_coverage_detail.prev_cur_exp_est AS prev_ccvg_expn_resr_amt,
                claim_coverage_detail.prev_cur_int_est AS prev_ccvg_intr_resr_amt,
                claim_coverage_detail.prev_subrogation_loss AS prev_ccvg_loss_subr_amt,
                claim_coverage_detail.prev_subrogation_exp AS prev_ccvg_expn_subr_amt,
                claim_coverage_detail.prev_salvage_tot AS prev_ccvg_salv_tot_amt,
                (claim_coverage_detail.loss_pay_to_date-claim_coverage_detail.prev_loss_pay_to_date) AS ccvg_loss_pd_amt_delta
			,(claim_coverage_detail.cur_loss_est-claim_coverage_detail.prev_cur_loss_est) AS ccvg_loss_resr_amt_delta
			,(claim_coverage_detail.expense_pay_to_date-claim_coverage_detail.prev_expense_pay_to_date) AS ccvg_expn_pd_amt_delta
			,(claim_coverage_detail.cur_exp_est-claim_coverage_detail.prev_cur_exp_est) AS ccvg_expn_resr_amt_delta
			,(claim_coverage_detail.cur_int_est-claim_coverage_detail.prev_cur_int_est) AS ccvg_intr_resr_amt_delta
			,(claim_coverage_detail.subrogation_loss-claim_coverage_detail.prev_subrogation_loss) AS ccvg_loss_subr_amt_delta
			,(claim_coverage_detail.subrogation_exp-claim_coverage_detail.prev_subrogation_exp) AS ccvg_expn_subr_amt_delta
			,(claim_coverage_detail.salvage_tot-claim_coverage_detail.prev_salvage_tot) AS ccvg_salv_tot_amt_delta
			,claim_coverage_detail.orig_exp_est AS ccvg_orig_expn_est
			,claim_coverage_detail.date_last_exp_est
			,claim_coverage_detail.orig_int_est AS ccvg_orig_intr_est
			,claim_coverage_detail.date_last_int_est
			,claim_coverage_detail.orig_loss_est AS ccvg_orig_loss_est
			,claim_coverage_detail.date_last_loss_est
      ,(claim_coverage_detail.cur_loss_est+claim_coverage_detail.cur_exp_est+claim_coverage_detail.cur_int_est+claim_coverage_detail.loss_pay_to_date+claim_coverage_detail.expense_pay_to_date-claim_coverage_detail.subrogation_loss-claim_coverage_detail.subrogation_exp-claim_coverage_detail.salvage_tot) AS ccvg_incurred_amt
      ,(claim_coverage_detail.loss_pay_to_date+claim_coverage_detail.expense_pay_to_date-claim_coverage_detail.subrogation_loss-claim_coverage_detail.subrogation_exp-claim_coverage_detail.salvage_tot) AS ccvg_net_pd_amt
			,(claim_coverage_detail.cur_loss_est+claim_coverage_detail.cur_exp_est+claim_coverage_detail.cur_int_est) AS ccvg_resr_amt
			,(claim_coverage_detail.pay_back_loss+claim_coverage_detail.pay_back_exp) AS ccvg_payback_amt,
                claim_coverage_detail.tab_res AS tabular_reserve_ind,
                DATE(claim_coverage_detail.date_tab_res) AS tabular_resr_chng_dt
              FROM
                `@curated_project.@curated_dataset_name.claim_coverage_detail` AS claim_coverage_detail
              WHERE DATE(claim_coverage_detail.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_coverage_detail.status_det_cov <> 1
          ) AS cvgdtl ON cvgdtl.int_claim_num_826 = sel.int_claim_num_mxtr
           AND cvgdtl.processed_date_826 = sel.pd_826
           AND cvgdtl.line_type_826 = cvgsum.line_type_822
           LEFT OUTER JOIN -- 826 / cvg detail - earliest open date for int_claim_num / line_type / claimant_num combo for
          --                    original open date on reopen coverage detail claims
          (
            SELECT
                claim_financial_history.int_claim_num,
                claim_financial_history.claimant_num,
                claim_financial_history.line_type,
                DATE(claim_financial_history.last_process_date) AS orig_ccvg_open_dt,
                row_number() OVER (PARTITION BY claim_financial_history.int_claim_num, claim_financial_history.claimant_num, claim_financial_history.line_type ORDER BY claim_financial_history.last_process_date, claim_financial_history.processed_date, claim_financial_history.claimant_num, claim_financial_history.line_type) AS rownum
              FROM
                `@curated_project.@curated_dataset_name.claim_financial_history` AS claim_financial_history
              WHERE DATE(claim_financial_history.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_financial_history.file_status <> 1
               AND claim_financial_history.action_desc = 'OPEN'
          ) AS origopncvdt ON origopncvdt.int_claim_num = sel.int_claim_num_mxtr
           AND origopncvdt.claimant_num = cvgdtl.claimant_num_826
           AND origopncvdt.line_type = cvgdtl.line_type_826
           AND origopncvdt.rownum = 1
           LEFT OUTER JOIN -- -----------------------------------------------------------------------------------
          -- -------------------------------------------------------------------------
          -- -----------------------------------------------------------------------------------
          -- 822 / cvg sum - earliest open date for int_claim_num / line_type combo for
          --                 original open date on reopen coverage summary claims
          (
            SELECT
                claim_financial_history.int_claim_num,
                claim_financial_history.line_type,
                DATE(claim_financial_history.last_process_date) AS orig_cvg_open_dt,
                row_number() OVER (PARTITION BY claim_financial_history.int_claim_num, claim_financial_history.line_type ORDER BY claim_financial_history.last_process_date, claim_financial_history.processed_date, claim_financial_history.line_type) AS rownum
              FROM
                `@curated_project.@curated_dataset_name.claim_financial_history` AS claim_financial_history
              WHERE DATE(claim_financial_history.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_financial_history.file_status <> 1
               AND claim_financial_history.action_desc = 'OPEN'
          ) AS origopncvsm ON origopncvsm.int_claim_num = sel.int_claim_num_mxtr
           AND origopncvsm.line_type = cvgsum.line_type_822
           AND origopncvsm.rownum = 1
           LEFT OUTER JOIN -- -----------------------------------------------------------------------------------
          -- -------------------------------------------------------------------------
          -- -----------------------------------------------------------------------------------
          -- 826 / cvg detail - accummulate original estimates for cvgsum level
          (
            SELECT
                claim_coverage_detail.int_claim_num,
                DATE(claim_coverage_detail.processed_date) AS processed_date,
                claim_coverage_detail.line_type,
                sum(claim_coverage_detail.orig_loss_est) AS cvg_orig_loss_est,
                sum(claim_coverage_detail.orig_exp_est) AS cvg_orig_expn_est,
                sum(claim_coverage_detail.orig_int_est) AS cvg_orig_intr_est
              FROM
                `@curated_project.@curated_dataset_name.claim_coverage_detail` AS claim_coverage_detail
              WHERE DATE(claim_coverage_detail.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_coverage_detail.status_det_cov <> 1
              GROUP BY 1, claim_coverage_detail.processed_date, 3
          ) AS estacc ON estacc.int_claim_num = sel.int_claim_num_mxtr
           AND estacc.processed_date = sel.pd_826
           AND estacc.line_type = cvgsum.line_type_822
           ) AS main
           INNER JOIN --  main claims data cl/cvg/ccvg
    -- -----------------------------------------------------------------------------------
    --  to Claimant Info ------------------------------------------------------
    -- -----------------------------------------------------------------------------------
    (
      SELECT
          x.*
        FROM
          (
            SELECT
                tbl818.pd_mxtr,
                tbl818.lpd_mxtr,
                tbl818.pd_818,
                tbl818.lpd_818,
                clmtinfo.*
              FROM
                --  ,row_number() over (partition by tbl818.int_claim_num_mxtr, tbl818.pd_mxtr, tbl818.clmt_num_818
                --                          order by tbl818.int_claim_num_mxtr, tbl818.pd_mxtr desc, tbl818.lpd_mxtr desc) as rownum
                --  818 - Claimant Info Keys ------------------------------------------------
                (
                  SELECT
                      x_0.*
                    FROM
                      (
                        SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl818.int_claim_num AS int_claim_num_818,
                            DATE(cl818.last_process_date) AS lpd_818,
                            DATE(cl818.processed_date) AS pd_818,
                            cl818.sequence_num AS clmt_num_818,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date, cl818.sequence_num ORDER BY cl818.int_claim_num, cl818.processed_date DESC, cl818.last_process_date DESC) AS rownum
                          FROM
                            --  main extract -----------------------------------------------------------
                            (
                              SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type IN(
                                        1, 3, 5, 6, 7, 8
                                      )
                                  ) AS ec813
                                  LEFT OUTER JOIN -- 2=prop 4=cprop 1,3,5,6,7,8=auto
                                  --        and int_claim_num = '4300852'
                                  -- ec817
                                  (
                                    SELECT
                                        claim_common_auto.int_claim_num,
                                        DATE(claim_common_auto.last_process_date) AS last_process_date,
                                        DATE(claim_common_auto.processed_date) AS processed_date,
                                        claim_common_auto.file_status,
                                        claim_common_auto.company,
                                        concat(claim_common_auto.loss_chart, claim_common_auto.loss_desc_code1) AS loss_chart_desc_code
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_auto` AS claim_common_auto
                                      WHERE DATE(claim_common_auto.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_auto.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_auto.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.loss_chart_desc_code NOT IN(
                                  '1901', '1902', '1903', '1904', '1905', '1906'
                                )
                            ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_claimant_info` AS cl818 ON cl818.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl818.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl818.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl818.last_process_date) <= CAST('@execution_date' as DATE)
                      ) AS x_0
                    WHERE x_0.rownum = 1
                ) AS tbl818
                INNER JOIN -- -----------------------------------------------------------------------------------
                -- ------------------------------------------------------------------------
                -- -----------------------------------------------------------------------------------
                -- 818 / claimant info data
                (
                  SELECT
                      claim_claimant_info.int_claim_num AS int_claim_num_818,
                      claim_claimant_info.sequence_num AS claimant_num_818,
                      claim_claimant_info.name_category AS name_category_818,
                      DATE(claim_claimant_info.last_process_date) AS last_process_date_818,
                      DATE(claim_claimant_info.processed_date) AS processed_date_818,
                      DATE(claim_claimant_info.creation_dt) AS eclmclmt_creation_date,
                      claim_claimant_info.claimant_status AS eclmclmt_status_cd,
                      claim_claimant_info.status_desc AS eclmclmt_status_desc_geo,
                      CASE
                        WHEN claim_claimant_info.claimant_status = 2 THEN 'OPN'
                        WHEN claim_claimant_info.claimant_status = 3 THEN 'CLS'
                        WHEN claim_claimant_info.claimant_status = 6 THEN 'REO'
                        WHEN claim_claimant_info.claimant_status = 4 THEN 'STR'
                        WHEN claim_claimant_info.claimant_status = 1 THEN 'PEN'
                        ELSE CAST(claim_claimant_info.claimant_status AS STRING)
                      END AS eclmclmt_status_desc,
                      claim_claimant_info.claimant_categ AS eclmclmt_clmt_type_desc,
                      claim_claimant_info.surname AS eclmclmt_last_name,
                      claim_claimant_info.first_name AS eclmclmt_first_name,
                      claim_claimant_info.middle_name AS eclmclmt_middle_name,
                      claim_claimant_info.company_name AS eclmclmt_company_name,
                      claim_claimant_info.comp_or_individ_ind AS eclmclmt_cmpny_or_indvd_ind,
                      claim_claimant_info.licence_num AS eclmclmt_lic_num,
                      claim_claimant_info.lic_iss_prov AS eclmclmt_lic_prov,
                      DATE(claim_claimant_info.claimant_dob) AS eclmclmt_clmt_dob,
                      claim_claimant_info.abc_orig_type_ind AS eclmclmt_bi_code_orig,
                      claim_claimant_info.abc_curr_type_ind AS eclmclmt_bi_code_curr,
                      claim_claimant_info.loss_transfer_code AS eclmclmt_loss_trnsfr_code,
                      claim_claimant_info.tp_veh_type_desc AS eclmclmt_tp_vehic_type_desc
                    FROM
                      `@curated_project.@curated_dataset_name.claim_claimant_info` AS claim_claimant_info
                    WHERE DATE(claim_claimant_info.processed_date) <= CAST('@execution_date' as DATE)
                ) AS clmtinfo ON tbl818.int_claim_num_mxtr = clmtinfo.int_claim_num_818
                 AND tbl818.clmt_num_818 = clmtinfo.claimant_num_818
                 AND tbl818.pd_818 = clmtinfo.processed_date_818
                 AND tbl818.lpd_818 = clmtinfo.last_process_date_818
          ) AS x
    ) AS clmt ON main.cl_int_claim_num = clmt.int_claim_num_818
     AND main.ccvg_claimant_num = clmt.claimant_num_818
     AND main.cl_processed_date = clmt.pd_mxtr
     AND main.cl_last_process_date = clmt.lpd_mxtr
UNION ALL
SELECT
    --      and claimant_status <> 1         -- 'pending' status allowed here so claimants don't get dropped
    --        and int_claim_num = '4300852'
    -- where x.rownum = 1
    --  join of main claims data to claimant data
    -- ***********************************************************************************
    --  Commercial Property --
    -- ***********************************************************************************
    main.cl_int_claim_num,
    main.cl_last_process_date,
    main.cl_processed_date,
    main.pol_num,
    main.loss_dt,
    main.occur_num,
    main.term_eff_dt,
    main.cds_number,
    main.subscription_prefix,
    main.contr_id,
    main.cl_pol_type,
    main.cl_pol_type_division,
    main.cl_pol_type_desc,
    main.last_fin_dt,
    main.pay_and_close_ind,
    main.insured_fault_pct,
    main.branch,
    main.no_claimants_open,
    main.no_claimants_clsd,
    main.no_covg_line_open,
    main.no_covg_line_clsd,
    main.no_rein_line_open,
    main.no_cov_det_lines_open,
    main.no_fin_hist,
    main.in_suit_cnt,
    main.siu_ab_ind,
    main.siu_non_ab_ind,
    main.cl_co_cd,
    main.cl_prov_cd,
    main.juris_prov_cd,
    main.total_loss_ind,
    main.loss_event_id,
    main.glass_repl_ind,
    main.ibc_stat_ter_cd,
    main.auto_loss_chart_cd,
    main.auto_desc_of_loss_cd,
    main.prop_desc_of_loss_cd AS prop_desc_of_loss_cd,
    main.risk_pool_ind,
    main.facility_ind,
    main.type_of_use,
    main.type_of_use_comm,
    main.car_code,
    main.body_type,
    main.cl_status_cd,
    main.cl_open_dt,
    main.first_closed_date,
    main.curr_brk_num,
    main.repid_001,
    main.repid_002,
    main.repid_003,
    main.repid_004,
    main.repid_sup,
    main.repid_ho,
    main.mga_number,
    main.hndlng_br_num,
    main.cl_vin,
    main.car_year,
    main.make,
    main.model,
    main.veh_loc_pstl_cd,
    main.trailer_ind,
    main.rate_class,
    main.int_veh_num,
    main.auto_ibc_code,
    main.loc_city AS loc_city,
    main.loc_prov AS loc_prov,
    main.total_losses,
    main.total_expense,
    main.total_loss_reserve,
    main.total_expense_reserve,
    main.total_interest_reserve,
    main.subrogation_tot,
    main.salvage_tot,
    main.prev_total_losses,
    main.prev_total_expense,
    main.prev_total_loss_reserve,
    main.prev_total_expense_reserve,
    main.prev_total_interest_reserv,
    main.prev_subrogation_tot,
    main.prev_salvage_tot,
    main.total_losses_delta,
    main.total_expense_delta,
    main.total_loss_reserve_delta,
    main.total_expense_reserve_delta,
    main.total_interest_reserve_delta,
    main.subrogation_tot_delta,
    main.salvage_tot_delta,
    main.cvg_int_claim_num,
    main.cvg_last_process_date,
    main.cvg_processed_date,
    main.cl_line_type_cd,
    main.cl_line_type_desc,
    main.cvg_seg_type,
    main.ibc_kindof_loss_cd,
    main.cl_class_bus_cd,
    main.cl_ibc_cd,
    main.cvg_cd,
    main.rag_num,
    main.kind_of_loss,
    main.deductible_amount,
    main.deductible_type,
    main.deduct_basis_cd,
    main.cvg_status_desc,
    main.cvg_open_dt,
    main.cvg_orig_loss_est,
    main.cvg_orig_expn_est,
    main.cvg_orig_intr_est,
    main.cvg_loss_pd_amt,
    main.cvg_expn_pd_amt,
    main.cvg_loss_resr_amt,
    main.cvg_expn_resr_amt,
    main.cvg_intr_resr_amt,
    main.cvg_loss_subr_amt,
    main.cvg_expn_subr_amt,
    main.cvg_salv_tot_amt,
    main.cvg_payback_amt,
    main.prev_cvg_loss_pd_amt,
    main.prev_cvg_expn_pd_amt,
    main.prev_cvg_loss_resr_amt,
    main.prev_cvg_expn_resr_amt,
    main.prev_cvg_intr_resr_amt,
    main.prev_cvg_loss_subr_amt,
    main.prev_cvg_expn_subr_amt,
    main.prev_cvg_salv_tot_amt,
    main.cvg_loss_pd_amt_delta,
    main.cvg_expn_pd_amt_delta,
    main.cvg_loss_resr_amt_delta,
    main.cvg_expn_resr_amt_delta,
    main.cvg_intr_resr_amt_delta,
    main.cvg_loss_subr_amt_delta,
    main.cvg_expn_subr_amt_delta,
    main.cvg_salv_tot_amt_delta,
    main.cvg_net_pd_amt,
    main.cvg_resr_amt,
    main.cvg_incurred_amt,
    main.ccvg_int_claim_num,
    main.ccvg_cl_line_type,
    main.ccvg_claimant_num,
    main.ccvg_last_process_date,
    main.ccvg_processed_date,
    main.ccvg_status_desc,
    main.ccvg_open_dt,
    main.ccvg_reopen_dt,
    main.ccvg_closed_dt,
    main.ccvg_orig_loss_est,
    main.ccvg_orig_expn_est,
    main.ccvg_orig_intr_est,
    main.ccvg_loss_pd_amt,
    main.ccvg_expn_pd_amt,
    main.ccvg_loss_resr_amt,
    main.ccvg_expn_resr_amt,
    main.ccvg_intr_resr_amt,
    main.ccvg_loss_subr_amt,
    main.ccvg_expn_subr_amt,
    main.ccvg_salv_tot_amt,
    main.ccvg_payback_amt,
    main.prev_ccvg_loss_pd_amt,
    main.prev_ccvg_loss_resr_amt,
    main.prev_ccvg_expn_pd_amt,
    main.prev_ccvg_expn_resr_amt,
    main.prev_ccvg_intr_resr_amt,
    main.prev_ccvg_loss_subr_amt,
    main.prev_ccvg_expn_subr_amt,
    main.prev_ccvg_salv_tot_amt,
    main.ccvg_loss_pd_amt_delta,
    main.ccvg_expn_pd_amt_delta,
    main.ccvg_loss_resr_amt_delta,
    main.ccvg_expn_resr_amt_delta,
    main.ccvg_intr_resr_amt_delta,
    main.ccvg_loss_subr_amt_delta,
    main.ccvg_expn_subr_amt_delta,
    main.ccvg_salv_tot_amt_delta,
    main.ccvg_net_pd_amt,
    main.ccvg_resr_amt,
    main.ccvg_incurred_amt,
    main.ccvg_tablr_reserve_ind,
    main.ccvg_tablr_resr_chng_dt,
    -- 818   --clmtinfo.*
    clmt.int_claim_num_818 AS eclmclmt_int_claim_num,
    clmt.claimant_num_818 AS eclmclmt_claimant_num,
    clmt.name_category_818 AS eclmclmt_name_category,
    clmt.last_process_date_818 AS eclmclmt_last_process_date,
    clmt.processed_date_818 AS eclmclmt_processed_date,
    clmt.eclmclmt_creation_date,
    clmt.eclmclmt_status_desc,
    clmt.eclmclmt_clmt_type_desc,
    clmt.eclmclmt_last_name,
    clmt.eclmclmt_first_name,
    clmt.eclmclmt_middle_name,
    clmt.eclmclmt_company_name,
    clmt.eclmclmt_cmpny_or_indvd_ind,
    clmt.eclmclmt_lic_num,
    clmt.eclmclmt_lic_prov,
    coalesce(CAST(clmt.eclmclmt_clmt_dob as STRING), '') AS eclmclmt_dob,
    clmt.eclmclmt_bi_code_orig,
    clmt.eclmclmt_bi_code_curr,
    clmt.eclmclmt_loss_trnsfr_code,
    clmt.eclmclmt_tp_vehic_type_desc
  FROM
    (SELECT
          -- 813/817       --clsum.*/clcom.*
          clsum.int_claim_num_813 AS cl_int_claim_num,
          clsum.last_process_date_813 AS cl_last_process_date,
          clsum.processed_date_813 AS cl_processed_date,
          clsum.pol_num,
          clsum.loss_dt,
          clsum.occur_num,
          clsum.term_eff_dt,
          clsum.cds_number,
          clsum.subscription_prefix,
          clsum.contr_id,
          clsum.cl_pol_type,
          clsum.cl_pol_type_division,
          clsum.cl_pol_type_desc,
          clsum.last_fin_dt,
          clsum.pay_and_close_ind,
          clsum.insured_fault_pct,
          clsum.branch,
          clsum.no_claimants_open,
          clsum.no_claimants_clsd,
          clsum.no_covg_line_open,
          clsum.no_covg_line_clsd,
          clsum.no_rein_line_open,
          clsum.no_cov_det_lines_open,
          clsum.no_fin_hist,
          clsum.in_suit_cnt,
          clcom.siu_ab_ind,
          clcom.siu_non_ab_ind,
          clcom.cl_co_cd,
          clcom.cl_prov_cd,
          clcom.juris_prov_cd,
          clcom.total_loss_ind,
          clcom.loss_event_id,
          '' AS glass_repl_ind,
          0 AS ibc_stat_ter_cd,
          0 AS auto_loss_chart_cd,
          '' AS auto_desc_of_loss_cd,
          clcom.prop_loss_code AS prop_desc_of_loss_cd,
          0 AS risk_pool_ind,
          0 AS facility_ind,
          0 AS type_of_use,
          0 AS type_of_use_comm,
          0 AS car_code,
          0 AS body_type,
          clsum.cl_status_desc_813 AS cl_status_cd,
          coalesce(CAST(clcom.cl_open_dt as STRING), '') AS cl_open_dt,
          coalesce(CAST(clcom.first_closed_date as STRING), '') AS first_closed_date,
          clcom.curr_brk_num,
          clcom.repid_001,
          clcom.repid_002,
          clcom.repid_003,
          clcom.repid_004,
          clcom.repid_sup,
          clcom.repid_ho,
          clcom.mga_number,
          clcom.hndlng_br_num,
          '' AS cl_vin,
          0 AS car_year,
          '' AS make,
          '' AS model,
          '' AS veh_loc_pstl_cd,
          '' AS trailer_ind,
          0 AS rate_class,
          0 AS int_veh_num,
          0 AS auto_ibc_code,
          clcom.loc_city,
          clcom.loc_prov,
          clsum.total_losses,
          clsum.total_expense,
          clsum.total_loss_reserve,
          clsum.total_expense_reserve,
          clsum.total_interest_reserve,
          clsum.subrogation_tot,
          clsum.salvage_tot,
          clsum.prev_total_losses,
          clsum.prev_total_expense,
          clsum.prev_total_loss_reserve,
          clsum.prev_total_expense_reserve,
          clsum.prev_total_interest_reserv,
          clsum.prev_subrogation_tot,
          clsum.prev_salvage_tot,
          clsum.total_losses_delta,
          clsum.total_expense_delta,
          clsum.total_loss_reserve_delta,
          clsum.total_expense_reserve_delta,
          clsum.total_interest_reserve_delta,
          clsum.subrogation_tot_delta,
          clsum.salvage_tot_delta,
          -- 822   --cvgsum.*
          cvgsum.int_claim_num_822 AS cvg_int_claim_num,
          cvgsum.last_process_date_822 AS cvg_last_process_date,
          cvgsum.processed_date_822 AS cvg_processed_date,
          cvgsum.cl_line_type_cd,
          cvgsum.cl_line_type_desc,
          cvgsum.cvg_seg_type,
          cvgsum.ibc_kindof_loss_cd,
          cvgsum.cl_class_bus_cd,
          cvgsum.cl_ibc_cd,
          cvgsum.cvg_cd,
          cvgsum.rag_num,
          cvgsum.kind_of_loss,
          cvgsum.deductible_amount,
          cvgsum.deductible_type,
          cvgsum.deduct_basis_cd,
          cvgsum.cvg_status_desc,
          CASE
            WHEN cvgsum.date_open_sum > origopncvsm.orig_cvg_open_dt THEN origopncvsm.orig_cvg_open_dt
            ELSE cvgsum.date_open_sum
          END AS cvg_open_dt,
          --  estacc.*
          estacc.cvg_orig_loss_est,
          estacc.cvg_orig_expn_est,
          estacc.cvg_orig_intr_est,
          cvgsum.cvg_loss_pd_amt,
          cvgsum.cvg_expn_pd_amt,
          cvgsum.cvg_loss_resr_amt,
          cvgsum.cvg_expn_resr_amt,
          cvgsum.cvg_intr_resr_amt,
          cvgsum.cvg_loss_subr_amt,
          cvgsum.cvg_expn_subr_amt,
          cvgsum.cvg_salv_tot_amt,
          cvgsum.cvg_payback_amt,
          cvgsum.prev_cvg_loss_pd_amt,
          cvgsum.prev_cvg_expn_pd_amt,
          cvgsum.prev_cvg_loss_resr_amt,
          cvgsum.prev_cvg_expn_resr_amt,
          cvgsum.prev_cvg_intr_resr_amt,
          cvgsum.prev_cvg_loss_subr_amt,
          cvgsum.prev_cvg_expn_subr_amt,
          cvgsum.prev_cvg_salv_tot_amt,
          cvgsum.cvg_loss_pd_amt_delta,
          cvgsum.cvg_expn_pd_amt_delta,
          cvgsum.cvg_loss_resr_amt_delta,
          cvgsum.cvg_expn_resr_amt_delta,
          cvgsum.cvg_intr_resr_amt_delta,
          cvgsum.cvg_loss_subr_amt_delta,
          cvgsum.cvg_expn_subr_amt_delta,
          cvgsum.cvg_salv_tot_amt_delta,
          cvgsum.cvg_net_pd_amt,
          cvgsum.cvg_resr_amt,
          cvgsum.cvg_incurred_amt,
          -- 826   --cvgdtl.*
          cvgdtl.int_claim_num_826 AS ccvg_int_claim_num,
          cvgdtl.line_type_826 AS ccvg_cl_line_type,
          cvgdtl.claimant_num_826 AS ccvg_claimant_num,
          cvgdtl.last_process_date_826 AS ccvg_last_process_date,
          cvgdtl.processed_date_826 AS ccvg_processed_date,
          cvgdtl.ccvg_status_desc,
          CASE
            WHEN cvgdtl.date_det_open > origopncvdt.orig_ccvg_open_dt THEN origopncvdt.orig_ccvg_open_dt
            ELSE cvgdtl.date_det_open
          END AS ccvg_open_dt,
          coalesce(CAST(cvgdtl.ccvg_reopen_dt as STRING), '') AS ccvg_reopen_dt,
          coalesce(CAST(cvgdtl.ccvg_closed_dt as STRING), '') AS ccvg_closed_dt,
          cvgdtl.ccvg_orig_loss_est,
          cvgdtl.ccvg_orig_expn_est,
          cvgdtl.ccvg_orig_intr_est,
          cvgdtl.ccvg_loss_pd_amt,
          cvgdtl.ccvg_expn_pd_amt,
          cvgdtl.ccvg_loss_resr_amt,
          cvgdtl.ccvg_expn_resr_amt,
          cvgdtl.ccvg_intr_resr_amt,
          cvgdtl.ccvg_loss_subr_amt,
          cvgdtl.ccvg_expn_subr_amt,
          cvgdtl.ccvg_salv_tot_amt,
          cvgdtl.ccvg_payback_amt,
          cvgdtl.prev_ccvg_loss_pd_amt,
          cvgdtl.prev_ccvg_loss_resr_amt,
          cvgdtl.prev_ccvg_expn_pd_amt,
          cvgdtl.prev_ccvg_expn_resr_amt,
          cvgdtl.prev_ccvg_intr_resr_amt,
          cvgdtl.prev_ccvg_loss_subr_amt,
          cvgdtl.prev_ccvg_expn_subr_amt,
          cvgdtl.prev_ccvg_salv_tot_amt,
          cvgdtl.ccvg_loss_pd_amt_delta,
          cvgdtl.ccvg_expn_pd_amt_delta,
          cvgdtl.ccvg_loss_resr_amt_delta,
          cvgdtl.ccvg_expn_resr_amt_delta,
          cvgdtl.ccvg_intr_resr_amt_delta,
          cvgdtl.ccvg_loss_subr_amt_delta,
          cvgdtl.ccvg_expn_subr_amt_delta,
          cvgdtl.ccvg_salv_tot_amt_delta,
          cvgdtl.ccvg_net_pd_amt,
          cvgdtl.ccvg_resr_amt,
          cvgdtl.ccvg_incurred_amt,
          cvgdtl.tabular_reserve_ind AS ccvg_tablr_reserve_ind,
          coalesce(CAST(cvgdtl.tabular_resr_chng_dt as STRING), '') AS ccvg_tablr_resr_chng_dt
        FROM
          --  mainxtr - table list of keys for joining to the eclm tables --
          (SELECT
                tbl813.int_claim_num_mxtr,
                tbl813.lpd_mxtr,
                tbl813.pd_mxtr,
                tbl813.lpd_813,
                tbl813.pd_813,
                tbl817.lpd_817,
                tbl817.pd_817,
                tbl822.lpd_822,
                tbl822.pd_822,
                tbl826.lpd_826,
                tbl826.pd_826
              FROM
                --  813 - Claim Summary ----------------------------------------------------
                (SELECT
                      x.*
                    FROM
                      (SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl813.int_claim_num AS int_claim_num_813,
                            DATE(cl813.last_process_date) AS lpd_813,
                            DATE(cl813.processed_date) AS pd_813,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date ORDER BY cl813.int_claim_num DESC, cl813.processed_date DESC, cl813.last_process_date DESC) AS rownum
                          FROM
                            --  main extract -----------------------------------------------------------
                            (SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type = 4
                                       ) AS ec813
                                       LEFT OUTER JOIN -- ec817
                                  (
                                    SELECT
                                        claim_common_prop.int_claim_num,
                                        DATE(claim_common_prop.last_process_date) AS last_process_date,
                                        DATE(claim_common_prop.processed_date) AS processed_date,
                                        claim_common_prop.file_status,
                                        claim_common_prop.company,
                                        substr(trim(claim_common_prop.prop_loss_code), 1, 3) AS prop_loss_code_1st3
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_prop` AS claim_common_prop
                                      WHERE DATE(claim_common_prop.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_prop.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_prop.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.prop_loss_code_1st3 NOT IN(
                                  '901', '902', '903', '904', '905', '906'
                                )
                                ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_claim_summary` AS cl813 ON cl813.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl813.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl813.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl813.last_process_date) <= CAST('@execution_date' as DATE)
                           ) AS x
                    WHERE x.rownum = 1
                    ) AS tbl813
                LEFT OUTER JOIN --  817 - Claim Common ------------------------------------------------
                (
                  SELECT
                      x.*
                    FROM
                      (
                        SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl817.int_claim_num AS int_claim_num_817,
                            DATE(cl817.last_process_date) AS lpd_817,
                            DATE(cl817.processed_date) AS pd_817,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date ORDER BY cl817.int_claim_num DESC, cl817.processed_date DESC, cl817.last_process_date DESC) AS rownum
                          FROM
                            --  main extract ------------------------------------------------------------
                            (
                              SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type = 4
                                  ) AS ec813
                                  LEFT OUTER JOIN -- ec817
                                  (
                                    SELECT
                                        claim_common_prop.int_claim_num,
                                        DATE(claim_common_prop.last_process_date) AS last_process_date,
                                        DATE(claim_common_prop.processed_date) AS processed_date,
                                        claim_common_prop.file_status,
                                        claim_common_prop.company,
                                        substr(trim(claim_common_prop.prop_loss_code), 1, 3) AS prop_loss_code_1st3
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_prop` AS claim_common_prop
                                      WHERE DATE(claim_common_prop.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_prop.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_prop.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.prop_loss_code_1st3 NOT IN(
                                  '901', '902', '903', '904', '905', '906'
                                )
                            ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_common_prop` AS cl817 ON cl817.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl817.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl817.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl817.last_process_date) <= CAST('@execution_date' as DATE)
                      ) AS x
                    WHERE x.rownum = 1
                ) AS tbl817 ON tbl817.int_claim_num_mxtr = tbl813.int_claim_num_mxtr
                 AND tbl817.pd_mxtr = tbl813.pd_mxtr
                 LEFT OUTER JOIN --  822 - Coverage Summary -------------------------------------------
                (
                  SELECT
                      x.*
                    FROM
                      (
                        SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl822.int_claim_num AS int_claim_num_822,
                            DATE(cl822.last_process_date) AS lpd_822,
                            DATE(cl822.processed_date) AS pd_822,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date ORDER BY cl822.int_claim_num, cl822.processed_date DESC, cl822.last_process_date DESC) AS rownum
                          FROM
                            --  main extract ------------------------------------------------------------
                            (
                              SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type = 4
                                  ) AS ec813
                                  LEFT OUTER JOIN -- ec817
                                  (
                                    SELECT
                                        claim_common_prop.int_claim_num,
                                        DATE(claim_common_prop.last_process_date) AS last_process_date,
                                        DATE(claim_common_prop.processed_date) AS processed_date,
                                        claim_common_prop.file_status,
                                        claim_common_prop.company,
                                        substr(trim(claim_common_prop.prop_loss_code), 1, 3) AS prop_loss_code_1st3
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_prop` AS claim_common_prop
                                      WHERE DATE(claim_common_prop.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_prop.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_prop.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.prop_loss_code_1st3 NOT IN(
                                  '901', '902', '903', '904', '905', '906'
                                )
                            ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_coverage_summary_prop` AS cl822 ON cl822.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl822.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl822.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl822.last_process_date) <= CAST('@execution_date' as DATE)
                      ) AS x
                    WHERE x.rownum = 1
                ) AS tbl822 ON tbl822.int_claim_num_mxtr = tbl813.int_claim_num_mxtr
                 AND tbl822.pd_mxtr = tbl813.pd_mxtr
                 LEFT OUTER JOIN --  826 - Coverage Detail ------------------------------------------------
                (
                  SELECT
                      x.*
                    FROM
                      (
                        SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl826.int_claim_num AS int_claim_num_826,
                            DATE(cl826.last_process_date) AS lpd_826,
                            DATE(cl826.processed_date) AS pd_826,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date ORDER BY cl826.int_claim_num, cl826.processed_date DESC, cl826.last_process_date DESC) AS rownum
                          FROM
                            --  main extract -----------------------------------------------------------
                            (
                              SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type = 4
                                  ) AS ec813
                                  LEFT OUTER JOIN -- ec817
                                  (
                                    SELECT
                                        claim_common_prop.int_claim_num,
                                        DATE(claim_common_prop.last_process_date) AS last_process_date,
                                        DATE(claim_common_prop.processed_date) AS processed_date,
                                        claim_common_prop.file_status,
                                        claim_common_prop.company,
                                        substr(trim(claim_common_prop.prop_loss_code), 1, 3) AS prop_loss_code_1st3
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_prop` AS claim_common_prop
                                      WHERE DATE(claim_common_prop.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_prop.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_prop.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.prop_loss_code_1st3 NOT IN(
                                  '901', '902', '903', '904', '905', '906'
                                )
                            ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_coverage_detail` AS cl826 ON cl826.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl826.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl826.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl826.last_process_date) <= CAST('@execution_date' as DATE)
                      ) AS x
                    WHERE x.rownum = 1
                ) AS tbl826 ON tbl826.int_claim_num_mxtr = tbl813.int_claim_num_mxtr
                 AND tbl826.pd_mxtr = tbl813.pd_mxtr
              WHERE tbl813.int_claim_num_mxtr = tbl813.int_claim_num_813
               AND tbl813.pd_mxtr = tbl813.pd_mxtr
               AND tbl813.int_claim_num_mxtr = tbl817.int_claim_num_817
               AND tbl813.pd_mxtr = tbl817.pd_mxtr
               AND tbl813.int_claim_num_mxtr = tbl822.int_claim_num_822
               AND tbl813.pd_mxtr = tbl822.pd_mxtr
               AND tbl813.int_claim_num_mxtr = tbl826.int_claim_num_826
               AND tbl813.pd_mxtr = tbl826.pd_mxtr
               ) AS sel
               INNER JOIN --  end of mainxtr - table list of keys for joining to the eclm tables --
          --  813 / claim summary
          (
            SELECT
                claim_claim_summary.int_claim_num AS int_claim_num_813,
                DATE(claim_claim_summary.last_process_date) AS last_process_date_813,
                DATE(claim_claim_summary.processed_date) AS processed_date_813,
                claim_claim_summary.policy_type AS cl_pol_type,
                CASE
                  WHEN claim_claim_summary.policy_type = 2 THEN 'PPROP'
                  WHEN claim_claim_summary.policy_type = 4 THEN 'CPROP'
                  ELSE CAST(claim_claim_summary.policy_type AS STRING)
                END AS cl_pol_type_division,
                CASE
                  WHEN claim_claim_summary.policy_type = 2 THEN 'Pers Prop'
                  WHEN claim_claim_summary.policy_type = 4 THEN 'Comm Prop'
                  ELSE CAST(claim_claim_summary.policy_type AS STRING)
                END AS cl_pol_type_desc,
                claim_claim_summary.claim_status AS cl_status_cd_813,
                CASE
                  WHEN claim_claim_summary.claim_status = 2 THEN 'OPN'
                  WHEN claim_claim_summary.claim_status = 3 THEN 'CLS'
                  WHEN claim_claim_summary.claim_status = 6 THEN 'REO'
                  WHEN claim_claim_summary.claim_status = 4 THEN 'STR'
                  ELSE CAST(claim_claim_summary.claim_status AS STRING)
                END AS cl_status_desc_813,
                DATE(claim_claim_summary.last_financial_date) AS last_fin_dt,
                claim_claim_summary.pc_indicator AS pay_and_close_ind,
                claim_claim_summary.cds_claim_num AS cds_number,
                claim_claim_summary.policy_num AS pol_num,
                DATE(claim_claim_summary.loss_date) AS loss_dt,
                claim_claim_summary.occurrence AS occur_num,
                DATE(claim_claim_summary.policy_efdt) AS term_eff_dt,
                claim_claim_summary.prefix AS subscription_prefix,
                claim_claim_summary.contr_id,
                claim_claim_summary.percent_fault AS insured_fault_pct,
                claim_claim_summary.branch,
                claim_claim_summary.no_claimants_open,
                claim_claim_summary.no_claimants_clsd,
                claim_claim_summary.no_covg_line_open,
                claim_claim_summary.no_covg_line_clsd,
                claim_claim_summary.no_rein_line_open,
                claim_claim_summary.no_cov_det_lines_open,
                claim_claim_summary.no_fin_hist,
                coalesce(claim_claim_summary.in_suit_cnt, 0) AS in_suit_cnt,
                claim_claim_summary.total_losses,
                claim_claim_summary.total_expense,
                claim_claim_summary.total_loss_reserve,
                claim_claim_summary.total_expense_reserve,
                claim_claim_summary.total_interest_reserve,
                claim_claim_summary.subrogation_tot,
                claim_claim_summary.salvage_tot,
                claim_claim_summary.prev_total_losses,
                claim_claim_summary.prev_total_expense,
                claim_claim_summary.prev_total_loss_reserve,
                claim_claim_summary.prev_total_expense_reserve,
                claim_claim_summary.prev_total_interest_reserv,
                claim_claim_summary.prev_subrogation_tot,
                claim_claim_summary.prev_salvage_tot,
                (claim_claim_summary.total_losses-claim_claim_summary.prev_total_losses) AS total_losses_delta,
                (claim_claim_summary.total_expense-claim_claim_summary.prev_total_expense) AS total_expense_delta,
                (claim_claim_summary.total_loss_reserve-claim_claim_summary.prev_total_loss_reserve) AS total_loss_reserve_delta,
                (claim_claim_summary.total_expense_reserve-claim_claim_summary.prev_total_expense_reserve) AS total_expense_reserve_delta,
                (claim_claim_summary.total_interest_reserve-claim_claim_summary.prev_total_interest_reserv) AS total_interest_reserve_delta,
                (claim_claim_summary.subrogation_tot-claim_claim_summary.prev_subrogation_tot) AS subrogation_tot_delta,
                (claim_claim_summary.salvage_tot-claim_claim_summary.prev_salvage_tot) AS salvage_tot_delta
              FROM
                `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
              WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_claim_summary.claim_status <> 1
               AND claim_claim_summary.policy_type = 4
          ) AS clsum ON clsum.int_claim_num_813 = sel.int_claim_num_mxtr
           AND clsum.processed_date_813 = sel.pd_813
           INNER JOIN -- 817 / claim common
          (
            SELECT
                claim_common_prop.int_claim_num AS int_claim_num_817,
                DATE(claim_common_prop.last_process_date) AS last_process_date_817,
                DATE(claim_common_prop.processed_date) AS processed_date_817,
                claim_common_prop.agent_num AS curr_brk_num,
                claim_common_prop.siu_ind_ab AS siu_ab_ind,
                claim_common_prop.siu_ind AS siu_non_ab_ind,
                claim_common_prop.clm_jurisdiction AS juris_prov_cd,
                claim_common_prop.company AS cl_co_cd,
                claim_common_prop.prov_cd AS cl_prov_cd,
                claim_common_prop.claim_status AS cl_status_cd_817,
                claim_common_prop.file_status AS file_status_cd_817,
                CASE
                  WHEN claim_common_prop.total_loss_ind = 'Z' THEN ''
                  WHEN claim_common_prop.total_loss_ind = 'P' THEN 'N'
                  WHEN claim_common_prop.total_loss_ind = 'T' THEN 'Y'
                  ELSE ''
                END AS total_loss_ind,
                DATE(claim_common_prop.first_closed_dt) AS first_closed_date,
                DATE(claim_common_prop.open_dt) AS cl_open_dt,
                claim_common_prop.rep_code_1 AS repid_001,
                claim_common_prop.rep_code_2 AS repid_002,
                claim_common_prop.rep_code_3 AS repid_003,
                claim_common_prop.rep_code_4 AS repid_004,
                claim_common_prop.sup_rep_code AS repid_sup,
                claim_common_prop.rep_code_ho AS repid_ho,
                claim_common_prop.mga_number,
                claim_common_prop.cat_loss_id AS loss_event_id,
                CASE
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'HO'
                   AND claim_common_prop.company = 8 THEN 28
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'UK' THEN 0
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'HB' THEN 1
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'OT' THEN 2
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'TO' THEN 3
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'HA' THEN 4
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'LO' THEN 5
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'ST' THEN 6
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'MI' THEN 7
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WS' THEN 8
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'VN' THEN 11
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'ED' THEN 12
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'CA' THEN 13
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WG' THEN 14
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'MO' THEN 15
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'MN' THEN 16
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'HX' THEN 17
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'HO' THEN 19
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'MO' THEN 20
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'FR' THEN 21
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'MH' THEN 22
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'ST' THEN 23
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'PR' THEN 24
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WA' THEN 25
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WH' THEN 26
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'QU' THEN 27
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'SO' THEN 28
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'PE' THEN 31
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'PW' THEN 32
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'PO' THEN 33
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WE' THEN 34
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WW' THEN 35
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WO' THEN 36
                  ELSE 0
                END AS hndlng_br_num,
                claim_common_prop.loc_city,
                claim_common_prop.loc_prov,
                claim_common_prop.prop_loss_code
              FROM
                `@curated_project.@curated_dataset_name.claim_common_prop` AS claim_common_prop
              WHERE DATE(claim_common_prop.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_common_prop.file_status <> 1
          ) AS clcom ON clcom.int_claim_num_817 = sel.int_claim_num_mxtr
           AND clcom.processed_date_817 = sel.pd_817
           INNER JOIN -- 822 / cvg summary
          (
            SELECT
                claim_coverage_summary_prop.int_claim_num AS int_claim_num_822,
                claim_coverage_summary_prop.line_type AS line_type_822,
                DATE(claim_coverage_summary_prop.last_process_date) AS last_process_date_822,
                DATE(claim_coverage_summary_prop.processed_date) AS processed_date_822,
                claim_coverage_summary_prop.line_type AS cl_line_type_cd,
                claim_coverage_summary_prop.line_type_desc AS cl_line_type_desc,
                claim_coverage_summary_prop.status_cov_sum AS cvg_status_cd,
                claim_coverage_summary_prop.status_desc AS cvg_status_desc_geo,
                CASE
                  WHEN claim_coverage_summary_prop.status_cov_sum = 2 THEN 'OPN'
                  WHEN claim_coverage_summary_prop.status_cov_sum = 3 THEN 'CLS'
                  WHEN claim_coverage_summary_prop.status_cov_sum = 6 THEN 'REO'
                  WHEN claim_coverage_summary_prop.status_cov_sum = 4 THEN 'STR'
                  ELSE CAST(claim_coverage_summary_prop.status_cov_sum AS STRING)
                END AS cvg_status_desc,
                claim_coverage_summary_prop.ibc_kind_of_loss_cd AS ibc_kindof_loss_cd,
                claim_coverage_summary_prop.class_of_bus AS cl_class_bus_cd,
                claim_coverage_summary_prop.ibc_code AS cl_ibc_cd,
                claim_coverage_summary_prop.coverage_code AS cvg_cd,
                DATE(claim_coverage_summary_prop.date_open_sum) AS date_open_sum,
                CASE
                  WHEN claim_coverage_summary_prop.item_type IN(
                    1, 2, 10
                  ) THEN 'AUT'
                  WHEN claim_coverage_summary_prop.item_type = 3 THEN 'LOC'
                  WHEN claim_coverage_summary_prop.item_type = 4 THEN 'LIA'
                  WHEN claim_coverage_summary_prop.item_type = 5 THEN 'MIS'
                  WHEN claim_coverage_summary_prop.item_type = 6 THEN 'SAF'
                  WHEN claim_coverage_summary_prop.item_type = 7 THEN 'BOM'
                  WHEN claim_coverage_summary_prop.item_type = 8 THEN 'CLI'
                  WHEN claim_coverage_summary_prop.item_type = 9 THEN 'CMP'
                  ELSE CAST(claim_coverage_summary_prop.item_type AS STRING)
                END AS cvg_seg_type,
                claim_coverage_summary_prop.rag_num,
                claim_coverage_summary_prop.kind_of_loss,
                claim_coverage_summary_prop.deductible_amount,
                claim_coverage_summary_prop.deductible_type,
                claim_coverage_summary_prop.deduct_basis_cd,
                claim_coverage_summary_prop.loss_pay_to_dt AS cvg_loss_pd_amt,
                claim_coverage_summary_prop.exp_pay_to_dt AS cvg_expn_pd_amt,
                claim_coverage_summary_prop.loss_reser_to_dt AS cvg_loss_resr_amt,
                claim_coverage_summary_prop.exp_reser_to_dt AS cvg_expn_resr_amt,
                claim_coverage_summary_prop.int_reser_to_dt AS cvg_intr_resr_amt,
                claim_coverage_summary_prop.subrogation_loss AS cvg_loss_subr_amt,
                claim_coverage_summary_prop.subrogation_exp AS cvg_expn_subr_amt,
                claim_coverage_summary_prop.salvage_tot AS cvg_salv_tot_amt,
                claim_coverage_summary_prop.pay_back AS cvg_payback_amt,
                claim_coverage_summary_prop.prev_loss_pay_to_dt AS prev_cvg_loss_pd_amt,
                claim_coverage_summary_prop.prev_exp_pay_to_dt AS prev_cvg_expn_pd_amt,
                claim_coverage_summary_prop.prev_loss_reser_to_dt AS prev_cvg_loss_resr_amt,
                claim_coverage_summary_prop.prev_exp_reser_to_dt AS prev_cvg_expn_resr_amt,
                claim_coverage_summary_prop.prev_int_reser_to_dt AS prev_cvg_intr_resr_amt,
                claim_coverage_summary_prop.prev_subrogation_loss AS prev_cvg_loss_subr_amt,
                claim_coverage_summary_prop.prev_subrogation_exp AS prev_cvg_expn_subr_amt,
                claim_coverage_summary_prop.prev_salvage_tot AS prev_cvg_salv_tot_amt,
                (claim_coverage_summary_prop.loss_pay_to_dt-claim_coverage_summary_prop.prev_loss_pay_to_dt) AS cvg_loss_pd_amt_delta,
                (claim_coverage_summary_prop.exp_pay_to_dt-claim_coverage_summary_prop.prev_exp_pay_to_dt) AS cvg_expn_pd_amt_delta,
                (claim_coverage_summary_prop.loss_reser_to_dt-claim_coverage_summary_prop.prev_loss_reser_to_dt) AS cvg_loss_resr_amt_delta,
                (claim_coverage_summary_prop.exp_reser_to_dt-claim_coverage_summary_prop.prev_exp_reser_to_dt) AS cvg_expn_resr_amt_delta,
                (claim_coverage_summary_prop.int_reser_to_dt-claim_coverage_summary_prop.prev_int_reser_to_dt) AS cvg_intr_resr_amt_delta,
                (claim_coverage_summary_prop.subrogation_loss-claim_coverage_summary_prop.prev_subrogation_loss) AS cvg_loss_subr_amt_delta,
                (claim_coverage_summary_prop.subrogation_exp-claim_coverage_summary_prop.prev_subrogation_exp) AS cvg_expn_subr_amt_delta,
                (claim_coverage_summary_prop.salvage_tot-claim_coverage_summary_prop.prev_salvage_tot) AS cvg_salv_tot_amt_delta,
                (claim_coverage_summary_prop.loss_reser_to_dt+claim_coverage_summary_prop.exp_reser_to_dt+claim_coverage_summary_prop.int_reser_to_dt+claim_coverage_summary_prop.loss_pay_to_dt+claim_coverage_summary_prop.exp_pay_to_dt-claim_coverage_summary_prop.subrogation_loss-claim_coverage_summary_prop.subrogation_exp-claim_coverage_summary_prop.salvage_tot) AS cvg_incurred_amt,
                (claim_coverage_summary_prop.loss_pay_to_dt+claim_coverage_summary_prop.exp_pay_to_dt-claim_coverage_summary_prop.subrogation_loss-claim_coverage_summary_prop.subrogation_exp-claim_coverage_summary_prop.salvage_tot) AS cvg_net_pd_amt,
                (claim_coverage_summary_prop.loss_reser_to_dt+claim_coverage_summary_prop.exp_reser_to_dt+claim_coverage_summary_prop.int_reser_to_dt) AS cvg_resr_amt
              FROM
                `@curated_project.@curated_dataset_name.claim_coverage_summary_prop` AS claim_coverage_summary_prop
              WHERE DATE(claim_coverage_summary_prop.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_coverage_summary_prop.status_cov_sum <> 1
          ) AS cvgsum ON cvgsum.int_claim_num_822 = sel.int_claim_num_mxtr
           AND cvgsum.processed_date_822 = sel.pd_822
           INNER JOIN -- 826 / cvg detail
          (
            SELECT
                claim_coverage_detail.int_claim_num AS int_claim_num_826,
                claim_coverage_detail.line_type AS line_type_826,
                claim_coverage_detail.claimant_num AS claimant_num_826,
                DATE(claim_coverage_detail.last_process_date) AS last_process_date_826,
                DATE(claim_coverage_detail.processed_date) AS processed_date_826,
                claim_coverage_detail.status_det_cov AS ccvg_status_cd,
                claim_coverage_detail.status_desc AS ccvg_status_desc_geo,
                CASE
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NOT NULL THEN 'REO'
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NULL THEN 'OPN'
                  WHEN claim_coverage_detail.status_det_cov = 3 THEN 'CLS'
                  WHEN claim_coverage_detail.status_det_cov = 4 THEN 'STR'
                  ELSE CAST(claim_coverage_detail.status_det_cov AS STRING)
                END AS ccvg_status_desc,
                DATE(claim_coverage_detail.date_det_open) AS date_det_open,
                DATE(claim_coverage_detail.date_det_clsd) AS date_det_clsd,
                CASE
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NULL THEN DATE(claim_coverage_detail.date_det_open)
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NOT NULL THEN DATE(claim_coverage_detail.date_det_open)
                  WHEN claim_coverage_detail.status_det_cov IN(
                    3, 4
                  ) THEN DATE(claim_coverage_detail.date_det_open)
                  ELSE CAST(NULL as DATE)
                END AS ccvg_open_dt,
                CASE
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NULL THEN CAST(NULL as DATE)
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NOT NULL THEN DATE(claim_coverage_detail.date_det_open)
                  WHEN claim_coverage_detail.status_det_cov IN(
                    3, 4
                  ) THEN CAST(NULL as DATE)
                  ELSE CAST(NULL as DATE)
                END AS ccvg_reopen_dt,
                CASE
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NULL THEN CAST(NULL as DATE)
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NOT NULL THEN CAST(NULL as DATE)
                  WHEN claim_coverage_detail.status_det_cov IN(
                    3, 4
                  ) THEN DATE(claim_coverage_detail.date_det_clsd)
                  ELSE CAST(NULL as DATE)
                END AS ccvg_closed_dt,
                claim_coverage_detail.loss_pay_to_date AS ccvg_loss_pd_amt,
                claim_coverage_detail.cur_loss_est AS ccvg_loss_resr_amt,
                claim_coverage_detail.expense_pay_to_date AS ccvg_expn_pd_amt,
                claim_coverage_detail.cur_exp_est AS ccvg_expn_resr_amt,
                claim_coverage_detail.cur_int_est AS ccvg_intr_resr_amt,
                claim_coverage_detail.subrogation_loss AS ccvg_loss_subr_amt,
                claim_coverage_detail.subrogation_exp AS ccvg_expn_subr_amt,
                claim_coverage_detail.salvage_tot AS ccvg_salv_tot_amt,
                claim_coverage_detail.prev_loss_pay_to_date AS prev_ccvg_loss_pd_amt,
                claim_coverage_detail.prev_cur_loss_est AS prev_ccvg_loss_resr_amt,
                claim_coverage_detail.prev_expense_pay_to_date AS prev_ccvg_expn_pd_amt,
                claim_coverage_detail.prev_cur_exp_est AS prev_ccvg_expn_resr_amt,
                claim_coverage_detail.prev_cur_int_est AS prev_ccvg_intr_resr_amt,
                claim_coverage_detail.prev_subrogation_loss AS prev_ccvg_loss_subr_amt,
                claim_coverage_detail.prev_subrogation_exp AS prev_ccvg_expn_subr_amt,
                claim_coverage_detail.prev_salvage_tot AS prev_ccvg_salv_tot_amt,
                (claim_coverage_detail.loss_pay_to_date-claim_coverage_detail.prev_loss_pay_to_date) AS ccvg_loss_pd_amt_delta
			,(claim_coverage_detail.cur_loss_est-claim_coverage_detail.prev_cur_loss_est) AS ccvg_loss_resr_amt_delta
			,(claim_coverage_detail.expense_pay_to_date-claim_coverage_detail.prev_expense_pay_to_date) AS ccvg_expn_pd_amt_delta
			,(claim_coverage_detail.cur_exp_est-claim_coverage_detail.prev_cur_exp_est) AS ccvg_expn_resr_amt_delta
			,(claim_coverage_detail.cur_int_est-claim_coverage_detail.prev_cur_int_est) AS ccvg_intr_resr_amt_delta
			,(claim_coverage_detail.subrogation_loss-claim_coverage_detail.prev_subrogation_loss) AS ccvg_loss_subr_amt_delta
			,(claim_coverage_detail.subrogation_exp-claim_coverage_detail.prev_subrogation_exp) AS ccvg_expn_subr_amt_delta
			,(claim_coverage_detail.salvage_tot-claim_coverage_detail.prev_salvage_tot) AS ccvg_salv_tot_amt_delta
			,claim_coverage_detail.orig_exp_est AS ccvg_orig_expn_est
			,claim_coverage_detail.date_last_exp_est
			,claim_coverage_detail.orig_int_est AS ccvg_orig_intr_est
			,claim_coverage_detail.date_last_int_est
			,claim_coverage_detail.orig_loss_est AS ccvg_orig_loss_est
			,claim_coverage_detail.date_last_loss_est
      ,(claim_coverage_detail.cur_loss_est+claim_coverage_detail.cur_exp_est+claim_coverage_detail.cur_int_est+claim_coverage_detail.loss_pay_to_date+claim_coverage_detail.expense_pay_to_date-claim_coverage_detail.subrogation_loss-claim_coverage_detail.subrogation_exp-claim_coverage_detail.salvage_tot) AS ccvg_incurred_amt
      ,(claim_coverage_detail.loss_pay_to_date+claim_coverage_detail.expense_pay_to_date-claim_coverage_detail.subrogation_loss-claim_coverage_detail.subrogation_exp-claim_coverage_detail.salvage_tot) AS ccvg_net_pd_amt
			,(claim_coverage_detail.cur_loss_est+claim_coverage_detail.cur_exp_est+claim_coverage_detail.cur_int_est) AS ccvg_resr_amt
			,(claim_coverage_detail.pay_back_loss+claim_coverage_detail.pay_back_exp) AS ccvg_payback_amt,
                claim_coverage_detail.tab_res AS tabular_reserve_ind,
                DATE(claim_coverage_detail.date_tab_res) AS tabular_resr_chng_dt
              FROM
                `@curated_project.@curated_dataset_name.claim_coverage_detail` AS claim_coverage_detail
              WHERE DATE(claim_coverage_detail.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_coverage_detail.status_det_cov <> 1
          ) AS cvgdtl ON cvgdtl.int_claim_num_826 = sel.int_claim_num_mxtr
           AND cvgdtl.processed_date_826 = sel.pd_826
           AND cvgdtl.line_type_826 = cvgsum.line_type_822
           LEFT OUTER JOIN -- 826 / cvg detail - earliest open date for int_claim_num / line_type / claimant_num combo for
          --                    original open date on reopen coverage detail claims
          (
            SELECT
                claim_financial_history.int_claim_num,
                claim_financial_history.claimant_num,
                claim_financial_history.line_type,
                DATE(claim_financial_history.last_process_date) AS orig_ccvg_open_dt,
                row_number() OVER (PARTITION BY claim_financial_history.int_claim_num, claim_financial_history.claimant_num, claim_financial_history.line_type ORDER BY claim_financial_history.last_process_date, claim_financial_history.processed_date, claim_financial_history.claimant_num, claim_financial_history.line_type) AS rownum
              FROM
                `@curated_project.@curated_dataset_name.claim_financial_history` AS claim_financial_history
              WHERE DATE(claim_financial_history.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_financial_history.file_status <> 1
               AND claim_financial_history.action_desc = 'OPEN'
          ) AS origopncvdt ON origopncvdt.int_claim_num = sel.int_claim_num_mxtr
           AND origopncvdt.claimant_num = cvgdtl.claimant_num_826
           AND origopncvdt.line_type = cvgdtl.line_type_826
           AND origopncvdt.rownum = 1
           LEFT OUTER JOIN -- 822 / cvg sum - earliest open date for int_claim_num / line_type combo for
          --                 original open date on reopen coverage summary claims
          (
            SELECT
                claim_financial_history.int_claim_num,
                claim_financial_history.line_type,
                DATE(claim_financial_history.last_process_date) AS orig_cvg_open_dt,
                row_number() OVER (PARTITION BY claim_financial_history.int_claim_num, claim_financial_history.line_type ORDER BY claim_financial_history.last_process_date, claim_financial_history.processed_date, claim_financial_history.line_type) AS rownum
              FROM
                `@curated_project.@curated_dataset_name.claim_financial_history` AS claim_financial_history
              WHERE DATE(claim_financial_history.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_financial_history.file_status <> 1
               AND claim_financial_history.action_desc = 'OPEN'
          ) AS origopncvsm ON origopncvsm.int_claim_num = sel.int_claim_num_mxtr
           AND origopncvsm.line_type = cvgsum.line_type_822
           AND origopncvsm.rownum = 1
           LEFT OUTER JOIN -- 826 / cvg detail - accummulate original estimates for cvgsum level
          (
            SELECT
                claim_coverage_detail.int_claim_num,
                DATE(claim_coverage_detail.processed_date) AS processed_date,
                claim_coverage_detail.line_type,
                sum(claim_coverage_detail.orig_loss_est) AS cvg_orig_loss_est,
                sum(claim_coverage_detail.orig_exp_est) AS cvg_orig_expn_est,
                sum(claim_coverage_detail.orig_int_est) AS cvg_orig_intr_est
              FROM
                `@curated_project.@curated_dataset_name.claim_coverage_detail` AS claim_coverage_detail
              WHERE DATE(claim_coverage_detail.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_coverage_detail.status_det_cov <> 1
              GROUP BY 1, claim_coverage_detail.processed_date, 3
          ) AS estacc ON estacc.int_claim_num = sel.int_claim_num_mxtr
           AND estacc.processed_date = sel.pd_826
           AND estacc.line_type = cvgsum.line_type_822
           ) AS main
    INNER JOIN --  main claims data cl/cvg/ccvg
    -- -----------------------------------------------------------------------------------
    --  to Claimant Info ------------------------------------------------------
    -- -----------------------------------------------------------------------------------
    (
      SELECT
          x.*
        FROM
          (
            SELECT
                tbl818.pd_mxtr,
                tbl818.lpd_mxtr,
                tbl818.pd_818,
                tbl818.lpd_818,
                clmtinfo.*
              FROM
                --  ,row_number() over (partition by tbl818.int_claim_num_mxtr, tbl818.pd_mxtr, tbl818.clmt_num_818
                --                          order by tbl818.int_claim_num_mxtr, tbl818.pd_mxtr desc, tbl818.lpd_mxtr desc) as rownum
                --  818 - Claimant Info Keys ------------------------------------------------
                (
                  SELECT
                      x_0.*
                    FROM
                      (
                        SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl818.int_claim_num AS int_claim_num_818,
                            DATE(cl818.last_process_date) AS lpd_818,
                            DATE(cl818.processed_date) AS pd_818,
                            cl818.sequence_num AS clmt_num_818,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date, cl818.sequence_num ORDER BY cl818.int_claim_num, cl818.processed_date DESC, cl818.last_process_date DESC) AS rownum
                          FROM
                            --  main extract -----------------------------------------------------------
                            (
                              SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type = 4
                                  ) AS ec813
                                  LEFT OUTER JOIN -- 2=prop 4=cprop 1,3,5,6,7,8=auto
                                  --        and int_claim_num = '4197907'
                                  -- ec817
                                  (
                                    SELECT
                                        claim_common_prop.int_claim_num,
                                        DATE(claim_common_prop.last_process_date) AS last_process_date,
                                        DATE(claim_common_prop.processed_date) AS processed_date,
                                        claim_common_prop.file_status,
                                        claim_common_prop.company,
                                        substr(trim(claim_common_prop.prop_loss_code), 1, 3) AS prop_loss_code_1st3
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_prop` AS claim_common_prop
                                      WHERE DATE(claim_common_prop.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_prop.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_prop.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.prop_loss_code_1st3 NOT IN(
                                  '901', '902', '903', '904', '905', '906'
                                )
                            ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_claimant_info` AS cl818 ON cl818.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl818.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl818.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl818.last_process_date) <= CAST('@execution_date' as DATE)
                      ) AS x_0
                    WHERE x_0.rownum = 1
                ) AS tbl818
                INNER JOIN -- -----------------------------------------------------------------------------------
                -- ------------------------------------------------------------------------
                -- -----------------------------------------------------------------------------------
                -- 818 / claimant info data
                (
                  SELECT
                      claim_claimant_info.int_claim_num AS int_claim_num_818,
                      claim_claimant_info.sequence_num AS claimant_num_818,
                      claim_claimant_info.name_category AS name_category_818,
                      DATE(claim_claimant_info.last_process_date) AS last_process_date_818,
                      DATE(claim_claimant_info.processed_date) AS processed_date_818,
                      DATE(claim_claimant_info.creation_dt) AS eclmclmt_creation_date,
                      claim_claimant_info.claimant_status AS eclmclmt_status_cd,
                      claim_claimant_info.status_desc AS eclmclmt_status_desc_geo,
                      CASE
                        WHEN claim_claimant_info.claimant_status = 2 THEN 'OPN'
                        WHEN claim_claimant_info.claimant_status = 3 THEN 'CLS'
                        WHEN claim_claimant_info.claimant_status = 6 THEN 'REO'
                        WHEN claim_claimant_info.claimant_status = 4 THEN 'STR'
                        WHEN claim_claimant_info.claimant_status = 1 THEN 'PEN'
                        ELSE CAST(claim_claimant_info.claimant_status AS STRING)
                      END AS eclmclmt_status_desc,
                      claim_claimant_info.claimant_categ AS eclmclmt_clmt_type_desc,
                      claim_claimant_info.surname AS eclmclmt_last_name,
                      claim_claimant_info.first_name AS eclmclmt_first_name,
                      claim_claimant_info.middle_name AS eclmclmt_middle_name,
                      claim_claimant_info.company_name AS eclmclmt_company_name,
                      claim_claimant_info.comp_or_individ_ind AS eclmclmt_cmpny_or_indvd_ind,
                      claim_claimant_info.licence_num AS eclmclmt_lic_num,
                      claim_claimant_info.lic_iss_prov AS eclmclmt_lic_prov,
                      DATE(claim_claimant_info.claimant_dob) AS eclmclmt_clmt_dob,
                      claim_claimant_info.abc_orig_type_ind AS eclmclmt_bi_code_orig,
                      claim_claimant_info.abc_curr_type_ind AS eclmclmt_bi_code_curr,
                      claim_claimant_info.loss_transfer_code AS eclmclmt_loss_trnsfr_code,
                      claim_claimant_info.tp_veh_type_desc AS eclmclmt_tp_vehic_type_desc
                    FROM
                      `@curated_project.@curated_dataset_name.claim_claimant_info` AS claim_claimant_info
                    WHERE DATE(claim_claimant_info.processed_date) <= CAST('@execution_date' as DATE)
                ) AS clmtinfo ON tbl818.int_claim_num_mxtr = clmtinfo.int_claim_num_818
                 AND tbl818.clmt_num_818 = clmtinfo.claimant_num_818
                 AND tbl818.pd_818 = clmtinfo.processed_date_818
                 AND tbl818.lpd_818 = clmtinfo.last_process_date_818
          ) AS x
    ) AS clmt ON main.cl_int_claim_num = clmt.int_claim_num_818
     AND main.ccvg_claimant_num = clmt.claimant_num_818
     AND main.cl_processed_date = clmt.pd_mxtr
     AND main.cl_last_process_date = clmt.lpd_mxtr
  UNION ALL 
    SELECT
    --      and claimant_status <> 1         -- 'pending' status allowed here so claimants don't get dropped
    --        and int_claim_num = '4300852'
    -- where x.rownum = 1
    --  join of main claims data to claimant data
    -- ***********************************************************************************
    --  Personal Property --
    -- ***********************************************************************************
    main.cl_int_claim_num,
    main.cl_last_process_date,
    main.cl_processed_date,
    main.pol_num,
    main.loss_dt,
    main.occur_num,
    main.term_eff_dt,
    main.cds_number,
    main.subscription_prefix,
    main.contr_id,
    main.cl_pol_type,
    main.cl_pol_type_division,
    main.cl_pol_type_desc,
    main.last_fin_dt,
    main.pay_and_close_ind,
    main.insured_fault_pct,
    main.branch,
    main.no_claimants_open,
    main.no_claimants_clsd,
    main.no_covg_line_open,
    main.no_covg_line_clsd,
    main.no_rein_line_open,
    main.no_cov_det_lines_open,
    main.no_fin_hist,
    main.in_suit_cnt,
    main.siu_ab_ind,
    main.siu_non_ab_ind,
    main.cl_co_cd,
    main.cl_prov_cd,
    main.juris_prov_cd,
    main.total_loss_ind,
    main.loss_event_id,
    main.glass_repl_ind,
    main.ibc_stat_ter_cd,
    main.auto_loss_chart_cd,
    main.auto_desc_of_loss_cd,
    main.prop_desc_of_loss_cd AS prop_desc_of_loss_cd,
    main.risk_pool_ind,
    main.facility_ind,
    main.type_of_use,
    main.type_of_use_comm,
    main.car_code,
    main.body_type,
    main.cl_status_cd,
    main.cl_open_dt,
    main.first_closed_date,
    main.curr_brk_num,
    main.repid_001,
    main.repid_002,
    main.repid_003,
    main.repid_004,
    main.repid_sup,
    main.repid_ho,
    main.mga_number,
    main.hndlng_br_num,
    main.cl_vin,
    main.car_year,
    main.make,
    main.model,
    main.veh_loc_pstl_cd,
    main.trailer_ind,
    main.rate_class,
    main.int_veh_num,
    main.auto_ibc_code,
    main.loc_city AS loc_city,
    main.loc_prov AS loc_prov,
    main.total_losses,
    main.total_expense,
    main.total_loss_reserve,
    main.total_expense_reserve,
    main.total_interest_reserve,
    main.subrogation_tot,
    main.salvage_tot,
    main.prev_total_losses,
    main.prev_total_expense,
    main.prev_total_loss_reserve,
    main.prev_total_expense_reserve,
    main.prev_total_interest_reserv,
    main.prev_subrogation_tot,
    main.prev_salvage_tot,
    main.total_losses_delta,
    main.total_expense_delta,
    main.total_loss_reserve_delta,
    main.total_expense_reserve_delta,
    main.total_interest_reserve_delta,
    main.subrogation_tot_delta,
    main.salvage_tot_delta,
    main.cvg_int_claim_num,
    main.cvg_last_process_date,
    main.cvg_processed_date,
    main.cl_line_type_cd,
    main.cl_line_type_desc,
    main.cvg_seg_type,
    main.ibc_kindof_loss_cd,
    main.cl_class_bus_cd,
    main.cl_ibc_cd,
    main.cvg_cd,
    main.rag_num,
    main.kind_of_loss,
    main.deductible_amount,
    main.deductible_type,
    main.deduct_basis_cd,
    main.cvg_status_desc,
    main.cvg_open_dt,
    main.cvg_orig_loss_est,
    main.cvg_orig_expn_est,
    main.cvg_orig_intr_est,
    main.cvg_loss_pd_amt,
    main.cvg_expn_pd_amt,
    main.cvg_loss_resr_amt,
    main.cvg_expn_resr_amt,
    main.cvg_intr_resr_amt,
    main.cvg_loss_subr_amt,
    main.cvg_expn_subr_amt,
    main.cvg_salv_tot_amt,
    main.cvg_payback_amt,
    main.prev_cvg_loss_pd_amt,
    main.prev_cvg_expn_pd_amt,
    main.prev_cvg_loss_resr_amt,
    main.prev_cvg_expn_resr_amt,
    main.prev_cvg_intr_resr_amt,
    main.prev_cvg_loss_subr_amt,
    main.prev_cvg_expn_subr_amt,
    main.prev_cvg_salv_tot_amt,
    main.cvg_loss_pd_amt_delta,
    main.cvg_expn_pd_amt_delta,
    main.cvg_loss_resr_amt_delta,
    main.cvg_expn_resr_amt_delta,
    main.cvg_intr_resr_amt_delta,
    main.cvg_loss_subr_amt_delta,
    main.cvg_expn_subr_amt_delta,
    main.cvg_salv_tot_amt_delta,
    main.cvg_net_pd_amt,
    main.cvg_resr_amt,
    main.cvg_incurred_amt,
    main.ccvg_int_claim_num,
    main.ccvg_cl_line_type,
    main.ccvg_claimant_num,
    main.ccvg_last_process_date,
    main.ccvg_processed_date,
    main.ccvg_status_desc,
    main.ccvg_open_dt,
    main.ccvg_reopen_dt,
    main.ccvg_closed_dt,
    main.ccvg_orig_loss_est,
    main.ccvg_orig_expn_est,
    main.ccvg_orig_intr_est,
    main.ccvg_loss_pd_amt,
    main.ccvg_expn_pd_amt,
    main.ccvg_loss_resr_amt,
    main.ccvg_expn_resr_amt,
    main.ccvg_intr_resr_amt,
    main.ccvg_loss_subr_amt,
    main.ccvg_expn_subr_amt,
    main.ccvg_salv_tot_amt,
    main.ccvg_payback_amt,
    main.prev_ccvg_loss_pd_amt,
    main.prev_ccvg_loss_resr_amt,
    main.prev_ccvg_expn_pd_amt,
    main.prev_ccvg_expn_resr_amt,
    main.prev_ccvg_intr_resr_amt,
    main.prev_ccvg_loss_subr_amt,
    main.prev_ccvg_expn_subr_amt,
    main.prev_ccvg_salv_tot_amt,
    main.ccvg_loss_pd_amt_delta,
    main.ccvg_expn_pd_amt_delta,
    main.ccvg_loss_resr_amt_delta,
    main.ccvg_expn_resr_amt_delta,
    main.ccvg_intr_resr_amt_delta,
    main.ccvg_loss_subr_amt_delta,
    main.ccvg_expn_subr_amt_delta,
    main.ccvg_salv_tot_amt_delta,
    main.ccvg_net_pd_amt,
    main.ccvg_resr_amt,
    main.ccvg_incurred_amt,
    main.ccvg_tablr_reserve_ind,
    main.ccvg_tablr_resr_chng_dt,
    -- 818   --clmtinfo.*
    clmt.int_claim_num_818 AS eclmclmt_int_claim_num,
    clmt.claimant_num_818 AS eclmclmt_claimant_num,
    clmt.name_category_818 AS eclmclmt_name_category,
    clmt.last_process_date_818 AS eclmclmt_last_process_date,
    clmt.processed_date_818 AS eclmclmt_processed_date,
    clmt.eclmclmt_creation_date,
    clmt.eclmclmt_status_desc,
    clmt.eclmclmt_clmt_type_desc,
    clmt.eclmclmt_last_name,
    clmt.eclmclmt_first_name,
    clmt.eclmclmt_middle_name,
    clmt.eclmclmt_company_name,
    clmt.eclmclmt_cmpny_or_indvd_ind,
    clmt.eclmclmt_lic_num,
    clmt.eclmclmt_lic_prov,
    coalesce(CAST(clmt.eclmclmt_clmt_dob as STRING), '') AS eclmclmt_dob,
    clmt.eclmclmt_bi_code_orig,
    clmt.eclmclmt_bi_code_curr,
    clmt.eclmclmt_loss_trnsfr_code,
    clmt.eclmclmt_tp_vehic_type_desc
  FROM
    (SELECT
          -- 813/817       --clsum.*/clcom.*
          clsum.int_claim_num_813 AS cl_int_claim_num,
          clsum.last_process_date_813 AS cl_last_process_date,
          clsum.processed_date_813 AS cl_processed_date,
          clsum.pol_num,
          clsum.loss_dt,
          clsum.occur_num,
          clsum.term_eff_dt,
          clsum.cds_number,
          clsum.subscription_prefix,
          clsum.contr_id,
          clsum.cl_pol_type,
          clsum.cl_pol_type_division,
          clsum.cl_pol_type_desc,
          clsum.last_fin_dt,
          clsum.pay_and_close_ind,
          clsum.insured_fault_pct,
          clsum.branch,
          clsum.no_claimants_open,
          clsum.no_claimants_clsd,
          clsum.no_covg_line_open,
          clsum.no_covg_line_clsd,
          clsum.no_rein_line_open,
          clsum.no_cov_det_lines_open,
          clsum.no_fin_hist,
          clsum.in_suit_cnt,
          clcom.siu_ab_ind,
          clcom.siu_non_ab_ind,
          clcom.cl_co_cd,
          clcom.cl_prov_cd,
          clcom.juris_prov_cd,
          clcom.total_loss_ind,
          clcom.loss_event_id,
          '' AS glass_repl_ind,
          0 AS ibc_stat_ter_cd,
          0 AS auto_loss_chart_cd,
          '' AS auto_desc_of_loss_cd,
          clcom.prop_loss_code AS prop_desc_of_loss_cd,
          0 AS risk_pool_ind,
          0 AS facility_ind,
          0 AS type_of_use,
          0 AS type_of_use_comm,
          0 AS car_code,
          0 AS body_type,
          clsum.cl_status_desc_813 AS cl_status_cd,
          coalesce(CAST(clcom.cl_open_dt as STRING), '') AS cl_open_dt,
          coalesce(CAST(clcom.first_closed_date as STRING), '') AS first_closed_date,
          clcom.curr_brk_num,
          clcom.repid_001,
          clcom.repid_002,
          clcom.repid_003,
          clcom.repid_004,
          clcom.repid_sup,
          clcom.repid_ho,
          clcom.mga_number,
          clcom.hndlng_br_num,
          '' AS cl_vin,
          0 AS car_year,
          '' AS make,
          '' AS model,
          '' AS veh_loc_pstl_cd,
          '' AS trailer_ind,
          0 AS rate_class,
          0 AS int_veh_num,
          0 AS auto_ibc_code,
          clcom.loc_city,
          clcom.loc_prov,
          clsum.total_losses,
          clsum.total_expense,
          clsum.total_loss_reserve,
          clsum.total_expense_reserve,
          clsum.total_interest_reserve,
          clsum.subrogation_tot,
          clsum.salvage_tot,
          clsum.prev_total_losses,
          clsum.prev_total_expense,
          clsum.prev_total_loss_reserve,
          clsum.prev_total_expense_reserve,
          clsum.prev_total_interest_reserv,
          clsum.prev_subrogation_tot,
          clsum.prev_salvage_tot,
          clsum.total_losses_delta,
          clsum.total_expense_delta,
          clsum.total_loss_reserve_delta,
          clsum.total_expense_reserve_delta,
          clsum.total_interest_reserve_delta,
          clsum.subrogation_tot_delta,
          clsum.salvage_tot_delta,
          -- 822   --cvgsum.*
          cvgsum.int_claim_num_822 AS cvg_int_claim_num,
          cvgsum.last_process_date_822 AS cvg_last_process_date,
          cvgsum.processed_date_822 AS cvg_processed_date,
          cvgsum.cl_line_type_cd,
          cvgsum.cl_line_type_desc,
          cvgsum.cvg_seg_type,
          cvgsum.ibc_kindof_loss_cd,
          cvgsum.cl_class_bus_cd,
          cvgsum.cl_ibc_cd,
          cvgsum.cvg_cd,
          cvgsum.rag_num,
          cvgsum.kind_of_loss,
          cvgsum.deductible_amount,
          cvgsum.deductible_type,
          cvgsum.deduct_basis_cd,
          cvgsum.cvg_status_desc,
          CASE
            WHEN cvgsum.date_open_sum > origopncvsm.orig_cvg_open_dt THEN origopncvsm.orig_cvg_open_dt
            ELSE cvgsum.date_open_sum
          END AS cvg_open_dt,
          --  estacc.*
          estacc.cvg_orig_loss_est,
          estacc.cvg_orig_expn_est,
          estacc.cvg_orig_intr_est,
          cvgsum.cvg_loss_pd_amt,
          cvgsum.cvg_expn_pd_amt,
          cvgsum.cvg_loss_resr_amt,
          cvgsum.cvg_expn_resr_amt,
          cvgsum.cvg_intr_resr_amt,
          cvgsum.cvg_loss_subr_amt,
          cvgsum.cvg_expn_subr_amt,
          cvgsum.cvg_salv_tot_amt,
          cvgsum.cvg_payback_amt,
          cvgsum.prev_cvg_loss_pd_amt,
          cvgsum.prev_cvg_expn_pd_amt,
          cvgsum.prev_cvg_loss_resr_amt,
          cvgsum.prev_cvg_expn_resr_amt,
          cvgsum.prev_cvg_intr_resr_amt,
          cvgsum.prev_cvg_loss_subr_amt,
          cvgsum.prev_cvg_expn_subr_amt,
          cvgsum.prev_cvg_salv_tot_amt,
          cvgsum.cvg_loss_pd_amt_delta,
          cvgsum.cvg_expn_pd_amt_delta,
          cvgsum.cvg_loss_resr_amt_delta,
          cvgsum.cvg_expn_resr_amt_delta,
          cvgsum.cvg_intr_resr_amt_delta,
          cvgsum.cvg_loss_subr_amt_delta,
          cvgsum.cvg_expn_subr_amt_delta,
          cvgsum.cvg_salv_tot_amt_delta,
          cvgsum.cvg_net_pd_amt,
          cvgsum.cvg_resr_amt,
          cvgsum.cvg_incurred_amt,
          -- 826   --cvgdtl.*
          cvgdtl.int_claim_num_826 AS ccvg_int_claim_num,
          cvgdtl.line_type_826 AS ccvg_cl_line_type,
          cvgdtl.claimant_num_826 AS ccvg_claimant_num,
          cvgdtl.last_process_date_826 AS ccvg_last_process_date,
          cvgdtl.processed_date_826 AS ccvg_processed_date,
          cvgdtl.ccvg_status_desc,
          CASE
            WHEN cvgdtl.date_det_open > origopncvdt.orig_ccvg_open_dt THEN origopncvdt.orig_ccvg_open_dt
            ELSE cvgdtl.date_det_open
          END AS ccvg_open_dt,
          coalesce(CAST(cvgdtl.ccvg_reopen_dt as STRING), '') AS ccvg_reopen_dt,
          coalesce(CAST(cvgdtl.ccvg_closed_dt as STRING), '') AS ccvg_closed_dt,
          cvgdtl.ccvg_orig_loss_est,
          cvgdtl.ccvg_orig_expn_est,
          cvgdtl.ccvg_orig_intr_est,
          cvgdtl.ccvg_loss_pd_amt,
          cvgdtl.ccvg_expn_pd_amt,
          cvgdtl.ccvg_loss_resr_amt,
          cvgdtl.ccvg_expn_resr_amt,
          cvgdtl.ccvg_intr_resr_amt,
          cvgdtl.ccvg_loss_subr_amt,
          cvgdtl.ccvg_expn_subr_amt,
          cvgdtl.ccvg_salv_tot_amt,
          cvgdtl.ccvg_payback_amt,
          cvgdtl.prev_ccvg_loss_pd_amt,
          cvgdtl.prev_ccvg_loss_resr_amt,
          cvgdtl.prev_ccvg_expn_pd_amt,
          cvgdtl.prev_ccvg_expn_resr_amt,
          cvgdtl.prev_ccvg_intr_resr_amt,
          cvgdtl.prev_ccvg_loss_subr_amt,
          cvgdtl.prev_ccvg_expn_subr_amt,
          cvgdtl.prev_ccvg_salv_tot_amt,
          cvgdtl.ccvg_loss_pd_amt_delta,
          cvgdtl.ccvg_expn_pd_amt_delta,
          cvgdtl.ccvg_loss_resr_amt_delta,
          cvgdtl.ccvg_expn_resr_amt_delta,
          cvgdtl.ccvg_intr_resr_amt_delta,
          cvgdtl.ccvg_loss_subr_amt_delta,
          cvgdtl.ccvg_expn_subr_amt_delta,
          cvgdtl.ccvg_salv_tot_amt_delta,
          cvgdtl.ccvg_net_pd_amt,
          cvgdtl.ccvg_resr_amt,
          cvgdtl.ccvg_incurred_amt,
          cvgdtl.tabular_reserve_ind AS ccvg_tablr_reserve_ind,
          coalesce(CAST(cvgdtl.tabular_resr_chng_dt as STRING), '') AS ccvg_tablr_resr_chng_dt
        FROM
          --  mainxtr - table list of keys for joining to the eclm tables --
          (SELECT
                tbl813.int_claim_num_mxtr,
                tbl813.lpd_mxtr,
                tbl813.pd_mxtr,
                tbl813.lpd_813,
                tbl813.pd_813,
                tbl817.lpd_817,
                tbl817.pd_817,
                tbl822.lpd_822,
                tbl822.pd_822,
                tbl826.lpd_826,
                tbl826.pd_826
              FROM
                --  813 - Claim Summary ----------------------------------------------------
                (SELECT
                      x.*
                    FROM
                      (SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl813.int_claim_num AS int_claim_num_813,
                            DATE(cl813.last_process_date) AS lpd_813,
                            DATE(cl813.processed_date) AS pd_813,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date ORDER BY cl813.int_claim_num DESC, cl813.processed_date DESC, cl813.last_process_date DESC) AS rownum
                          FROM
                            --  main extract -----------------------------------------------------------
                            (
                              SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type = 2
                                  ) AS ec813
                                  LEFT OUTER JOIN -- 2=prop 4=cprop 1,3,5,6,7,8=auto
                                  --        and int_claim_num = '4092107'
                                  -- ec817
                                  (
                                    SELECT
                                        claim_common_prop.int_claim_num,
                                        DATE(claim_common_prop.last_process_date) AS last_process_date,
                                        DATE(claim_common_prop.processed_date) AS processed_date,
                                        claim_common_prop.file_status,
                                        claim_common_prop.company,
                                        substr(trim(claim_common_prop.prop_loss_code), 1, 3) AS prop_loss_code_1st3
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_prop` AS claim_common_prop
                                      WHERE DATE(claim_common_prop.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_prop.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_prop.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.prop_loss_code_1st3 NOT IN(
                                  '901', '902', '903', '904', '905', '906'
                                )
                                ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_claim_summary` AS cl813 ON cl813.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl813.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl813.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl813.last_process_date) <= CAST('@execution_date' as DATE)
                           ) AS x
                    WHERE x.rownum = 1
                    ) AS tbl813
                    LEFT OUTER JOIN --  817 - Claim Common ------------------------------------------------
                (
                  SELECT
                      x.*
                    FROM
                      (
                        SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl817.int_claim_num AS int_claim_num_817,
                            DATE(cl817.last_process_date) AS lpd_817,
                            DATE(cl817.processed_date) AS pd_817,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date ORDER BY cl817.int_claim_num DESC, cl817.processed_date DESC, cl817.last_process_date DESC) AS rownum
                          FROM
                            --  main extract ------------------------------------------------------------
                            (
                              SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type = 2
                                  ) AS ec813
                                  LEFT OUTER JOIN -- 2=prop 4=cprop 1,3,5,6,7,8=auto
                                  --        and int_claim_num = '4092107'
                                  -- ec817
                                  (
                                    SELECT
                                        claim_common_prop.int_claim_num,
                                        DATE(claim_common_prop.last_process_date) AS last_process_date,
                                        DATE(claim_common_prop.processed_date) AS processed_date,
                                        claim_common_prop.file_status,
                                        claim_common_prop.company,
                                        substr(trim(claim_common_prop.prop_loss_code), 1, 3) AS prop_loss_code_1st3
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_prop` AS claim_common_prop
                                      WHERE DATE(claim_common_prop.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_prop.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_prop.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.prop_loss_code_1st3 NOT IN(
                                  '901', '902', '903', '904', '905', '906'
                                )
                            ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_common_prop` AS cl817 ON cl817.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl817.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl817.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl817.last_process_date) <= CAST('@execution_date' as DATE)
                      ) AS x
                    WHERE x.rownum = 1
                ) AS tbl817 ON tbl817.int_claim_num_mxtr = tbl813.int_claim_num_mxtr
                 AND tbl817.pd_mxtr = tbl813.pd_mxtr
                 LEFT OUTER JOIN --  822 - Coverage Summary --------------------------------------------
                (
                  SELECT
                      x.*
                    FROM
                      (
                        SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl822.int_claim_num AS int_claim_num_822,
                            DATE(cl822.last_process_date) AS lpd_822,
                            DATE(cl822.processed_date) AS pd_822,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date ORDER BY cl822.int_claim_num, cl822.processed_date DESC, cl822.last_process_date DESC) AS rownum
                          FROM
                            --  main extract ------------------------------------------------------------
                            (
                              SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type = 2
                                  ) AS ec813
                                  LEFT OUTER JOIN -- 2=prop 4=cprop 1,3,5,6,7,8=auto
                                  --        and int_claim_num = '4092107'
                                  -- ec817
                                  (
                                    SELECT
                                        claim_common_prop.int_claim_num,
                                        DATE(claim_common_prop.last_process_date) AS last_process_date,
                                        DATE(claim_common_prop.processed_date) AS processed_date,
                                        claim_common_prop.file_status,
                                        claim_common_prop.company,
                                        substr(trim(claim_common_prop.prop_loss_code), 1, 3) AS prop_loss_code_1st3
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_prop` AS claim_common_prop
                                      WHERE DATE(claim_common_prop.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_prop.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_prop.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.prop_loss_code_1st3 NOT IN(
                                  '901', '902', '903', '904', '905', '906'
                                )
                            ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_coverage_summary_prop` AS cl822 ON cl822.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl822.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl822.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl822.last_process_date) <= CAST('@execution_date' as DATE)
                      ) AS x
                    WHERE x.rownum = 1
                ) AS tbl822 ON tbl822.int_claim_num_mxtr = tbl813.int_claim_num_mxtr
                 AND tbl822.pd_mxtr = tbl813.pd_mxtr
                 LEFT OUTER JOIN --  826 - Coverage Detail ------------------------------------------------
                (
                  SELECT
                      x.*
                    FROM
                      (
                        SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl826.int_claim_num AS int_claim_num_826,
                            DATE(cl826.last_process_date) AS lpd_826,
                            DATE(cl826.processed_date) AS pd_826,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date ORDER BY cl826.int_claim_num, cl826.processed_date DESC, cl826.last_process_date DESC) AS rownum
                          FROM
                            --  main extract -----------------------------------------------------------
                            (
                              SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type = 2
                                  ) AS ec813
                                  LEFT OUTER JOIN -- 2=prop 4=cprop 1,3,5,6,7,8=auto
                                  -- ec817
                                  (
                                    SELECT
                                        claim_common_prop.int_claim_num,
                                        DATE(claim_common_prop.last_process_date) AS last_process_date,
                                        DATE(claim_common_prop.processed_date) AS processed_date,
                                        claim_common_prop.file_status,
                                        claim_common_prop.company,
                                        substr(trim(claim_common_prop.prop_loss_code), 1, 3) AS prop_loss_code_1st3
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_prop` AS claim_common_prop
                                      WHERE DATE(claim_common_prop.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_prop.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_prop.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.prop_loss_code_1st3 NOT IN(
                                  '901', '902', '903', '904', '905', '906'
                                )
                            ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_coverage_detail` AS cl826 ON cl826.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl826.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl826.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl826.last_process_date) <= CAST('@execution_date' as DATE)
                      ) AS x
                    WHERE x.rownum = 1
                ) AS tbl826 ON tbl826.int_claim_num_mxtr = tbl813.int_claim_num_mxtr
                 AND tbl826.pd_mxtr = tbl813.pd_mxtr
              WHERE tbl813.int_claim_num_mxtr = tbl813.int_claim_num_813
               AND tbl813.pd_mxtr = tbl813.pd_mxtr
               AND tbl813.int_claim_num_mxtr = tbl817.int_claim_num_817
               AND tbl813.pd_mxtr = tbl817.pd_mxtr
               AND tbl813.int_claim_num_mxtr = tbl822.int_claim_num_822
               AND tbl813.pd_mxtr = tbl822.pd_mxtr
               AND tbl813.int_claim_num_mxtr = tbl826.int_claim_num_826
               AND tbl813.pd_mxtr = tbl826.pd_mxtr
               ) AS sel
          INNER JOIN --  end of mainxtr - table list of keys for joining to the eclm tables
          --  813 / claim summary
          (
            SELECT
                claim_claim_summary.int_claim_num AS int_claim_num_813,
                DATE(claim_claim_summary.last_process_date) AS last_process_date_813,
                DATE(claim_claim_summary.processed_date) AS processed_date_813,
                claim_claim_summary.policy_type AS cl_pol_type,
                CASE
                  WHEN claim_claim_summary.policy_type = 2 THEN 'PPROP'
                  WHEN claim_claim_summary.policy_type = 4 THEN 'CPROP'
                  ELSE CAST(claim_claim_summary.policy_type AS STRING)
                END AS cl_pol_type_division,
                CASE
                  WHEN claim_claim_summary.policy_type = 2 THEN 'Pers Prop'
                  WHEN claim_claim_summary.policy_type = 4 THEN 'Comm Prop'
                  ELSE CAST(claim_claim_summary.policy_type AS STRING)
                END AS cl_pol_type_desc,
                claim_claim_summary.claim_status AS cl_status_cd_813,
                CASE
                  WHEN claim_claim_summary.claim_status = 2 THEN 'OPN'
                  WHEN claim_claim_summary.claim_status = 3 THEN 'CLS'
                  WHEN claim_claim_summary.claim_status = 6 THEN 'REO'
                  WHEN claim_claim_summary.claim_status = 4 THEN 'STR'
                  ELSE CAST(claim_claim_summary.claim_status AS STRING)
                END AS cl_status_desc_813,
                DATE(claim_claim_summary.last_financial_date) AS last_fin_dt,
                claim_claim_summary.pc_indicator AS pay_and_close_ind,
                claim_claim_summary.cds_claim_num AS cds_number,
                claim_claim_summary.policy_num AS pol_num,
                DATE(claim_claim_summary.loss_date) AS loss_dt,
                claim_claim_summary.occurrence AS occur_num,
                DATE(claim_claim_summary.policy_efdt) AS term_eff_dt,
                claim_claim_summary.prefix AS subscription_prefix,
                claim_claim_summary.contr_id,
                claim_claim_summary.percent_fault AS insured_fault_pct,
                claim_claim_summary.branch,
                claim_claim_summary.no_claimants_open,
                claim_claim_summary.no_claimants_clsd,
                claim_claim_summary.no_covg_line_open,
                claim_claim_summary.no_covg_line_clsd,
                claim_claim_summary.no_rein_line_open,
                claim_claim_summary.no_cov_det_lines_open,
                claim_claim_summary.no_fin_hist,
                coalesce(claim_claim_summary.in_suit_cnt, 0) AS in_suit_cnt,
                claim_claim_summary.total_losses,
                claim_claim_summary.total_expense,
                claim_claim_summary.total_loss_reserve,
                claim_claim_summary.total_expense_reserve,
                claim_claim_summary.total_interest_reserve,
                claim_claim_summary.subrogation_tot,
                claim_claim_summary.salvage_tot,
                claim_claim_summary.prev_total_losses,
                claim_claim_summary.prev_total_expense,
                claim_claim_summary.prev_total_loss_reserve,
                claim_claim_summary.prev_total_expense_reserve,
                claim_claim_summary.prev_total_interest_reserv,
                claim_claim_summary.prev_subrogation_tot,
                claim_claim_summary.prev_salvage_tot,
                (claim_claim_summary.total_losses-claim_claim_summary.prev_total_losses) AS total_losses_delta,
                (claim_claim_summary.total_expense-claim_claim_summary.prev_total_expense) AS total_expense_delta,
                (claim_claim_summary.total_loss_reserve-claim_claim_summary.prev_total_loss_reserve) AS total_loss_reserve_delta,
                (claim_claim_summary.total_expense_reserve-claim_claim_summary.prev_total_expense_reserve) AS total_expense_reserve_delta,
                (claim_claim_summary.total_interest_reserve-claim_claim_summary.prev_total_interest_reserv) AS total_interest_reserve_delta,
                (claim_claim_summary.subrogation_tot-claim_claim_summary.prev_subrogation_tot) AS subrogation_tot_delta,
                (claim_claim_summary.salvage_tot-claim_claim_summary.prev_salvage_tot) AS salvage_tot_delta
              FROM
                `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
              WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_claim_summary.claim_status <> 1
               AND claim_claim_summary.policy_type = 2
          ) AS clsum ON clsum.int_claim_num_813 = sel.int_claim_num_mxtr
           AND clsum.processed_date_813 = sel.pd_813
           INNER JOIN -- 2=prop 4=cprop 1,3,5,6,7,8=auto
          -- -----------------------------------------------------------------------------------
          -- ------------------------------------------------------------------------
          -- -----------------------------------------------------------------------------------
          -- 817 / claim common
          (
            SELECT
                claim_common_prop.int_claim_num AS int_claim_num_817,
                DATE(claim_common_prop.last_process_date) AS last_process_date_817,
                DATE(claim_common_prop.processed_date) AS processed_date_817,
                claim_common_prop.agent_num AS curr_brk_num,
                claim_common_prop.siu_ind_ab AS siu_ab_ind,
                claim_common_prop.siu_ind AS siu_non_ab_ind,
                claim_common_prop.clm_jurisdiction AS juris_prov_cd,
                claim_common_prop.company AS cl_co_cd,
                claim_common_prop.prov_cd AS cl_prov_cd,
                claim_common_prop.claim_status AS cl_status_cd_817,
                claim_common_prop.file_status AS file_status_cd_817,
                CASE
                  WHEN claim_common_prop.total_loss_ind = 'Z' THEN ''
                  WHEN claim_common_prop.total_loss_ind = 'P' THEN 'N'
                  WHEN claim_common_prop.total_loss_ind = 'T' THEN 'Y'
                  ELSE ''
                END AS total_loss_ind,
                DATE(claim_common_prop.first_closed_dt) AS first_closed_date,
                DATE(claim_common_prop.open_dt) AS cl_open_dt,
                claim_common_prop.rep_code_1 AS repid_001,
                claim_common_prop.rep_code_2 AS repid_002,
                claim_common_prop.rep_code_3 AS repid_003,
                claim_common_prop.rep_code_4 AS repid_004,
                claim_common_prop.sup_rep_code AS repid_sup,
                claim_common_prop.rep_code_ho AS repid_ho,
                claim_common_prop.mga_number,
                claim_common_prop.cat_loss_id AS loss_event_id,
                CASE
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'HO'
                   AND claim_common_prop.company = 8 THEN 28
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'UK' THEN 0
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'HB' THEN 1
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'OT' THEN 2
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'TO' THEN 3
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'HA' THEN 4
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'LO' THEN 5
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'ST' THEN 6
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'MI' THEN 7
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WS' THEN 8
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'VN' THEN 11
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'ED' THEN 12
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'CA' THEN 13
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WG' THEN 14
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'MO' THEN 15
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'MN' THEN 16
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'HX' THEN 17
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'HO' THEN 19
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'MO' THEN 20
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'FR' THEN 21
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'MH' THEN 22
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'ST' THEN 23
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'PR' THEN 24
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WA' THEN 25
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WH' THEN 26
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'QU' THEN 27
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'SO' THEN 28
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'PE' THEN 31
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'PW' THEN 32
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'PO' THEN 33
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WE' THEN 34
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WW' THEN 35
                  WHEN substr(claim_common_prop.rep_code_1, 1, 2) = 'WO' THEN 36
                  ELSE 0
                END AS hndlng_br_num,
                claim_common_prop.loc_city,
                claim_common_prop.loc_prov,
                claim_common_prop.prop_loss_code
              FROM
                `@curated_project.@curated_dataset_name.claim_common_prop` AS claim_common_prop
              WHERE DATE(claim_common_prop.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_common_prop.file_status <> 1
          ) AS clcom ON clcom.int_claim_num_817 = sel.int_claim_num_mxtr
           AND clcom.processed_date_817 = sel.pd_817
           INNER JOIN -- 822 / cvg summary
          (
            SELECT
                claim_coverage_summary_prop.int_claim_num AS int_claim_num_822,
                claim_coverage_summary_prop.line_type AS line_type_822,
                DATE(claim_coverage_summary_prop.last_process_date) AS last_process_date_822,
                DATE(claim_coverage_summary_prop.processed_date) AS processed_date_822,
                claim_coverage_summary_prop.line_type AS cl_line_type_cd,
                claim_coverage_summary_prop.line_type_desc AS cl_line_type_desc,
                claim_coverage_summary_prop.status_cov_sum AS cvg_status_cd,
                claim_coverage_summary_prop.status_desc AS cvg_status_desc_geo,
                CASE
                  WHEN claim_coverage_summary_prop.status_cov_sum = 2 THEN 'OPN'
                  WHEN claim_coverage_summary_prop.status_cov_sum = 3 THEN 'CLS'
                  WHEN claim_coverage_summary_prop.status_cov_sum = 6 THEN 'REO'
                  WHEN claim_coverage_summary_prop.status_cov_sum = 4 THEN 'STR'
                  ELSE CAST(claim_coverage_summary_prop.status_cov_sum AS STRING)
                END AS cvg_status_desc,
                claim_coverage_summary_prop.ibc_kind_of_loss_cd AS ibc_kindof_loss_cd,
                claim_coverage_summary_prop.class_of_bus AS cl_class_bus_cd,
                claim_coverage_summary_prop.ibc_code AS cl_ibc_cd,
                claim_coverage_summary_prop.coverage_code AS cvg_cd,
                DATE(claim_coverage_summary_prop.date_open_sum) AS date_open_sum,
                CASE
                  WHEN claim_coverage_summary_prop.item_type IN(
                    1, 2, 10
                  ) THEN 'AUT'
                  WHEN claim_coverage_summary_prop.item_type = 3 THEN 'LOC'
                  WHEN claim_coverage_summary_prop.item_type = 4 THEN 'LIA'
                  WHEN claim_coverage_summary_prop.item_type = 5 THEN 'MIS'
                  WHEN claim_coverage_summary_prop.item_type = 6 THEN 'SAF'
                  WHEN claim_coverage_summary_prop.item_type = 7 THEN 'BOM'
                  WHEN claim_coverage_summary_prop.item_type = 8 THEN 'CLI'
                  WHEN claim_coverage_summary_prop.item_type = 9 THEN 'CMP'
                  ELSE CAST(claim_coverage_summary_prop.item_type AS STRING)
                END AS cvg_seg_type,
                claim_coverage_summary_prop.rag_num,
                claim_coverage_summary_prop.kind_of_loss,
                claim_coverage_summary_prop.deductible_amount,
                claim_coverage_summary_prop.deductible_type,
                claim_coverage_summary_prop.deduct_basis_cd,
                claim_coverage_summary_prop.loss_pay_to_dt AS cvg_loss_pd_amt,
                claim_coverage_summary_prop.exp_pay_to_dt AS cvg_expn_pd_amt,
                claim_coverage_summary_prop.loss_reser_to_dt AS cvg_loss_resr_amt,
                claim_coverage_summary_prop.exp_reser_to_dt AS cvg_expn_resr_amt,
                claim_coverage_summary_prop.int_reser_to_dt AS cvg_intr_resr_amt,
                claim_coverage_summary_prop.subrogation_loss AS cvg_loss_subr_amt,
                claim_coverage_summary_prop.subrogation_exp AS cvg_expn_subr_amt,
                claim_coverage_summary_prop.salvage_tot AS cvg_salv_tot_amt,
                claim_coverage_summary_prop.pay_back AS cvg_payback_amt,
                claim_coverage_summary_prop.prev_loss_pay_to_dt AS prev_cvg_loss_pd_amt,
                claim_coverage_summary_prop.prev_exp_pay_to_dt AS prev_cvg_expn_pd_amt,
                claim_coverage_summary_prop.prev_loss_reser_to_dt AS prev_cvg_loss_resr_amt,
                claim_coverage_summary_prop.prev_exp_reser_to_dt AS prev_cvg_expn_resr_amt,
                claim_coverage_summary_prop.prev_int_reser_to_dt AS prev_cvg_intr_resr_amt,
                claim_coverage_summary_prop.prev_subrogation_loss AS prev_cvg_loss_subr_amt,
                claim_coverage_summary_prop.prev_subrogation_exp AS prev_cvg_expn_subr_amt,
                claim_coverage_summary_prop.prev_salvage_tot AS prev_cvg_salv_tot_amt,
                (claim_coverage_summary_prop.loss_pay_to_dt-claim_coverage_summary_prop.prev_loss_pay_to_dt) AS cvg_loss_pd_amt_delta,
                (claim_coverage_summary_prop.exp_pay_to_dt-claim_coverage_summary_prop.prev_exp_pay_to_dt) AS cvg_expn_pd_amt_delta,
                (claim_coverage_summary_prop.loss_reser_to_dt-claim_coverage_summary_prop.prev_loss_reser_to_dt) AS cvg_loss_resr_amt_delta,
                (claim_coverage_summary_prop.exp_reser_to_dt-claim_coverage_summary_prop.prev_exp_reser_to_dt) AS cvg_expn_resr_amt_delta,
                (claim_coverage_summary_prop.int_reser_to_dt-claim_coverage_summary_prop.prev_int_reser_to_dt) AS cvg_intr_resr_amt_delta,
                (claim_coverage_summary_prop.subrogation_loss-claim_coverage_summary_prop.prev_subrogation_loss) AS cvg_loss_subr_amt_delta,
                (claim_coverage_summary_prop.subrogation_exp-claim_coverage_summary_prop.prev_subrogation_exp) AS cvg_expn_subr_amt_delta,
                (claim_coverage_summary_prop.salvage_tot-claim_coverage_summary_prop.prev_salvage_tot) AS cvg_salv_tot_amt_delta,
                (claim_coverage_summary_prop.loss_reser_to_dt+claim_coverage_summary_prop.exp_reser_to_dt+claim_coverage_summary_prop.int_reser_to_dt+claim_coverage_summary_prop.loss_pay_to_dt+claim_coverage_summary_prop.exp_pay_to_dt-claim_coverage_summary_prop.subrogation_loss-claim_coverage_summary_prop.subrogation_exp-claim_coverage_summary_prop.salvage_tot) AS cvg_incurred_amt,
               (claim_coverage_summary_prop.loss_pay_to_dt+claim_coverage_summary_prop.exp_pay_to_dt-claim_coverage_summary_prop.subrogation_loss-claim_coverage_summary_prop.subrogation_exp-claim_coverage_summary_prop.salvage_tot) AS cvg_net_pd_amt,
                (claim_coverage_summary_prop.loss_reser_to_dt+claim_coverage_summary_prop.exp_reser_to_dt+claim_coverage_summary_prop.int_reser_to_dt) AS cvg_resr_amt
              FROM
                `@curated_project.@curated_dataset_name.claim_coverage_summary_prop` AS claim_coverage_summary_prop
              WHERE DATE(claim_coverage_summary_prop.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_coverage_summary_prop.status_cov_sum <> 1
          ) AS cvgsum ON cvgsum.int_claim_num_822 = sel.int_claim_num_mxtr
           AND cvgsum.processed_date_822 = sel.pd_822
           INNER JOIN -- 826 / cvg detail
          (
            SELECT
                claim_coverage_detail.int_claim_num AS int_claim_num_826,
                claim_coverage_detail.line_type AS line_type_826,
                claim_coverage_detail.claimant_num AS claimant_num_826,
                DATE(claim_coverage_detail.last_process_date) AS last_process_date_826,
                DATE(claim_coverage_detail.processed_date) AS processed_date_826,
                claim_coverage_detail.status_det_cov AS ccvg_status_cd,
                claim_coverage_detail.status_desc AS ccvg_status_desc_geo,
                CASE
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NOT NULL THEN 'REO'
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NULL THEN 'OPN'
                  WHEN claim_coverage_detail.status_det_cov = 3 THEN 'CLS'
                  WHEN claim_coverage_detail.status_det_cov = 4 THEN 'STR'
                  ELSE CAST(claim_coverage_detail.status_det_cov AS STRING)
                END AS ccvg_status_desc,
                DATE(claim_coverage_detail.date_det_open) AS date_det_open,
                DATE(claim_coverage_detail.date_det_clsd) AS date_det_clsd,
                CASE
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NULL THEN DATE(claim_coverage_detail.date_det_open)
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NOT NULL THEN DATE(claim_coverage_detail.date_det_open)
                  WHEN claim_coverage_detail.status_det_cov IN(
                    3, 4
                  ) THEN DATE(claim_coverage_detail.date_det_open)
                  ELSE CAST(NULL as DATE)
                END AS ccvg_open_dt,
                CASE
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NULL THEN CAST(NULL as DATE)
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NOT NULL THEN DATE(claim_coverage_detail.date_det_open)
                  WHEN claim_coverage_detail.status_det_cov IN(
                    3, 4
                  ) THEN CAST(NULL as DATE)
                  ELSE CAST(NULL as DATE)
                END AS ccvg_reopen_dt,
                CASE
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NULL THEN CAST(NULL as DATE)
                  WHEN claim_coverage_detail.status_det_cov = 2
                   AND claim_coverage_detail.date_det_clsd IS NOT NULL THEN CAST(NULL as DATE)
                  WHEN claim_coverage_detail.status_det_cov IN(
                    3, 4
                  ) THEN DATE(claim_coverage_detail.date_det_clsd)
                  ELSE CAST(NULL as DATE)
                END AS ccvg_closed_dt,
                claim_coverage_detail.loss_pay_to_date AS ccvg_loss_pd_amt,
                claim_coverage_detail.cur_loss_est AS ccvg_loss_resr_amt,
                claim_coverage_detail.expense_pay_to_date AS ccvg_expn_pd_amt,
                claim_coverage_detail.cur_exp_est AS ccvg_expn_resr_amt,
                claim_coverage_detail.cur_int_est AS ccvg_intr_resr_amt,
                claim_coverage_detail.subrogation_loss AS ccvg_loss_subr_amt,
                claim_coverage_detail.subrogation_exp AS ccvg_expn_subr_amt,
                claim_coverage_detail.salvage_tot AS ccvg_salv_tot_amt,
                claim_coverage_detail.prev_loss_pay_to_date AS prev_ccvg_loss_pd_amt,
                claim_coverage_detail.prev_cur_loss_est AS prev_ccvg_loss_resr_amt,
                claim_coverage_detail.prev_expense_pay_to_date AS prev_ccvg_expn_pd_amt,
                claim_coverage_detail.prev_cur_exp_est AS prev_ccvg_expn_resr_amt,
                claim_coverage_detail.prev_cur_int_est AS prev_ccvg_intr_resr_amt,
                claim_coverage_detail.prev_subrogation_loss AS prev_ccvg_loss_subr_amt,
                claim_coverage_detail.prev_subrogation_exp AS prev_ccvg_expn_subr_amt,
                claim_coverage_detail.prev_salvage_tot AS prev_ccvg_salv_tot_amt
                ,(claim_coverage_detail.loss_pay_to_date-claim_coverage_detail.prev_loss_pay_to_date) AS ccvg_loss_pd_amt_delta
			,(claim_coverage_detail.cur_loss_est-claim_coverage_detail.prev_cur_loss_est) AS ccvg_loss_resr_amt_delta
			,(claim_coverage_detail.expense_pay_to_date-claim_coverage_detail.prev_expense_pay_to_date) AS ccvg_expn_pd_amt_delta
			,(claim_coverage_detail.cur_exp_est-claim_coverage_detail.prev_cur_exp_est) AS ccvg_expn_resr_amt_delta
			,(claim_coverage_detail.cur_int_est-claim_coverage_detail.prev_cur_int_est) AS ccvg_intr_resr_amt_delta
			,(claim_coverage_detail.subrogation_loss-claim_coverage_detail.prev_subrogation_loss) AS ccvg_loss_subr_amt_delta
			,(claim_coverage_detail.subrogation_exp-claim_coverage_detail.prev_subrogation_exp) AS ccvg_expn_subr_amt_delta
			,(claim_coverage_detail.salvage_tot-claim_coverage_detail.prev_salvage_tot) AS ccvg_salv_tot_amt_delta
			,claim_coverage_detail.orig_exp_est AS ccvg_orig_expn_est
			,claim_coverage_detail.date_last_exp_est
			,claim_coverage_detail.orig_int_est AS ccvg_orig_intr_est
			,claim_coverage_detail.date_last_int_est
			,claim_coverage_detail.orig_loss_est AS ccvg_orig_loss_est
			,claim_coverage_detail.date_last_loss_est
      ,(claim_coverage_detail.cur_loss_est+claim_coverage_detail.cur_exp_est+claim_coverage_detail.cur_int_est+claim_coverage_detail.loss_pay_to_date+claim_coverage_detail.expense_pay_to_date-claim_coverage_detail.subrogation_loss-claim_coverage_detail.subrogation_exp-claim_coverage_detail.salvage_tot) AS ccvg_incurred_amt
      ,(claim_coverage_detail.loss_pay_to_date+claim_coverage_detail.expense_pay_to_date-claim_coverage_detail.subrogation_loss-claim_coverage_detail.subrogation_exp-claim_coverage_detail.salvage_tot) AS ccvg_net_pd_amt
			,(claim_coverage_detail.cur_loss_est+claim_coverage_detail.cur_exp_est+claim_coverage_detail.cur_int_est) AS ccvg_resr_amt
			,(claim_coverage_detail.pay_back_loss+claim_coverage_detail.pay_back_exp) AS ccvg_payback_amt,
                claim_coverage_detail.tab_res AS tabular_reserve_ind,
                DATE(claim_coverage_detail.date_tab_res) AS tabular_resr_chng_dt
              FROM
                `@curated_project.@curated_dataset_name.claim_coverage_detail` AS claim_coverage_detail
              WHERE DATE(claim_coverage_detail.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_coverage_detail.status_det_cov <> 1
          ) AS cvgdtl ON cvgdtl.int_claim_num_826 = sel.int_claim_num_mxtr
           AND cvgdtl.processed_date_826 = sel.pd_826
           AND cvgdtl.line_type_826 = cvgsum.line_type_822
           LEFT OUTER JOIN -- 826 / cvg detail - earliest open date for int_claim_num,line_type,claimant_num combo for
          --  original open date on reopen coverage detail claims
          (
            SELECT
                claim_financial_history.int_claim_num,
                claim_financial_history.claimant_num,
                claim_financial_history.line_type,
                DATE(claim_financial_history.last_process_date) AS orig_ccvg_open_dt,
                row_number() OVER (PARTITION BY claim_financial_history.int_claim_num, claim_financial_history.claimant_num, claim_financial_history.line_type ORDER BY claim_financial_history.last_process_date, claim_financial_history.processed_date, claim_financial_history.claimant_num, claim_financial_history.line_type) AS rownum
              FROM
                `@curated_project.@curated_dataset_name.claim_financial_history` AS claim_financial_history
              WHERE DATE(claim_financial_history.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_financial_history.file_status <> 1
               AND claim_financial_history.action_desc = 'OPEN'
          ) AS origopncvdt ON origopncvdt.int_claim_num = sel.int_claim_num_mxtr
           AND origopncvdt.claimant_num = cvgdtl.claimant_num_826
           AND origopncvdt.line_type = cvgdtl.line_type_826
           AND origopncvdt.rownum = 1
           LEFT OUTER JOIN -- 822 / cvg sum - earliest open date for int_claim_num / line_type combo for
          --  original open date on reopen coverage summary claims
          (
            SELECT
                claim_financial_history.int_claim_num,
                claim_financial_history.line_type,
                DATE(claim_financial_history.last_process_date) AS orig_cvg_open_dt,
                row_number() OVER (PARTITION BY claim_financial_history.int_claim_num, claim_financial_history.line_type ORDER BY claim_financial_history.last_process_date, claim_financial_history.processed_date, claim_financial_history.line_type) AS rownum
              FROM
                `@curated_project.@curated_dataset_name.claim_financial_history` AS claim_financial_history
              WHERE DATE(claim_financial_history.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_financial_history.file_status <> 1
               AND claim_financial_history.action_desc = 'OPEN'
          ) AS origopncvsm ON origopncvsm.int_claim_num = sel.int_claim_num_mxtr
           AND origopncvsm.line_type = cvgsum.line_type_822
           AND origopncvsm.rownum = 1
           LEFT OUTER JOIN -- 826 / cvg detail - accummulate original estimates for cvgsum level
          (
            SELECT
                claim_coverage_detail.int_claim_num,
                DATE(claim_coverage_detail.processed_date) AS processed_date,
                claim_coverage_detail.line_type,
                sum(claim_coverage_detail.orig_loss_est) AS cvg_orig_loss_est,
                sum(claim_coverage_detail.orig_exp_est) AS cvg_orig_expn_est,
                sum(claim_coverage_detail.orig_int_est) AS cvg_orig_intr_est
              FROM
                `@curated_project.@curated_dataset_name.claim_coverage_detail` AS claim_coverage_detail
              WHERE DATE(claim_coverage_detail.processed_date) <= CAST('@execution_date' as DATE)
               AND claim_coverage_detail.status_det_cov <> 1
              GROUP BY 1, claim_coverage_detail.processed_date, 3
          ) AS estacc ON estacc.int_claim_num = sel.int_claim_num_mxtr
           AND estacc.processed_date = sel.pd_826
           AND estacc.line_type = cvgsum.line_type_822
           ) AS main
    INNER JOIN --  main claims data cl/cvg/ccvg
    -- -----------------------------------------------------------------------------------
    --  to Claimant Info ------------------------------------------------------
    -- -----------------------------------------------------------------------------------
    (
      SELECT
          x.*
        FROM
          (
            SELECT
                tbl818.pd_mxtr,
                tbl818.lpd_mxtr,
                tbl818.pd_818,
                tbl818.lpd_818,
                clmtinfo.*
              FROM
                --  ,row_number() over (partition by tbl818.int_claim_num_mxtr, tbl818.pd_mxtr, tbl818.clmt_num_818
                --                          order by tbl818.int_claim_num_mxtr, tbl818.pd_mxtr desc, tbl818.lpd_mxtr desc) as rownum
                --  818 - Claimant Info Keys ------------------------------------------------
                (
                  SELECT
                      x_0.*
                    FROM
                      (
                        SELECT
                            mainextr.int_claim_num AS int_claim_num_mxtr,
                            mainextr.last_process_date AS lpd_mxtr,
                            mainextr.processed_date AS pd_mxtr,
                            cl818.int_claim_num AS int_claim_num_818,
                            DATE(cl818.last_process_date) AS lpd_818,
                            DATE(cl818.processed_date) AS pd_818,
                            cl818.sequence_num AS clmt_num_818,
                            row_number() OVER (PARTITION BY mainextr.int_claim_num, mainextr.processed_date, cl818.sequence_num ORDER BY cl818.int_claim_num, cl818.processed_date DESC, cl818.last_process_date DESC) AS rownum
                          FROM
                            --  main extract ------------------------------------------------------------
                            (
                              SELECT
                                  ec813.int_claim_num,
                                  ec813.last_process_date,
                                  ec813.processed_date
                                FROM
                                  -- ec813
                                  (
                                    SELECT
                                        claim_claim_summary.int_claim_num,
                                        DATE(claim_claim_summary.last_process_date) AS last_process_date,
                                        DATE(claim_claim_summary.processed_date) AS processed_date,
                                        claim_claim_summary.policy_type,
                                        claim_claim_summary.claim_status,
                                        claim_claim_summary.company
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_claim_summary` AS claim_claim_summary
                                      WHERE DATE(claim_claim_summary.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.processed_date) >= CAST('@execution_date' as DATE)
                                       AND DATE(claim_claim_summary.last_process_date) <= CAST('@execution_date' as DATE)
                                       AND claim_claim_summary.claim_status <> 1
                                       AND claim_claim_summary.policy_type = 2
                                  ) AS ec813
                                  LEFT OUTER JOIN -- 2=prop 4=cprop 1,3,5,6,7,8=auto
                                  --        and int_claim_num = '4197907'
                                  -- ec817
                                  (
                                    SELECT
                                        claim_common_prop.int_claim_num,
                                        DATE(claim_common_prop.last_process_date) AS last_process_date,
                                        DATE(claim_common_prop.processed_date) AS processed_date,
                                        claim_common_prop.file_status,
                                        claim_common_prop.company,
                                        substr(trim(claim_common_prop.prop_loss_code), 1, 3) AS prop_loss_code_1st3
                                      FROM
                                        `@curated_project.@curated_dataset_name.claim_common_prop` AS claim_common_prop
                                      WHERE DATE(claim_common_prop.processed_date) <= CAST('@execution_date' as DATE)
                                       AND DATE(claim_common_prop.processed_date) >= CAST('@execution_date' as DATE)
                                       AND claim_common_prop.file_status <> 1
                                  ) AS ec817 ON ec817.int_claim_num = ec813.int_claim_num
                                   AND ec817.processed_date <= ec813.processed_date
                                WHERE ec817.file_status IN(
                                  2, 4, 5, 6
                                )
                                 OR ec817.file_status = 3
                                 AND ec817.prop_loss_code_1st3 NOT IN(
                                  '901', '902', '903', '904', '905', '906'
                                )
                            ) AS mainextr
                            INNER JOIN `@curated_project.@curated_dataset_name.claim_claimant_info` AS cl818 ON cl818.int_claim_num = mainextr.int_claim_num
                          WHERE DATE(cl818.processed_date) <= mainextr.processed_date
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.processed_date as DATETIME)) >= CAST('@execution_date' as DATE)
                           AND DATE(CAST(mainextr.last_process_date as DATETIME)) <= CAST('@execution_date' as DATE)
                           AND DATE(cl818.processed_date) <= CAST('@execution_date' as DATE)
                           AND DATE(cl818.last_process_date) <= CAST('@execution_date' as DATE)
                      ) AS x_0
                    WHERE x_0.rownum = 1
                ) AS tbl818
                INNER JOIN -- -----------------------------------------------------------------------------------
                -- ------------------------------------------------------------------------
                -- -----------------------------------------------------------------------------------
                -- 818 / claimant info data
                (
                  SELECT
                      claim_claimant_info.int_claim_num AS int_claim_num_818,
                      claim_claimant_info.sequence_num AS claimant_num_818,
                      claim_claimant_info.name_category AS name_category_818,
                      DATE(claim_claimant_info.last_process_date) AS last_process_date_818,
                      DATE(claim_claimant_info.processed_date) AS processed_date_818,
                      DATE(claim_claimant_info.creation_dt) AS eclmclmt_creation_date,
                      claim_claimant_info.claimant_status AS eclmclmt_status_cd,
                      claim_claimant_info.status_desc AS eclmclmt_status_desc_geo,
                      CASE
                        WHEN claim_claimant_info.claimant_status = 2 THEN 'OPN'
                        WHEN claim_claimant_info.claimant_status = 3 THEN 'CLS'
                        WHEN claim_claimant_info.claimant_status = 6 THEN 'REO'
                        WHEN claim_claimant_info.claimant_status = 4 THEN 'STR'
                        WHEN claim_claimant_info.claimant_status = 1 THEN 'PEN'
                        ELSE CAST(claim_claimant_info.claimant_status AS STRING)
                      END AS eclmclmt_status_desc,
                      claim_claimant_info.claimant_categ AS eclmclmt_clmt_type_desc,
                      claim_claimant_info.surname AS eclmclmt_last_name,
                      claim_claimant_info.first_name AS eclmclmt_first_name,
                      claim_claimant_info.middle_name AS eclmclmt_middle_name,
                      claim_claimant_info.company_name AS eclmclmt_company_name,
                      claim_claimant_info.comp_or_individ_ind AS eclmclmt_cmpny_or_indvd_ind,
                      claim_claimant_info.licence_num AS eclmclmt_lic_num,
                      claim_claimant_info.lic_iss_prov AS eclmclmt_lic_prov,
                      DATE(claim_claimant_info.claimant_dob) AS eclmclmt_clmt_dob,
                      claim_claimant_info.abc_orig_type_ind AS eclmclmt_bi_code_orig,
                      claim_claimant_info.abc_curr_type_ind AS eclmclmt_bi_code_curr,
                      claim_claimant_info.loss_transfer_code AS eclmclmt_loss_trnsfr_code,
                      claim_claimant_info.tp_veh_type_desc AS eclmclmt_tp_vehic_type_desc
                    FROM
                      `@curated_project.@curated_dataset_name.claim_claimant_info` AS claim_claimant_info
                    WHERE DATE(claim_claimant_info.processed_date) <= CAST('@execution_date' as DATE)
                ) AS clmtinfo ON tbl818.int_claim_num_mxtr = clmtinfo.int_claim_num_818
                 AND tbl818.clmt_num_818 = clmtinfo.claimant_num_818
                 AND tbl818.pd_818 = clmtinfo.processed_date_818
                 AND tbl818.lpd_818 = clmtinfo.last_process_date_818
          ) AS x
    ) AS clmt ON main.cl_int_claim_num = clmt.int_claim_num_818
     AND main.ccvg_claimant_num = clmt.claimant_num_818
     AND main.cl_processed_date = clmt.pd_mxtr
     AND main.cl_last_process_date = clmt.lpd_mxtr
);