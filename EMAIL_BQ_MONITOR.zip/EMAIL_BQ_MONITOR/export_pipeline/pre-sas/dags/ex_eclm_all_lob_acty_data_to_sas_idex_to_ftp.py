import logging
from datetime import datetime
import pytz
from google.cloud import storage, bigquery
from airflow import DAG
from airflow.models import Variable
from airflow.operators.empty import EmptyOperator
from airflow.exceptions import AirflowException
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from airflow.providers.google.cloud.transfers.gcs_to_sftp import GCSToSFTPOperator
from airflow.providers.google.cloud.operators.gcs import GCSDeleteObjectsOperator
from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator


curated_project = Variable.get("curated_project_name")
derived_project = Variable.get("derived_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_bucket_name = Variable.get("derived_bucket_name")

presas_jobs_variables = Variable.get(
    "presas_jobs_variables", deserialize_json=True)

query_path = presas_jobs_variables["query_path"]
presas_sql_file = presas_jobs_variables["presas_sql_file"]
output_folder_path = presas_jobs_variables["output_folder_path"]
runtime_path = presas_jobs_variables["runtime_path"]
composer_path = presas_jobs_variables["composer_path"]
filename = presas_jobs_variables["filename"]
runtime_filename = presas_jobs_variables["runtime_filename"]
curated_dataset_name = presas_jobs_variables["curated_dataset_name"]
ftp_conn_id = presas_jobs_variables["Ftp_conn_id"]
destination_path = presas_jobs_variables["destination_path"]
export_to_ftp = presas_jobs_variables["export_to_ftp"]


# GCS client
storage_client = storage.Client(project=derived_bucket_name)

# Bigquery client
bigquery_client = bigquery.Client(project=curated_project)
est_tz = pytz.timezone("America/Toronto")


def get_execution_date_time(**kwargs):
    """
    Function to get execution datetime
    """
    date = kwargs["dag_run"].conf["run_date"]
    input_date = datetime.strptime(date, "%Y-%m-%d")
    execution_date = input_date.strftime("%Y_%b_%d")
    execution_datetime = datetime.now().astimezone(est_tz).strftime("%Y%m%d%H%M%S%f")[:-3]
    runtime = runtime_path.replace("@execution_datetime", execution_datetime)
    print(runtime)
    logging.info("This is the date from scheduler", execution_date)

    return date, execution_date, runtime


def get_execute_query(sql_file, **context):
    """
    function to read and execute query in Bigquery
    """

    try:
        datetime = context["ti"].xcom_pull(task_ids=get_execution_date_time.task_id)
        execution_date = datetime[0]
        print(execution_date)
        bucket = storage_client.bucket(deployment_bucket_name)
        blob = bucket.get_blob(sql_file)
        query = blob.download_as_string().decode("utf-8")
        query = (
            query.replace("@curated_project", curated_project)
            .replace("@execution_date", execution_date)
            .replace("@curated_dataset_name", curated_dataset_name)
        )
        print(query)
        logging.info("Query submitted for execution in BigQuery")
        query_job = bigquery_client.query(query)
        query_job.result()

    except Exception:
        logging.error("Error in reading/executing query")
        raise AirflowException("Error in reading/executing query")


def ex_eclm_all_lob_acty_data_to_sas_idex_to_gcs(**context):
    try:
        trigger_ex_eclm_all_lob_acty_data_to_sas_idex_to_gcs = TriggerDagRunOperator(
            task_id="trigger_ex_eclm_all_lob_acty_data_to_sas_idex_to_gcs",
            trigger_dag_id="ex_eclm_all_lob_acty_data_to_sas_idex_to_gcs",
            wait_for_completion=True,
            poke_interval=60,
        )
        trigger_ex_eclm_all_lob_acty_data_to_sas_idex_to_gcs.execute(dict(context))

        return move_files_to_runtime.task_id

    except Exception as error:
        raise AirflowException(
            f"Following error occurred while exporting sonnet data to GCS: {error}"
        )


def get_ftp_filename(runtime_timestamp):
    ftp_filename = runtime_filename.replace("@execution_datetime", runtime_timestamp)
    return ftp_filename


def move_files_to_runtime(**context):
    datetime = context["ti"].xcom_pull(task_ids=get_execution_date_time.task_id)
    execution_date = datetime[1]
    runtime = datetime[2]

    ftp_filename = get_ftp_filename(execution_date)
    print(ftp_filename)
    try:
        move_presas_file = GCSToGCSOperator(
            task_id="move_files_to_runtime",
            source_bucket=derived_bucket_name,
            source_object=f"{output_folder_path}{filename}",
            destination_bucket=derived_bucket_name,
            destination_object=f"{runtime}{ftp_filename}",
            move_object=True,
        )
        move_presas_file.execute(dict(context))

        if export_to_ftp.lower() == "true":
            return copy_files_to_composer.task_id
        else:
            return end.task_id

    except Exception as error:
        raise AirflowException(
            f"""Following error occurred while moving files from output path -{output_folder_path} to
                runtime path - {runtime_path}: {error}"""
        )


def copy_files_to_composer(**context):
    datetime = context["ti"].xcom_pull(task_ids=get_execution_date_time.task_id)
    runtime = datetime[2]
    try:
        copy_files_to_local = GCSToGCSOperator(
            task_id="copy_files_to_composer",
            source_bucket=derived_bucket_name,
            source_object=f"{runtime}*.csv",
            destination_bucket=composer_bucket_name,
            destination_object=composer_path,
            move_object=False,
        )
        copy_files_to_local.execute(dict(context))
    except Exception as error:
        raise AirflowException(
            f"""Following error occurred while copying files from {runtime} to
                composer src path - {composer_path} : {error}"""
        )


def move_files_to_ftp(**context):
    datetime = context["ti"].xcom_pull(task_ids=get_execution_date_time.task_id)
    execution_date = datetime[1]

    ftp_filename = get_ftp_filename(execution_date)

    try:
        upload_files_on_ftp = GCSToSFTPOperator(
            task_id="upload_files_on_ftp",
            sftp_conn_id=ftp_conn_id,
            source_bucket=composer_bucket_name,
            source_object=f"{composer_path}{ftp_filename}",
            destination_path=destination_path,
            keep_directory_structure=False,
        )
        upload_files_on_ftp.execute(dict(context))
    except Exception as error:
        raise AirflowException(
            f"""Following error occurred while moving files from composer bucket path - {composer_path} to
                FTP path - {composer_path}: {error}"""
        )


def delete_files_from_composer(**context):
    datetime = context["ti"].xcom_pull(task_ids=get_execution_date_time.task_id)
    execution_date = datetime[1]

    ftp_filename = get_ftp_filename(execution_date)
    try:
        delete_files = GCSDeleteObjectsOperator(
            task_id="delete_files",
            bucket_name=composer_bucket_name,
            objects=[f"{composer_path}{ftp_filename}"],
        )
        delete_files.execute(dict(context))

    except Exception as error:
        raise AirflowException(
            f"Following error occurred while deleting file from composer bucket path - {composer_path}: {error}"
        )


with DAG(
    dag_id="ex_eclm_all_lob_acty_data_to_sas_idex_to_ftp",
    start_date=datetime(2023, 7, 11),
    tags=["daily", "export"],
    schedule_interval=None,
    catchup=False,
    max_active_runs=1,
) as dag:
    start = EmptyOperator(
        task_id="start",
    )

    get_execution_date_time = PythonOperator(
        task_id="get_execution_date_time",
        python_callable=get_execution_date_time,
        dag=dag,
        provide_context=True,
    )

    get_execute_query = PythonOperator(
        task_id="get_execute_query",
        python_callable=get_execute_query,
        op_kwargs={
            "sql_file": f"{query_path}/{presas_sql_file}",
        },
        trigger_rule="all_success",
        provide_context=True,
        dag=dag,
    )

    ex_eclm_all_lob_acty_data_to_sas_idex_to_gcs = PythonOperator(
        task_id="ex_eclm_all_lob_acty_data_to_sas_idex_to_gcs",
        python_callable=ex_eclm_all_lob_acty_data_to_sas_idex_to_gcs,
        provide_context=True,
    )

    move_files_to_runtime = BranchPythonOperator(
        task_id="move_files_to_runtime",
        python_callable=move_files_to_runtime,
        trigger_rule="all_success",
        provide_context=True,
    )

    copy_files_to_composer = PythonOperator(
        task_id="copy_files_to_composer",
        python_callable=copy_files_to_composer,
        trigger_rule="all_success",
        provide_context=True,
    )
    move_files_to_ftp = PythonOperator(
        task_id="move_files_to_ftp",
        python_callable=move_files_to_ftp,
        provide_context=True,
    )
    delete_files_from_composer = PythonOperator(
        task_id="delete_files_from_composer",
        python_callable=delete_files_from_composer,
        provide_context=True,
    )

    end = EmptyOperator(task_id="end", trigger_rule="none_failed_min_one_success")

(
    start
    >> get_execution_date_time
    >> get_execute_query
    >> ex_eclm_all_lob_acty_data_to_sas_idex_to_gcs
    >> move_files_to_runtime
    >> copy_files_to_composer
    >> move_files_to_ftp
    >> delete_files_from_composer
    >> end
)

(
    start
    >> get_execution_date_time
    >> get_execute_query
    >> ex_eclm_all_lob_acty_data_to_sas_idex_to_gcs
    >> move_files_to_runtime
    >> end
)
