INSERT INTO
	export_framework.exf_ds_def (
		exf_ds_name,
		exf_ds_desc,
		exf_ds_type,
		exf_ds_location,
		exf_conn_type,
		exf_conn_details_variable
	)
VALUES
	(
		"dp-prod-curated-b30b.eclm",
		"BQ dataset for preasa table BigQuery",
		"BigQuery",
		"northamerica-northeast1",
		"BigQuery",
		""
	);

INSERT INTO
	export_framework.exf_job_def (
		exf_job_name,
		exf_pattern_id,
		exf_src_id,
		exf_sink_id,
		exf_frequency,
		exf_owner,
		exf_target,
		exf_src_query,
		exf_active_ind,
		exf_creation_time,
		exf_inc_extract_flg,
		exf_custom_filter_condition,
		exf_value,
		exf_load_type,
		exf_file_delimiter,
		exf_file_format,
		exf_filenm_conf,
		exf_fixed_width_def,
		exf_header_query,
		exf_footer_query,
		exf_create_zero_byte_file
	)
VALUES
	(
		"ex_eclm_all_lob_acty_data_to_sas_idex_to_gcs",
		1,
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'dp-prod-curated-b30b.eclm'
		),
		(
			SELECT
				exf_ds_id
			FROM
				export_framework.exf_ds_def
			WHERE
				exf_ds_name = 'definity-prod-derived-bucket'
		),
		"daily",
		"SDP",
		"gs://$bucket_name/Pre-sas/eclm_all_lob_acty_data_to_sas/output/",
		"SELECT * FROM `$project_id.$dataset_id.export_PreSAS`;",
		1,
		CURRENT_TIMESTAMP(),
		"N",
		NULL,
		"",
		"overwrite",
		",",
		"CSV",
		'{"filename": {"base": "eclm_extr", "extension": "csv", "separator": ","}}',
		NULL,
		NULL,
		NULL,
		NULL
	);