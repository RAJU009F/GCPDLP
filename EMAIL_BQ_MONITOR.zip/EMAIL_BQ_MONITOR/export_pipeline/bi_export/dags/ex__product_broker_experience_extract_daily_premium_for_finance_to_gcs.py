from datetime import datetime
import pytz
from google.cloud import storage, bigquery
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.google.cloud.transfers.gcs_to_gcs import (
    GCSToGCSOperator,
)


"""Fetching Airflow Variables Values"""
raw_project_name = Variable.get("raw_project_name")
raw_bucket_name = Variable.get("raw_bucket_name")
curated_project = Variable.get("curated_project_name")
derived_project = Variable.get("derived_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_bucket_name = Variable.get("derived_bucket_name")

export_written_premium = Variable.get(
    "export_written_premium", deserialize_json=True)

dag_start_date = export_written_premium["dag_start_date"]
local_file_path = export_written_premium["local_path"]
file_name = export_written_premium["file_name"]
folder_path = export_written_premium["folder_path"]
derived_dataset_name = export_written_premium["derived_dataset_name"]
destination_folder = export_written_premium["destination_folder"]
framework_path = export_written_premium["framework_path"]
job_book_path = export_written_premium["job_book_path"]
troubleshooting_path = export_written_premium[
    "troubleshooting_path"
]

"""Initializing storage,bigquery clients and gcshook"""
storage_client = storage.Client(project=derived_project)
bigquery_client = bigquery.Client(project=derived_project)
est_tz = pytz.timezone("America/Toronto")


# function to set execution time
def set_execution_time(**context):
    execution_time = (context["execution_date"].astimezone(
        est_tz)).strftime("%Y%m%d%H%M%S%f")[:-3]
    task_instance = context['task_instance']
    task_instance.xcom_push(key='timestamp', value=execution_time)


with DAG(
    dag_id="ex__product_broker_experience_extract_daily_premium_for_finance_to_gcs",
    start_date=datetime.strptime(dag_start_date, "%Y-%m-%d"),
    schedule_interval=None,
    tags=["product_broker_experience", "daily"],
    catchup=False,
) as dag:

    # trigger ex__product_broker_experience_extract_daily_premium_for_finance DAG
    trigger_ex__product_broker_experience_extract_daily_premium_for_finance = TriggerDagRunOperator(
        task_id="trigger_ex__product_broker_experience_extract_daily_premium_for_finance",
        trigger_dag_id="ex__product_broker_experience_extract_daily_premium_for_finance",
        wait_for_completion=True,
        poke_interval=60,
        dag=dag,
    )

    # Set execution time
    set_execution_time = PythonOperator(
        task_id="set_execution_time",
        python_callable=set_execution_time,
        dag=dag,
    )

    # copy to runtime folder
    copy_to_runtime_folder = GCSToGCSOperator(
        task_id="copy_to_runtime_folder",
        source_bucket=derived_bucket_name,
        source_object=f"{derived_dataset_name}/{file_name}.csv",
        destination_bucket=derived_bucket_name,
        destination_object=f"{derived_dataset_name}/runtime_" +
        "{{task_instance.xcom_pull(task_ids='set_execution_time',key='timestamp')}}" f"/output/{file_name}_" +
        "{{task_instance.xcom_pull(task_ids='set_execution_time',key='timestamp')}}"+".csv",
        source_object_required=True
    )

    # copy to composer bucket output folder
    copy_to_composer_bucket = GCSToGCSOperator(
        task_id="copy_to_composer_bucket",
        source_bucket=derived_bucket_name,
        source_object=f"{derived_dataset_name}/{file_name}.csv",
        destination_bucket=composer_bucket_name,
        destination_object=f"{folder_path}/{destination_folder}/{file_name}_" +
        "{{task_instance.xcom_pull(task_ids='set_execution_time',key='timestamp')}}"+".csv",
        source_object_required=True
    )


dag.doc_md = f"""
### DAG Documentation
- Job Description - Transformation job to load data into derived tables
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""

(
    trigger_ex__product_broker_experience_extract_daily_premium_for_finance
    >> set_execution_time
    >> copy_to_runtime_folder
    >> copy_to_composer_bucket
)
