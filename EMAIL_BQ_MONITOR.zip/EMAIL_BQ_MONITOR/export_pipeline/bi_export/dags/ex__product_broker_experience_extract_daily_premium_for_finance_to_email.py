from datetime import datetime
import pytz
from google.cloud import storage, bigquery
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.operators.gcs import GCSDeleteObjectsOperator
from airflow.operators.email import EmailOperator


"""Fetching Airflow Variables Values"""
raw_project_name = Variable.get("raw_project_name")
raw_bucket_name = Variable.get("raw_bucket_name")
curated_project = Variable.get("curated_project_name")
derived_project = Variable.get("derived_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_bucket_name = Variable.get("derived_bucket_name")

export_written_premium = Variable.get(
    "export_written_premium", deserialize_json=True)

dag_start_date = export_written_premium["dag_start_date"]
to_email = export_written_premium["to_email"]
cc_email = export_written_premium["cc_email"]
local_file_path = export_written_premium["local_path"]
file_name = export_written_premium["file_name"]
folder_path = export_written_premium["folder_path"]
derived_dataset_name = export_written_premium["derived_dataset_name"]
destination_folder = export_written_premium["destination_folder"]
framework_path = export_written_premium["framework_path"]
job_book_path = export_written_premium["job_book_path"]
troubleshooting_path = export_written_premium[
    "troubleshooting_path"
]

"""Initializing storage,bigquery clients and gcshook"""
storage_client = storage.Client(project=derived_project)
bigquery_client = bigquery.Client(project=derived_project)
est_tz = pytz.timezone("America/Toronto")


# function to set execution time
def get_filename(**context):
    storage_client = storage.Client()
    blobs = storage_client.list_blobs(
        composer_bucket_name, prefix=f'data/product_broker_experience/output/{file_name}_', delimiter='/')
    file_name_wrt = ''
    for blob in blobs:
        file_name_wrt = blob.name.rsplit('/')[-1]
        print(file_name_wrt)

    task_instance = context['task_instance']
    task_instance.xcom_push(key='file_name_wrt', value=file_name_wrt)


with DAG(
    dag_id="ex__product_broker_experience_extract_daily_premium_for_finance_to_email",
    start_date=datetime.strptime(dag_start_date, "%Y-%m-%d"),
    schedule_interval=None,
    tags=["product_broker_experience", "daily"],
    catchup=False,
) as dag:

    # Set execution time
    get_filename = PythonOperator(
        task_id="get_filename",
        python_callable=get_filename,
        dag=dag,
    )

    # sends email to recipients
    send_email = EmailOperator(
        task_id="send_email",
        conn_id="sendgrid_default",
        to=to_email,
        cc=cc_email,
        subject="SDP written premium extract for Sales and Distribution",
        html_content="Please see attached.",
        files=[f"{local_file_path}/{folder_path}/{destination_folder}/" +
               "{{task_instance.xcom_pull(task_ids='get_filename',key='file_name_wrt')}}"],
        dag=dag,
    )

    # delete file from composer bucket
    delete_file_from_composer = GCSDeleteObjectsOperator(
        task_id="delete_file_from_composer",
        bucket_name=composer_bucket_name,
        objects=[f"{folder_path}/{destination_folder}/" +
                 "{{task_instance.xcom_pull(task_ids='get_filename',key='file_name_wrt')}}"]
    )


dag.doc_md = f"""
### DAG Documentation
- Job Description - Transformation job to load data into derived tables
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""

(
    get_filename
    >> send_email
    >> delete_file_from_composer
)
