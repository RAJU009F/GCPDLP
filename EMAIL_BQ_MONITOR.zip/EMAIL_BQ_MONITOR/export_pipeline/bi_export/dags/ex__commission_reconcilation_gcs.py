from datetime import datetime
import pytz
from google.cloud import storage
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator


raw_project_name = Variable.get("raw_project_name")
raw_bucket_name = Variable.get("raw_bucket_name")
curated_project = Variable.get("curated_project_name")
derived_project = Variable.get("derived_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_bucket_name = Variable.get("derived_bucket_name")

# edit this completety according to our use case
dh_commission_reconcilation_ftp = Variable.get(
    "dh_commission_reconcilation_ftp", deserialize_json=True
)
local_path = dh_commission_reconcilation_ftp["local_path"]
file_name = dh_commission_reconcilation_ftp["file_name"]
remote_path = dh_commission_reconcilation_ftp["remote_path"]
query_path = dh_commission_reconcilation_ftp["query_path"]
folder_path = dh_commission_reconcilation_ftp["folder_path"]
derived_dataset_name = dh_commission_reconcilation_ftp["derived_dataset_name"]
framework_path = dh_commission_reconcilation_ftp["framework_path"]
dag_start_date = dh_commission_reconcilation_ftp["dag_start_date"]
job_book_path = dh_commission_reconcilation_ftp["job_book_path"]
destination_folder = dh_commission_reconcilation_ftp["destination_folder"]
troubleshooting_path = dh_commission_reconcilation_ftp["troubleshooting_path"]

# GCS client
storage_client = storage.Client(project=raw_project_name)
deployment_bucket = storage_client.bucket(deployment_bucket_name)

est_tz = pytz.timezone("America/Toronto")


def get_execution_date_time(**context):
    execution_date = context["dag_run"].conf.get("run_date")
    if execution_date:
        print("Execution date: ", execution_date)
    else:
        execution_date = context["execution_date"].astimezone(
            est_tz).strftime("%Y-%m-%d")
    execution_time = datetime.now().astimezone(
        est_tz).strftime("%Y%m%d%H%M%S%f")[:-3]
    return str(execution_date), str(execution_time)


def copy_files_to_runtime(**context):
    execution_time = context["task_output"][1]
    # copy files from raw bucket to raw bucket
    copy_file = GCSToGCSOperator(
        task_id="copy_files_to_runtime",
        source_bucket=derived_bucket_name,
        source_object=f"{derived_dataset_name}/{file_name}.csv",
        destination_bucket=derived_bucket_name,
        move_object=False,
        destination_object=(
            f"{derived_dataset_name}/runtime_{execution_time}/output/{file_name}.csv"
        ),
    )
    copy_file.execute(dict(context))


def copy_files_to_composer_bucket(**context):
    # copy files from raw bucket to composer bucket
    copy_file = GCSToGCSOperator(
        task_id="copy_files_to_composer_bucket",
        source_bucket=derived_bucket_name,
        source_object=f"{derived_dataset_name}/{file_name}.csv",
        destination_bucket=composer_bucket_name,
        destination_object=f"{folder_path}/{destination_folder}/{file_name}.csv",
        move_object=False,
    )
    copy_file.execute(dict(context))


with DAG(
    dag_id="ex__commission_reconcilation_gcs",
    schedule_interval=None,
    start_date=datetime.strptime(dag_start_date, "%Y-%m-%d"),
    tags=["gl", "monthly", "ftp"],
    catchup=False,
) as dag:
    get_execution_date_time = PythonOperator(
        task_id="get_execution_date_time", python_callable=get_execution_date_time, dag=dag
    )

    ex_export_gl_commission_reconcilation = TriggerDagRunOperator(
        task_id="ex_export_gl_commission_reconcilation",
        trigger_dag_id="ex_export_gl_commission_reconcilation",
        wait_for_completion=True,
        poke_interval=60,
        dag=dag,
    )

    # copy to runtime in derived
    copy_files_to_runtime = PythonOperator(
        task_id="copy_files_to_runtime",
        python_callable=copy_files_to_runtime,
        op_kwargs={"task_output": get_execution_date_time.output},
        dag=dag,
    )

    # copy files from derived bucket to composer bucket
    copy_files_to_composer_bucket = PythonOperator(
        task_id="copy_files_to_composer_bucket",
        python_callable=copy_files_to_composer_bucket,
        dag=dag,
    )


dag.doc_md = f"""
### DAG Documentation
- Job Description - Transformation job for creating create_farc_icm_cpc_data_file and sending to FTP Mainframe
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""

(

    get_execution_date_time
    >> ex_export_gl_commission_reconcilation
    >> copy_files_to_runtime
    >> copy_files_to_composer_bucket

)
