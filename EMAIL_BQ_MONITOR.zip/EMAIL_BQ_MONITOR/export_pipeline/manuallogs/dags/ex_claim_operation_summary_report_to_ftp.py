import logging
import pytz
from datetime import datetime

from google.cloud import storage

from airflow import DAG
from airflow.models import Variable
from airflow.exceptions import AirflowException
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from providers.definity.gcp.transfers.gcs_to_ftp import GCSToFTPOperator


derived_project_name = Variable.get("derived_project_name")
processing_project_name = Variable.get("processing_project_name")
derived_bucket_name = Variable.get("derived_bucket_name")
composer_bucket_name = Variable.get("composer_bucket_name")

variables = Variable.get("manuallogs_export_variables", deserialize_json=True)

framework_path = variables["framework_path"]
troubleshooting_path = variables["troubleshooting_path"]
job_book_path = variables["job_book_path"]

export_to_ftp = variables["export_to_ftp"]
ftp_conn_id = variables["ftp_conn_id"]
src_path = variables["src_path"]
local_src_path = variables["local_src_path"]
ftp_path = variables["summary_report_ftp_path"]
file_name = variables["summary_report_file_name"]
output_file = variables["summary_report_output_file"]
derived_path = variables["summary_report_derived_path"]
output_path = variables["error_report_output_path"].replace("@error_report_derived_path", derived_path)
runtime_path = variables["summary_report_runtime_path"].replace("@summary_report_derived_path", derived_path)

est_tz = pytz.timezone("America/Toronto")


def get_runtime_timestamp():
    """
    function to get current runtime_timestamp
    """
    current_timestamp = datetime.now(est_tz)
    runtime_timestamp = current_timestamp.strftime('%Y%m%d%H%M%S%f')[:-3]
    file_name_timestamp = current_timestamp.strftime('%d%m%Y')

    logging.info(f'runtime_timestamp: {runtime_timestamp}')
    return runtime_timestamp, file_name_timestamp


def get_execution_date_func(**kwargs):
    """
    Function to get execution date from Control-M
    """
    try:
        execution_date = (
            kwargs['dag_run'].conf['run_date']
        )
        logging.info("Execution date received from Control-M scheduler: ", execution_date)

        runtime_timestamp, file_name_timestamp = get_runtime_timestamp()

        ftp_file_name = file_name.replace("%d%m%Y", file_name_timestamp)
        runtime_dir_path = runtime_path.replace("@execution_datetime", runtime_timestamp)

        return execution_date, ftp_file_name, runtime_dir_path

    except Exception as exception:
        logging.info(exception)
        execution_runtime = kwargs["data_interval_start"].astimezone(est_tz)
        execution_date = execution_runtime.strftime("%Y-%m-%d")

        runtime_timestamp, file_name_timestamp = get_runtime_timestamp()

        ftp_file_name = file_name.replace("%d%m%Y", file_name_timestamp)
        runtime_dir_path = runtime_path.replace("@execution_datetime", runtime_timestamp)

        return execution_date, ftp_file_name, runtime_dir_path


def move_file(src_bucket_name, src_blob_name, dest_bucket_name, dest_blob_name, move_file):
    """
    Function to move files from one folder to another
    """
    try:
        storage_client = storage.Client(project=derived_project_name)
        source_bucket = storage_client.get_bucket(src_bucket_name)
        source_blob = source_bucket.blob(src_blob_name)
        destination_bucket = storage_client.get_bucket(dest_bucket_name)
        dest_blob = source_bucket.copy_blob(
            source_blob, destination_bucket, dest_blob_name
        )

        if move_file:
            source_blob.delete()
            logging.info(f"File moved from {source_blob} to {dest_blob}")
        else:
            logging.info(f"File copied from {source_blob} to {dest_blob}")
    except Exception:
        raise AirflowException(f"Error in copying/moving file {src_blob_name}")


def move_file_to_runtime_func(**context):

    runtime_details = context['ti'].xcom_pull(task_ids=get_execution_date.task_id)
    ftp_file_name = runtime_details[1]
    runtime_dir_path = runtime_details[2]

    try:
        move_file(
            derived_bucket_name,
            f"{output_path}{output_file}",
            derived_bucket_name,
            f"{runtime_dir_path}{ftp_file_name}",
            True
        )

        if export_to_ftp:
            return copy_file_to_local.task_id
        else:
            return end.task_id

    except Exception as error:
        raise AirflowException(
            f"""Following error occurred while moving {output_file} to
                runtime path - {runtime_dir_path}{ftp_file_name}: {error}"""
        )


def copy_file_to_local_func(**context):

    runtime_details = context['ti'].xcom_pull(task_ids=get_execution_date.task_id)
    ftp_file_name = runtime_details[1]
    runtime_dir_path = runtime_details[2]

    try:
        move_file(
            derived_bucket_name,
            f"{runtime_dir_path}{ftp_file_name}",
            composer_bucket_name,
            f"{src_path}{ftp_file_name}",
            False
        )
    except Exception as error:
        raise AirflowException(
            f"""Following error occurred while copying {ftp_file_name} to
                local path - {src_path}{ftp_file_name}: {error}"""
        )


def move_file_to_ftp_func(**context):

    runtime_details = context['ti'].xcom_pull(task_ids=get_execution_date.task_id)
    execution_date = runtime_details[0]
    ftp_file_name = runtime_details[1]
    remote_ftp_path = ftp_path.replace("@execution_date", execution_date.replace("-", "_"))

    try:
        copy_file_from_local_to_ftp = GCSToFTPOperator(
            task_id="copy_file_from_local_to_ftp",
            ftp_conn_id=ftp_conn_id,
            source_bucket=composer_bucket_name,
            source_object=f"{src_path}{ftp_file_name}",
            destination_path=remote_ftp_path,
        )
        copy_file_from_local_to_ftp.execute(context)

    except Exception as error:
        raise AirflowException(
            f"""Following error occurred while moving {ftp_file_name} to
                FTP path - {remote_ftp_path}{ftp_file_name}: {error}"""
        )


def delete_file_from_local_func(**context):

    runtime_details = context['ti'].xcom_pull(task_ids=get_execution_date.task_id)
    ftp_file_name = runtime_details[1]

    try:
        storage_client = storage.Client(project=processing_project_name)
        composer_bucket = storage_client.get_bucket(composer_bucket_name)
        source_blob = composer_bucket.blob(f"{src_path}{ftp_file_name}")
        source_blob.delete()
        logging.info(f"{source_blob} File deleted from gs://{composer_bucket_name}{src_path}/ folder")
    except Exception as error:
        raise AirflowException(
            f"""Following error occurred while deleting {ftp_file_name}
                from gs://{composer_bucket_name}{src_path}/ folder: {error}"""
        )


with DAG(
    dag_id='ex_claim_operation_summary_report_to_ftp',
    start_date=datetime(2023, 7, 30),
    tags=['ExportFramework', 'Quantiphi', 'manuallogs', 'daily', 'csv'],
    schedule_interval=None,
    catchup=False,
    max_active_runs=1,
) as dag:

    start = EmptyOperator(
        task_id='start',
    )

    get_execution_date = PythonOperator(
        task_id="get_execution_date",
        python_callable=get_execution_date_func,
        provide_context=True
    )

    trigger_ex_claim_operation_summary_report_to_gcs = TriggerDagRunOperator(
        task_id="trigger_ex_claim_operation_summary_report_to_gcs",
        trigger_dag_id="ex_claim_operation_summary_report_to_gcs",
        wait_for_completion=True,
        poke_interval=60,
    )

    move_file_to_runtime = BranchPythonOperator(
        task_id="move_file_to_runtime",
        python_callable=move_file_to_runtime_func,
        provide_context=True,
    )

    copy_file_to_local = PythonOperator(
        task_id="copy_file_to_local",
        python_callable=copy_file_to_local_func,
        provide_context=True,
    )

    move_file_to_ftp = PythonOperator(
        task_id="move_file_to_ftp",
        python_callable=move_file_to_ftp_func,
        provide_context=True,
    )

    delete_file_from_local = PythonOperator(
        task_id="delete_file_from_local",
        python_callable=delete_file_from_local_func,
        provide_context=True
    )

    end = EmptyOperator(
        task_id="end",
        trigger_rule="none_failed_min_one_success"
    )


dag.doc_md = f"""
### DAG Documentation
- Job Description - Ingestion Jobs for Manuallogs
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""


(
    start
    >> get_execution_date
    >> trigger_ex_claim_operation_summary_report_to_gcs
    >> move_file_to_runtime
    >> copy_file_to_local
    >> move_file_to_ftp
    >> delete_file_from_local
    >> end
)

(
    start
    >> get_execution_date
    >> trigger_ex_claim_operation_summary_report_to_gcs
    >> move_file_to_runtime
    >> end
)
