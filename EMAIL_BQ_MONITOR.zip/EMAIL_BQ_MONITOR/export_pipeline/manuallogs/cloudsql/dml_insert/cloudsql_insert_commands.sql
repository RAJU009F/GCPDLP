INSERT INTO export_framework.exf_ds_def (
	exf_ds_name,
	exf_ds_desc,
	exf_ds_type,
	exf_ds_location,
	exf_conn_type,
	exf_conn_details_variable
) VALUES (
	"dp-prod-curated-b30b.claim_operation",
	"BQ dataset for error_report table",
	"BigQuery",
	"northamerica-northeast1",
	"BigQuery",
	""
);

INSERT INTO export_framework.exf_ds_def (
	exf_ds_name,
	exf_ds_desc,
	exf_ds_type,
	exf_ds_location,
	exf_conn_type,
	exf_conn_details_variable
) VALUES (
	"dp-prod-curated-b30b.family",
	"BQ dataset for reconciliation_report table",
	"BigQuery",
	"northamerica-northeast1",
	"BigQuery",
	""
);

INSERT INTO export_framework.exf_job_def (
	exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
) VALUES (
	"ex_claim_operation_error_report_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-curated-b30b.claim_operation'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/claim_operation/error_report/output/",
	"SELECT source_file_name, dlh_process_ts AS process_date, column_name, src_value AS value, error_message FROM `$project_id.$dataset_id.error_report` WHERE EXTRACT(DATE FROM dlh_process_ts) = CURRENT_DATE('America/Toronto');",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "error_report", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def (
	exf_job_name,
	exf_pattern_id,
	exf_src_id,
	exf_sink_id,
	exf_frequency,
	exf_owner,
	exf_target,
	exf_src_query,
	exf_active_ind,
	exf_creation_time,
	exf_inc_extract_flg,
	exf_custom_filter_condition,
	exf_value,
	exf_load_type,
	exf_file_delimiter,
	exf_file_format,
	exf_filenm_conf,
	exf_fixed_width_def,
	exf_header_query,
	exf_footer_query,
	exf_create_zero_byte_file
) VALUES (
	"ex_claim_operation_summary_report_to_gcs",
	1,
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'dp-prod-curated-b30b.family'
	),
	(
		SELECT exf_ds_id 
		FROM export_framework.exf_ds_def 
		WHERE exf_ds_name = 'definity-prod-derived-bucket'
	),
	"daily",
	"SDP",
	"gs://$bucket_name/claim_operation/summary_report/output/",
	"SELECT dlh_process_ts AS processed_date, src_name, data_table, data_field, data_total FROM `$project_id.$dataset_id.reconciliation_report` WHERE data_table LIKE 'ff_%' AND src_name LIKE '%.csv' AND EXTRACT(DATE FROM dlh_process_ts) = CURRENT_DATE('America/Toronto') GROUP BY dlh_process_ts, src_name, data_table, data_field, data_total;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	"",
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "summary_report", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL	
);