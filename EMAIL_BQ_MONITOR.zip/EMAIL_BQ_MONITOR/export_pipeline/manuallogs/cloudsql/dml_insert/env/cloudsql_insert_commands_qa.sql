INSERT INTO export_framework.exf_ds_def VALUES (
	110,
	"dp-qa-curated-27f1.claim_operation",
	"BQ dataset for error_report table",
	"BigQuery",
	"northamerica-northeast1",
	"BigQuery",
	""
);

INSERT INTO export_framework.exf_ds_def VALUES (
	103,
	"dp-qa-curated-27f1.family",
	"BQ dataset for reconciliation_report table",
	"BigQuery",
	"northamerica-northeast1",
	"BigQuery",
	""
);

INSERT INTO export_framework.exf_ds_def VALUES (
	106,
	"definity-qa-derived-bucket",
	"Derived bucket",
	"Google Storage",
	"northamerica-northeast1",
	"Google Storage",
	NULL
);


INSERT INTO export_framework.exf_job_def VALUES (
	118,
	"export_claim_operation_error_report_to_gcs",
	1,
	110,
	106,
	"daily",
	"SDP",
	"gs://$bucket_name/claim_operation/error_report/output/",
	"SELECT source_file_name, dlh_process_ts AS process_date, column_name, src_value AS value, error_message FROM `$project_id.$dataset_id.error_report` WHERE EXTRACT(DATE FROM dlh_process_ts) = CURRENT_DATE('America/Toronto');",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	'',
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "error_report", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);

INSERT INTO export_framework.exf_job_def VALUES (
	119,
	"export_claim_operation_summary_report_to_gcs",
	1,
	103,
	106,
	"daily",
	"SDP",
	"gs://$bucket_name/claim_operation/summary_report/output/",
	"SELECT dlh_process_ts AS processed_date, src_name, data_table, data_field, data_total FROM `$project_id.$dataset_id.reconciliation_report` WHERE data_table LIKE 'ff_%' AND src_name LIKE '%.csv' AND EXTRACT(DATE FROM dlh_process_ts) = CURRENT_DATE('America/Toronto') GROUP BY dlh_process_ts, src_name, data_table, data_field, data_total;",
	1,
	CURRENT_TIMESTAMP(),
	"N",
	NULL,
	'',
	"overwrite",
	",",
	"CSV",
	'{"filename": {"base": "summary_report", "extension": "csv", "separator": ","}}',
	NULL,
	NULL,
	NULL,
	NULL
);