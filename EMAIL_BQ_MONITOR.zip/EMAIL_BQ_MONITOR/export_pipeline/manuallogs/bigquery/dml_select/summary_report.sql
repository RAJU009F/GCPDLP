SELECT
	dlh_process_ts AS processed_date,
	src_name,
	data_table,
	data_field,
	data_total
FROM
	`$project_id.$dataset_id.reconciliation_report`
WHERE
	data_table LIKE 'ff_%'
	AND src_name LIKE '%.csv'
	AND EXTRACT(
		DATE
		FROM
			dlh_process_ts
	) = CURRENT_DATE('America/Toronto')
GROUP BY
	dlh_process_ts,
	src_name,
	data_table,
	data_field,
	data_total;