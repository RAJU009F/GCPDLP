SELECT
	source_file_name,
	dlh_process_ts AS process_date,
	column_name,
	src_value AS value,
	error_message
FROM
	`$project_id.$dataset_id.error_report`
WHERE
	EXTRACT(
		DATE
		FROM
			dlh_process_ts
	) = CURRENT_DATE('America/Toronto');