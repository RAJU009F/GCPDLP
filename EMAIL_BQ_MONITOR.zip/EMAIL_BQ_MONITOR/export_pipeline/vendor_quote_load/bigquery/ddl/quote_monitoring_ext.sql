CREATE  EXTERNAL TABLE IF NOT EXISTS  `@curated_project.pi_quote.quote_monitoring_ext`
  OPTIONS (
    format ="json",
    uris = ['gs://@raw_bucket/vendor_quote/landing/ms_vendorquotes-GlobalWindow-pane-*']
    );