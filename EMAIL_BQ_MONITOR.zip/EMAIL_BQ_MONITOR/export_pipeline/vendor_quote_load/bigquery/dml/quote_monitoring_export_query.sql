select "total_quote", count(*)
    FROM `@curated_project.pi_quote.quote_monitoring_ext`
    WHERE TIMESTAMP_MILLIS(creationtime) > TIMESTAMP_ADD(current_timestamp(), INTERVAL -60 MINUTE)
union all
    select "unsuccessful_quote", count(*)
    FROM `@curated_project.pi_quote.quote_monitoring_ext`
    WHERE TIMESTAMP_MILLIS(creationtime) > TIMESTAMP_ADD(current_timestamp(), INTERVAL -60 MINUTE)
      AND csioResponse like
"%<ExtendedStatusDesc>Rating for this risk is momentarily unavailable, please requote. If the issue persists, please contact Economical for assistance.</ExtendedStatusDesc>%";