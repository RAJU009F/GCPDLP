from datetime import datetime
import pytz
from google.cloud import bigquery, storage
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.operators.email import EmailOperator


deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_project = Variable.get("derived_project_name")
curated_project = Variable.get("curated_project_name")
vendor_quote_monitor_email = Variable.get(
    "vendor_quote_monitor_summary_email", deserialize_json=True)
to_email = vendor_quote_monitor_email["to_email"]
cc_email = vendor_quote_monitor_email["cc_email"]
est_tz = pytz.timezone("America/Toronto")


# function to get record count
def get_vendor_qt_count_from_bq(**context):
    bigquery_client = bigquery.Client(project=curated_project)
    storage_client = storage.Client()
    bucket = storage_client.bucket(deployment_bucket_name)
    blob = bucket.get_blob('export_pipeline/vendor_quote_load/bigquery/dml/quote_monitoring_export_query_daily.sql')
    contents = blob.download_as_string().decode('utf-8')
    bq_count_query = contents.replace("@curated_project", curated_project)
    query_job = bigquery_client.query(bq_count_query)
    query_vq_count = query_job.result()
    unsuccessful_quote = 0
    total_count = 0
    for row in list(query_vq_count):
        print(row)
        if 'total_quote' in row[0]:
            total_count = row[1]
        else:
            unsuccessful_quote = row[1]
    suceesful_quote = total_count - unsuccessful_quote
    print("suceesful_cquote:{}, unsuccessful_quote:{}".format(suceesful_quote, unsuccessful_quote))

    task_instance = context['task_instance']
    task_instance.xcom_push(key='suceesful_quote', value=suceesful_quote)
    task_instance.xcom_push(key='unsuccessful_quote', value=unsuccessful_quote)


with DAG(
        dag_id="vendor_quote_monitor_daily",
        start_date=datetime(2023, 10, 16),
        schedule_interval='55 23 * * *',
        tags=["vendor_quote_monitor", "daily"],
        catchup=False,
) as dag:
    # Set execution time
    get_vendor_qt_count_from_bq = PythonOperator(
        task_id="get_vendor_qt_count_from_bq",
        provide_context=True,
        python_callable=get_vendor_qt_count_from_bq,
        # op_kwargs={'sql':bq_count_query},
        dag=dag
    )

    # sends email to recipients
    send_email = EmailOperator(
        task_id="send_email",
        conn_id="sendgrid_default",
        to=to_email,
        cc=cc_email,
        subject="Quoting Vendor message count summary   {{ yesterday_ds }}",
        html_content="Start Time: {{ yesterday_ds }}, End Time: {{ ds }}, \
         Successful Quote Number: \
        {{task_instance.xcom_pull(task_ids='get_vendor_qt_count_from_bq',key='suceesful_quote')}}, \
        Failed Quote Number: \
        {{task_instance.xcom_pull(task_ids='get_vendor_qt_count_from_bq',key='unsuccessful_quote')}}",
        dag=dag
    )

(
        get_vendor_qt_count_from_bq >> send_email
)
