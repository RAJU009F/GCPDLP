from datetime import datetime
import pytz
from google.cloud import storage
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.providers.ftp.operators.ftp import (
    FTPFileTransmitOperator, FTPOperation)
from airflow.providers.google.cloud.operators.gcs import GCSDeleteObjectsOperator


raw_project_name = Variable.get("raw_project_name")
raw_bucket_name = Variable.get("raw_bucket_name")
curated_project = Variable.get("curated_project_name")
derived_project = Variable.get("derived_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_bucket_name = Variable.get("derived_bucket_name")


# edit this completety according to our use case
rp_farc_feed_commission_exp_data_ftp = Variable.get(
    "rp_farc_feed_commission_exp_data_ftp", deserialize_json=True)

local_path = rp_farc_feed_commission_exp_data_ftp["local_path"]
file_name = rp_farc_feed_commission_exp_data_ftp["file_name"]
remote_path = rp_farc_feed_commission_exp_data_ftp["remote_path"]
query_path = rp_farc_feed_commission_exp_data_ftp["query_path"]
folder_path = rp_farc_feed_commission_exp_data_ftp["folder_path"]
derived_file_path = rp_farc_feed_commission_exp_data_ftp["derived_file_path"]
derived_dataset_name = rp_farc_feed_commission_exp_data_ftp["derived_dataset_name"]
framework_path = rp_farc_feed_commission_exp_data_ftp["framework_path"]
dag_start_date = rp_farc_feed_commission_exp_data_ftp["dag_start_date"]
job_book_path = rp_farc_feed_commission_exp_data_ftp["job_book_path"]
destination_folder = rp_farc_feed_commission_exp_data_ftp["destination_folder"]
troubleshooting_path = rp_farc_feed_commission_exp_data_ftp["troubleshooting_path"]
ftp_conn_id = rp_farc_feed_commission_exp_data_ftp["ftp_conn_id"]

# GCS client
storage_client = storage.Client(project=raw_project_name)
deployment_bucket = storage_client.bucket(deployment_bucket_name)

est_tz = pytz.timezone("America/Toronto")


def get_execution_date_time(**context):
    execution_date = context['dag_run'].conf['run_date']
    print("Fetching execution date: ", execution_date)
    if execution_date:
        print("Using provided date: ", execution_date)
    else:
        execution_date = context["execution_date"].astimezone(est_tz).strftime("%Y-%m-%d")
    execution_time = (
        datetime.now().astimezone(est_tz).strftime("%Y%m%d%H%M%S%f")[:-3]
    )
    return str(execution_date), str(execution_time)


with DAG(
    dag_id="ex__product_gl__rp_farc_feed_commission_FTP",
    schedule_interval=None,
    start_date=datetime.strptime(dag_start_date, "%Y-%m-%d"),
    tags=["gl", "monthly", "ftp"],
    catchup=False,
) as dag:

    get_execution_date_time = PythonOperator(
        task_id="get_execution_date_time",
        python_callable=get_execution_date_time,
        dag=dag,
    )

    # send files to ftp
    gcs_to_ftp = FTPFileTransmitOperator(
        task_id="gcs_to_ftp",
        ftp_conn_id=ftp_conn_id,
        local_filepath=f"{local_path}/{folder_path}/{destination_folder}/{file_name}.csv",
        remote_filepath=remote_path,
        operation=FTPOperation.PUT,
    )

    # delete files from composer bucket
    delete_files_from_composer_bucket = GCSDeleteObjectsOperator(
        task_id="delete_files_from_composer_bucket",
        bucket_name=composer_bucket_name,
        objects=[f"{folder_path}/{destination_folder}/{file_name}.csv"]
    )

dag.doc_md = f"""
### DAG Documentation
- Job Description - Transformation job for creating create_farc_icm_cpc_data_file and sending to FTP Mainframe
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""

(
    get_execution_date_time
    >> gcs_to_ftp
    >> delete_files_from_composer_bucket
)
