INSERT INTO export_framework.exf_ds_def (exf_ds_id,
exf_ds_name,
exf_ds_desc,
exf_ds_type,
exf_ds_location,
exf_conn_type,
exf_conn_details_variable)
VALUES (
    60,
    "@derived_project.product_uber",
    "BQ dataset for ubermart",
    "BigQuery",
    "northamerica-northeast1",
    "BigQuery",
    NULL
);