from datetime import datetime
import pytz
import logging
from google.cloud import storage
from airflow import DAG
from airflow.exceptions import AirflowException
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator
from airflow.providers.ftp.operators.ftp import (
    FTPFileTransmitOperator, FTPOperation)
from airflow.providers.google.cloud.operators.gcs import GCSDeleteObjectsOperator


raw_project_name = Variable.get("raw_project_name")
raw_bucket_name = Variable.get("raw_bucket_name")
curated_project = Variable.get("curated_project_name")
derived_project = Variable.get("derived_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_bucket_name = Variable.get("derived_bucket_name")

# FTP connection id
ftp_conn_id = Variable.get("ubermart_ftp")

# edit this completety according to our use case
config = Variable.get(
    "ex_ubermart_aggr_accident_variables", deserialize_json=True
)

source_folder_path = config["source_folder_path"]
runtime_folder_path = config["runtime_folder_path"]
composer_folder_path = config["composer_folder_path"]
ftp_source_dir = config["ftp_source_dir"]
local_path = config["local_path"]
folder_path = config["folder_path"]
destination_folder = config["destination_folder"]
source_file_name = config["file_name"]


# GCS client
storage_client = storage.Client(project=raw_project_name)
deployment_bucket = storage_client.bucket(deployment_bucket_name)

est_tz = pytz.timezone("America/Toronto")


def get_execution_time_func(**kwargs):
    '''
    function to get execution date
    '''
    try:
        execution_date = (
            kwargs['dag_run'].conf['run_date']
        )
        print("This is the execution date from Scheduler", execution_date)

    except Exception as exception:
        logging.info(exception)
        execution_date = kwargs["execution_date"].astimezone(est_tz)
        execution_date = execution_date.strftime("%Y-%m-%d")
        print("This is the execution date from exception", execution_date)

    # execution_date_format = datetime.strptime(execution_date, "%Y-%m-%d")
    # execution_time = execution_date_format.strftime("%Y%m%d%H%M%S")
    execution_time = datetime.now().astimezone(est_tz).strftime("%Y%m%d%H%M%S")
    print("execution_time -> ", execution_time)
    # csv_date_dynamic = (execution_date_format).strftime("%m%d%Y")
    # print("dynamically generated csv date -> ", csv_date_dynamic)
    return execution_time, execution_date


def copy_files_to_runtime_folder(**context):
    # copy files from raw bucket to runtime folder
    execution_time = context["task_output"][0]
    try:
        copy_file = GCSToGCSOperator(
            task_id='copy_files_to_runtime_folder',
            source_bucket=derived_bucket_name,
            source_object=f"{source_folder_path}/{source_file_name}",
            destination_bucket=derived_bucket_name,
            destination_object=f"{source_folder_path}/{runtime_folder_path}_{execution_time}/",
            move_object=False,
        )
        copy_file.execute(dict(context))
    except Exception:
        raise AirflowException("Error in copying file")


def copy_files_to_composer_bucket(**context):
    # copy files from raw bucket to composer bucket
    try:
        copy_file = GCSToGCSOperator(
            task_id='copy_files_to_composer_bucket',
            source_bucket=derived_bucket_name,
            source_object=f"{source_folder_path}/{source_file_name}",
            destination_bucket=composer_bucket_name,
            destination_object=f"{composer_folder_path}/",
            move_object=False,
        )
        copy_file.execute(dict(context))
    except Exception:
        raise AirflowException("Error in copying file")


def export_file_to_ftp(**context):
    """
    function to export file to FTP
    """
    execution_time = context["task_output"][0]
    local_file_path = f"{local_path}/{folder_path}"

    gcs_to_ftp = FTPFileTransmitOperator(
        task_id="gcs_to_ftp",
        ftp_conn_id=ftp_conn_id,
        local_filepath=f"{local_file_path}/{destination_folder}/{source_file_name}",
        remote_filepath=f"{ftp_source_dir}/{execution_time}_{source_file_name}",
        operation=FTPOperation.PUT,
    )
    gcs_to_ftp.execute(dict(context))


with DAG(
    dag_id="ex__product_uber__aggr_accident_date_gcs_to_ftp",
    schedule_interval=None,
    start_date=datetime(2023, 7, 17),
    tags=["ubermart", "gcs", "ftp"],
    catchup=False,
) as dag:

    get_execution_time = PythonOperator(
        task_id="get_execution_time",
        python_callable=get_execution_time_func,
        dag=dag
    )

    # copy files from derived bucket to runtime folder
    copy_files_to_runtime_folder = PythonOperator(
        task_id="copy_files_to_runtime_folder",
        python_callable=copy_files_to_runtime_folder,
        op_kwargs={
            "task_output": get_execution_time.output
        },
        dag=dag,
    )

    # copy files from derived bucket to composer bucket
    copy_files_to_composer_bucket = PythonOperator(
        task_id="copy_files_to_composer_bucket",
        python_callable=copy_files_to_composer_bucket,
        dag=dag,
    )

    # send files to ftp
    gcs_to_ftp = PythonOperator(
        task_id="gcs_to_ftp",
        python_callable=export_file_to_ftp,
        op_kwargs={
            "task_output": get_execution_time.output
        },
        dag=dag,
    )

    # delete files from composer bucket
    delete_files_from_composer_bucket = GCSDeleteObjectsOperator(
        task_id="delete_files_from_composer_bucket",
        bucket_name=composer_bucket_name,
        objects=[f"{composer_folder_path}/{source_file_name}"]
    )

(
    get_execution_time
    >> copy_files_to_runtime_folder
    >> copy_files_to_composer_bucket
    >> gcs_to_ftp
    >> delete_files_from_composer_bucket
)
