from airflow import DAG
import datetime
from airflow.providers.google.cloud.operators.bigquery import BigQueryDeleteTableOperator
from providers.definity.gcp.operators.exf_audit_init import GetRuntimeArgsInitiateExportAudit
from providers.definity.gcp.operators.exf_check_target_type import CheckTargetType
from providers.definity.gcp.operators.exf_databricks_task import FixedWidthRDBMSExportTask
from providers.definity.gcp.operators.exf_audit_update import ExportAuditStatusUpdate
from providers.definity.gcp.operators.exf_bq_gcs_tasks import BigQueryTempTableToGCS, ExecuteSrcQueryToBQTempTable
from providers.definity.gcp.operators.exf_gcs_external import GCSToExternal

dag_id = 'ex_product_uber_aggr_accident_date_report_to_gcs'
job_name = 'ex_product_uber_aggr_accident_date_report_to_gcs'
tag_list = ['ExportFramework', 'Quantiphi', 'ubermart']
schedule_interval = None
owner = 'Quantiphi'
default_args = {
    'owner': owner
}

with DAG(
        dag_id=dag_id,
        tags=tag_list,
        default_args={
            'email_on_failure': False,
        },
        schedule_interval=schedule_interval,
        start_date=datetime.datetime(2022, 12, 19),
        catchup=False
) as dag:
    auditInit = GetRuntimeArgsInitiateExportAudit(task_id='get_runtime_args', job_name=job_name)

    bq_execute_query = ExecuteSrcQueryToBQTempTable(task_id='execute_src_query', job_name=job_name)

    check_file_format = CheckTargetType(
        task_id='check_file_format'
    )

    export_bq_table_to_fxd_wdth = FixedWidthRDBMSExportTask(task_id='export_bq_table_to_fxd_wdth', job_name=job_name)

    export_bq_table_to_on_prem = FixedWidthRDBMSExportTask(task_id='export_bq_table_to_on_prem', job_name=job_name)

    export_bq_table_to_gcs = BigQueryTempTableToGCS(task_id='export_bq_table_to_gcs', job_name=job_name)

    delete_bq_table = BigQueryDeleteTableOperator(
        task_id='delete_bq_table',
        deletion_dataset_table="{{ti.xcom_pull(task_ids='get_runtime_args', key='bq_table_id')}}",
        trigger_rule='none_failed'
    )

    auditUpdate = ExportAuditStatusUpdate(task_id='update_audit_status', job_name=job_name)

    export_gcs_to_external = GCSToExternal(
        task_id='export_gcs_to_external',
        job_name=job_name,
        trigger_rule='none_failed'
    )

(
    auditInit
    >> bq_execute_query
    >> check_file_format
    >> [export_bq_table_to_gcs, export_bq_table_to_fxd_wdth, export_bq_table_to_on_prem]
)

(
    [export_bq_table_to_gcs, export_bq_table_to_fxd_wdth] >> export_gcs_to_external
)

(
    [export_bq_table_to_on_prem, export_gcs_to_external] >> delete_bq_table >> auditUpdate
)
