from datetime import datetime
import pytz
from airflow import DAG
from google.cloud import storage, bigquery
from airflow.exceptions import AirflowException
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator

raw_project_name = Variable.get("raw_project_name")
raw_bucket_name = Variable.get("raw_bucket_name")
curated_project = Variable.get("curated_project_name")
derived_project = Variable.get("derived_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
derived_bucket_name = Variable.get("derived_bucket_name")

gwpc_policy_variables = Variable.get("gwpc_export_variables", deserialize_json=True)

dataset_name = gwpc_policy_variables["derived_dataset_name"]
file_name = gwpc_policy_variables["file_name_policy"]

framework_path = gwpc_policy_variables["framework_path"]
troubleshooting_path = gwpc_policy_variables["troubleshooting_path"]
job_book_path = gwpc_policy_variables["job_book_path"]

bigquery_client = bigquery.Client(project=derived_project)
storage_client = storage.Client(project=raw_project_name)
est_tz = pytz.timezone("America/Toronto")


def get_date_func(**context):
    execution_date = context["dag_run"].conf.get("run_date")
    jbv_current_date = execution_date
    jbv_last_extract_date = gwpc_policy_variables["jbv_last_extract_date_policy"]
    if jbv_last_extract_date == "":
        jbv_last_extract_date = execution_date
    if jbv_current_date and jbv_last_extract_date and jbv_current_date >= jbv_last_extract_date:
        print(jbv_current_date, jbv_last_extract_date)
    else:
        raise AirflowException("Missing Date parameter")
    return str(jbv_current_date), str(jbv_last_extract_date)


def set_execution_time(**context):
    execution_time = datetime.now().astimezone(est_tz).strftime("%Y%m%d%H%M%S%f")[:-3]
    task_instance = context["task_instance"]
    task_instance.xcom_push(key="timestamp", value=execution_time)


def get_file_date_suffix(**context):
    jbv_current_date, jbv_last_extract_date = context["ti"].xcom_pull(task_ids=get_date.task_id)
    query = (
        "select cast(dd.calender_date as String) jbv_date , dd.date_dim_key date_dim_key           "
        "  from `@curated.centralise_ref_tables.datamart_dim_date` dd 	        where "
        " '@jbv_current_date' = dd.calender_date"
    )
    query = query.replace("@curated", curated_project).replace(
        "@jbv_current_date", jbv_current_date
    )
    try:
        print("Executing Query: ", query)
        query_job_bound = bigquery_client.query(query)
        result = query_job_bound.result()
        for row in result:
            date_dim_key = row.date_dim_key
        task_instance = context["task_instance"]
        task_instance.xcom_push(key="file_suffix", value=date_dim_key)
        return date_dim_key
    except Exception:
        raise AirflowException("Error while running query")


with DAG(
    "ex_gwpc_policy_staging_GCS",
    schedule_interval=None,
    start_date=datetime(2023, 10, 11),
    max_active_runs=1,
    catchup=False,
) as dag:
    get_date = PythonOperator(
        task_id="get_date", python_callable=get_date_func, provide_context=True
    )

    trigger_export_gwpc_policy_staging = TriggerDagRunOperator(
        task_id="trigger_export_gwpc_policy_staging",
        trigger_dag_id="ex_gwpc_policy_staging",
        wait_for_completion=True,
        poke_interval=60,
        dag=dag,
    )

    set_execution_time = PythonOperator(
        task_id="set_execution_time",
        python_callable=set_execution_time,
        dag=dag,
    )

    get_file_date_suffix = PythonOperator(
        task_id="get_file_date_suffix",
        python_callable=get_file_date_suffix,
        dag=dag,
    )

    # copy to runtime in derived
    move_to_runtime_folder = GCSToGCSOperator(
        task_id="move_to_runtime_folder",
        source_bucket=derived_bucket_name,
        source_object=f"{dataset_name}/{file_name}.csv",
        destination_bucket=derived_bucket_name,
        destination_object=f"{dataset_name}/runtime_"
        + "{{task_instance.xcom_pull(task_ids='set_execution_time',key='timestamp')}}"
        + f"/output/{file_name}_"
        + "{{task_instance.xcom_pull(task_ids='get_file_date_suffix',key='file_suffix')}}"
        + ".csv",  # YYYYMMDDHHMMSS
        move_object=True,
    )

dag.doc_md = f"""
### DAG Documentation
- Job Description - Export Job to extract gwpc customer and policy table data
from BigQuery to GCS.
- For the Framework Details - Please refer to this
<a href={framework_path} target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href={troubleshooting_path} target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href={job_book_path} target="_blank" style="color:blue"><u>link</u></a>
"""
(
    get_date
    >> trigger_export_gwpc_policy_staging
    >> set_execution_time
    >> get_file_date_suffix
    >> move_to_runtime_folder
)
