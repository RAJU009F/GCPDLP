package com.economical.sdp.mq.util;

import org.apache.beam.sdk.harness.JvmInitializer;
import com.google.cloud.secretmanager.v1.AccessSecretVersionResponse;
import com.google.cloud.secretmanager.v1.SecretManagerServiceClient;
import com.google.cloud.secretmanager.v1.SecretVersionName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class FetchMqSecretsFromSecretManager {

    private static final Logger LOG = LoggerFactory.getLogger(FetchMqSecretsFromSecretManager.class);


    private static final String SECRETVERSION = "latest";

    public String fetchMqSecretValueFromSecretManager(String projectId, String secretId) throws IOException {
        String secretValue = "";
        try (SecretManagerServiceClient client = SecretManagerServiceClient.create()) {
            SecretVersionName secretVersionName = SecretVersionName.of(projectId, secretId, SECRETVERSION);
            AccessSecretVersionResponse response = client.accessSecretVersion(secretVersionName);
            secretValue = response.getPayload().getData().toStringUtf8();
        } catch (IOException e) {
            LOG.error("ERROR :while fetching secrets from SecretManager " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            LOG.error("ERROR :while fetching secrets from SecretManager " + e.getMessage());
            e.printStackTrace();
        }
        return secretValue;
    }

}
