package com.economical.sdp.mq.options;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.options.*;

public interface MqToGcsOptions extends PipelineOptions, StreamingOptions, DataflowPipelineOptions {
    @Validation.Required
    int getNumOfShards();

    void setNumOfShards(int numOfShards);

    @Validation.Required
    ValueProvider<String> getGcsOutput();

    void setGcsOutput(ValueProvider<String> gcsOutput);

    @Validation.Required
    ValueProvider<String> getMqChannel();

    void setMqChannel(ValueProvider<String> mqChannel);

    @Validation.Required
    ValueProvider<String> getMqManager();

    void setMqManager(ValueProvider<String> mqManager);

    @Validation.Required
    ValueProvider<String> getMqUserSecret();

    void setMqUserSecret(ValueProvider<String> mqUserSecret);

    @Validation.Required
    ValueProvider<String> getMqPasswordSecret();

    void setMqPasswordSecret(ValueProvider<String> mqPasswordSecret);

    @Validation.Required
    ValueProvider<Integer> getMqPort();

    void setMqPort(ValueProvider<Integer> mqPort);

    @Validation.Required
    ValueProvider<String> getMqHost();

    void setMqHost(ValueProvider<String> mqHost);

    @Validation.Required
    ValueProvider<String> getBucketName();

    void setBucketName(ValueProvider<String> bucketName);

    @Validation.Required
    ValueProvider<String> getMqQueue();

    void setMqQueue(ValueProvider<String> mqQueue);

    @Validation.Required
    long getWindowDuration();

    void setWindowDuration(long windowDuration);

    @Validation.Required
    ValueProvider<String> getEnv();

    void setEnv(ValueProvider<String> env);

    @Validation.Required
    ValueProvider<String> getMqChannelLb();

    void setMqChannelLb(ValueProvider<String> mqChannelLb);

    @Validation.Required
    ValueProvider<String> getMqManagerLb();

    void setMqManagerLb(ValueProvider<String> mqManagerLb);

    @Validation.Required
    ValueProvider<String> getMqUserSecretLb();

    void setMqUserSecretLb(ValueProvider<String> mqUserSecretLb);

    @Validation.Required
    ValueProvider<String> getMqPasswordSecretLb();

    void setMqPasswordSecretLb(ValueProvider<String> mqPasswordSecretLb);

    @Validation.Required
    ValueProvider<Integer> getMqPortLb();

    void setMqPortLb(ValueProvider<Integer> mqPortLb);

    @Validation.Required
    ValueProvider<String> getMqHostLb();

    void setMqHostLb(ValueProvider<String> mqHostLb);


    @Validation.Required
    ValueProvider<String> getMqQueueLb();
    void setMqQueueLb(ValueProvider<String> mqQueueLb);

    @Validation.Required
    ValueProvider<String> getMqLbEnvFlag();
    void setMqLbEnvFlag(ValueProvider<String> mqLbEnvFlag);

    @Validation.Required
    ValueProvider<String> getBatchEnableFlag();
    void setBatchEnableFlag(ValueProvider<String> batchEnableFlag);

}
