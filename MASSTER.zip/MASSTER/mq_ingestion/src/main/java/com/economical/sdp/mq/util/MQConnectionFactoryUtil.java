package com.economical.sdp.mq.util;

import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.JMSException;
import java.io.IOException;

public class MQConnectionFactoryUtil {
    private static final Logger LOG = LoggerFactory.getLogger(MQConnectionFactoryUtil.class);

    public MQConnectionFactory init(String mqHost, String mqPort, String mqManager, String mqChannel, String mqUserSecret, String mqPasswordSecret, String project) throws JMSException, IOException {

        FetchMqSecretsFromSecretManager fetchMqSecretsdFromSecretManager = new FetchMqSecretsFromSecretManager();
        String mqPassword = fetchMqSecretsdFromSecretManager.fetchMqSecretValueFromSecretManager(project, mqPasswordSecret);
        String mqUser = fetchMqSecretsdFromSecretManager.fetchMqSecretValueFromSecretManager(project, mqUserSecret);

        MQConnectionFactory connectionFactory = new MQConnectionFactory();
        connectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
        connectionFactory.setHostName(mqHost);
        connectionFactory.setPort(Integer.valueOf(mqPort));
        connectionFactory.setQueueManager(mqManager);
        connectionFactory.setChannel(mqChannel);
        connectionFactory.setStringProperty(WMQConstants.USERID, mqUser);
        connectionFactory.setStringProperty(WMQConstants.PASSWORD, mqPassword);
        return connectionFactory;

    }

}
