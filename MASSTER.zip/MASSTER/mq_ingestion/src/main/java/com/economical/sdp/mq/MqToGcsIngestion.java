package com.economical.sdp.mq;

import com.economical.sdp.mq.util.FetchMqSecretsFromSecretManager;
import com.economical.sdp.mq.options.MqToGcsOptions;
import com.economical.sdp.mq.util.MQConnectionFactoryUtil;
import com.google.cloud.storage.*;
import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.jms.JmsIO;
import org.apache.beam.sdk.io.jms.JmsRecord;
import org.apache.beam.sdk.metrics.MetricNameFilter;
import org.apache.beam.sdk.metrics.MetricQueryResults;
import org.apache.beam.sdk.metrics.MetricsFilter;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.beam.runners.dataflow.DataflowRunner;
import org.apache.beam.sdk.PipelineResult;
import org.springframework.objenesis.strategy.SingleInstantiatorStrategy;

import static java.nio.charset.StandardCharsets.UTF_8;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import java.io.IOException;

public class MqToGcsIngestion {
    private static final Logger LOG = LoggerFactory.getLogger(MqToGcsIngestion.class);

    public static void main(String[] args) {

        final String MQTOGC_SMETRIC_NAMESPACE = "MQTOGC_SMETRIC_NAMESPACE";
        try {
            MqToGcsOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(MqToGcsOptions.class);

            options.setRunner(DataflowRunner.class);
            options.setUsePublicIps(false);
            options.setStreaming(true);


            options.setRegion(String.valueOf(options.getRegion()));
            options.setGcpTempLocation(String.valueOf(options.getTempLocation()));
            options.setStagingLocation(String.valueOf(options.getStagingLocation()));
            options.setSubnetwork(String.valueOf(options.getSubnetwork()));
            options.setJobName(options.getJobName());
            options.setServiceAccount(options.getServiceAccount());
            options.setDataflowServiceOptions(options.getDataflowServiceOptions());

            PipelineResult result;

            if (options.getBatchEnableFlag().toString().equalsIgnoreCase("true")) {

                if (options.getMqLbEnvFlag().toString().equalsIgnoreCase("true")) {
                    result = runMultipleSources(options);

                } else {
                    result = run(options);
                }

            } else {
                if (options.getMqLbEnvFlag().toString().equalsIgnoreCase("true")) {
                    result = runMultipleSourcesStream(options);

                } else {
                    result = runStream(options);
                }

            }
            result.waitUntilFinish();

            // Dataflow Job metrics of events
            MetricQueryResults metrics = result.metrics()
                    .queryMetrics(
                            MetricsFilter.builder()
                                    .addNameFilter(MetricNameFilter.named("MQTOGC_SMETRIC_NAMESPACE", "MQTOGCS_SUCCESS"))
                                    .addNameFilter(MetricNameFilter.named("MQTOGC_SMETRIC_NAMESPACE", "MQTOGCS_FAILURE"))
                                    .build());

        } catch (Exception e) {

            if (e instanceof IllegalArgumentException) {
                LOG.error("ERROR MQTOGCS -Please Provide the correct parameter and values ", e.getMessage());
                e.printStackTrace();
                System.exit(1);
            } else {
                LOG.error("ERROR MQTOGCS -Please check the google runtime error log", e.getMessage(), e);
                e.printStackTrace();
                System.exit(1);

            }
        }
    }


    public static PipelineResult runMultipleSources(MqToGcsOptions options) throws JMSException {

        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);
        LOG.info("start Reading from MQ");

        try {
            ConnectionFactory connectionFactory = new MQConnectionFactoryUtil().init(options.getMqHost().toString(), options.getMqPort().toString(), options.getMqManager().toString(), options.getMqChannel().toString(), options.getMqUserSecret().toString(), options.getMqPasswordSecret().toString(), options.getProject());

            ConnectionFactory connectionFactoryLb = new MQConnectionFactoryUtil().init(options.getMqHostLb().toString(), options.getMqPortLb().toString(), options.getMqManagerLb().toString(), options.getMqChannelLb().toString(), options.getMqUserSecretLb().toString(), options.getMqPasswordSecretLb().toString(), options.getProject());


            PCollection<JmsRecord> JmsRecordMQ = pipeline.apply("Read From MQ", JmsIO.read()
                    .withConnectionFactory(connectionFactory)
                    .withQueue(String.valueOf(options.getMqQueue())));

            PCollection<String> JmsRecordMQStrings = JmsRecordMQ.apply("extract payloads", ParDo.of(new DoFn<JmsRecord, String>() {    // a DoFn as an anonymous inner class instance
                @ProcessElement
                public void processElement(@Element JmsRecord message, OutputReceiver<String> out) {

                    out.output(message.getPayload());
                }
            }));
            PCollection<JmsRecord> JmsRecordMQLb = pipeline.apply("Read From MQ", JmsIO.read()
                    .withConnectionFactory(connectionFactoryLb)
                    .withQueue(String.valueOf(options.getMqQueueLb())));

            PCollection<String> JmsRecordMQLbStrings = JmsRecordMQLb.apply("extract payloads", ParDo.of(new DoFn<JmsRecord, String>() {    // a DoFn as an anonymous inner class instance
                @ProcessElement
                public void processElement(@Element JmsRecord message, OutputReceiver<String> out) {

                    out.output(message.getPayload());
                }
            }));


            PCollectionList<String> collectionList = PCollectionList.of(JmsRecordMQStrings).and(JmsRecordMQLbStrings);
            PCollection<String> mergedCollectionWithFlatten = collectionList
                    .apply(Flatten.<String>pCollections());

            mergedCollectionWithFlatten.apply("Fire Every Ns", Window.<String>configure().triggering(
                    Repeatedly.forever(
                            AfterProcessingTime.pastFirstElementInPane()
                                    .plusDelayOf(Duration.standardSeconds(options.getWindowDuration()))))
                    .discardingFiredPanes())
                    .apply("Write to GCS", TextIO.write()
                            .to(options.getGcsOutput())
                            .withWindowedWrites()
                            .withNumShards(options.getNumOfShards()));

        } catch (Exception e) {
            LOG.error("ERROR MQTOGCS-Unable to process the pipeline", e.getMessage());
            e.printStackTrace();

        }

        return pipeline.run();//.waitUntilFinish();
    }

    public static PipelineResult run(MqToGcsOptions options) throws JMSException {

        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);
        LOG.info("start Reading from MQ");

        try {
            MQConnectionFactory connectionFactory = new MQConnectionFactoryUtil().init(options.getMqHost().toString(), options.getMqPort().toString(), options.getMqManager().toString(), options.getMqChannel().toString(), options.getMqUserSecret().toString(), options.getMqPasswordSecret().toString(), options.getProject());


            pipeline.apply("Read From MQ", JmsIO.read()
                    .withConnectionFactory(connectionFactory)
                    .withQueue(String.valueOf(options.getMqQueue())))

                    .apply("extract payloads", ParDo.of(new DoFn<JmsRecord, String>() {    // a DoFn as an anonymous inner class instance
                        @ProcessElement
                        public void processElement(@Element JmsRecord message, OutputReceiver<String> out) {

                            out.output(message.getPayload());
                        }
                    }))
                    .apply("Fire Every Ns", Window.<String>configure().triggering(
                            Repeatedly.forever(
                                    AfterProcessingTime.pastFirstElementInPane()
                                            .plusDelayOf(Duration.standardSeconds(options.getWindowDuration()))))
                            .discardingFiredPanes())
                    .apply("Write to GCS", TextIO.write()
                            .to(options.getGcsOutput())
                            .withWindowedWrites()
                            .withNumShards(options.getNumOfShards()));


        } catch (Exception e) {
            LOG.error("ERROR MQTOGCS-Unable to process the pipeline", e.getMessage());
            e.printStackTrace();

        }


        return pipeline.run();//.waitUntilFinish();
    }

    public static PipelineResult runMultipleSourcesStream(MqToGcsOptions options) throws JMSException {

        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);
        LOG.info("start Reading from MQ");

        try {
            ConnectionFactory connectionFactory = new MQConnectionFactoryUtil().init(options.getMqHost().toString(), options.getMqPort().toString(), options.getMqManager().toString(), options.getMqChannel().toString(), options.getMqUserSecret().toString(), options.getMqPasswordSecret().toString(), options.getProject());

            ConnectionFactory connectionFactoryLb = new MQConnectionFactoryUtil().init(options.getMqHostLb().toString(), options.getMqPortLb().toString(), options.getMqManagerLb().toString(), options.getMqChannelLb().toString(), options.getMqUserSecretLb().toString(), options.getMqPasswordSecretLb().toString(), options.getProject());


            PCollection<JmsRecord> JmsRecordMQ = pipeline.apply("Read From MQ", JmsIO.read()
                    .withConnectionFactory(connectionFactory)
                    .withQueue(String.valueOf(options.getMqQueue())));

            PCollection<JmsRecord> JmsRecordMQLb = pipeline.apply("Read From MQ", JmsIO.read()
                    .withConnectionFactory(connectionFactoryLb)
                    .withQueue(String.valueOf(options.getMqQueueLb())));


            PCollectionList<JmsRecord> collectionList = PCollectionList.of(JmsRecordMQ).and(JmsRecordMQLb);
            PCollection<JmsRecord> mergedCollectionWithFlatten = collectionList
                    .apply(Flatten.<JmsRecord>pCollections());

            mergedCollectionWithFlatten.apply("Extract N Write To GCS", ParDo.of(new DoFn<JmsRecord, String>() {    // a DoFn as an anonymous inner class instance
                @ProcessElement
                public void processElement(ProcessContext c, OutputReceiver<String> out) {

                    MqToGcsOptions options = c.getPipelineOptions().as(MqToGcsOptions.class);

                    // Create your service object
                    Storage storage = (Storage) StorageOptions.getDefaultInstance().getService();
                    long currentTimeMillis = System.currentTimeMillis();

                    // Upload a blob to the newly created bucket
                    BlobId blobId = BlobId.of(options.getBucketName().toString(), options.getGcsOutput().toString() + currentTimeMillis);

                    BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("text/plain").build();
                    @SuppressWarnings("unused")
                    Blob blob = storage.create(blobInfo, c.element().getPayload().getBytes(UTF_8));
                    // out.output(c.element().getPayload());

                }
            }));


        } catch (Exception e) {
            LOG.error("ERROR MQTOGCS-Unable to process the pipeline", e.getMessage());
            e.printStackTrace();

        }

        return pipeline.run();//.waitUntilFinish();
    }

    public static PipelineResult runStream(MqToGcsOptions options) throws JMSException {

        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);
        LOG.info("start Reading from MQ");

        try {
            MQConnectionFactory connectionFactory = new MQConnectionFactoryUtil().init(options.getMqHost().toString(), options.getMqPort().toString(), options.getMqManager().toString(), options.getMqChannel().toString(), options.getMqUserSecret().toString(), options.getMqPasswordSecret().toString(), options.getProject());

            pipeline.apply("Read From MQ", JmsIO.read()
                    .withConnectionFactory(connectionFactory)
                    .withQueue(String.valueOf(options.getMqQueue())))

                    .apply("Extract N Write To GCS", ParDo.of(new DoFn<JmsRecord, String>() {    // a DoFn as an anonymous inner class instance
                        @ProcessElement
                        public void processElement(ProcessContext c, OutputReceiver<String> out) {

                            MqToGcsOptions options = c.getPipelineOptions().as(MqToGcsOptions.class);

                            // Create your service object
                            Storage storage = (Storage) StorageOptions.getDefaultInstance().getService();
                            long currentTimeMillis = System.currentTimeMillis();

                            // Upload a blob to the newly created bucket
                            BlobId blobId = BlobId.of(options.getBucketName().toString(), options.getGcsOutput().toString() + currentTimeMillis);

                            BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("text/plain").build();
                            @SuppressWarnings("unused")
                            Blob blob = storage.create(blobInfo, c.element().getPayload().getBytes(UTF_8));
                            // out.output(c.element().getPayload());

                        }
                    }));


        } catch (Exception e) {
            LOG.error("ERROR MQTOGCS-Unable to process the pipeline", e.getMessage());
            e.printStackTrace();

        }

        return pipeline.run();//.waitUntilFinish();
    }

}
