CREATE TABLE IF NOT EXISTS `@curated_project.thirdparty_reports.cgi_mvr`
(
  dlh_batch_ts DATETIME NOT NULL,
  dlh_process_ts DATETIME NOT NULL,
  firstName STRING NOT NULL,
  lastName STRING NOT NULL,
  dateOfBirth STRING NOT NULL,
  customerDnl STRING NOT NULL,
  rawData STRING,
  version INT64 NOT NULL,
  recordSource STRING NOT NULL,
  rawData_json STRING
)
PARTITION BY DATE(dlh_batch_ts);

CREATE TABLE IF NOT EXISTS `@curated_project.thirdparty_reports.cgi_autoplus`
(
  dlh_batch_ts DATETIME NOT NULL,
  dlh_process_ts DATETIME NOT NULL,
  customerDnl STRING NOT NULL,
  rawData STRING,
  version INT64 NOT NULL,
  recordSource STRING NOT NULL,
  rawData_json STRING
)
PARTITION BY DATE(dlh_batch_ts);

CREATE TABLE IF NOT EXISTS `@curated_project.thirdparty_reports.transunion_creditreport`
(
  dlh_batch_ts DATETIME NOT NULL,
  dlh_process_ts DATETIME NOT NULL,
  transUnionRawResponse STRING,
  firstName STRING NOT NULL,
  lastName STRING NOT NULL,
  dateOfBirth STRING NOT NULL,
  rawData STRING,
  version INT64 NOT NULL,
  recordSource STRING NOT NULL,
  rawData_json STRING
)
PARTITION BY DATE(dlh_batch_ts);

CREATE TABLE IF NOT EXISTS `@curated_project.thirdparty_reports.opta_fus`
(
  dlh_batch_ts DATETIME NOT NULL,
  dlh_process_ts DATETIME NOT NULL,
  addressLine STRING NOT NULL,
  city STRING NOT NULL,
  postalCode STRING NOT NULL,
  province STRING NOT NULL,
  rawData STRING,
  version INT64 NOT NULL,
  recordSource STRING NOT NULL
)
PARTITION BY DATE(dlh_batch_ts);

CREATE TABLE IF NOT EXISTS `@curated_project.thirdparty_reports.dmti_elevation`
(
  dlh_batch_ts DATETIME NOT NULL,
  dlh_process_ts DATETIME NOT NULL,
  addressLine STRING NOT NULL,
  city STRING NOT NULL,
  postalCode STRING NOT NULL,
  province STRING NOT NULL,
  rawData STRING,
  version INT64 NOT NULL,
  recordSource STRING NOT NULL
)
PARTITION BY DATE(dlh_batch_ts);


CREATE TABLE IF NOT EXISTS `@curated_project.thirdparty_reports.opta_iclarify`
(
  dlh_batch_ts DATETIME NOT NULL,
  dlh_process_ts DATETIME NOT NULL,
  addressLine STRING NOT NULL,
  city STRING NOT NULL,
  postalCode STRING NOT NULL,
  province STRING NOT NULL,
  rawData STRING,
  version INT64 NOT NULL,
  recordSource STRING NOT NULL,
  rawData_json STRING
)
PARTITION BY DATE(dlh_batch_ts);

CREATE TABLE IF NOT EXISTS `@curated_project.thirdparty_reports.dmti_proximity_water`
(
  dlh_batch_ts DATETIME NOT NULL,
  dlh_process_ts DATETIME NOT NULL,
  addressLine STRING NOT NULL,
  city STRING NOT NULL,
  postalCode STRING NOT NULL,
  province STRING NOT NULL,
  rawData STRING,
  version INT64 NOT NULL,
  recordSource STRING NOT NULL
)
PARTITION BY DATE(dlh_batch_ts);

CREATE TABLE IF NOT EXISTS `@curated_project.thirdparty_reports.gaa_fcsa`
(
  dlh_batch_ts DATETIME NOT NULL,
  dlh_process_ts DATETIME NOT NULL,
  customerDnl STRING NOT NULL,
  rawData STRING,
  version	INT64 NOT NULL,
  recordSource STRING NOT NULL,
  rawData_json STRING
)
PARTITION BY DATE(dlh_batch_ts);

CREATE TABLE IF NOT EXISTS `@curated_project.thirdparty_reports.cgi_manual_mvr` (
    dlh_batch_ts DATETIME NOT NULL,
    dlh_process_ts DATETIME NOT NULL,
    requestReceipt STRING,
    requestDate STRING,
    retrievalDate STRING,
    matchResult STRING,
    version STRING NOT NULL,
    driverInformation
        STRUCT<
            firstName STRING,
            lastName STRING,
            gender STRING,
            dateOfBirth STRING,
            maritalStatus STRING,
            licenceNumber STRING,
            licenceProvince STRING,
            licenceStatus STRING,
            licenceMVRClass STRING,
            licenceCondition STRING,
            licenceEndorsement STRING,
            licenceIssueDate STRING,
            licenceExpiryDate STRING,
            isLicenceSuspended STRING,
            demeritPoints STRING,
            conviction 
                ARRAY<
                    STRUCT<
                        convictionCode STRING,
                        ministryCode STRING,
                        type STRING,
                        description STRING,
                        convictionDate STRING,
                        severity STRING,
                        userOverride BOOL,
                        source STRING,
                        lastUpdatedUserId STRING
                >>,
            suspension 
                ARRAY<
                    STRUCT<
                        type STRING,
                        description STRING,
                        suspensionCode STRING,
                        suspendDate STRING,
                        reinstateDate STRING,
                        administrative BOOL,
                        source STRING
                >>,
            licenceClass 
                ARRAY<
                    STRUCT<
                        classCode STRING,
                        issueDate STRING
                >>
        >,
    firstName STRING,
    lastName STRING,
    dateOfBirth STRING,
    customerDln STRING
)
PARTITION BY DATE(dlh_batch_ts);
CREATE TABLE IF NOT EXISTS `@curated_project.thirdparty_reports.manual_driver_info` (
    dlh_batch_ts DATETIME NOT NULL,
    dlh_process_ts DATETIME NOT NULL,
    customerDln string,
    gender STRING,
    maritalStatus STRING,
    reportRequestUserId STRING,
    reportStatus STRING,
	reportSource string,
	lastUpdDate INT64 NOT NULL,
	lastUpdUserId string,
    errorMessage STRING,
    firstName STRING,
    lastName STRING,
    dateOfBirth STRING,
    version STRING NOT NULL
)
PARTITION BY DATE(dlh_batch_ts);