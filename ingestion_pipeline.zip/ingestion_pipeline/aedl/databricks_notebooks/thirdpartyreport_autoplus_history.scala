/* Domain:  Thirdpartyreport
   Qualifier: CA
   Version:  1.0
   Date:  2023-05-12
   Comments: N/A
   Team:  Data Engineering
*/


import com.databricks.spark.xml.functions.from_xml
import com.databricks.spark.xml.schema_of_xml
import org.apache.spark.sql.functions.{trim, to_json, col, udf, from_unixtime, round, current_timestamp, to_timestamp, from_utc_timestamp}
import org.apache.spark.sql.types._
import org.apache.spark.sql.SaveMode
import spark.sqlContext.implicits._
import org.apache.hadoop.fs._
import org.apache.spark.sql.types.{DataType, StructType}
import scala.collection.JavaConversions._
import org.apache.spark.sql.DataFrame
import org.apache.avro._
import org.apache.spark.sql.avro._


val MAX_LONG_VAL = (9223372036854775807L)
val temporaryGcsBucket = dbutils.widgets.get("bigquery_temp_bucket")
val project_id = dbutils.widgets.get("project_id")
val ingestion_bucket = dbutils.widgets.get("ingestion_bucket")
val temp_table_id = dbutils.widgets.get("temp_table_id")
val bq_table_id = dbutils.widgets.get("bq_table_id")
val dataset = dbutils.widgets.get("dataset")
val partitionField = dbutils.widgets.get("partitionField")
val partitionType = dbutils.widgets.get("partitionType")
val domain = dbutils.widgets.get("domain")
val root_table = dbutils.widgets.get("root_table")
val root_table_modifier = dbutils.widgets.get("root_table_modifier")
val root_table_category = dbutils.widgets.get("root_table_category")
val fileformat = dbutils.widgets.get("fileformat")
//val curr_hour=dbutils.widgets.get("hour")
val avroSchemaFileName = bq_table_id + ".avsc"


val destination_project_dataset_table = project_id + "." + dataset + "." + temp_table_id
val conf = sc.hadoopConfiguration
val fileloc = "gs://" + ingestion_bucket + "/" + domain + "/data/source/" + root_table_modifier + "/" + root_table_category + "/*." + fileformat
val srcgcsbucket = "gs://" + ingestion_bucket + "/" + domain + "/data/source/" + root_table_modifier + "/" + root_table_category
val avroSchemaFilePath = "gs://" + ingestion_bucket + "/" + domain + "/code/schema/" + avroSchemaFileName
val dt = java.time.LocalDate.now.toString

print("INFO: Pipeline started: " + dt + "\n")

// STEP1:  Get list of files to process
val gcsBucket = new Path(srcgcsbucket)
val filesIter = gcsBucket.getFileSystem(conf).listFiles(gcsBucket, true)

//Initialise variables
var files = Seq[Path]()
var df_src_gcs_raw_file = spark.emptyDataFrame
var df_write_final = spark.emptyDataFrame
var df_src_bq = spark.emptyDataFrame
var df_src_gcs_raw = spark.emptyDataFrame
var df_src_gcs_raw_file_with_ts_fields = spark.emptyDataFrame
var sparkSchema: StructType = new StructType
var avroschema: String = ""


def convertSchemaToString(schema: StructType): StructType =  {
	def convertDataType(dataType: DataType): DataType = dataType match {
	case structType: StructType =>
	val convertedFields= structType.fields.map(field => field.copy(dataType = convertDataType(field.dataType)))
	StructType(convertedFields)
	case arrayType: ArrayType =>
	ArrayType(convertDataType(arrayType.elementType))
	case _ =>
	StringType
	
	}
	val convertedFields = schema.fields.map{field =>
	val convertedType = convertDataType(field.dataType)
	field.copy(dataType = convertedType)
	}
		StructType(convertedFields)
		}

while (filesIter.hasNext) {
  files = files :+ filesIter.next().getPath
}
print("INFO: Files to process \n")
for (files <- files) {
  print(files + "\n")
}

// STEP2:  Read source files in GCS bucket in spark dataframe 
print("INFO: Read data into dataframe from src GCS bucket \n")

if (files.isEmpty) {

  print("ERROR: No files to process.  Read data failed. \n")
  dbutils.notebook.exit("ERROR: No files to process.    Exit Notebook. \n")
}


//  Read avro schema  
val dfAvroSchema = spark.read.option("wholetext", true).text(avroSchemaFilePath)
avroschema = dfAvroSchema.collect()(0)(0).toString
val schemaAvro = new Schema.Parser().parse(avroschema)
df_src_gcs_raw_file = spark.read.format(fileformat).option("avroSchema", schemaAvro.toString).load(fileloc)


//add two required fields . Attach the new schema on the dataframe. This would ensure not null contraints as enforced by avro schema on spark dataframe
//convert avro schema to spark schema    
for (field <- schemaAvro.getFields()) {
  val nullable = field.hasDefaultValue()
  sparkSchema = sparkSchema.add(field.name, SchemaConverters.toSqlType(field.schema).dataType, nullable)
}


//add two additional fields with not null constraint to the schema (nullable =false)
sparkSchema = sparkSchema.add("etl_timestamp1", org.apache.spark.sql.types.TimestampType, false).add("record_timestamp1", org.apache.spark.sql.types.TimestampType, false)
df_src_gcs_raw_file_with_ts_fields = df_src_gcs_raw_file.withColumn("etl_timestamp1", to_timestamp(current_timestamp(), "yyyy-MM-dd HH:mm:ss.nnnnnn").as("current_timestamp")).withColumn("record_timestamp1", (round(-(col("version").cast(LongType) - MAX_LONG_VAL) / 1000, 0).cast(LongType).cast(TimestampType)))
//attach the new schema to the dataframe
df_src_gcs_raw = df_src_gcs_raw_file_with_ts_fields.sqlContext.createDataFrame(df_src_gcs_raw_file_with_ts_fields.rdd, sparkSchema)


// STEP4:  Transform xml and other fields.
print("INFO: Started Transformation Data Step. \n")
//df_src_gcs_raw.select("rawData").show(1)
val xmlSchema = convertSchemaToString(schema_of_xml(df_src_gcs_raw.select("rawData").as[String]))
print("INFO: XML schema obtained")
val df_extracted = df_src_gcs_raw.withColumn("rawData_preprocessed", from_xml($"rawData", xmlSchema)).withColumn("rawData_json", to_json($"rawData_preprocessed"))
print("INFO: Added new field rawData_json")
val df_extracted_write = df_extracted
  .drop("rawData_preprocessed")
  .select("*")

// STEP5: Re-order columns
print("INFO: Reorder columns. \n")
val df_src_gcs = df_extracted_write.select($"record_timestamp1".alias("dlh_batch_ts"), $"etl_timestamp1".alias("dlh_process_ts"), $"*").drop("record_timestamp1").drop("etl_timestamp1")

df_write_final = df_src_gcs
print("INFO: Count before final write: " + df_write_final.count() + "\n")


print("INFO: Save data to temp table \n")
// STEP8:  Write the final dataframe to curated BQ table
df_write_final.write.format("bigquery").option("SchemaUpdateOption", "ALLOW_FIELD_ADDITION").option("partitionField", partitionField).option("temporaryGcsBucket", temporaryGcsBucket).option("partitionType", partitionType).option("table", destination_project_dataset_table).option("require_partition_filter", "True").mode(SaveMode.Overwrite).save
