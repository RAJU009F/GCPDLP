// Databricks notebook source
/* Domain:  Quote
   Description:  Sonnet Unsaved quotes program.  Data ingested from gcs raw zone and loaded into into bq partitioned table on a scheduled basis through airflow.
   Version:  1.0
   Date:  2022-12-01
   Comments: N/A
   Team:  Data Engineering
*/

import com.databricks.spark.xml.functions.from_xml
import com.databricks.spark.xml.schema_of_xml
import org.apache.spark.sql.functions.{trim, to_json,col, udf, from_unixtime, round, current_timestamp, to_timestamp, from_utc_timestamp}
import org.apache.spark.sql.types._
import org.apache.spark.sql.SaveMode
import spark.sqlContext.implicits._
import org.apache.hadoop.fs._
import org.apache.spark.sql.types.{DataType, StructType}
import scala.collection.JavaConversions._ 
import org.apache.spark.sql.DataFrame
import org.apache.avro._
import org.apache.spark.sql.avro._




def archivefiles(files: Seq[org.apache.hadoop.fs.Path]){
  try{
    for (files <- files) {
    print("INFO: Archiving file: " + files + "\n")
    val filestr = files.toString
    val filesdt = filestr.toString.split("/").take(8).last
    val archive_location_dt = archive_loc + filesdt
    dbutils.fs.mkdirs(archive_location_dt)
    dbutils.fs.mv(filestr, archive_location_dt)
   }
  }catch {
    case t: Throwable => t.printStackTrace()
      print("ERROR: Archival of files failed. \n")
    System.exit(-1)
 }
} 



def rejectFiles(files: Seq[org.apache.hadoop.fs.Path] ){
  try{
    for (files <- files) {
    print("INFO: Rejected file: " + files + "\n")
    val filestr = files.toString
    val filesdt = filestr.toString.split("/").take(8).last
    val rejected_location_dt = rejectedrec + filesdt
    dbutils.fs.mkdirs(rejected_location_dt)
    val reject_location_hour = rejected_location_dt + "/" +curr_hour
    dbutils.fs.mkdirs(reject_location_hour)
    dbutils.fs.mv(filestr, reject_location_hour)
   }
  }catch {
    case t: Throwable => t.printStackTrace()
      print("ERROR: Rejected file copy failed. \n")
      System.exit(-1)
 }
}  

val MAX_LONG_VAL = (9223372036854775807L)
val temporaryGcsBucket=dbutils.widgets.get("bigquery_temp_bucket")
val project_id=dbutils.widgets.get("project_id")
val ingestion_bucket=dbutils.widgets.get("ingestion_bucket")
val table_id=dbutils.widgets.get("table_id")
val dataset=dbutils.widgets.get("dataset")
val partitionField=dbutils.widgets.get("partitionField")
val partitionType=dbutils.widgets.get("partitionType")
val domain=dbutils.widgets.get("domain")
val topic=dbutils.widgets.get("topic")
val fileformat=dbutils.widgets.get("fileformat")
val curr_hour=dbutils.widgets.get("hour")
val avroSchemaFileName=table_id+".avsc"
//val topic="aws.prod01.pi.cmd.quoteandrecommendation.0"

val destination_project_dataset_table=project_id + "." + dataset + "." + table_id
val conf = sc.hadoopConfiguration
val fileloc =  "gs://"+ ingestion_bucket +"/"+ domain + "/data/" + table_id + "/" + topic + "/*/*." + fileformat
val archive_loc = "gs://"+ ingestion_bucket +"/"+ domain + "/data/archive/" +table_id +"/"
val srcgcsbucket = "gs://"+ ingestion_bucket +"/"+ domain + "/data/" + table_id + "/" + topic 
val avroSchemaFilePath = "gs://"+ ingestion_bucket +"/"+ domain +"/code/schema/" + avroSchemaFileName
val dt = java.time.LocalDate.now.toString
val rejectedrec = "gs://"+ ingestion_bucket +"/"+ domain + "/data/rejected/" +table_id +"/"

print("INFO: Pipeline started: " + dt + "\n")

// STEP1:  Get list of files to process
val gcsBucket = new Path(srcgcsbucket)
val filesIter = gcsBucket.getFileSystem(conf).listFiles(gcsBucket, true)

//Initialise variables
var files = Seq[Path]()
var df_src_gcs_raw_file = spark.emptyDataFrame
var df_write_final = spark.emptyDataFrame
var df_src_bq = spark.emptyDataFrame
var df_src_gcs_raw = spark.emptyDataFrame
var df_src_gcs_raw_file_with_ts_fields = spark.emptyDataFrame
var sparkSchema : StructType = new StructType
var avroschema :String =""

while (filesIter.hasNext) {
    files = files :+ filesIter.next().getPath
}
print("INFO: Files to process \n")
for (files <- files) { print(files + "\n")}

// STEP2:  Read source files in GCS bucket in spark dataframe 
print("INFO: Read data into dataframe from src GCS bucket \n")

if ( files.isEmpty ){
  
    print("ERROR: No files to process.  Read data failed. \n")
    dbutils.notebook.exit("ERROR: No files to process.    Exit Notebook. \n")
}




try{
   //  Read avro schema  
   print("INFO: Read avro schema \n")
   val dfAvroSchema = spark.read.option("wholetext", true).text(avroSchemaFilePath)
   avroschema = dfAvroSchema.collect()(0)(0).toString
   print("INFO: Parse avro schema \n")
   val schemaAvro = new Schema.Parser().parse(avroschema) 
   df_src_gcs_raw_file = spark.read.format(fileformat).option("avroSchema", schemaAvro.toString).load(fileloc)

   
//add two required fields . Attach the new schema on the dataframe. This would ensure not null contraints as enforced by avro schema on spark dataframe
//convert avro schema to spark schema    
 for(field <- schemaAvro.getFields()){
  val nullable =field.hasDefaultValue()
  sparkSchema = sparkSchema.add(field.name, SchemaConverters.toSqlType(field.schema).dataType ,nullable )
 }
  }catch {
    case t: Throwable => t.printStackTrace()
    print("ERROR: Avro file read Failed ")
    rejectFiles(files)
    System.exit(-1)
    //dbutils.notebook.exit("ERROR: No files to process.  Read failed.  Exit Notebook. \n")
}

try
{


 //add two additional fields with not null constraint to the schema (nullable =false)
 sparkSchema = sparkSchema.add("etl_timestamp1", org.apache.spark.sql.types.TimestampType ,false ).add("record_timestamp1", org.apache.spark.sql.types.TimestampType ,false)
 df_src_gcs_raw_file_with_ts_fields=df_src_gcs_raw_file.withColumn("etl_timestamp1",  to_timestamp(current_timestamp(),"yyyy-MM-dd HH:mm:ss.nnnnnn").as ("current_timestamp")).withColumn("record_timestamp1",(round(-(col("version").cast(LongType) - MAX_LONG_VAL)/1000,0).cast(LongType).cast(TimestampType)))
 //attach the new schema to the dataframe
 df_src_gcs_raw=df_src_gcs_raw_file_with_ts_fields.sqlContext.createDataFrame( df_src_gcs_raw_file_with_ts_fields.rdd, sparkSchema )
}
catch {
    case t: Throwable => t.printStackTrace()
    print(t)
    print("ERROR: Avro schema error \n")
    rejectFiles(files)
    System.exit(-1)
}
  
  
try
{
// STEP4:  Transform xml and other fields.
print("INFO: Transform data. \n")

val xmlSchema = schema_of_xml(df_src_gcs_raw.select("xml").as[String])
print("INFO: XML schema obtained")
val df_extracted = df_src_gcs_raw.withColumn("xml_preprocessed", from_xml($"xml", xmlSchema)).withColumn("xml_json", to_json($"xml_preprocessed"))
print("INFO: Added new field xml_json")
val df_extracted_write=df_extracted
                        .drop("xml_preprocessed")
                        .select("*")

// STEP5: Re-order columns

print("INFO: Reorder columns. \n")
val df_src_gcs = df_extracted_write.select($"record_timestamp1".alias("dlh_batch_ts"), $"etl_timestamp1".alias("dlh_process_ts"), $"*").drop("record_timestamp1").drop("etl_timestamp1")


print("INFO:  Read the curated table last 7 days partition data \n")
  
// STEP6:  Read the curated table last 7 days partition data.
df_src_bq = spark.read.format("bigquery").option("table", destination_project_dataset_table).option("filter", "DATE(dlh_batch_ts) > DATE_SUB(current_date(), INTERVAL 7 DAY)").load()

print("INFO: Count before left anti join: " + df_src_gcs.count() + "\n")

// STEP7:  Perform left anti join to only get rows that are not matched from the gcs df.
//val df_write_final = df_src_gcs.alias("dfgcs").join(
df_write_final = df_src_gcs.join(
    df_src_bq, 
    df_src_gcs("firstName") <=> df_src_bq("firstName")
        && df_src_gcs("lastName") <=> df_src_bq("lastName")
        && df_src_gcs("policyIdentifier") <=> df_src_bq("policyIdentifier")
        && df_src_gcs("dateOfBirth") <=> df_src_bq("dateOfBirth")
        && df_src_gcs("version") <=> df_src_bq("version")
        && df_src_gcs("quoteType") <=> df_src_bq("quoteType")
        && df_src_gcs("productType") <=> df_src_bq("productType"),
    "left_anti"
)


val cnt = df_write_final.count()
print ("INFO: Count after left anti join: " + cnt + "\n")
}
  catch {
    case t: Throwable => t.printStackTrace()
    print("ERROR: Spark transformation failed \n")
    rejectFiles(files)
    System.exit(-1)
}
  
  


try{ 
 
 print("INFO: Save data to curated table \n")

// STEP8:  Write the final dataframe to curated BQ table
  df_write_final.write.format("bigquery").option("SchemaUpdateOption","ALLOW_FIELD_ADDITION").option("partitionField",partitionField).option("temporaryGcsBucket",temporaryGcsBucket).option("partitionType",partitionType).option("table",destination_project_dataset_table).option("require_partition_filter", "True").mode(SaveMode.Append).save
}catch {
    case t: Throwable => t.printStackTrace()
    print("ERROR: Bigquery Write failed \n")
    rejectFiles(files)
    System.exit(-1)
}

// STEP9:  Archive files to archive location
print("INFO: Biqquery write succeded \n")
print("INFO: Archive files. \n")
val result1 = archivefiles(files)
val dt_end = java.time.LocalDate.now.toString
print("INFO: Pipeline completed: " + dt_end + " \n")

