/* Domain:  thirdparty_reports_realtime
   Type: Without xml to json conversion
   Description:  Data ingested from gcs raw zone and loaded into avro files
   Version:  1.0
   Date:  2023-08-14
   Comments: N/A
   Author: Sakthi Venkatesan
   Team:  Data Engineering
*/

import com.databricks.spark.xml.functions.from_xml
import com.databricks.spark.xml.schema_of_xml
import org.apache.spark.sql.functions.{trim, to_json,col, udf, from_unixtime, round, current_timestamp, to_timestamp, from_utc_timestamp}
import org.apache.spark.sql.types._
import org.apache.spark.sql.SaveMode
import spark.sqlContext.implicits._
import org.apache.hadoop.fs._
import org.apache.spark.sql.types.{DataType, StructType}
import scala.collection.JavaConversions._
import org.apache.spark.sql.DataFrame
import org.apache.avro._
import org.apache.spark.sql.avro._
import java.io._
import org.apache.commons.io.FilenameUtils

/*Flatten struct type schema recursively*/
def getFlattenedColumnNames(schema: StructType, prefix: String = ""):
Array[String] = {
  schema.fields.flatMap{
    field =>
      val fieldName = if(prefix.isEmpty) field.name else s"$prefix.${field.name}"
      field.dataType match{
        case st:StructType =>getFlattenedColumnNames(st,fieldName)
        case at:ArrayType => getFlattenedColumnNames(at,fieldName)
        case _ => Array(fieldName)

      }

  }
}

/*Flatten Schema with nested arrays recursively*/
def getFlattenedColumnNames(arrayType: ArrayType, prefix: String):
Array[String] = {
  arrayType.elementType match{
    case st: StructType =>getFlattenedColumnNames(st,prefix)
    case at:ArrayType => getFlattenedColumnNames(at,prefix)
    case _ => Array(prefix)
  }}

/*
Generate all the hierarchy levels from deeply nested schema 
*/
def generateCombinations(set: Set[String]): Set[String]={
  def splitAndCombine(s: String): Set[String] = {
    s.split("\\.").inits.filter(_.nonEmpty).map(_.mkString(".")).toSet
  }
  set.flatMap(splitAndCombine)
}


/* Get new fields in the schema1 which is not present in schema2
@return new fields as comma separated string

*/
def compareAndGetNewColumns(schema1: StructType,schema2: StructType): String=
{

  val flattenedColumnNamesSchema1 = getFlattenedColumnNames(schema1,"")
  val flattenedColumnNamesSchema2 = getFlattenedColumnNames(schema2,"")
  val set1 = flattenedColumnNamesSchema1.map(_.toLowerCase).toSet
  val set2 = flattenedColumnNamesSchema2.map(_.toLowerCase).toSet
  var newFieldsSet = scala.collection.mutable.Set[String]()
  val setDiff=set1.diff(generateCombinations(set2))
  print("New fields in Schema ")
  print(setDiff)
  setDiff.mkString(",")
}

def isSubset(schema1: StructType,schema2: StructType): Boolean=
{

  val flattenedColumnNamesSchema1 = getFlattenedColumnNames(schema1,"")
  val flattenedColumnNamesSchema2 = getFlattenedColumnNames(schema2,"")
  val set1 = flattenedColumnNamesSchema1.map(_.toLowerCase).toSet
  val set2 = flattenedColumnNamesSchema2.map(_.toLowerCase).toSet
  //check if set2(json feed) is a subset of set1(.avsc schema provided)
  set1.subsetOf(generateCombinations(set2))

}



def pathExists(tablePath: String): Boolean = {
  try{
    dbutils.fs.ls(tablePath)
    return true
  } catch {
    case e: java.io.FileNotFoundException => println("Given path cannot be located")
      return false
  }
}


def writeAuditFile(status :String,total_record_count :String,source_files : String,rejectedFiles : String,error_message : String, filePath : String){
  try{

    val auditJson: String = s"""{"status":"$status","total_record_count":"$total_record_count","source_files":"$source_files","rejectedFiles":"$rejectedFiles","error_message":"$error_message"}"""
    dbutils.fs.put(filePath,auditJson,true)

  }catch {
    case t: Throwable => t.printStackTrace()
      print("ERROR: Audit Write failed \n")
      System.exit(-1)
  }
}

def archivefiles(files: Seq[org.apache.hadoop.fs.Path]){
  try{
    for (files <- files) {
      //print("INFO: Archiving file: " + files + "\n")
      val filestr = files.toString
      val filesdt = filestr.toString.split("/").take(9).last
      val archive_location_dt = archive_loc + filesdt
      dbutils.fs.mkdirs(archive_location_dt)
      dbutils.fs.mv(filestr, archive_location_dt)
    }
  }catch {
    case t: Throwable => t.printStackTrace()
      print("ERROR: Archival of files failed. \n")
      System.exit(-1)
  }
}

def convertSchemaToString(schema: StructType): StructType =  {
	def convertDataType(dataType: DataType): DataType = dataType match {
	case structType: StructType =>
	val convertedFields= structType.fields.map(field => field.copy(dataType = convertDataType(field.dataType)))
	StructType(convertedFields)
	case arrayType: ArrayType =>
	ArrayType(convertDataType(arrayType.elementType))
	case _ =>
	StringType
	
	}
	val convertedFields = schema.fields.map{field =>
	val convertedType = convertDataType(field.dataType)
	field.copy(dataType = convertedType)
	}
		StructType(convertedFields)
		}


def rejectFiles(files: Seq[org.apache.hadoop.fs.Path] ): String = {
  var rejectfiles = ""
  try{
    for (files <- files) {
      print("INFO: Rejected file: " + files + "\n")
      val filestr = files.toString
      val filesdt = filestr.toString.split("/").take(9).last
      val rejected_location_dt = rejectedrec + filesdt
      dbutils.fs.mkdirs(rejected_location_dt)
      val reject_location_hour = rejected_location_dt + "/" +curr_hour
      dbutils.fs.mkdirs(reject_location_hour)
      dbutils.fs.mv(filestr, reject_location_hour)
      rejectfiles= rejectfiles + "," + reject_location_hour + "/" + filestr.toString.split("/").take(11).last
    }
  }catch {
    case t: Throwable => t.printStackTrace()
      print("ERROR: Rejected file copy failed. \n")
      System.exit(-1)
  }
  return rejectfiles.substring(1)

}



/*
Todo:
1.Customize error message
2.Type changes error(read with json file and proceed)
3.corrupt_records and files identification
4.output to json and then load
5.
*/

val MAX_LONG_VAL = (9223372036854775807L)

val temporaryGcsBucket=dbutils.widgets.get("bigquery_temp_bucket")
val project_id=dbutils.widgets.get("project_id")
val ingestion_bucket=dbutils.widgets.get("ingestion_bucket")
val table_id=dbutils.widgets.get("table_id")
val dataset=dbutils.widgets.get("dataset")
val partitionField=dbutils.widgets.get("partitionField")
val partitionType=dbutils.widgets.get("partitionType")
val domain=dbutils.widgets.get("domain")
val topic=dbutils.widgets.get("topic")
val fileformat=dbutils.widgets.get("fileformat")
val curr_hour=dbutils.widgets.get("hour")
val avroSchemaFileName=table_id+".avsc"
//val audit_path=dbutils.widgets.get("audit_path")
val lob=dbutils.widgets.get("lob")
val parent_table=dbutils.widgets.get("parent_table")

/*
val temporaryGcsBucket="def-dev-raw-bucket"
val project_id="dp-dev-curated-5fb7"
val ingestion_bucket="def-dev-raw-bucket"
val table_id="thirdpartyreport_mvr"
val dataset="aedl"
val partitionField="dlh_batch_ts"
val partitionType="DAY"
val domain="pi_quote"
val topic="aws.dtb.pi.cmd.tprd.cm.0"
val fileformat="json"
val curr_hour="00_00_00"
val avroSchemaFileName=table_id+".avsc"
//val audit_path=domain + "/data/audit/" +table_id +"_audit.json"
val lob="mvr"
val parent_table="thirdpartyreport"
*/


var errorMessage =""
val audit_path=domain + "/data/audit/" +table_id +"_audit.json"
val json_status_file="gs://"+ ingestion_bucket +"/"+ audit_path
val conf = sc.hadoopConfiguration
val fileloc =  "gs://"+ ingestion_bucket +"/"+ domain + "/data/source/"  + lob  + "/" + topic + "/*/*.json"
val archive_loc = "gs://"+ ingestion_bucket +"/"+ domain + "/data/processed/"  + lob  + "/" + topic + "/"
val srcgcsbucket = "gs://"+ ingestion_bucket +"/"+ domain + "/data/source/"  + lob  + "/" + topic
val avroSchemaFilePath = "gs://"+ ingestion_bucket +"/"+ domain +"/code/schema/" + avroSchemaFileName
val dt = java.time.LocalDate.now.toString
val rejectedrec = "gs://"+ ingestion_bucket +"/"+ domain + "/data/rejected/"  + lob  + "/" + topic + "/"
val temp_location = "gs://"+ ingestion_bucket +"/"+ domain + "/data/pre-processing/"  + lob  + "/" + topic + "/temp"

//val library = "gs://" + ingestion_bucket + "/" + dataset + "/code/config/library/spark-xml_2.12-0.15.0.jar"

print("INFO: Pipeline started: " + dt + "\n")

// STEP1:  Get list of files to process
val gcsBucket = new Path(srcgcsbucket)
val filesIter = gcsBucket.getFileSystem(conf).listFiles(gcsBucket, true)

//Initialise variables
var files = Seq[Path]()
var df_src_gcs_raw_file = spark.emptyDataFrame
var df_write_final = spark.emptyDataFrame
var df_src_bq = spark.emptyDataFrame
var df_src_gcs_raw = spark.emptyDataFrame
var df_src_gcs_raw_file_with_ts_fields = spark.emptyDataFrame
var sparkSchema : StructType = new StructType
var avroschema :String =""
var df_write_final_val = spark.emptyDataFrame
var fileNames : String =""
var fileNamesList : String =""
var src_count : String =""

//Added condition to fail if we have files other than json extension in landing folder
while (filesIter.hasNext) {
  files = files :+ filesIter.next().getPath
}
print("INFO: Files to process \n")
for (files <- files) { //print(files + "\n")
  fileNames = fileNames +","+ files
  if (FilenameUtils.getExtension(fileNames) != "json") {
      print("ERROR: Files with extension other than json found in landing path" + "\n")
      print(fileNames + "\n")
	    val filestr = files.toString
      val filesdt = filestr.toString.split("/").take(9).last
      val rejected_location_dt = rejectedrec + filesdt
      dbutils.fs.mkdirs(rejected_location_dt)
      val reject_location_hour = rejected_location_dt + "/" +curr_hour
      dbutils.fs.mkdirs(reject_location_hour)
      dbutils.fs.mv(filestr, reject_location_hour)
      writeAuditFile("FAILED","0","",filestr,"Databricks ERROR: File with extension other than json found in landing path", json_status_file)
      System.exit(-1)
      }
}



// STEP2:  Read source files in GCS bucket in spark dataframe 
print("INFO: Read data into dataframe from src GCS bucket \n")

if ( files.isEmpty ){

  print("ERROR: No files to process.  Read data failed. \n")
  writeAuditFile("SUCCESS","0","","","Databricks ERROR:  No files to process", json_status_file)
  dbutils.notebook.exit("ERROR: No files to process.    Exit Notebook. \n")
}

try{
  // Read avro schema 
  fileNamesList= fileNames.substring(1)

  val dfAvroSchema = spark.read.option("wholetext", true).text(avroSchemaFilePath)
  avroschema = dfAvroSchema.collect()(0)(0).toString
  val schemaAvro = new Schema.Parser().parse(avroschema)
  print(fileloc)
  //convert avro schema to spark schema    
  for(field <- schemaAvro.getFields()){
    val nullable =field.hasDefaultValue()
    sparkSchema = sparkSchema.add(field.name, SchemaConverters.toSqlType(field.schema).dataType ,nullable )
  }
  df_src_gcs_raw_file = spark.read.json(fileloc)
  val cnt = df_src_gcs_raw_file.count()
  src_count=String.valueOf(cnt)
  var isValidSchema=false
  var newColumns= ""
  errorMessage="Databricks ERROR: Json file read Failed.Please refer Databricks logs for details"

  if (isSubset(df_src_gcs_raw_file.schema,sparkSchema))
  {
    isValidSchema=true

  }

  else{
    newColumns =compareAndGetNewColumns(df_src_gcs_raw_file.schema,sparkSchema)
    print("NewColumns::"+newColumns)
    if (newColumns.isEmpty){
      isValidSchema=true
    }
    else{
      print("In else")
      if (!newColumns.isEmpty){
        print("In not empty")
        var column_list=""
        if(newColumns.contains("_corrupt_record")){
          column_list=newColumns.replace(",_corrupt_record","").replace("_corrupt_record,","").replace(",_corrupt_record,","").replace("_corrupt_record","")
        }
        else
        {
          column_list=newColumns
        }

        if(column_list.trim() =="")
        {
          print("EMPTY")
        }
        else
        {
          print("newcolumns available")
          val newcolArr=column_list.trim().split("\\,")
          print(newcolArr)
          if (newcolArr.length >=1)
          {
            print("length > 1")
            errorMessage="Databricks ERROR: Schema error. New fields found :" + column_list
            print(errorMessage)
            throw new Exception(errorMessage)
          }
        }


      }
    }}

  df_src_gcs_raw_file = spark.read.option("mode","FAILFAST").option("columnNameOfCorruptRecord","corrupt_record").schema(sparkSchema).json(fileloc)

  df_src_gcs_raw_file.printSchema()
  df_src_gcs_raw_file.show(1)
  print ("INFO: Records read " + cnt + "\n")
}catch {
  case t: Throwable => {
    //t.printStackTrace()
  }
    print("ERROR: Json file read Failed ")
    print("------------------------>")
    val exceptionMessage =t.getMessage
    var message=""
    val exceptionMessageTrace =t.getStackTrace.mkString("\n")




    val sw = new StringWriter
    t.printStackTrace(new PrintWriter(sw))
    val stackTrace = sw.toString
    print(stackTrace)
    print("------------------------>")
    if(errorMessage.contains("New fields found") || stackTrace.contains("New fields found"))
    {
      print("CASE 1: new Fields error---> ")
    }
    else if((exceptionMessage.contains("BadRecordException") && !exceptionMessage.contains("Failed to parse field name")) || (stackTrace.contains("BadRecordException") && !stackTrace.contains("Failed to parse field name")))
    {
      print("CASE 2: Bad record Error---> ")
      errorMessage="Databricks ERROR: Bad record Error.Please refer Databricks logs for details"

    }
    else if ((exceptionMessage.contains("Malformed records") || exceptionMessage.contains("Failed to parse field name")) || (stackTrace.contains("Malformed records") || stackTrace.contains("Failed to parse field name")))
    {
      print("CASE 3: Schema error---> ")
      errorMessage="Databricks ERROR: Schema error.Please refer Databricks logs for details"
    }
    val rejectfilesList = rejectFiles(files)
    //print(rejectfilesList)
    writeAuditFile("FAILED",src_count,fileNamesList,"",errorMessage, json_status_file)
    System.exit(-1)
}

try
  {
    print("In schema")
    df_src_gcs_raw=df_src_gcs_raw_file.sqlContext.createDataFrame( df_src_gcs_raw_file.rdd,sparkSchema )
    df_src_gcs_raw.printSchema

  }
catch {
  case t: Throwable => t.printStackTrace()
    print("ERROR: force schema Failed ")

    val rejectfilesList = rejectFiles(files)
    writeAuditFile("FAILED",src_count,fileNamesList,rejectfilesList,"Databricks ERROR: Avro schema error.Please refer Databricks logs for details", json_status_file)
    print("ERROR: Avro schema error \n")
    System.exit(-1)
}

try{

  print("INFO: Save data to intermediate layer \n")
  if (pathExists(temp_location))
  {
    dbutils.fs.rm(temp_location,true)

  }

df_src_gcs_raw.write.format("avro").save(temp_location)

}catch {
  case t: Throwable => t.printStackTrace()
    //t.getMessage()
    print("ERROR: Spark temp Write failed \n")
    val exceptionMessageTrace =t.getStackTrace.mkString("\n")
    val exceptionMessage =t.getMessage
    val sw = new StringWriter
    t.printStackTrace(new PrintWriter(sw))
    val stackTrace = sw.toString
    val rejectfilesList = rejectFiles(files)
    print("------------------------>")
    if ((exceptionMessage.contains("Malformed records") || exceptionMessage.contains("Failed to parse field name")) || (stackTrace.contains("Malformed records") || stackTrace.contains("Failed to parse field name")))
    {
      errorMessage="Databricks ERROR: Schema error.Please refer Databricks logs for details"
    }
    else
    {
      errorMessage="Databricks ERROR: Spark temp file write failed.Please refer Databricks logs for details"
    }
    print(exceptionMessage)
    print(exceptionMessageTrace)
    print("------------------------>")
    writeAuditFile("FAILED",src_count,fileNamesList,"",errorMessage, json_status_file)
    System.exit(-1)
}

// STEP9:  Archive files to archive location.
print("INFO: Archive files. \n")
val result1 = archivefiles(files)
val dt_end = java.time.LocalDate.now.toString
writeAuditFile("SUCCESS",src_count,fileNamesList,"","", json_status_file)
print("INFO: Pipeline completed: " + dt_end + " \n")
