/**
The spark process read data from bigquery temp table  convert xml into json string and store it as an additional field.
It is then loaded into a curated bigquery table paritioned with version_dt
*/
import com.databricks.spark.xml.functions.from_xml
import com.databricks.spark.xml.schema_of_xml
import org.apache.spark.sql.functions.{to_json,col, udf, from_unixtime, round, current_timestamp, to_timestamp, from_utc_timestamp}
import org.apache.spark.sql.types._
import org.apache.spark.sql.SaveMode
import spark.sqlContext.implicits._
import org.apache.spark.sql.Column

val MAX_LONG_VAL = (9223372036854775807L)
val temporaryGcsBucket=dbutils.widgets.get("bigquery_temp_bucket")
val project_id=dbutils.widgets.get("project_id")
val ingestion_bucket=dbutils.widgets.get("ingestion_bucket")
val temp_table_id=dbutils.widgets.get("temp_table_id")
val table_id=dbutils.widgets.get("table_id")
val dataset=dbutils.widgets.get("dataset")
val partitionField=dbutils.widgets.get("partitionField")
val partitionType=dbutils.widgets.get("partitionType")

val temp_dataset_table=project_id + "." + dataset + "." + temp_table_id
val destination_project_dataset_table=project_id + "." + dataset + "." + table_id

val df_src_bq_raw = spark.read.format("bigquery").option("table", temp_dataset_table).load()
val sparkSchemaWithNewFields = df_src_bq_raw.schema.add("record_timestamp1", org.apache.spark.sql.types.TimestampType ,false ).add("etl_timestamp1", org.apache.spark.sql.types.TimestampType ,false)
val df_src_bq_with_ts= df_src_bq_raw.withColumn("record_timestamp1",(round(-(col("version").cast(LongType) - MAX_LONG_VAL)/1000,0).cast(LongType).cast(TimestampType))).withColumn("etl_timestamp1", to_timestamp(current_timestamp(),"yyyy-MM-dd HH:mm:ss.nnnnnn").as ("current_timestamp"))
val df_src_bq = df_src_bq_with_ts.sqlContext.createDataFrame( df_src_bq_with_ts.rdd,sparkSchemaWithNewFields)

val xmlSchema = schema_of_xml(df_src_bq.select("xml").as[String])
val df_extracted = df_src_bq.withColumn("xml_preprocessed", from_xml($"xml", xmlSchema)).withColumn("xml_json", to_json($"xml_preprocessed"))

val df_extracted_write=df_extracted
                        .drop("xml_preprocessed")
                        .select("*")

val df_extracted_write_final = df_extracted_write.select($"record_timestamp1".alias("dlh_batch_ts"), $"etl_timestamp1".alias("dlh_process_ts"), $"*").drop("record_timestamp1").drop("etl_timestamp1")

df_extracted_write_final.write.format("bigquery").option("SchemaUpdateOption","ALLOW_FIELD_ADDITION").option("partitionField",partitionField).option("temporaryGcsBucket",temporaryGcsBucket).option("partitionType",partitionType).option("table",destination_project_dataset_table).option("require_partition_filter", "True").mode(SaveMode.Append).save