CREATE DATABASE IF NOT EXISTS thirdparty_reports;
CREATE TABLE IF NOT EXISTS thirdparty_reports.audit_log (
  job_id varchar(200)DEFAULT NULL,
  Task_Name varchar(200) DEFAULT NULL,
  start_time varchar(200) DEFAULT NULL,
  end_time varchar(200) DEFAULT NULL,
  status varchar(200) DEFAULT NULL,
  record_count varchar(200) DEFAULT NULL,
  source_files mediumtext ,
  rejected_files mediumtext ,
  message text 
) 