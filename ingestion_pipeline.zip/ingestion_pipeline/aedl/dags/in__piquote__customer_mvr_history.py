import os
from datetime import datetime
from airflow import DAG
from airflow.models import Variable
from airflow.providers.google.cloud.transfers.gcs_to_bigquery \
    import GCSToBigQueryOperator
from airflow.providers.google.cloud.operators.bigquery \
    import BigQueryExecuteQueryOperator
from airflow.providers.google.cloud.operators.bigquery \
    import BigQueryDeleteTableOperator
from airflow.contrib.operators.gcs_to_gcs  \
    import GoogleCloudStorageToGoogleCloudStorageOperator
project_id_curated = Variable.get("curated_project_name")
project_id_procesing = str(os.environ.get('procesing'))
project_id_raw = str(os.environ.get('raw'))
environ_curated = project_id_curated.split("-")[1]
dataset = "thirdparty_reports"
table_id = "customer_mvr"
parent_table = "customer"
lob = "mvr"
partitionField = "version_dt"
partitionType = "DAY"
domain = "customer"

hist_tab = domain + "/" + lob + \
    "/history"
dt = datetime.today().strftime('%Y-%m-%d')
raw_bucket = Variable.get("raw_bucket_name")
ingestion_bucket = raw_bucket
raw_gcs_id = "google_cloud_storage_default"
bigquery_id = "bigquery_default"
bigquery_temp_bucket = Variable.get("bigquery_temp_bucket")
source_object = "gs://" + ingestion_bucket + "/" + dataset + \
    "/data/source/" + hist_tab + "/*.avro"
source_object_path = dataset + "/data/source/" + hist_tab + "/*.avro"
destination_object = dataset + "/data/processed/" + hist_tab + "/" + \
    dt + "/"
temp_table_id = "temp_" + table_id
destination_project_dataset_table = project_id_curated + "." + \
    dataset + "." + temp_table_id
destination_project_dataset_final_table = project_id_curated + "." + \
    dataset + "." + table_id
sqlvalue = """
    SELECT DATETIME(
    CASE
    WHEN
    CHAR_LENGTH(CAST(version as string))<=10
    THEN
    CAST(SAFE.TIMESTAMP_SECONDS(version) as Timestamp)
    ELSE
    CAST(SAFE.TIMESTAMP_SECONDS(CAST(((9223372036854775807 -
    CAST( version AS INT64)) /1000 )  AS INT64)) as Timestamp)
    END) AS dlh_batch_ts,
    DATETIME(CURRENT_TIMESTAMP()) as dlh_process_ts,*
    from `""" + \
    destination_project_dataset_table + """`"""

if environ_curated == "dev":
    google_service_account = \
        "def-aedl-databricks@dp-dev-processing-4993.iam.gserviceaccount.com"
    node_type_id = "n2-standard-16"
    driver_node_type_id = "n2-standard-4"
    min_workers = 1
    max_workers = 5
elif environ_curated == "qa":
    google_service_account =  \
        "def-aedl-databricks@dp-qa-processing-7cc0.iam.gserviceaccount.com"
    node_type_id = "n2-standard-16"
    driver_node_type_id = "n2-standard-4"
    min_workers = 5
    max_workers = 20
else:
    google_service_account = \
        "def-aedl-databricks@dp-prod-processing-b757.iam.gserviceaccount.com"
    node_type_id = "n2-standard-16"
    driver_node_type_id = "n2-standard-4"
    min_workers = 5
    max_workers = 20

with DAG(
  dag_id='in__piquote__customer_mvr_history',
  schedule_interval='@once',
  start_date=datetime(2023, 1, 1),
  tags=['piquote', 'customer_mvr', 'history', 'curated',
        'customer', 'mvr'],
  catchup=False,
  ) as dag:

    customer_mvr_gcs_to_bq = GCSToBigQueryOperator(
        task_id='customer_mvr_gcs_to_bq',
        bucket=ingestion_bucket,
        source_objects=[source_object_path],
        destination_project_dataset_table=destination_project_dataset_table,
        source_format="AVRO",
        create_disposition="CREATE_IF_NEEDED",
        write_disposition="WRITE_TRUNCATE",
    )

    customer_mvr_bq_to_bq_curated = BigQueryExecuteQueryOperator(
        task_id="customer_mvr_bq_to_bq_curated",
        sql=sqlvalue,
        destination_dataset_table=destination_project_dataset_final_table,
        write_disposition="WRITE_APPEND",
        time_partitioning={'field': 'dlh_batch_ts', 'type': 'DAY'},
        gcp_conn_id=bigquery_id,
        allow_large_results=True,
        create_disposition='CREATE_IF_NEEDED',
        use_legacy_sql=False,
    )

    gcs_to_processed = GoogleCloudStorageToGoogleCloudStorageOperator(
        task_id='customer_mvr_gcs_landing_to_processed',
        source_bucket=ingestion_bucket,
        source_object=source_object_path,
        destination_bucket=ingestion_bucket,
        destination_object=destination_object,
        move_object=True,
    )

    customer_mvr_temp_table_delete = BigQueryDeleteTableOperator(
        task_id="customer_mvr_temp_table_delete",
        deletion_dataset_table=destination_project_dataset_table,
        gcp_conn_id=bigquery_id,
        ignore_if_missing=False
    )

customer_mvr_gcs_to_bq >> customer_mvr_bq_to_bq_curated >> gcs_to_processed >> customer_mvr_temp_table_delete
