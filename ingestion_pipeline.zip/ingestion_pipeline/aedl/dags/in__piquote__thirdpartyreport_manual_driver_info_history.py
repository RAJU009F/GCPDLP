from airflow import DAG
from airflow.providers.databricks.operators.databricks  \
    import DatabricksSubmitRunOperator
from pytz import timezone
from airflow.providers.google.cloud.transfers.gcs_to_bigquery \
    import GCSToBigQueryOperator
from airflow.providers.google.cloud.operators.bigquery \
    import BigQueryExecuteQueryOperator
from airflow.providers.google.cloud.operators.bigquery \
    import BigQueryDeleteTableOperator
from airflow.models import Variable
import datetime


project_id_curated = Variable.get("curated_project_name")
policy_id = Variable.get("aedl_policy_id")
db_availability = Variable.get("db_availability")
environ_curated = project_id_curated.split("-")[1]
dataset = "thirdparty_reports"
table_id = "manual_driver_info"
notebook_id = "thirdpartyreport_realtime_without_xml_conversion"
parent_table = "thirdpartyreport"
lob = "driver_info_manual"
partitionField = "dlh_batch_ts"
partitionType = "DAY"
domain = "thirdparty_reports"
hist_tab = table_id
execution_date = datetime.datetime.now()
yestdate = datetime.datetime.now() - datetime.timedelta(days=1)
dt = datetime.datetime.today().strftime('%Y-%m-%d')
hour_audit = datetime.datetime.now(timezone('EST')).strftime("%H")
dt_audit = datetime.datetime.today().strftime('%Y%m%d')
fileformat = "json"
hour = datetime.datetime.now(timezone('EST')).strftime("%H_%M_%S")
hour_audit = datetime.datetime.now(timezone('EST')).strftime("%H")
dt_audit = datetime.datetime.today().strftime('%Y%m%d')
raw_bucket = Variable.get("raw_bucket_name")
ingestion_bucket = raw_bucket
bigquery_id = "bigquery_default"
notebook_path = "/ingestion_pipeline/aedl/databricks_notebooks/" + notebook_id

raw_gcs_id = "google_cloud_storage_default"
bigquery_temp_bucket = Variable.get("bigquery_temp_bucket")
databricks_conn_id = "databricks_aedl"


library = "gs://" + ingestion_bucket + "/" + domain + \
    "/code/config/library/spark-xml_2.12-0.15.0.jar"
destination_object = dataset + "/data/processed/" + hist_tab + "/" + \
    dt + "/"
json_status_file_full_path = "gs://" + ingestion_bucket + "/" + domain + \
    "/data/audit/" + table_id + "_audit.json"
json_status_file_path = domain + \
    "/data/audit/" + table_id + "_audit.json"
temp_table_id = "temp_" + table_id
destination_project_dataset_table = project_id_curated + "." + \
    dataset + "." + temp_table_id
destination_project_dataset_final_table = project_id_curated + "." + \
    dataset + "." + table_id
sqlvalue = """
    SELECT DATETIME(
    CASE
    WHEN
    CHAR_LENGTH(CAST(version as string))<=10
    THEN
    CAST(SAFE.TIMESTAMP_SECONDS(CAST( version AS INT64)) as Timestamp)
    ELSE
    CAST(SAFE.TIMESTAMP_SECONDS(CAST(((9223372036854775807 -
    CAST( version AS INT64)) /1000 )  AS INT64)) as Timestamp)
    END) AS dlh_batch_ts,
    DATETIME(CURRENT_TIMESTAMP()) as dlh_process_ts,*
    from `""" + \
    destination_project_dataset_table + """`"""

if environ_curated == "dev":
    google_service_account = \
        "def-aedl-databricks@dp-dev-processing-4993.iam.gserviceaccount.com"
    topic = "history"
    node_type_id = "n2-standard-4"
    driver_node_type_id = "n2-standard-4"
    min_workers = 1
    max_workers = 2
    schedule_interval = '@once'
    start_date = yestdate
    max_active_runs = 1
elif environ_curated == "qa":
    google_service_account = \
        "def-aedl-databricks@dp-qa-processing-7cc0.iam.gserviceaccount.com"
    topic = "history"
    node_type_id = "n2-standard-4"
    driver_node_type_id = "n2-standard-4"
    min_workers = 5
    max_workers = 20
    schedule_interval = '@once'
    start_date = yestdate
    max_active_runs = 1
else:
    google_service_account = \
        "def-aedl-databricks@dp-prod-processing-b757.iam.gserviceaccount.com"
    topic = "history"
    node_type_id = "n2-standard-16"
    driver_node_type_id = "n2-standard-4"
    min_workers = 1
    max_workers = 2
    schedule_interval = '@once'
    start_date = yestdate
    max_active_runs = 1

source_object_path_temp = dataset + "/data/pre-processing" + \
    "/" + lob + "/" + topic + "/temp/*.avro"
source_object_path_temp_dir = dataset + "/data/pre-processing" + \
    "/" + lob + "/" + topic + "/temp"

new_cluster = {
        "spark_version": "10.4.x-scala2.12",
        "node_type_id": node_type_id,
        "driver_node_type_id": driver_node_type_id,
        "policy_id": policy_id,
        "max_active_runs": max_active_runs,
        "custom_tags": {
            "TeamName": "AEDL"
        },
        "gcp_attributes": {
            "google_service_account": google_service_account,
            "availability": db_availability,
            "zone_id": "HA"
        }
  }

base_parameters = {
                "bigquery_temp_bucket": bigquery_temp_bucket,
                "project_id": project_id_curated,
                "ingestion_bucket": ingestion_bucket,
                "table_id": table_id,
                "dataset": dataset,
                "partitionField": partitionField,
                "partitionType": partitionType,
                "topic": topic,
                "fileformat": fileformat,
                "domain": domain,
                "hour": hour,
                "lob": lob,
                "parent_table": parent_table,
  }


default_args = {
    'owner': 'aedl-migration',
    'depends_on_past': False,
    'retries': 0,
    'retry_delay': datetime.timedelta(minutes=5),
    'start_date': yestdate
}

with DAG(
  dag_id='in__piquote__thirdpartyreport_manual_driver_info_history',
  default_args=default_args,
  schedule_interval=schedule_interval,
  start_date=start_date,
  max_active_runs=max_active_runs,
  tags=['aedl', 'thirdpartyreport_manual_driver_info_history', 'hourly', 'curated', 'quote', 'VM'],
  catchup=False,
  ) as dag:

    task_1_gcs_src_preprocess = DatabricksSubmitRunOperator(
        task_id='task_1_gcs_src_preprocess',
        new_cluster=new_cluster,
        notebook_task={
            'notebook_path': notebook_path,
            'base_parameters': base_parameters
        },
        databricks_conn_id=databricks_conn_id,
        libraries=[
            {'jar': library}
        ],
        dag=dag,
    )
    task_2_gcs_preprocess_bq_temp = GCSToBigQueryOperator(
        task_id='task_2_gcs_preprocess_bq_temp',
        bucket=ingestion_bucket,
        source_objects=[source_object_path_temp],
        destination_project_dataset_table=destination_project_dataset_table,
        source_format="AVRO",
        create_disposition="CREATE_IF_NEEDED",
        write_disposition="WRITE_TRUNCATE",
        dag=dag,
    )
    task_3_bq_temp_curated = BigQueryExecuteQueryOperator(
        task_id="task_3_bq_temp_curated",
        sql=sqlvalue,
        destination_dataset_table=destination_project_dataset_final_table,
        write_disposition="WRITE_APPEND",
        time_partitioning={'field': 'dlh_batch_ts', 'type': 'DAY'},
        gcp_conn_id=bigquery_id,
        allow_large_results=True,
        create_disposition='CREATE_IF_NEEDED',
        use_legacy_sql=False,
        dag=dag,
    )
    task_4_delete_bq_temp_table = BigQueryDeleteTableOperator(
        task_id="task_4_delete_bq_temp_table",
        deletion_dataset_table=destination_project_dataset_table,
        gcp_conn_id=bigquery_id,
        ignore_if_missing=False
    )

task_1_gcs_src_preprocess >> task_2_gcs_preprocess_bq_temp
task_2_gcs_preprocess_bq_temp >> task_3_bq_temp_curated
task_3_bq_temp_curated >> task_4_delete_bq_temp_table
