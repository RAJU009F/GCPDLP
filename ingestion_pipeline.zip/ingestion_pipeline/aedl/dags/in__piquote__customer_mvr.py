from airflow import DAG
from airflow.providers.databricks.operators.databricks  \
    import DatabricksSubmitRunOperator
from airflow.operators.python_operator \
    import ShortCircuitOperator
from pytz import timezone
from airflow.providers.google.cloud.transfers.gcs_to_bigquery \
    import GCSToBigQueryOperator
from airflow.providers.google.cloud.operators.bigquery \
    import BigQueryExecuteQueryOperator
from airflow.providers.google.cloud.operators.bigquery \
    import BigQueryDeleteTableOperator
from airflow import AirflowException
from airflow.hooks.mysql_hook import MySqlHook
from airflow.models import Variable
from datetime import datetime
import logging
import json
import pytz
from airflow.contrib.hooks.gcs_hook import GoogleCloudStorageHook


project_id_curated = Variable.get("curated_project_name")
policy_id = Variable.get("aedl_policy_id")
db_availability = Variable.get("db_availability")
environ_curated = project_id_curated.split("-")[1]
dataset = "thirdparty_reports"
table_id = "customer_mvr"
parent_table = "customer"
lob = "mvr"
partitionField = "dlh_batch_ts"
partitionType = "DAY"
domain = "customer"
hist_tab = table_id
execution_date = datetime.now()
dt = datetime.today().strftime('%Y-%m-%d')
hour_audit = datetime.now(timezone('EST')).strftime("%H")
dt_audit = datetime.today().strftime('%Y%m%d')
fileformat = "json"
hour = datetime.now(timezone('EST')).strftime("%H_%M_%S")
hour_audit = datetime.now(timezone('EST')).strftime("%H")
dt_audit = datetime.today().strftime('%Y%m%d')
raw_bucket = Variable.get("raw_bucket_name")
ingestion_bucket = raw_bucket
bigquery_id = "bigquery_default"
notebook_path = "/ingestion_pipeline/aedl/databricks_notebooks/" + table_id
raw_gcs_id = "google_cloud_storage_default"
bigquery_temp_bucket = Variable.get("bigquery_temp_bucket")
databricks_conn_id = "databricks_aedl"


library = "gs://" + ingestion_bucket + "/" + dataset + \
    "/code/config/library/spark-xml_2.12-0.15.0.jar"
destination_object = dataset + "/data/processed/" + hist_tab + "/" + \
    dt + "/"
json_status_file_full_path = "gs://" + ingestion_bucket + "/" + dataset + \
    "/data/audit/" + table_id + "_audit.json"
json_status_file_path = dataset + \
    "/data/audit/" + table_id + "_audit.json"
temp_table_id = "temp_" + table_id
destination_project_dataset_table = project_id_curated + "." + \
    dataset + "." + temp_table_id
destination_project_dataset_final_table = project_id_curated + "." + \
    dataset + "." + table_id
sqlvalue = """
    SELECT DATETIME(
    CASE
    WHEN
    CHAR_LENGTH(CAST(version as string))<=10
    THEN
    CAST(SAFE.TIMESTAMP_SECONDS(version) as Timestamp)
    ELSE
    CAST(SAFE.TIMESTAMP_SECONDS(CAST(((9223372036854775807 -
    CAST( version AS INT64)) /1000 )  AS INT64)) as Timestamp)
    END) AS dlh_batch_ts,
    DATETIME(CURRENT_TIMESTAMP()) as dlh_process_ts,*
    from `""" + \
    destination_project_dataset_table + """`"""

if environ_curated == "dev":
    google_service_account = \
        "def-aedl-databricks@dp-dev-processing-4993.iam.gserviceaccount.com"
    topic = "aws.dev13.pi.cmd.customer.m.0"
    node_type_id = "n2-standard-4"
    driver_node_type_id = "n2-standard-4"
    min_workers = 1
    max_workers = 2
    schedule_interval = '0 * * * *'
    start_date = datetime(2023, 1, 1, 0, 0, 0)
    max_active_runs = 1
elif environ_curated == "qa":
    google_service_account = \
        "def-aedl-databricks@dp-qa-processing-7cc0.iam.gserviceaccount.com"
    topic = "aws.sit01.pi.cmd.customer.m.0"
    node_type_id = "n2-standard-4"
    driver_node_type_id = "n2-standard-4"
    min_workers = 5
    max_workers = 20
    schedule_interval = '0 * * * *'
    start_date = datetime(2023, 2, 24, 15, 0, 0)
    max_active_runs = 1
else:
    google_service_account = \
        "def-aedl-databricks@dp-prod-processing-b757.iam.gserviceaccount.com"
    topic = "aws.prod01.pi.cmd.customer.m.0"
    node_type_id = "n2-standard-16"
    driver_node_type_id = "n2-standard-4"
    min_workers = 1
    max_workers = 2
    schedule_interval = '0 * * * *'
    start_date = datetime(2023, 7, 13, 11, 0, 0)
    max_active_runs = 1

source_object_path_temp = dataset + "/data/pre-processing/" + parent_table + \
    "/" + lob + "/" + topic + "/temp/*.avro"
source_object_path_temp_dir = dataset + "/data/pre-processing/" + parent_table + \
    "/" + lob + "/" + topic + "/temp"

new_cluster = {
        "spark_version": "10.4.x-scala2.12",
        "node_type_id": node_type_id,
        "driver_node_type_id": driver_node_type_id,
        "policy_id": policy_id,
        "max_active_runs": max_active_runs,
        "custom_tags": {
            "TeamName": "AEDL"
        },
        "gcp_attributes": {
            "google_service_account": google_service_account,
            "availability": db_availability,
            "zone_id": "HA"
        }
  }

base_parameters = {
                "bigquery_temp_bucket": bigquery_temp_bucket,
                "project_id": project_id_curated,
                "ingestion_bucket": ingestion_bucket,
                "table_id": table_id,
                "dataset": dataset,
                "partitionField": partitionField,
                "partitionType": partitionType,
                "topic": topic,
                "fileformat": fileformat,
                "domain": domain,
                "hour": hour,
                "lob": lob,
                "parent_table": parent_table,
  }


def isFileExists():
    print("In file exists check")
    audit_config = readAuditJsonFile()
    record_count = audit_config["total_record_count"]
    if (record_count == "0" or record_count == ""):
        return False
    else:
        return True


def auditQueryBuilder(job_id, task_name, start_time, end_time, status,
                      record_count, source_files, rejected_files, message):
    query = 'INSERT INTO thirdparty_reports.audit_log(job_id,task_name,start_time,end_time,status' + \
            ',record_count,source_files,rejected_files,message)' \
            ' VALUES (\'' + job_id + '\', \
                      \'' + task_name + '\', \
                      \'' + start_time + '\', \
                      \'' + end_time + '\', \
                      \'' + status + '\', \
                      \'' + record_count + '\', \
                      \'' + source_files + '\', \
                      \'' + rejected_files + '\', \
                      \'' + message + '\');'
    return query


def auditSelectQueryBuilder():
    query = """ SELECT max(job_id) as job_id from thirdparty_reports.audit_log where \
             job_id like '%in__piquote__customer_mvr%' and \
             task_name="parent_task"
             """
    return query


def auditUpdateQueryBuilder(end_time, status,
                            job_id,  message, task_name):
    update_query = 'UPDATE  thirdparty_reports.audit_log set end_time=\
                    \'' + end_time + '\' , \
                    status=\
                    \'' + status + '\' ,\
                    message=\
                    \'' + message + '\' where job_id=\
                    \'' + job_id + '\' AND  task_name=\
                    \'' + task_name + '\''
    return update_query


def readAuditJsonFile():
    gcs_hook = GoogleCloudStorageHook()
    try:
        file_content = gcs_hook.download(ingestion_bucket, json_status_file_path)
        audit_config = json.loads(file_content)
    except Exception as e:
        logging.info("Json file read failed : " + str(e))
        audit_config = json.loads(""" {"error_message": "", "rejectedFiles": "",
          "source_files": "", "status": "", "total_record_count": ""}""")
    return audit_config


def deleteDirectory(bucket_name, dir_path):
    gcs_hook = GoogleCloudStorageHook()
    try:
        objects = gcs_hook.list(bucket_name, prefix=dir_path)
        val_names = ",".join([obj.name for obj in objects])
        print("Object names delete:" + val_names)
    except Exception as e:
        print("File delete failed" + str(e))


def deleteFileIfExists(bucket_name, file_path):
    gcs_hook = GoogleCloudStorageHook()
    try:
        gcs_hook.delete(bucket_name, file_path)
    except Exception as e:
        logging.info("File delete failed : " + str(e))


def execute_query(query):
    try:
        """Accepts a query and execute it on Cloud SQL"""
        mysql_hook = MySqlHook(mysql_conn_id='DCF_CloudSQL_conn', schema='thirdparty_reports')
        connection = mysql_hook.get_conn()
        cursor = connection.cursor()
        cursor.execute(query)
        output = cursor.fetchall()
        logging.info("executing query : " + query)
        connection.commit()
        cursor.close()
        return output
    except Exception as e:
        logging.info("Query Execution failed : " + str(e))
        raise AirflowException(f"Error while running query {query} using MySQL connection DCF_CloudSQL_conn")


def execute_cleanup_and_audit_fail(context):
    print("TASK FAILED")
    EST = pytz.timezone('US/Eastern')
    print("context:", context)
    ti = context['task_instance']
    print(f"task {ti.task_id } failed in dag  ")
    task_start_date = context['ti'].start_date
    task_end_date = context['ti'].end_date
    task_start_time = task_start_date.astimezone(EST).strftime("%Y-%m-%d %H:%M:%S")
    task_end_time = task_end_date.astimezone(EST).strftime("%Y-%m-%d %H:%M:%S")
    start_time = execution_date.astimezone(EST).strftime("%Y-%m-%d %H:%M:%S")
    formatted_start_time = execution_date.astimezone(EST).strftime("%Y%m%d_%H_%M")
    job_id = "in__piquote__customer_mvr" + "_" + formatted_start_time
    end_time = datetime.now().astimezone(EST).strftime("%Y-%m-%d %H:%M:%S")
    audit_config = readAuditJsonFile()
    error_message = audit_config["error_message"]
    record_count = audit_config["total_record_count"]
    source_files = audit_config["source_files"]
    rejected_files = audit_config["rejectedFiles"]
    if (error_message == ""):
        message = "Failed task : {ti.task_id }"
    else:
        message = error_message
    if (ti.task_id == "task_1_gcs_src_preprocess"):
        query = auditQueryBuilder(job_id, "parent_task", start_time, end_time, "FAILED",
                                  record_count, source_files, rejected_files, "Failed task : task_1_gcs_src_preprocess")
        execute_query(query)
        query = auditQueryBuilder(job_id, "task_1_gcs_src_preprocess", task_start_time, task_end_time, "FAILED",
                                  record_count, "", rejected_files, message)
        execute_query(query)
    elif (ti.task_id == "task_2_gcs_preprocess_bq_temp"):
        query_job_id = auditSelectQueryBuilder()
        resultset_job_id = execute_query(query_job_id)
        job_id = ""
        for row in resultset_job_id:
            job_id = row[0]
        query = auditQueryBuilder(job_id, ti.task_id, task_start_time, end_time, "FAILED",
                                  record_count, "", "", "")
        execute_query(query)
        update_query = auditUpdateQueryBuilder(end_time, "FAILED",
                                               job_id, message, "parent_task")
        execute_query(update_query)
        deleteDirectory(ingestion_bucket, source_object_path_temp_dir)
        deleteFileIfExists(ingestion_bucket, json_status_file_path)
    elif (ti.task_id == "task_3_bq_temp_curated"):
        query = auditQueryBuilder(job_id, ti.task_id, task_start_time, end_time, "FAILED",
                                  record_count, "", "", "")
        execute_query(query)
        update_query = auditUpdateQueryBuilder(end_time, "FAILED",
                                               job_id, message, "parent_task")
        execute_query(update_query)
        deleteDirectory(ingestion_bucket, source_object_path_temp_dir)
        deleteFileIfExists(ingestion_bucket, json_status_file_path)


def execute_cleanup_and_audit_success(context):
    print("TASK SUCCESS")
    print("context:", context)
    ti = context['task_instance']
    EST = pytz.timezone('US/Eastern')
    task_start_date = context['ti'].start_date
    task_end_date = context['ti'].end_date
    task_start_time = task_start_date.astimezone(EST).strftime("%Y-%m-%d %H:%M:%S")
    task_end_time = task_end_date.astimezone(EST).strftime("%Y-%m-%d %H:%M:%S")
    start_time = execution_date.astimezone(EST).strftime("%Y-%m-%d %H:%M:%S")
    end_time = datetime.now().astimezone(EST).strftime("%Y-%m-%d %H:%M:%S")
    formatted_start_time = execution_date.astimezone(EST).strftime("%Y%m%d_%H_%M")
    job_id = "in__piquote__customer_mvr" + "_" + formatted_start_time
    audit_config = readAuditJsonFile()
    error_message = audit_config["error_message"]
    record_count = audit_config["total_record_count"]
    source_files = audit_config["source_files"]
    if (error_message == ""):
        message = ""
    else:
        message = error_message
    print(f"task {ti.task_id } succeded in dag { ti.dag_id } ")
    if (ti.task_id == "task_1_gcs_src_preprocess"):
        query = auditQueryBuilder(job_id, "parent_task", start_time, "", "IN PROGRESS",
                                  record_count, source_files, "", "")
        execute_query(query)
        query = auditQueryBuilder(job_id, "task_1_gcs_src_preprocess", task_start_time, task_end_time, "SUCCESS",
                                  record_count, "", "", message)
        execute_query(query)
    elif (ti.task_id == "task_1_1_gcs_preprocess_validation"):
        query_job_id = auditSelectQueryBuilder()
        resultset_job_id = execute_query(query_job_id)
        for row in resultset_job_id:
            job_id = row[0]
        if (record_count == "0"):
            update_query = auditUpdateQueryBuilder(end_time, "SUCCESS",
                                                   job_id, "No Files Found at source. Downstream tasks skipped. \
                                                   Refer task_1_gcs_src_preprocess for logs", "parent_task")
            deleteFileIfExists(ingestion_bucket, json_status_file_path)
            execute_query(update_query)
    elif (ti.task_id == "task_3_bq_temp_curated"):
        query_job_id = auditSelectQueryBuilder()
        resultset_job_id = execute_query(query_job_id)
        for row in resultset_job_id:
            job_id = row[0]
        query = auditQueryBuilder(job_id, ti.task_id, task_start_time, task_end_time, "SUCCESS",
                                  record_count, "", "", "")
        execute_query(query)
        update_query = auditUpdateQueryBuilder(end_time, "SUCCESS",
                                               job_id, message, "parent_task")
        execute_query(update_query)
        deleteFileIfExists(ingestion_bucket, json_status_file_path)
        deleteDirectory(ingestion_bucket, source_object_path_temp_dir)
    elif (ti.task_id == "task_2_gcs_preprocess_bq_temp"):
        query_job_id = auditSelectQueryBuilder()
        resultset_job_id = execute_query(query_job_id)
        for row in resultset_job_id:
            job_id = row[0]
        query = auditQueryBuilder(job_id, ti.task_id, task_start_time, task_end_time, "SUCCESS",
                                  record_count, "", "", "")
        execute_query(query)


default_args = {
                'on_failure_callback': execute_cleanup_and_audit_fail,
                'on_success_callback': execute_cleanup_and_audit_success,
                }

with DAG(
  dag_id='in__piquote__customer_mvr',
  default_args=default_args,
  schedule_interval=None,
  start_date=start_date,
  max_active_runs=max_active_runs,
  tags=['aedl', 'customer_mvr', 'hourly', 'curated', 'quote'],
  catchup=False,
  ) as dag:

    task_1_gcs_src_preprocess = DatabricksSubmitRunOperator(
        task_id='task_1_gcs_src_preprocess',
        new_cluster=new_cluster,
        notebook_task={
            'notebook_path': notebook_path,
            'base_parameters': base_parameters
        },
        databricks_conn_id=databricks_conn_id,
        libraries=[
            {'jar': library}
        ],
        dag=dag,
    )
    task_1_1_gcs_preprocess_validation = ShortCircuitOperator(
        task_id='task_1_1_gcs_preprocess_validation',
        python_callable=isFileExists,
    )
    task_2_gcs_preprocess_bq_temp = GCSToBigQueryOperator(
        task_id='task_2_gcs_preprocess_bq_temp',
        bucket=ingestion_bucket,
        source_objects=[source_object_path_temp],
        destination_project_dataset_table=destination_project_dataset_table,
        source_format="AVRO",
        create_disposition="CREATE_IF_NEEDED",
        write_disposition="WRITE_TRUNCATE",
        dag=dag,
    )
    task_3_bq_temp_curated = BigQueryExecuteQueryOperator(
        task_id="task_3_bq_temp_curated",
        sql=sqlvalue,
        destination_dataset_table=destination_project_dataset_final_table,
        write_disposition="WRITE_APPEND",
        time_partitioning={'field': 'dlh_batch_ts', 'type': 'DAY'},
        gcp_conn_id=bigquery_id,
        allow_large_results=True,
        create_disposition='CREATE_IF_NEEDED',
        use_legacy_sql=False,
        dag=dag,
    )
    task_4_delete_bq_temp_table = BigQueryDeleteTableOperator(
        task_id="task_4_delete_bq_temp_table",
        deletion_dataset_table=destination_project_dataset_table,
        gcp_conn_id=bigquery_id,
        ignore_if_missing=False
    )

task_1_gcs_src_preprocess >> task_1_1_gcs_preprocess_validation
task_1_1_gcs_preprocess_validation >> task_2_gcs_preprocess_bq_temp
task_2_gcs_preprocess_bq_temp >> task_3_bq_temp_curated
task_3_bq_temp_curated >> task_4_delete_bq_temp_table
