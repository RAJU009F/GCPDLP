import os
from datetime import datetime
from airflow import DAG
from airflow.providers.databricks.operators.databricks \
    import DatabricksSubmitRunOperator
from airflow.models import Variable
from airflow.providers.google.cloud.transfers.gcs_to_bigquery \
    import GCSToBigQueryOperator
from airflow.contrib.operators.gcs_to_gcs \
    import GoogleCloudStorageToGoogleCloudStorageOperator

project_id_curated = Variable.get("curated_project_name")
project_id_raw = str(os.environ.get('raw'))
policy_id = Variable.get("aedl_policy_id")
environ_curated = project_id_curated.split("-")[1]
dataset = "pi_quote"
table_id = "unsaved_sonnet_hourly_snapshot"
partitionField = "dlh_batch_ts"
partitionType = "DAY"
domain = "quote"
hist_tab = "unsaved_sonnet_history"
dt = datetime.today().strftime('%Y-%m-%d')
source_object = dataset + "/data/" + hist_tab + "/*.avro"
destination_object = dataset + "/data/processed/" + hist_tab + "/" + dt + "/"
temp_table_id = "temp_" + table_id
raw_bucket = Variable.get("raw_bucket_name")
ingestion_bucket = raw_bucket
notebook_path = "/Shared/projects/pi_quote/src/quote_unsaved_sonnet_hourly_snapshot_hist"
raw_gcs_id = "google_cloud_storage_default"
bigquery_temp_bucket = Variable.get("bigquery_temp_bucket")
databricks_conn_id = "databricks_aedl"
library = "gs://" + ingestion_bucket + "/" + dataset \
    + "/code/config/library/spark-xml_2.12-0.15.0.jar"
destination_project_dataset_table = project_id_curated \
    + "." + dataset + "." + temp_table_id

if environ_curated == "dev":
    google_service_account = \
        "def-aedl-databricks@dp-dev-processing-4993.iam.gserviceaccount.com"
    node_type_id = "n2-standard-16"
    driver_node_type_id = "n2-standard-4"
    min_workers = 1
    max_workers = 5

elif environ_curated == "qa":
    google_service_account = \
        "def-aedl-databricks@dp-qa-processing-7cc0.iam.gserviceaccount.com"
    node_type_id = "n2-standard-16"
    driver_node_type_id = "n2-standard-4"
    min_workers = 5
    max_workers = 20

else:
    google_service_account = \
        "def-aedl-databricks@dp-prod-processing-b757.iam.gserviceaccount.com"
    node_type_id = "n2-standard-16"
    driver_node_type_id = "n2-standard-4"
    min_workers = 1
    max_workers = 2

new_cluster = {
        "spark_version": "10.4.x-scala2.12",
        "node_type_id": node_type_id,
        "driver_node_type_id": driver_node_type_id,
        "policy_id": policy_id,
        "custom_tags": {
            "TeamName": "AEDL"
        },
        "gcp_attributes": {
            "google_service_account": google_service_account,
            "zone_id": "HA"
        }
  }

base_parameters = {
                "bigquery_temp_bucket": bigquery_temp_bucket,
                "project_id": project_id_curated,
                "ingestion_bucket": ingestion_bucket,
                "temp_table_id": temp_table_id,
                "table_id": table_id,
                "dataset": dataset,
                "partitionField": partitionField,
                "partitionType": partitionType
  }

with DAG(
  dag_id='in__piquote__unsaved_sonnet_hourly_snapshot_history',
  schedule_interval='@once',
  start_date=datetime(2023, 7, 14),
  tags=['aedl1', 'unsaved_sonnet_hourly_snapshot',
        'history', 'unsaved_quote', 'curated', 'quote'],
  catchup=False,
  ) as dag:

    quote_gcs_to_bq = GCSToBigQueryOperator(
        task_id='quote_gcs_to_bq',
        bucket=ingestion_bucket,
        source_objects=[source_object],
        destination_project_dataset_table=destination_project_dataset_table,
        source_format="AVRO",
        create_disposition="CREATE_IF_NEEDED",
        write_disposition="WRITE_TRUNCATE",
    )

    quote_bq_to_curated = DatabricksSubmitRunOperator(
        task_id='quote_bq_to_curated',
        new_cluster=new_cluster,
        notebook_task={
            'notebook_path': notebook_path,
            'base_parameters': base_parameters
        },
        databricks_conn_id=databricks_conn_id,
        libraries=[
            {'jar': library}
        ],
    )

    quote_gcs_processed = GoogleCloudStorageToGoogleCloudStorageOperator(
        task_id='quote_gcs_landing_to_processed',
        source_bucket=ingestion_bucket,
        source_object=source_object,
        destination_bucket=ingestion_bucket,
        destination_object=destination_object,
        move_object=True,
    )

quote_gcs_to_bq >> quote_bq_to_curated >> quote_gcs_processed
