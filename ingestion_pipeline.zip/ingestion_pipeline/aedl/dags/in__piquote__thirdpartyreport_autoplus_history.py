import os
from airflow import DAG
from airflow.models import Variable
from airflow.providers.databricks.operators.databricks import DatabricksSubmitRunOperator
from airflow.contrib.operators.gcs_to_gcs import GoogleCloudStorageToGoogleCloudStorageOperator
import datetime
from pytz import timezone
from airflow.providers.google.cloud.operators.bigquery \
    import BigQueryExecuteQueryOperator
from airflow.providers.google.cloud.operators.bigquery \
    import BigQueryDeleteTableOperator

project_id_curated = Variable.get("curated_project_name")
project_id_procesing = str(os.environ.get('procesing'))
project_id_raw = str(os.environ.get('raw'))

environ_curated = project_id_curated.split("-")[1]
dataset = "thirdparty_reports"

# table_id is used for setting up gcs raw bucket directories
table_id = "thirdpartyreport_autoplus_history"
notebook_id = "thirdpartyreport_autoplus_history"
# bq_table_id is for target table
bq_table_id = "cgi_autoplus"
partitionField = "dlh_batch_ts"
partitionType = "DAY"

dt = datetime.datetime.now().strftime('%Y-%m-%d')
yestdate = datetime.datetime.now() - datetime.timedelta(days=1)
hour = datetime.datetime.now(timezone('EST')).strftime("%H_%M_%S")

raw_bucket = Variable.get("raw_bucket_name")
ingestion_bucket = raw_bucket
raw_gcs_id = "google_cloud_storage_default"
bigquery_id = "bigquery_default"


# Source Avro File Location ( output of PP job Extract)
root_table = table_id.split("_")[0]
root_table_modifier = table_id.split("_")[1]
root_table_category = table_id.split("_")[2]

library = "gs://" + ingestion_bucket + "/" + dataset \
    + "/code/config/library/spark-xml_2.12-0.15.0.jar"
source_object = "gs://" + ingestion_bucket + "/" + dataset + "/data/source/" + \
                root_table_modifier + "/" + root_table_category + "/*.avro"

# Source Location for Moving gcs raw data folder to procesed folder
# ( For airflow opertator , provide without gs://<bucketName )
source_object_path = dataset + "/data/source/" \
                     + root_table_modifier + "/" + root_table_category + "/*.avro"

# Avro Schema Location for
schema_object_path = "gs://" + ingestion_bucket + "/" + dataset + "/code/schema/" + bq_table_id + ".avsc"

# Target Destination for gcs processed files
destination_object = dataset + "/data/processed/" \
                     + root_table_modifier + "/" + root_table_category + "/" + dt + "/"
temp_table_id = "temp_" + bq_table_id

# Parameters for DataBricks Job
policy_id = Variable.get("aedl_policy_id")

# notebook_path = "/Shared/projects/pi_quote/src/" + table_id
# NoteBook path is from the ingestio_pipeline Set up : /$_REPO_NAME/"$line"/databricks_notebooks
notebook_path = "/ingestion_pipeline/aedl/databricks_notebooks/" + notebook_id

bigquery_temp_bucket = Variable.get("bigquery_temp_bucket")
databricks_conn_id = "databricks_aedl"
fileformat = "avro"
domain = "thirdparty_reports"

destination_project_dataset_temp_table = project_id_curated + "." + dataset + "." + temp_table_id
destination_project_dataset_final_table = project_id_curated + "." + dataset + "." + bq_table_id


sqlvalue = """
    SELECT
    extract(datetime from dlh_batch_ts) as dlh_batch_ts,
    extract(datetime from dlh_process_ts) as dlh_process_ts,
    customerDnl,
    rawData,
    version,
    recordSource,
    rawData_json from `""" + \
           destination_project_dataset_temp_table + """`"""


if environ_curated == "dev":
    google_service_account = \
        "def-aedl-databricks@dp-dev-processing-4993.iam.gserviceaccount.com"
    node_type_id = "n2-standard-16"
    driver_node_type_id = "n2-standard-4"
    min_workers = 1
    max_workers = 5
    max_active_runs = 1
elif environ_curated == "qa":
    google_service_account = \
        "def-aedl-databricks@dp-qa-processing-7cc0.iam.gserviceaccount.com"
    node_type_id = "n2-standard-16"
    driver_node_type_id = "n2-standard-4"
    min_workers = 5
    max_workers = 20
    max_active_runs = 1
else:
    google_service_account = \
        "def-aedl-databricks@dp-prod-processing-b757.iam.gserviceaccount.com"
    node_type_id = "n2-standard-16"
    driver_node_type_id = "n2-standard-4"
    min_workers = 5
    max_workers = 20
    max_active_runs = 1

new_cluster = {
        "spark_version": "10.4.x-scala2.12",
        "node_type_id": node_type_id,
        "driver_node_type_id": driver_node_type_id,
        "policy_id": policy_id,
        "custom_tags": {
            "TeamName": "AEDL"
        },
        "gcp_attributes": {
            "google_service_account": google_service_account,
            "zone_id": "HA"
        }
  }


default_args = {
    'owner': 'aedl-migration',
    'depends_on_past': False,
    'retries': 0,
    'retry_delay': datetime.timedelta(minutes=5),
    'start_date': yestdate
}

base_parameters = {
                "bigquery_temp_bucket": bigquery_temp_bucket,
                "project_id": project_id_curated,
                "ingestion_bucket": ingestion_bucket,
                "temp_table_id": temp_table_id,
                "table_id": table_id,
                "bq_table_id": bq_table_id,
                "dataset": dataset,
                "partitionField": partitionField,
                "partitionType": partitionType,
                "domain": domain,
                "root_table": root_table,
                "root_table_modifier": root_table_modifier,
                "root_table_category": root_table_category,
                "fileformat": fileformat
  }

with DAG(
        dag_id='in__piquote__thirdpartyreport_autoplus_history',
        schedule_interval='@once',
        default_args=default_args,
        tags=['piquote', 'thirdpartyreport_autoplus_history', 'history', 'curated',
              'thirdpartyreport', 'autoplus'],
        catchup=False,
) as dag:

    thirdpartyreport_autoplus_gcs_to_bq = DatabricksSubmitRunOperator(
        task_id="thirdpartyreport_autoplus_gcs_to_bq",
        new_cluster=new_cluster,
        notebook_task={
            'notebook_path': notebook_path,
            'base_parameters': base_parameters
        },
        databricks_conn_id=databricks_conn_id,
        libraries=[
            {'jar': library}
        ],
    )

    thirdpartyreport_autoplus_bq_to_bq_curated = BigQueryExecuteQueryOperator(
        task_id="thirdpartyreport_autoplus_bq_to_bq_curated",
        sql=sqlvalue,
        destination_dataset_table=destination_project_dataset_final_table,
        write_disposition="WRITE_APPEND",
        time_partitioning={'field': 'dlh_batch_ts', 'type': 'DAY'},
        gcp_conn_id=bigquery_id,
        allow_large_results=True,
        create_disposition='CREATE_IF_NEEDED',
        use_legacy_sql=False,
    )

    thirdpartyreport_autoplus_gcs_landing_to_processed = GoogleCloudStorageToGoogleCloudStorageOperator(
        task_id='thirdpartyreport_autoplus_gcs_landing_to_processed',
        source_bucket=ingestion_bucket,
        source_object=source_object_path,
        destination_bucket=ingestion_bucket,
        destination_object=destination_object,
        move_object=True,
    )

    thirdpartyreport_autoplus_temp_table_delete = BigQueryDeleteTableOperator(
        task_id="thirdpartyreport_autoplus_temp_table_delete",
        deletion_dataset_table=destination_project_dataset_temp_table,
        gcp_conn_id=bigquery_id,
        ignore_if_missing=False
    )

    thirdpartyreport_autoplus_gcs_to_bq >> thirdpartyreport_autoplus_bq_to_bq_curated >> \
        thirdpartyreport_autoplus_gcs_landing_to_processed >> thirdpartyreport_autoplus_temp_table_delete
