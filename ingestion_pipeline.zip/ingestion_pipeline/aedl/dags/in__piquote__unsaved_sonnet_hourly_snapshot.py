from airflow import DAG
from airflow.providers.databricks.operators.databricks  \
    import DatabricksSubmitRunOperator
from airflow.models import Variable
from datetime import datetime
from pytz import timezone

project_id_curated = Variable.get("curated_project_name")
policy_id = Variable.get("aedl_policy_id")
db_availability = Variable.get("db_availability")
environ_curated = project_id_curated.split("-")[1]
dataset = "pi_quote"
table_id = "unsaved_sonnet_hourly_snapshot"
partitionField = "dlh_batch_ts"
partitionType = "DAY"
domain = "pi_quote"
hist_tab = table_id
dt = datetime.today().strftime('%Y-%m-%d')
fileformat = "avro"
hour = datetime.now(timezone('EST')).strftime("%H_%M_%S")
raw_bucket = Variable.get("raw_bucket_name")
ingestion_bucket = raw_bucket
notebook_path = "/ingestion_pipeline/aedl/databricks_notebooks/" + table_id
raw_gcs_id = "google_cloud_storage_default"
bigquery_temp_bucket = Variable.get("bigquery_temp_bucket")
databricks_conn_id = "databricks_aedl"
library = "gs://" + ingestion_bucket + "/" + domain + \
    "/code/config/library/spark-xml_2.12-0.15.0.jar"

if environ_curated == "dev":
    google_service_account = \
        "def-aedl-databricks@dp-dev-processing-4993.iam.gserviceaccount.com"
    topic = "aws.dev13.pi.cmd.quoteandrecommendation.0"
    node_type_id = "n2-standard-4"
    driver_node_type_id = "n2-standard-4"
    min_workers = 1
    max_workers = 2
    schedule_interval = '0 * * * *'
    start_date = datetime(2023, 1, 1, 0, 0, 0)
    max_active_runs = 1
elif environ_curated == "qa":
    google_service_account = \
        "def-aedl-databricks@dp-qa-processing-7cc0.iam.gserviceaccount.com"
    topic = "aws.dt07.pi.cmd.quoteandrecommendation.0"
    node_type_id = "n2-standard-4"
    driver_node_type_id = "n2-standard-4"
    min_workers = 5
    max_workers = 20
    schedule_interval = '0 * * * *'
    start_date = datetime(2023, 2, 24, 15, 0, 0)
    max_active_runs = 1
else:
    google_service_account = \
        "def-aedl-databricks@dp-prod-processing-b757.iam.gserviceaccount.com"
    topic = "aws.prod01.pi.cmd.quoteandrecommendation.0"
    node_type_id = "n2-standard-16"
    driver_node_type_id = "n2-standard-4"
    min_workers = 1
    max_workers = 2
    schedule_interval = '0 * * * *'
    start_date = datetime(2023, 2, 25, 11, 0, 0)
    max_active_runs = 1

new_cluster = {
        "spark_version": "10.4.x-scala2.12",
        "node_type_id": node_type_id,
        "driver_node_type_id": driver_node_type_id,
        "policy_id": policy_id,
        "max_active_runs": max_active_runs,
        "custom_tags": {
            "TeamName": "AEDL"
        },
        "gcp_attributes": {
            "google_service_account": google_service_account,
            "availability": db_availability,
            "zone_id": "HA"
        }
  }

base_parameters = {
                "bigquery_temp_bucket": bigquery_temp_bucket,
                "project_id": project_id_curated,
                "ingestion_bucket": ingestion_bucket,
                "table_id": table_id,
                "dataset": dataset,
                "partitionField": partitionField,
                "partitionType": partitionType,
                "topic": topic,
                "fileformat": fileformat,
                "domain": domain,
                "hour": hour
  }

with DAG(
  dag_id='in__piquote__unsaved_sonnet_hourly_snapshot',
  schedule_interval=None,
  start_date=start_date,
  max_active_runs=max_active_runs,
  tags=['aedl', 'quote_unsaved_sonnet_snapshot', 'hourly',
        'unsaved_quote', 'curated', 'quote'],
  catchup=False,
  ) as dag:

    quote_gcs_to_bq_curated = DatabricksSubmitRunOperator(
        task_id='quote_gcs_to_bq_curated',
        new_cluster=new_cluster,
        notebook_task={
            'notebook_path': notebook_path,
            'base_parameters': base_parameters
        },
        databricks_conn_id=databricks_conn_id,
        libraries=[
            {'jar': library}
        ],
    )

quote_gcs_to_bq_curated
