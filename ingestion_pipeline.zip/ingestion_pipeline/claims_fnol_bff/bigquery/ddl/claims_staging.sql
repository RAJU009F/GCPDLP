CREATE TABLE `@curated_project.bff.claims_staging` (
  `value` STRING OPTIONS (description = 'To store entire payload/json as string'),
  `kafka_timestamp` DateTime OPTIONS (description = 'Stores time of the message injection into kafka'),
  `processed_date` DateTime OPTIONS (description = 'Stores time of the message consumption'),
)PARTITION BY
  DATETIME_TRUNC(processed_date, DAY);