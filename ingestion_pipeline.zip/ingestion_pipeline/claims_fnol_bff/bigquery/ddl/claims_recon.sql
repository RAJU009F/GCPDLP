CREATE TABLE `@curated_project.bff.claims_recon`
(
  timestamp TimeStamp,
  claims ARRAY<STRUCT<timestamp TimeStamp, id STRING>>,
  count INT64
)PARTITION BY
  TIMESTAMP_TRUNC(timestamp, DAY)
OPTIONS (
  partition_expiration_days = 90
);
