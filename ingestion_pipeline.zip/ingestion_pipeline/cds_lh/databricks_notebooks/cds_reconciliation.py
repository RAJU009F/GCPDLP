import subprocess
from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.dbutils import DBUtils
import json
import importlib

packages = [
    "google-cloud",
    "google-cloud-storage",
    "google-cloud-bigquery",
    "google-cloud-secret-manager",
    "pymysql",
    "pandas-gbq",
    "pymysql"
]
for package in packages:
    if package == "google-cloud-secret-manager" or package == "pymysql":
        subprocess.call(["pip3", "install", package])
    subprocess.call(["pip", "install", package])

pymysql = importlib.import_module("pymysql")
spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)


class rdif_jdbc_exception(Exception):
    pass


class rdif_spark_exception(Exception):
    pass


class rdif_generic_exception(Exception):
    pass


errorMessage = "Error "
oracal_table_name = dbutils.widgets.get("oracal_table_name")
bq_table_name = dbutils.widgets.get("bq_table_name")

bq_project_id = dbutils.widgets.get("bq_project_id")
bq_dataset_id = dbutils.widgets.get("bq_dataset_id")
bq_reconciliation_table = dbutils.widgets.get("bq_reconciliation_table")
bq_control_table = dbutils.widgets.get("bq_control_table")

app_bucket_name = dbutils.widgets.get("app_bucket_name")
properties_filename = dbutils.widgets.get("properties_filename")
secret_project_id = dbutils.widgets.get("secret_project_id")

# Creating spark session
spark = SparkSession.builder \
        .appName("SQL Server and BigQuery Comparison") \
        .getOrCreate()

# Function to get SQL Server data


def get_sql_server_data():
    from google.cloud import secretmanager
    from google.cloud import storage

    def get_metadata_db_connection(job_params):
        conn = None
        try:
            conn = pymysql.connect(**job_params)
        except Exception:
            raise rdif_jdbc_exception("Exception while connecting to metadata")
        return conn

    def get_metadata(job_params):
        audit_query = f"""
        Select a.src_count
        from rdif_run_def_2x a join rdif_job_def_2x b on a.job_id = b.job_id
        where b.source_table='{oracal_table_name}'
        order by end_time DESC limit 1
        """
        conn = get_metadata_db_connection(job_params=job_params)
        with conn.cursor() as cursor:
            cursor.execute(audit_query)
            result = cursor.fetchall()
            try:
                result = tuple(result[0])
                result = result[0]
            except Exception:
                result = 0
            if result is None:
                result = 0
            return result

    def get_properties(bucket_name, blob_name):
        separator = "="
        keys = {}
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(blob_name)
        blob = blob.download_as_string()
        blob = blob.decode('utf-8')
        for line in blob.splitlines():
            if separator in line:
                name, value = line.split(separator, 1)
                keys[name.strip()] = value.strip()
        return keys

    # secret manager
    def get_secret_version(project_id, secret_id):

        try:

            client = secretmanager.SecretManagerServiceClient()
            # client = secretmanager()
            name = f"projects/{project_id}/secrets/{secret_id}/versions/latest"
            response = client.access_secret_version(request={"name": name})
            payloadvalue = json.loads(response.payload.data.decode("UTF-8"))
            return payloadvalue
        except Exception as e:
            print(errorMessage, e.__class__, "occured")
            raise rdif_jdbc_exception(
                "Exception while getting secret " + secret_id)

    props = get_properties(app_bucket_name, properties_filename)
    rdif_audit_config = props.get("cloudsql_key")
    job_params = get_secret_version(secret_project_id, rdif_audit_config)
    row_count = get_metadata(job_params)

    result_data_control = spark.createDataFrame([(date_datetime,
                                                  date_datetime,
                                                  date_datetime,
                                                  'cds', oracal_table_name,
                                                  'COUNT', row_count)],
                                                ['dlh_batch_ts',
                                                 'dlh_process_ts',
                                                 'processed_date',
                                                 'src_name',
                                                 'src_table',
                                                 'src_field',
                                                 'src_total'])
    pandas_df = result_data_control.toPandas()
    pandas_df.to_gbq(
        destination_table=bq_control_table,
        project_id=bq_project_id, if_exists='append')
    print("Data loaded in control table.")
    return row_count


# Big Query row count
def get_bigquery_data(sql_server_data):
    table_id = f"{bq_project_id}.{bq_dataset_id}.{bq_table_name}"
    bigquery_data = spark.read \
        .format("bigquery") \
        .option("table", table_id) \
        .load()
    bigquery_data.createOrReplaceTempView("temp1")
    result = spark.sql("""
        SELECT count(*)
        FROM temp1
        where date(dlh_batch_ts) = (select max(date(dlh_batch_ts)) from temp1)
        """)
    single_value = result.select("count(1)").first()[0]
    integer_value = int(single_value)

    if sql_server_data == 0:
        integer_value = 0

    if sql_server_data == integer_value:
        result = "Pass"
    else:
        result = "Fail"
    result_data = spark.createDataFrame([(date_datetime,
                                          date_datetime,
                                          date_datetime,
                                          'cds', oracal_table_name,
                                          'COUNT', sql_server_data,
                                          bq_table_name, 'COUNT',
                                          integer_value, result)],
                                        ['dlh_batch_ts',
                                         'dlh_process_ts',
                                         'processed_date',
                                         'src_name',
                                         'src_table',
                                         'src_field',
                                         'src_total',
                                         'data_table',
                                         'data_field',
                                         'data_total',
                                         'result'])
    pandas_df = result_data.toPandas()
    pandas_df.to_gbq(
        destination_table=bq_reconciliation_table,
        project_id=bq_project_id, if_exists='append')
    print("Data loaded in reconciliation_table.")
    # result_data.show()

# datetime veriables


current_datetime = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
date_format = '%Y-%m-%d %H:%M:%S'
date_datetime = datetime.strptime(current_datetime, date_format)

# Run the functions to get data
sql_server_data = get_sql_server_data()
bigquery_data = get_bigquery_data(sql_server_data)
