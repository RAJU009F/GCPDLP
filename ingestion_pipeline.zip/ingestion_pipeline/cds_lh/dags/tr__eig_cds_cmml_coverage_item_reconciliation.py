from datetime import datetime

from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator
from airflow.providers.databricks.operators.databricks import (
    DatabricksSubmitRunOperator,
)

DAG_VARIABLES_KEY = "cds_table_name_bq_and_oracal"
cds_table_name_bq_and_oracal = Variable.get(
    DAG_VARIABLES_KEY, deserialize_json=True
)
app_bucket_name = Variable.get("rdif_app_bucket")
properties_filename = Variable.get("rdif_properties_filepath")

# variable for cluster
policy_id = Variable.get("cdpm_policy_id")
cluster_id = cds_table_name_bq_and_oracal["cluster_id"]
databricks_conn_id = cds_table_name_bq_and_oracal["databricks_conn_id"]
driver_node_type_id = cds_table_name_bq_and_oracal["driver_node_type_id"]
google_service_account = cds_table_name_bq_and_oracal["google_service_account"]
lib_1 = cds_table_name_bq_and_oracal["lib_1"]
min_workers = cds_table_name_bq_and_oracal["min_workers"]
max_workers = cds_table_name_bq_and_oracal["max_workers"]
notebook_path = cds_table_name_bq_and_oracal["notebook_path"]
notebook_name = cds_table_name_bq_and_oracal["notebook_name"]
node_type_id = cds_table_name_bq_and_oracal["node_type_id"]
max_active_runs = cds_table_name_bq_and_oracal["max_active_runs"]

# variable for reconciliation table name and dataset
oracl_table = cds_table_name_bq_and_oracal["eig_cds_cmml_coverage_item"][0]
bq_table_name = cds_table_name_bq_and_oracal["eig_cds_cmml_coverage_item"][1]
oracal_database = cds_table_name_bq_and_oracal["eig"]
column_list = cds_table_name_bq_and_oracal["eig_cds_cmml_coverage_item_col"]
url = cds_table_name_bq_and_oracal["url"]
user = cds_table_name_bq_and_oracal["user"]
password = cds_table_name_bq_and_oracal["password"]

# Convert column_list to a string using a comma as the delimiter
column_list_string = ",".join(column_list)

bq_project_id = cds_table_name_bq_and_oracal["bq_project_id"]
bq_dataset_id = cds_table_name_bq_and_oracal["bq_dataset_id"]
bq_recon_table = cds_table_name_bq_and_oracal["bq_reconciliation_table"]
bq_control_table = cds_table_name_bq_and_oracal["bq_control_table"]
secret_project_id = cds_table_name_bq_and_oracal["secret_project_id"]

# """ Calling Databricks Notebook for Landing to Working"""


def databricks_spark_job(**context):

    base_parameters = {
        "oracal_table_name": oracl_table,
        "bq_table_name": bq_table_name,
        "oracal_database": oracal_database,
        "url": url,
        "user": user,
        "password": password,
        "bq_project_id": bq_project_id,
        "bq_dataset_id": bq_dataset_id,
        "bq_reconciliation_table": bq_recon_table,
        "bq_control_table": bq_control_table,
        "column_list": column_list_string,
        "secret_project_id": secret_project_id,
        "app_bucket_name": app_bucket_name,
        "properties_filename": properties_filename
        }

    run_notebook = DatabricksSubmitRunOperator(
        task_id="run_notebook",
        new_cluster=new_cluster,
        notebook_task={
            "notebook_path": f"{notebook_path}{notebook_name}",
            "base_parameters": base_parameters,
        },
        databricks_conn_id=databricks_conn_id,
        libraries=[{"jar": lib_1}],
    )

    run_notebook.execute(context)

# Define the DAG


with DAG(
    'tr__eig_cds_cmml_coverage_item_reconciliation',
    start_date=datetime(2023, 7, 5),
    tags=['cds', 'cds_snapshot', 'cds_reconciliation', 'cds_claims'],
    schedule_interval=None,
    catchup=False
) as dag:
    new_cluster = {
        "spark_version": "10.4.x-scala2.12",
        "node_type_id": node_type_id,
        "driver_node_type_id": driver_node_type_id,
        "policy_id": policy_id,
        "max_active_runs": max_active_runs,
        "autoscale": {
            "min_workers": min_workers,
            "max_workers": max_workers,
        },
        "custom_tags": {"TeamName": "CDPM"},
        "gcp_attributes": {
            "google_service_account": google_service_account,
            "zone_id": "HA",
        },
    }
    reconciliation = PythonOperator(
        task_id="reconciliation",
        python_callable=databricks_spark_job,
        dag=dag,
    )

    # Set the task dependencies
    reconciliation
