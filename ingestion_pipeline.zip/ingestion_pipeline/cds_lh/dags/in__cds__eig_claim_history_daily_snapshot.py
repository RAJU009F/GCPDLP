import logging
from datetime import datetime

from google.cloud import storage
from google.cloud import bigquery

from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator
from airflow.providers.databricks.operators.databricks import (
    DatabricksSubmitRunOperator,
)

# """Fetching Airflow Variables Values"""
curated_project_name_cds = Variable.get(
    "curated_project_name"
)  # ,deserialize_json=False)
processing_project_name_cds = Variable.get("processing_project_name")
deployment_bucket_name_cds = Variable.get("deployment_bucket_name")
app_bucket_name = Variable.get("rdif_app_bucket")
properties_filename = Variable.get("rdif_properties_filepath")

DAG_VARIABLES_KEY = "cds_table_name_bq_and_oracal"
cds_table_name_bq_and_oracal = Variable.get(
    DAG_VARIABLES_KEY, deserialize_json=True)
# variable for loading the data
source_table = (f'{curated_project_name_cds}.'
                f'{cds_table_name_bq_and_oracal["cds_dataset"]}.'
                f'{cds_table_name_bq_and_oracal["eig_claim_history"][0]}')
destination_table = (f'{curated_project_name_cds}.'
                     f'{cds_table_name_bq_and_oracal["cds_dataset"]}.'
                     f'{cds_table_name_bq_and_oracal["eig_claim_history"][1]}')
append_to_final = cds_table_name_bq_and_oracal["eig_claim_history_query"]

# variable for cluster
policy_id = Variable.get("cdpm_policy_id")
cluster_id = cds_table_name_bq_and_oracal["cluster_id"]
databricks_conn_id = cds_table_name_bq_and_oracal["databricks_conn_id"]
driver_node_type_id = cds_table_name_bq_and_oracal["driver_node_type_id"]
google_service_account = cds_table_name_bq_and_oracal["google_service_account"]
lib_1 = cds_table_name_bq_and_oracal["lib_1"]
min_workers = cds_table_name_bq_and_oracal["min_workers"]
max_workers = cds_table_name_bq_and_oracal["max_workers"]
notebook_path = cds_table_name_bq_and_oracal["notebook_path"]
notebook_name = cds_table_name_bq_and_oracal["notebook_name"]
node_type_id = cds_table_name_bq_and_oracal["node_type_id"]
max_active_runs = cds_table_name_bq_and_oracal["max_active_runs"]

# variable for reconciliation table name and dataset
oracal_table_name = cds_table_name_bq_and_oracal["eig_claim_history"][0]
bq_table_name = cds_table_name_bq_and_oracal["eig_claim_history"][1]
oracal_database = cds_table_name_bq_and_oracal["eig"]
url = cds_table_name_bq_and_oracal["url"]
user = cds_table_name_bq_and_oracal["user"]
password = cds_table_name_bq_and_oracal["password"]

bq_project_id = cds_table_name_bq_and_oracal["bq_project_id"]
bq_dataset_id = cds_table_name_bq_and_oracal["bq_dataset_id"]
bq_recon_table = cds_table_name_bq_and_oracal["bq_reconciliation_table"]
bq_control_table = cds_table_name_bq_and_oracal["bq_control_table"]
secret_project_id = cds_table_name_bq_and_oracal["secret_project_id"]

# """ Calling Databricks Notebook for Landing to Working"""


def databricks_spark_job(**context):
    base_parameters = {
        "oracal_table_name": oracal_table_name,
        "bq_table_name": bq_table_name,
        "oracal_database": oracal_database,
        "url": url,
        "user": user,
        "password": password,
        "bq_project_id": bq_project_id,
        "bq_dataset_id": bq_dataset_id,
        "bq_reconciliation_table": bq_recon_table,
        "bq_control_table": bq_control_table,
        "secret_project_id": secret_project_id,
        "app_bucket_name": app_bucket_name,
        "properties_filename": properties_filename
    }

    run_notebook = DatabricksSubmitRunOperator(
        task_id="run_notebook",
        new_cluster=new_cluster,
        notebook_task={
            "notebook_path": f"{notebook_path}{notebook_name}",
            "base_parameters": base_parameters,
        },
        databricks_conn_id=databricks_conn_id,
        libraries=[{"jar": lib_1}],
    )

    run_notebook.execute(context)

# data_load_from_source_bq_table_to_destination_table


def append_to_final_table():
    storage_client = storage.Client(project=processing_project_name_cds)
    deployment_bucket = storage_client.get_bucket(deployment_bucket_name_cds)
    load_to_final_query_blob = deployment_bucket.blob(append_to_final)
    load_to_final_query = load_to_final_query_blob.download_as_text()
    load_to_final_query = load_to_final_query.replace(
        "@Source_table", source_table
    ).replace("@Destination_table", destination_table)
    client = bigquery.Client(project=processing_project_name_cds)
    insertion_task = client.query(load_to_final_query)
    insertion_task.result()
    logging.info("Data sucessfully loaded to final table")

# Define the DAG


with DAG(
    "in__cds__eig_claim_history_daily_snapshot",
    start_date=datetime(2023, 7, 5),
    tags=['cds', 'cds_reconciliation', 'cds_claims'],
    schedule_interval=None,
    catchup=False,
) as dag:
    new_cluster = {
        "spark_version": "10.4.x-scala2.12",
        "node_type_id": node_type_id,
        "driver_node_type_id": driver_node_type_id,
        "policy_id": policy_id,
        "max_active_runs": max_active_runs,
        "autoscale": {
            "min_workers": min_workers,
            "max_workers": max_workers,
        },
        "custom_tags": {"TeamName": "CDPM"},
        "gcp_attributes": {
            "google_service_account": google_service_account,
            "zone_id": "HA",
        },
    }

    reconciliation = PythonOperator(
        task_id="reconciliation",
        python_callable=databricks_spark_job,
        dag=dag,
    )

    load_to_curated = PythonOperator(
        task_id="load_to_curated",
        python_callable=append_to_final_table,
        provide_context=True,
        trigger_rule="none_failed_min_one_success",
    )

    # Set the task dependencies
    reconciliation >> load_to_curated
