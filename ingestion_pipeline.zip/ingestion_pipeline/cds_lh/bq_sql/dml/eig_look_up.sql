INSERT INTO 
        `@Destination_table` (
            dlh_batch_ts,
            dlh_process_ts,
            column_name,
            code,
            description,
            comments,
            creation_date,
            created_by,
            last_update_date,
            last_updated_by,
            value1,
            value2
)   (
        SELECT 
            CAST(current_date() as datetime) AS dlh_batch_ts,
            CAST(current_timestamp() as datetime) AS dlh_process_ts, 
            COLUMN_NAME, 
            CODE, 
            DESCRIPTION, 
            COMMENTS, 
            CREATION_DATE, 
            CREATED_BY, 
            LAST_UPDATE_DATE, 
            LAST_UPDATED_BY, 
            VALUE1, 
            VALUE2 
        FROM 
            `@Source_table`
  );