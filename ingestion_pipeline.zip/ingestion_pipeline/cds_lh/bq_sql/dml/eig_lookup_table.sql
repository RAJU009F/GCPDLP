INSERT INTO 
        `@Destination_table` (
            dlh_batch_ts,
            dlh_process_ts,
            compny_cd,
            prov_cd,
            column_name,
            code,
            lang_cd,
            value1,
            value2,
            compny_nme,
            eff_start_dt,
            eff_end_dt,
            description,
            comments,
            created_by,
            creation_date,
            last_updated_by,
            last_update_date,
            desc_cd
)   (
        SELECT 
            CAST(current_date() as datetime) AS dlh_batch_ts,
            CAST(current_timestamp() as datetime) AS dlh_process_ts, 
            COMPNY_CD, 
            PROV_CD, 
            COLUMN_NAME, 
            CODE, 
            LANG_CD, 
            VALUE1, 
            VALUE2, 
            COMPNY_NME, 
            EFF_START_DT, 
            EFF_END_DT, 
            DESCRIPTION, 
            COMMENTS, 
            CREATED_BY, 
            CREATION_DATE, 
            LAST_UPDATED_BY, 
            LAST_UPDATE_DATE, 
            DESC_CD
        FROM 
            `@Source_table`
  );