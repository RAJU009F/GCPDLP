INSERT INTO 
        `@Destination_table` (
            dlh_batch_ts,
            dlh_process_ts,
            prof_id,
            prof_code,
            description
)   (
      SELECT 
          CAST(current_date() as datetime) AS dlh_batch_ts,
          CAST(current_timestamp() as datetime) AS dlh_process_ts, 
          PROF_ID, 
          PROF_CODE, 
          DESCRIPTION
      FROM 
          `@Source_table`
);