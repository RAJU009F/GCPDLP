INSERT INTO 
        `@Destination_table` (
            dlh_batch_ts,
            dlh_process_ts,
            serv_prov_prof_id,
            hcai_serv_prov_id,
            prof_id,
            reg_number,
            created_by,
            creation_date,
            last_updated_by,
            last_update_date
)   (
        SELECT  
              CAST(current_date() as datetime) AS dlh_batch_ts,
              CAST(current_timestamp() as datetime) AS dlh_process_ts, 
              SERV_PROV_PROF_ID, 
              HCAI_SERV_PROV_ID, 
              PROF_ID, 
              REG_NUMBER, 
              CREATED_BY, 
              CREATION_DATE, 
              LAST_UPDATED_BY, 
              LAST_UPDATE_DATE
        FROM 
              `@Source_table`
  );