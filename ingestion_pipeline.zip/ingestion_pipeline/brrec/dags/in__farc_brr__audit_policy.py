import logging
from datetime import datetime
import pytz
from google.cloud import storage
from google.cloud import bigquery
from airflow import DAG
from airflow.exceptions import AirflowException
from airflow.hooks.mysql_hook import MySqlHook
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.operators.bigquery import (
    BigQueryDeleteTableOperator
)
from operators.com.economical.sdp.load_to_curated import LoadToCurated
from operators.com.economical.sdp.schema_validation import SchemaValidation

# Pulling Values from the Variables defined in Airflow
raw_project_name = Variable.get("raw_project_name")
raw_bucket_name = Variable.get("raw_bucket_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
curated_project = Variable.get("curated_project_name")
csv_ingestion_mysql_connection = Variable.get("csv_ingestion_mysql_connection")

config = Variable.get(
    "brokerrec_dly_policy_variables", deserialize_json=True
)
base_folder_path = config["base_folder_path"]
curated_dataset_name = config["curated_dataset_name"]
staging_table_name = config["staging_table_name"]
external_table_name = config["external_table_name"]
curated_table_name = config["curated_table_name"]
query_path = config["query_path"]
load_details_query_path = config["load_details_query_path"]
load_to_curated_query_path = config["load_to_curated_query_path"]

# final_query_file = "insert_into_audit_policy_curated_table.sql"

storage_client = storage.Client(project=raw_project_name)

bigquery_client = bigquery.Client(project=curated_project)
est_tz = pytz.timezone("America/Toronto")


def get_execution_time_func(**kwargs):
    '''
    function to get execution date
    '''
    try:
        execution_date = (
            kwargs['dag_run'].conf['run_date']
        )
        print("This is the execution date from Scheduler", execution_date)

    except Exception as exception:
        logging.info(exception)
        execution_date = kwargs["execution_date"].astimezone(est_tz)
        execution_date = execution_date.strftime("%Y-%m-%d")
        print("This is the execution date from exception", execution_date)

    execution_time = datetime.now().astimezone(est_tz).strftime("%Y%m%d%H%M%S")
    print("execution_time -> ", execution_time)

    return execution_time, execution_date


def move_files(
    src_bucket_name, src_blob_name, dest_bucket_name, dest_blob_name
):
    """
    Function to move files from one folder to another
    """
    try:
        source_bucket = storage_client.get_bucket(src_bucket_name)
        source_blob = source_bucket.blob(src_blob_name)
        destination_bucket = storage_client.get_bucket(dest_bucket_name)
        destination_blob = destination_bucket.blob(dest_blob_name)
        destination_blob.upload_from_string(source_blob.download_as_string())
        if not (("landing/" in src_blob_name) and ("working/" in dest_blob_name)):
            source_blob.delete()
        logging.info(
            f"File copied/moved from {source_blob} to {destination_blob}"
        )
    except Exception:
        logging.error(f"Error in copying/moving file {src_blob_name}")
        raise AirflowException(
            f"Error in copying/moving file {src_blob_name}"
        )


def check_file_existence_func(**context):
    """
    function to check whether file is present in GCS bucket or not and if no files found, skip the DAG
    """
    file_path = f"{base_folder_path}/landing/"
    print(file_path)
    bucket = storage_client.bucket(raw_bucket_name)
    file_list = list(bucket.list_blobs(prefix=file_path))
    source_files = [
        file.name
        for file in file_list
        if file.name != file_path
    ]
    print("source_files : ", source_files)
    if len(source_files) == 0:
        raise AirflowException("No files found, fail the DAG")

    return True, source_files


def landing_to_working_func(**context):
    """
    function to check whether file is present in GCS bucket or not
    and copy files from landing folder to working folder and move
    files from landing to archive
    """

    execution_time = context["task_output"][0]
    source_files = context["check_file_existence_output"][1]
    file_path = f"{base_folder_path}/landing/"
    print("execution_time", execution_time)

    # Creating runtime folder
    bucket = storage_client.bucket(raw_bucket_name)
    runtime_path = f"{base_folder_path}/runtime_{execution_time}/"
    blob_runtime = bucket.blob(runtime_path)
    blob_runtime.upload_from_string('')

    # Copying files from landing to working folder
    for file in source_files:
        file_name = file.rsplit("/", maxsplit=1)[-1]
        print("file_name : ", file_name)
        move_files(
            raw_bucket_name,
            f"{file_path}{file_name}",
            raw_bucket_name,
            f"{base_folder_path}/runtime_{execution_time}/working/{file_name}"
        )
    # Moving files from landing to archive folder
    for file in source_files:
        file_name = file.rsplit("/", maxsplit=1)[-1]
        print("file_name : ", file_name)
        move_files(
            raw_bucket_name,
            f"{file_path}{file_name}",
            raw_bucket_name,
            f"{base_folder_path}/runtime_{execution_time}/archive/{file_name}"
        )


def upload_data_to_gcs(file_path, data):
    '''
    Function to upload data to GCS
    '''
    logging.info(f'Uploading data to GCS: {file_path}')
    gcs_client = storage.Client(project=raw_project_name)
    bucket = gcs_client.bucket(raw_bucket_name)
    blob = bucket.blob(file_path)
    blob.upload_from_string(data)


def get_load_details(execution_time):
    '''
    Function to get details related to table from csv ingestion load details table
    '''
    try:
        storage_client = storage.Client()
        deployment_bucket = storage_client.get_bucket(deployment_bucket_name)
        load_details_query_blob = deployment_bucket.blob(load_details_query_path)
        load_details_query = load_details_query_blob.download_as_text()
        load_details_query = load_details_query.replace('@curated_table_name', curated_table_name)
        print(load_details_query)

        mysql_hook = MySqlHook(mysql_conn_id=csv_ingestion_mysql_connection, schema='csv_ingestion')
        connection = mysql_hook.get_conn()
        cursor = connection.cursor()
        cursor.execute(load_details_query)
        output = cursor.fetchall()
        return output
    except Exception:
        file_path = f"{base_folder_path}/runtime_{execution_time}/working"
        bucket = storage_client.bucket(raw_bucket_name)
        file_list = list(bucket.list_blobs(prefix=file_path))
        for file in file_list:
            file_name = file.name.rsplit("/", maxsplit=1)[-1]
            move_files(
                raw_bucket_name,
                file.name,
                raw_bucket_name,
                f"{base_folder_path}/runtime_{execution_time}/failed/{file_name}"
            )

        raise AirflowException(
            f"Error while running query using MySQL connection {csv_ingestion_mysql_connection}")


def load_to_curated_func(**context):
    '''
    Function to load data into curated using ingestion framework schema validation and load to curated operator
    '''
    execution_time = context["task_output"][0]
    execution_date = context["task_output"][1]
    files = get_load_details(execution_time)
    print(files)
    file_name_pattern = files[0][1]
    delimiter = files[0][2]
    header_records = files[0][3]
    source_system = files[0][4]
    file_path = files[0][5] + f'/runtime_{execution_time}/working/'
    file_location = raw_bucket_name + '/' + files[0][5] + f'/runtime_{execution_time}/working/'
    curated_dataset_name = files[0][6]
    external_table_name = files[0][7]
    curated_table_name = files[0][8]
    is_mandatory = files[0][9]
    is_incremental = files[0][10]
    external_table_id = f'{curated_project}.{curated_dataset_name}.{external_table_name}'
    print(external_table_id)
    curated_table_id = f'{curated_project}.{curated_dataset_name}.{curated_table_name}'
    print(curated_table_id)
    print("file_name:", file_location)
    print("execution_date", execution_date)
    print("execution_date_type", type(execution_date))

    deployment_bucket = storage_client.get_bucket(deployment_bucket_name)
    query_blob = deployment_bucket.get_blob(load_to_curated_query_path)
    load_to_curated_query = query_blob.download_as_text()
    load_to_curated_query = (
        load_to_curated_query.replace("@curated_table_id", curated_table_id)
        .replace("@batch_ts", execution_date)
        .replace("@external_table_id", external_table_id)
    )
    print("load_to_curated_query:", load_to_curated_query)

    try:
        schema_validation_task = SchemaValidation(
            task_id='schema_validation_task',
            raw_bucket_name=raw_bucket_name,
            curated_project_name=curated_project,
            csv_ingestion_mysql_connection=csv_ingestion_mysql_connection,
            file_name_pattern=file_name_pattern,
            delimiter=delimiter,
            header_records=header_records,
            source_system=source_system,
            file_location=file_path,
            file_name=file_name_pattern,
            curated_dataset_name=curated_dataset_name,
            external_table_name=external_table_name,
            curated_table_name=curated_table_name,
            is_mandatory=is_mandatory,
            table_id=external_table_id,
            curated_table_id=curated_table_id,
            bypass_file_check=True,
            allow_jagged_rows=True
        )

        schema_validation_task.execute(dict(context))

        load_to_curated_staging_task = LoadToCurated(
            task_id='load_to_curated_staging_task',
            raw_bucket_name=raw_bucket_name,
            curated_project_name=curated_project,
            csv_ingestion_mysql_connection=csv_ingestion_mysql_connection,
            source_system=source_system,
            file_location=file_path,
            curated_dataset_name=curated_dataset_name,
            external_table_name=external_table_name,
            curated_table_name=curated_table_name,
            is_incremental=is_incremental,
            table_id=external_table_id,
            curated_table_id=curated_table_id,
            query=load_to_curated_query
        )

        load_to_curated_staging_task.execute(dict(context))

        delete_external_table = BigQueryDeleteTableOperator(
            task_id="delete_external_table",
            deletion_dataset_table=external_table_id,
        )

        delete_external_table.execute(dict(context))

    except Exception as e:
        file_path = f"{base_folder_path}/runtime_{execution_time}/working"
        bucket = storage_client.bucket(raw_bucket_name)
        file_list = list(bucket.list_blobs(prefix=file_path))
        for file in file_list:
            file_name = file.name.rsplit("/", maxsplit=1)[-1]
            move_files(
                raw_bucket_name,
                file.name,
                raw_bucket_name,
                f"{base_folder_path}/runtime_{execution_time}/failed/{file_name}"
            )
        logging.error(f"Error:{e}")
        raise AirflowException("Ending the task.")


def move_to_success_func(**context):
    '''
    Function to move files to success folder
    '''
    execution_time = context["task_output"][0]
    file_path = f"{base_folder_path}/runtime_{execution_time}/working"
    bucket = storage_client.bucket(raw_bucket_name)
    file_list = list(bucket.list_blobs(prefix=file_path))
    for file in file_list:
        file_name = file.name.rsplit("/", maxsplit=1)[-1]
        move_files(
            raw_bucket_name,
            file.name,
            raw_bucket_name,
            f"{base_folder_path}/runtime_{execution_time}/success/{file_name}"
        )


with DAG(
    dag_id="in__farc_brr__audit_policy",
    schedule_interval=None,
    start_date=datetime(2023, 7, 17),
    tags=[
        "in__farc_brr__audit_policy",
        "curated",
        "farc_brr",
        "brrec",
        "daily",
    ],
    render_template_as_native_obj=True,
    catchup=False,
    max_active_runs=1

) as dag:

    get_execution_time = PythonOperator(
        task_id="get_execution_time",
        python_callable=get_execution_time_func,
        dag=dag
    )

    check_file_existence = PythonOperator(
        task_id="check_file_existence",
        python_callable=check_file_existence_func,
        dag=dag
    )

    landing_to_working = PythonOperator(
        task_id="landing_to_working",
        python_callable=landing_to_working_func,
        op_kwargs={
            "check_file_existence_output": check_file_existence.output,
            "task_output": get_execution_time.output
        },
        dag=dag
    )

    load_to_curated = PythonOperator(
        task_id="load_to_curated",
        python_callable=load_to_curated_func,
        op_kwargs={
            "task_output": get_execution_time.output
        },
        dag=dag
    )

    move_to_success = PythonOperator(
        task_id="move_to_success",
        python_callable=move_to_success_func,
        op_kwargs={
            "task_output": get_execution_time.output
        },
        dag=dag
    )

(

    get_execution_time
    >> check_file_existence
    >> landing_to_working
    >> load_to_curated
    >> move_to_success
)
