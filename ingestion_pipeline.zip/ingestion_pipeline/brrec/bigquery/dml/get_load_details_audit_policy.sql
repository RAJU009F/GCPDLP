SELECT *
FROM  csv_ingestion.csv_ingestion_load_details
WHERE curated_table_name='@curated_table_name'
AND
source_system = 'brrec'
AND
is_active = 1;