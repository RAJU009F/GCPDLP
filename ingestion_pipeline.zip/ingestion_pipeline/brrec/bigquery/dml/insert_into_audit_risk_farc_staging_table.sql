INSERT INTO
    `@staging_table_id`
SELECT
    *,
    CAST('@batch_ts' AS DATETIME) AS dlh_batch_ts,
    CAST(FORMAT_DATETIME("%Y-%m-%dT%H:%M:%S", (CURRENT_DATETIME("America/Toronto"))) AS DATETIME) AS dlh_process_ts
FROM
    `@external_table_id`;