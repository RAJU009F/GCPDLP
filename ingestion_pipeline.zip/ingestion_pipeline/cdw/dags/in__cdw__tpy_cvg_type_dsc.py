from airflow import DAG
import datetime
from airflow.models import Variable
from airflow.providers.google.cloud.hooks.datafusion import SUCCESS_STATES
from airflow.providers.google.cloud.operators.datafusion \
    import CloudDataFusionStartPipelineOperator
from airflow.utils.trigger_rule import TriggerRule
from operators.com.economical.sdp.rdif_metadata import JobMetadata
from operators.com.economical.sdp.rdif_BQ_operators \
    import ArchiveTable, StageToTarget, CleanUpStageTable

dag_id = 'in__cdw__tpy_cvg_type_dsc'
job_name = 'in__cdw__tpy_cvg_type_dsc'
tag_list = ['rdif', 'derived', 'cdw', 'db2', 'monthly']
schedule_interval = '00 03 10 * *'
owner = ''

default_args = {
    'owner': owner
}

with DAG(
    dag_id=dag_id,
    tags=tag_list,
    default_args=default_args,
    schedule_interval=schedule_interval,
    start_date=datetime.datetime(2023, 5, 10),
    catchup=False,
    render_template_as_native_obj=True
) as dag:
    getJobMeta = JobMetadata(
        task_id='get_job_metadata', job_name=job_name)
    archiveTable = ArchiveTable(
        task_id='archive_table')
    stageToTarget = StageToTarget(
        task_id='stage_to_target')
    cleanUpStageTable = CleanUpStageTable(
        task_id='cleanup_stage_table', trigger_rule=TriggerRule.ALL_DONE)

    RDBMStoBigQueryStaging = CloudDataFusionStartPipelineOperator(
        task_id="rdmstobigquery_cdf_pipeline",
        location=Variable.get("dcfDfLocation"),
        pipeline_name='{{ti.xcom_pull(\
            task_ids="get_job_metadata", key="dfPipelineName")}}',
        instance_name=Variable.get("dcfDfInstance"),
        runtime_args="{{ti.xcom_pull(\
            task_ids='get_job_metadata', key='pipeline_args')}}",
        success_states=SUCCESS_STATES,
        pipeline_timeout=60*60*4,
        project_id=Variable.get("dcfDfProject")
    )

dag.doc_md = """
### DAG Documentation
- Job Description - Ingestion job to load the data from \
ONPREM source CDW to GCP BigQuery by\
Relational Data Ingestion Framework (RDIF)
- For the Framework Details - Please refer to this <a href="\
https://economical.sharepoint.com/:w:/r/sites/NitinOnboardingDocuments/Shared\
%20Documents/General/Data%20Frameworks/Relational%20Data%20Ingestion\
%20Framework%20(RDIF)/Relational%20Data%20Ingestion%20Framework%20User\
%20Guide%20V2.docx?d=w395bad08bb964ec197dcd8b2d3758308&csf=1&web=1&e=\
f6mRRj&wdOrigin=TEAMS-ELECTRON.p2p.bim&wdExp=TEAMS-CONTROL&wdhostclicktime=\
1665176521378" target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this <a href="\
https://economical.sharepoint.com/:w:/r/sites/NitinOnboardingDocuments/Shared\
%20Documents/General/Data%20Frameworks/Relational%20Data%20Ingestion\
%20Framework%20(RDIF)/Relational%20Data%20Ingestion%20Framework%20-%20Data\
%20Fusion%20Known%20Error%20DataBase%20V1.0.docx?d=w2029a52520ac4573b02dc816\
c1f1755b&csf=1&web=1&wdOrigin=TEAMS-ELECTRON.p2p.\
bim&wdExp=TEAMS-CONTROL&wdhostclicktime=\
1665176537165" target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this <a href="\
https://economical.sharepoint.com/:w:/r/sites/NitinOnboardingDocuments\
/_layouts/15/Doc\
.aspx?sourcedoc=%7B70210E2D-F5CF-4D89-81E0-\
8DD3D72BBB3C%7D&file=Relational%20Data%20Ingestion\
%20Framework%20-%20Runbook.docx&action=default\
&mobileredirect=true&ovuser=6f8518e1-bbdc-41ae-\
a82c-024046d586dd%2CIYJ%40economical.com&\
clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwc\
FZlcnNpb24iOiIyNy8yMzAxMDEwMDkxMyIsIkhhc0ZlZGVy\
YXRlZFVzZXIiOmZhbHNlfQ%3D%3D&cid=f8d2a4a6-0fc1\
-4705-b025-7b849944cbce" target="_blank" style="color:blue"><u>link</u></a>
"""
getJobMeta >> RDBMStoBigQueryStaging >> \
    archiveTable >> stageToTarget >> cleanUpStageTable
