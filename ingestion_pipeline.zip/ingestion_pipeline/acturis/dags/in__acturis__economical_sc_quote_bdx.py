import re
from datetime import datetime

from airflow import DAG
from airflow.exceptions import AirflowException
from airflow.hooks.mysql_hook import MySqlHook
from airflow.models import Variable
from airflow.operators.python import PythonOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryDeleteTableOperator
from google.cloud import storage
from operators.com.economical.sdp.load_to_curated import LoadToCurated
from operators.com.economical.sdp.schema_validation import SchemaValidation
from pytz import timezone

# Pulling Values from the Variables defined in Airflow
raw_bucket_name = Variable.get("raw_bucket_name")
curated_project_name = Variable.get("curated_project_name")
csv_ingestion_mysql_connection = Variable.get("csv_ingestion_mysql_connection")


# Query Execution Function
def execute_read_query(query):
    try:
        mysql_hook = MySqlHook(mysql_conn_id=csv_ingestion_mysql_connection, schema='csv_ingestion')
        connection = mysql_hook.get_conn()
        cursor = connection.cursor()
        cursor.execute(query)
        output = cursor.fetchall()
        return output[0]
    except Exception:
        raise AirflowException(
            f"Error while running query {query} using MySQL connection {csv_ingestion_mysql_connection}")


# Query to fetch the results of specific table from csv_ingestion_load_details
load_details_query = "SELECT * FROM csv_ingestion.csv_ingestion_load_details " \
                     "WHERE " \
                     r"file_name_pattern='ECONOMICAL_Sc_Quote_Bdx_{\%Y\%m\%d}.txt' " \
                     "and " \
                     "source_system = 'acturis' " \
                     "AND " \
                     "is_active = 1;"
file = execute_read_query(load_details_query)

# Loading the results into appropriate variables
file_name_pattern = file[1]
delimiter = file[2]
header_records = file[3]
source_system = file[4]
file_location = file[5]
curated_dataset_name = file[6]
external_table_name = file[7]
curated_table_name = file[8]
is_mandatory = file[9]
is_incremental = file[10]

# Generating Table ID
table_id = f'{curated_project_name}.{curated_dataset_name}.{external_table_name}'

# Generating Curated Table ID
curated_table_id = f'{curated_project_name}.{curated_dataset_name}.{curated_table_name}'


def generate_file_name_fn(**kwargs):
    try:
        actual_file_name = ""
        client = storage.Client()
        file_name_pre = re.search("(.*){", kwargs['file_name_pattern']).group(1)
        file_name_date = datetime.strptime(kwargs["dag_run"].conf.get("run_date"), "%Y-%m-%d").strftime(
            re.search("{(.*)}", kwargs['file_name_pattern']).group(1).replace("\\", "")).lower()
        file_extension = kwargs['file_name_pattern'].split(".")[-1]
        file_name = f"{file_name_pre}{file_name_date}.{file_extension}"
        print(file_name)

        blobs = client.list_blobs(raw_bucket_name, prefix=f'{file_location}{file_name.split(".")[-2]}')
        # Note: The call returns a response only when the iterator is consumed.
        count = 0
        for blob in blobs:
            actual_file_name = blob.name.split("/")[-1]
            count += 1
        if count == 0:
            raise AirflowException(f"No file at data source - "
                                   f"gs://{raw_bucket_name}/{file_location}{file_name.split('.')[-2]}")
        elif count > 1:
            raise AirflowException(f"Expected 1 file but found {count} files present at the data source -"
                                   f"gs://{raw_bucket_name}/{file_location}{file_name.split('.')[-2]} ")
        return actual_file_name
    except Exception:
        raise AirflowException("File Name Generation Failed")


def generate_query_fn(**context):
    query = f"INSERT INTO `{curated_table_id}` " \
        f"SELECT *, " \
        f"CAST(\'{(datetime.strptime(context['dag_run'].conf.get('run_date'),'%Y-%m-%d')).strftime('%Y-%m-%d')}\' " \
        f"AS DATETIME), " \
            f"CAST(\'{(datetime.now(timezone('America/Toronto'))).strftime('%Y-%m-%dT%H:%M:%S')}\' " \
            "AS DATETIME), " \
        f" FROM `{table_id}`"
    return query


with DAG(
        dag_id='in__acturis__economical_sc_quote_bdx',
        schedule_interval=None,
        start_date=datetime(2023, 9, 22),
        tags=['fdif', 'curated', 'acturis', 'txt', 'daily'],
        catchup=False,
        max_active_runs=1,
        is_paused_upon_creation=True

) as dag:
    generate_file_name_task = PythonOperator(
        task_id='generate_file_name',
        provide_context=True,
        python_callable=generate_file_name_fn,
        op_kwargs={'file_name_pattern': file_name_pattern, }
    )
    schema_validation_task = SchemaValidation(
        task_id='schema_validation',
        raw_bucket_name=raw_bucket_name,
        curated_project_name=curated_project_name,
        csv_ingestion_mysql_connection=csv_ingestion_mysql_connection,
        file_name_pattern=file_name_pattern,
        delimiter=delimiter,
        header_records=header_records,
        source_system=source_system,
        file_location=file_location,
        curated_dataset_name=curated_dataset_name,
        external_table_name=external_table_name,
        curated_table_name=curated_table_name,
        is_mandatory=is_mandatory,
        table_id=table_id,
        curated_table_id=curated_table_id,
        file_name="{{ ti.xcom_pull(task_ids='generate_file_name') }}"
    )

    generate_query_task = PythonOperator(
        task_id='generate_query',
        provide_context=True,
        python_callable=generate_query_fn
    )

    # Load To Curated Task
    load_to_curated_task = LoadToCurated(
        task_id='load_to_curated',
        raw_bucket_name=raw_bucket_name,
        curated_project_name=curated_project_name,
        csv_ingestion_mysql_connection=csv_ingestion_mysql_connection,
        source_system=source_system,
        file_location=file_location,
        curated_dataset_name=curated_dataset_name,
        external_table_name=external_table_name,
        curated_table_name=curated_table_name,
        is_incremental=is_incremental,
        table_id=table_id,
        curated_table_id=curated_table_id,
        query="{{ ti.xcom_pull(task_ids='generate_query') }}"
    )

    delete_external_table_task = BigQueryDeleteTableOperator(
        task_id="delete_external_table",
        deletion_dataset_table=table_id,
    )
dag.doc_md = """
### DAG Documentation
- Job Description - Ingestion job to load the Acturis data from GCS to Bigquery\
using File Data Ingestion Framework
- For the Framework Details - Please refer to this <a href="https://economical.sharepoint.com/:w:/r/sites/Nitin\
OnboardingDocuments/Shared%20Documents/General/Data%20Frameworks/Delimited%20Flat%20File%20-%20File%20Data%20Ing\
estion%20Framework%20(FDIF)/Detailed%20Design%20-%20File%20Data%20Ingestion%20Framework.docx?d=w74d675bc5b224bf5\
b9ef16e416545577&csf=1&web=1&e=WcLgTX" target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this <a href="https://economical.sharepoint.com/:w:/r/sites/NitinOnboard\
ingDocuments/Shared%20Documents/General/Data%20Frameworks/Delimited%20Flat%20File%20-%20File%20Data%20Ingestion%\
20Framework%20(FDIF)/Known%20Errors%20DataBase%20-%20File%20Data%20Ingestion%20Framework.docx?d=wb1241f93d1794e4\
98b7c1f5378ac2908&csf=1&web=1&e=0R0uXx" target="_blank" st\
yle="color:blue"><u>link</u></a>
- For Job Book - Please refer to this <a href="https://economical.sharepoint.com/:w:/r/sites/NitinOnboardingDocu\
ments/Shared%20Documents/General/Data%20Frameworks/Delimited%20Flat%20File%20-%20File%20Data%20Ingestion%20Frame\
work%20(FDIF)/Runbook%20-%20File%20Data%20Ingestion%20Framework.docx?d=w1e6197264ae549e69c7256bdf36f0a34&csf=1&w\
eb=1&e=TLllXI" target="_blank" \
style="color:blue"><u>link</u></a>
"""
generate_file_name_task >> schema_validation_task >> generate_query_task >> load_to_curated_task >> \
    delete_external_table_task
