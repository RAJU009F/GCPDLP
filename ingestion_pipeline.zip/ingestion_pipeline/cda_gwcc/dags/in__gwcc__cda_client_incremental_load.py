from airflow import DAG
from airflow.models import Variable
from datetime import datetime, timedelta
from airflow.exceptions import AirflowException
from airflow.utils.trigger_rule import TriggerRule
from google.cloud import storage, bigquery

DAG_ID = 'in__gwcc__cda_client_incremental_load'
TAG_LIST = ['databricks', 'curated', 'gwcc', 'cda', 'lighthouse']
# SCHEDULE_INTERVAL = None
SCHEDULE_INTERVAL = '*/15 * * * *'
MAX_ACTIVE_RUNS = 1
OWNER = 'Data Sharks'
DESCRIPTION = 'This DAG is used for running the CDA Client\
                             Databricks Job - Incremental Load.'
DATABRICKS_RETRY_LIMIT = 1
NODE_TYPE_ID = "n2-standard-4"
DRIVER_NODE_TYPE_ID = "n2-standard-4"

DEFAULT_ARGS = {
  'owner': OWNER,
  'retries': 0,
  'retry_delay': timedelta(minutes=5),
}

config_vars = Variable.get("in__gwcc__cda_client_vars",
                           deserialize_json=True)
project = config_vars["curated_project_name"]
gwcc_data_dataset = config_vars["gwcc_data_dataset"]
manifest_dataset = config_vars["manifest_dataset"]
manifest_raw_table = config_vars["manifest_raw_table"]
bq_information_table = config_vars["bq_information_table"]
manifest_reconciliation_table = config_vars["manifest_reconciliation_table"]
manifest_bucket_name = config_vars["raw_bucket_name"]
unprocessed_folders_path = config_vars["unprocessed_folders_path"]
manifest_json_schema = config_vars["manifest_json_schema"]
destination_project_dataset_table = f'{project}'\
                                    f'.{manifest_dataset}'\
                                    f'.{manifest_raw_table}'
google_service_account = config_vars["google_service_account"]
min_workers = config_vars["min_workers"]
max_workers = config_vars["max_workers"]
policy_id = config_vars["policy_id"]
spark_version = config_vars["spark_version"]
instance_pool_id = config_vars["instance_pool_id"]
cda_library_file_name = config_vars["cda_library_file_name"]
config_file_name = config_vars["config_file_name"]
main_class_name = config_vars["main_class_name"]
databricks_conn_id = config_vars["databricks_conn_id"]
databricks_job_name = config_vars["databricks_job_name"]
deployment_bucket_name = config_vars["deployment_bucket_name"]
raw_bucket_name = config_vars["raw_bucket_name"]
acl_group_name = config_vars["acl_group_name"]

library_location = f'gs://{deployment_bucket_name}'\
                    f'/cda_gwcc/jars/{cda_library_file_name}'
sedona_spark_location = f'gs://{deployment_bucket_name}'\
                    '/cda_gwcc/jars/sedona-spark-shaded-3.0_2.12-1.4.0.jar'
geotools_wrap_location = f'gs://{deployment_bucket_name}'\
                    '/cda_gwcc/jars/geotools-wrapper-1.4.0-28.2.jar'
config_path = f'gs://{deployment_bucket_name}/ingestion_pipeline'\
                    f'/cda_gwcc/configs/{config_file_name}'


def get_sql_from_deployment_bucket(sql_file_name):
    storage_client = storage.Client()
    bucket = storage_client.bucket(deployment_bucket_name)
    blob = bucket.get_blob(
        f'ingestion_pipeline/cda_gwcc/bigquery/dml/{sql_file_name}')
    sql = blob.download_as_string().decode('utf-8')
    return sql


def get_failed_recon_rec_fn():
    bigquery_client = bigquery.Client()
    storage_client = storage.Client()
    bucket = storage_client.bucket(deployment_bucket_name)
    sql_file_path = 'ingestion_pipeline/cda_gwcc/bigquery/dml'\
                    '/cda_cc_client_manifest_recon_status.sql'
    blob = bucket.get_blob(sql_file_path)
    contents = blob.download_as_string().decode('utf-8')
    contents = contents.replace("@curated_project", project).replace(
        "@manifest_dataset", manifest_dataset).replace(
        "@manifest_reconciliation_table", manifest_reconciliation_table)
    print(contents)
    query_job = bigquery_client.query(contents)
    results = query_job.result()
    row_count = results.total_rows
    print(row_count)
    if row_count > 0:
        raise AirflowException(
            'GWCC - Curation - Manifest Reconcilition'
            ' failed. Check the reconcilation results in BigQuery'
                              )


def get_transformed_manifest_files_list(ti):
    files = ti.xcom_pull(task_ids='get_manifest_files',
                         key='return_value')
    if files:
        manifest_files = list(filter(
            lambda f: f.endswith('transformed_manifest.json'),
            files))
        return manifest_files
    else:
        return []


def check_files(ti):
    files = ti.xcom_pull(task_ids='filter_manifest_files',
                         key='return_value')
    if len(files) > 0:
        return 'load_manifest_files'
    else:
        return 'no_files_to_process'


with DAG(
  DAG_ID,
  default_args=DEFAULT_ARGS,
  description=DESCRIPTION,
  start_date=datetime(2023, 1, 1),
  tags=TAG_LIST,
  schedule_interval=SCHEDULE_INTERVAL,
  max_active_runs=MAX_ACTIVE_RUNS,
  catchup=False,
  is_paused_upon_creation=True,
  render_template_as_native_obj=True,
  user_defined_macros={"project": project,
                       "manifest_dataset": manifest_dataset,
                       "gwcc_data_dataset": gwcc_data_dataset,
                       "manifest_raw_table": manifest_raw_table,
                       "bq_information_table": bq_information_table,
                       "manifest_reconciliation_table":
                       manifest_reconciliation_table},
  ) as dag:
    databricks_cluster_config = {
        "spark_version": "11.3.x-scala2.12",
        # "node_type_id": NODE_TYPE_ID,
        # "driver_node_type_id": DRIVER_NODE_TYPE_ID,
        "policy_id": policy_id,
        "instance_pool_id": instance_pool_id,
        "max_active_runs": MAX_ACTIVE_RUNS,
        "autoscale": {
            "min_workers": min_workers,
            "max_workers": max_workers
        },
        "custom_tags": {
            "TeamName": "LightHouse_Data"
        },
        "gcp_attributes": {
            # "use_preemptible_executors": True,
            "google_service_account": google_service_account,
            "zone_id": "HA"
        },
    }

    from airflow.operators.empty import EmptyOperator
    end = EmptyOperator(task_id="end",
                        trigger_rule=TriggerRule.NONE_FAILED_OR_SKIPPED)
    no_files_to_process = EmptyOperator(task_id="no_files_to_process")

    from airflow.providers.google.cloud.operators.bigquery import (
        BigQueryInsertJobOperator)
    update_recon_status = BigQueryInsertJobOperator(
        task_id="update_recon_status",
        configuration={
            "query": {
                "query": get_sql_from_deployment_bucket(
                          'cda_cc_client_manifest_recon_v1.sql'
                          ),
                "useLegacySql": False
            }
        },
    )

#   check_recon_status = BigQueryValueCheckOperator(
#         task_id="check_recon_status",
#         sql=get_sql_from_deployment_bucket('cda_cc_client_manifest_recon_status.sql'),
#         pass_value=0,
#         use_legacy_sql=False
#     )

    from airflow.operators.python import PythonOperator
    check_recon_status = PythonOperator(
        task_id='check_recon_status',
        python_callable=get_failed_recon_rec_fn,
    )

    # from airflow.providers.databricks.operators.databricks import (
    #     DatabricksRunNowOperator)
    # gwcc_s3_to_sdp_cda_client = DatabricksRunNowOperator(
    #     # cda_client_task = DatabricksRunNowDeferrableOperator(
    #     task_id='gwcc_s3_to_sdp_cda_client',
    #     databricks_conn_id=databricks_conn_id,
    #     job_name=databricks_job_name,
    #     databricks_retry_limit=DATABRICKS_RETRY_LIMIT
    # )

    from airflow.providers.databricks.operators.databricks import (
        DatabricksSubmitRunOperator)
    gwcc_s3_to_sdp_cda_client = DatabricksSubmitRunOperator(
      task_id='gwcc_s3_to_sdp_cda_client',
      new_cluster=databricks_cluster_config,
      spark_jar_task={
        "main_class_name": main_class_name,
        "parameters": [
            "--configPath",
            config_path
        ]
      },
      databricks_conn_id=databricks_conn_id,
      libraries=[
          {
            'jar': library_location
          },
          {
            'jar': sedona_spark_location
          },
          {
            'jar': geotools_wrap_location
          }
      ],
    )

    # get_lists: get lists of unprocessed json files in manifest folders when
    # dag starts, pass the same list to load_json and move_json
    from airflow.providers.google.cloud.operators.gcs import (
        GCSListObjectsOperator)
    get_manifest_files = GCSListObjectsOperator(
      task_id='get_manifest_files',
      bucket=manifest_bucket_name,
      prefix=unprocessed_folders_path
    )

    filter_manifest_files = PythonOperator(
        task_id='filter_manifest_files',
        python_callable=get_transformed_manifest_files_list,
    )

    from airflow.operators.python import BranchPythonOperator
    check_if_files_exist = BranchPythonOperator(
        task_id='check_if_files_exist',
        python_callable=check_files,
    )

    from airflow.providers.google.cloud.transfers.gcs_to_bigquery import (
        GCSToBigQueryOperator)
    load_manifest_files = GCSToBigQueryOperator(
        task_id='load_manifest_files',
        bucket=manifest_bucket_name,
        source_objects="""{{ti.xcom_pull(task_ids='filter_manifest_files',
        key='return_value')}}""",
        destination_project_dataset_table=destination_project_dataset_table,
        create_disposition="CREATE_IF_NEEDED",
        write_disposition="WRITE_APPEND",
        source_format="NEWLINE_DELIMITED_JSON",
        schema_fields=manifest_json_schema,
        autodetect=False
    )

    from airflow.decorators import task
    from airflow.providers.google.cloud.hooks.gcs import GCSHook

    @task
    def copy_and_delete_files(filename):
        hook = GCSHook()
        hook.copy(manifest_bucket_name, filename, manifest_bucket_name,
                  filename.replace("unprocessed", "processed"))
        hook.delete(manifest_bucket_name, filename)

    move_manifest_files = copy_and_delete_files.expand(
        filename=get_manifest_files.output
    )

    gwcc_s3_to_sdp_cda_client >> get_manifest_files >> filter_manifest_files
    filter_manifest_files >> check_if_files_exist
    check_if_files_exist >> load_manifest_files >> move_manifest_files
    move_manifest_files >> update_recon_status >> check_recon_status >> end
    check_if_files_exist >> no_files_to_process >> end
