CREATE TABLE IF NOT EXISTS `@curated_project.gwcc_recon.modified_tables`
(
  modifiedTableNames ARRAY<STRING>,
  dlhBatchRunId INT64
) PARTITION BY _PARTITIONDATE;