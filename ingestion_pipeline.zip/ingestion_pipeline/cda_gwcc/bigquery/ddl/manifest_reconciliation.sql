CREATE TABLE IF NOT EXISTS `@curated_project.gwcc_recon.manifest_reconciliation` (
  table_name STRING,
  dlh_batch_run_id INTEGER,
  total_processed_records_count_manifest INTEGER,
  total_processed_records_count_gwcc INTEGER,
  recon_status STRING,
  createdon TIMESTAMP,
  updatedon TIMESTAMP
) PARTITION BY _PARTITIONDATE;

