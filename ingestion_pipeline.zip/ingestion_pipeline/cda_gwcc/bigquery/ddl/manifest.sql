CREATE TABLE IF NOT EXISTS `@curated_project.gwcc_recon.manifest`
(
  schemaHistory ARRAY<STRUCT<timestamp INT64, fingerPrintId STRING>>,
  dataFilesPath STRING,
  totalProcessedRecordsCount INT64,
  lastSuccessfulWriteTimestamp INT64,
  tableName STRING,
  dlhBatchRunId INT64
) PARTITION BY _PARTITIONDATE;