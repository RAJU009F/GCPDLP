	INSERT INTO `{{ project }}.{{ manifest_dataset }}.{{ manifest_reconciliation_table }}` (table_name,dlh_batch_run_id,total_processed_records_count_manifest,total_processed_records_count_gwcc,recon_status, createdon, updatedon)
    SELECT 
      tableName,
      dlhBatchRunId,
      totalProcessedRecordsCount,
      total_processed_records_count_gwcc,
      recon_status,
      createdon,
      updatedon
    FROM (
    SELECT
      tableName,
      dlhBatchRunId,
      totalProcessedRecordsCount,
      0 as total_processed_records_count_gwcc,
     'WIP' as recon_status,
      CURRENT_TIMESTAMP() as createdon,
      CURRENT_TIMESTAMP() as updatedon,
      ROW_NUMBER() OVER (PARTITION BY tableName ORDER BY dlhBatchRunId DESC) AS row_num
    FROM
      `{{ project }}.{{ manifest_dataset }}.{{ manifest_raw_table }}` 
      WHERE DATE(_PARTITIONTIME) = DATE(CURRENT_TIMESTAMP())
      ) t1
    where t1.row_num = 1 ;

MERGE `{{ project }}.{{ manifest_dataset }}.{{ manifest_reconciliation_table }}` cbm
USING
  (
  SELECT
    table_id,
    row_count
  FROM
    `{{ project }}.{{ gwcc_data_dataset }}.{{ bq_information_table }}`) data
ON
  cbm.table_name = data.table_id and cbm.recon_status = 'WIP'
  WHEN MATCHED AND cbm.total_processed_records_count_manifest = data.row_count THEN UPDATE SET cbm.recon_status = 'SUCCESS', cbm.total_processed_records_count_gwcc = data.row_count, cbm.updatedon = CURRENT_TIMESTAMP()
  WHEN MATCHED THEN UPDATE SET cbm.recon_status = 'FAIL', cbm.total_processed_records_count_gwcc = data.row_count, cbm.updatedon = CURRENT_TIMESTAMP()
  
  
  
  
  