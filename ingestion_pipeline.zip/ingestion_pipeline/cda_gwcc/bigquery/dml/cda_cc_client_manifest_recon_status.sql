SELECT recon_status,row_num FROM (
SELECT table_name,dlh_batch_run_id,recon_status,
ROW_NUMBER() OVER (PARTITION BY table_name ORDER BY dlh_batch_run_id DESC) AS row_num
FROM `@curated_project.@manifest_dataset.@manifest_reconciliation_table`
WHERE DATE(_PARTITIONTIME) = DATE(CURRENT_TIMESTAMP())
)
WHERE recon_status = 'FAIL' AND row_num = 1