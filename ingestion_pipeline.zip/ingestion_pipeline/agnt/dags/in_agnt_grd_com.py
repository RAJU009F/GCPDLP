import csv
import io
import re
from datetime import datetime
from google.cloud import storage
from google.cloud import bigquery
from airflow import DAG
from airflow.exceptions import AirflowException
from airflow.models import Variable
from airflow.hooks.mysql_hook import MySqlHook
from airflow.operators.python import PythonOperator
from airflow.providers.google.cloud.operators.bigquery import (
    BigQueryDeleteTableOperator,
)
from operators.com.economical.migration.bq_load_to_curated import (
    LoadToCurated,
)
from operators.com.economical.migration.move_files import MovingFile
from operators.com.economical.migration.pre_validation import PreValidation


# Pulling Values from the Variables defined in Airflow
raw_project_name = Variable.get("raw_project_name")
raw_bucket_name = Variable.get("raw_bucket_name")
curated_project_name = Variable.get("curated_project_name")
csv_ingestion_mysql_connection = Variable.get("csv_audit_mysql_connection")


# Query Execution Function
def execute_read_query(query):
    try:
        mysql_hook = MySqlHook(
            mysql_conn_id=csv_ingestion_mysql_connection,
            schema="csv_ingestion",
        )
        connection = mysql_hook.get_conn()
        cursor = connection.cursor()
        cursor.execute(query)
        output = cursor.fetchall()
        return output[0]
    except Exception:
        raise AirflowException(
            f"Error while running query {query} using MySQL connection"
            f" {csv_ingestion_mysql_connection}"
        )


# Query to fetch the results of specific table from csv_ingestion_load_details
load_details_query = (
    "SELECT * FROM csv_ingestion.csv_ingestion_load_details \
    WHERE file_name_pattern='DHAGASCI.DHAGASCI.GRDCOM.DH{\\%y\\%m\\%d}' \
    AND source_system = 'agnt' AND is_active = 1;"
)
file = execute_read_query(load_details_query)

# Loading the results into appropriate variables
file_name_pattern = file[1]
delimiter = file[2]
header_records = file[3]
source_system = file[4]
file_location = file[5]
curated_dataset_name = file[6]
external_table_name = file[7]
curated_table_name = file[8]
is_mandatory = file[9]
is_incremental = file[10]


file_name_prefix = re.search("(.*){", file_name_pattern).group(1)

# Generating Table ID
external_table_id = (
    f"{curated_project_name}.{curated_dataset_name}.{external_table_name}"
)

# Generating Curated Table ID
curated_table_id = (
    f"{curated_project_name}.{curated_dataset_name}.{curated_table_name}"
)

# GCS client
storage_client = storage.Client(project=raw_project_name)

# Bigquery client
bigquery_client = bigquery.Client(project=curated_project_name)


def get_file_execution_date(**kwargs):
    """
    function to get execution date
    """
    execution_date = kwargs['dag_run'].conf['run_date']
    print("Execution date in_agnt_grd_com dag:", execution_date)
    execution_date = (datetime.strptime(str(execution_date), "%Y-%m-%d"))
    strip_execution_date = (execution_date).strftime("%Y-%m-%d")[2:].replace("-", "")
    file_name = f"{file_name_prefix}{strip_execution_date}"
    execution_date = execution_date.strftime("%Y-%m-%d")
    return file_name, str(execution_date), strip_execution_date


def call_move_files(**context):
    """
    function to execute move_file_to_working_folder task
    """
    file_name = context["task_output"][0]
    strip_execution_date = context["task_output"][2]

    move_file_to_working_folder = MovingFile(
        task_id="move_file_to_working_folder",
        raw_project_name=raw_project_name,
        raw_bucket_name=raw_bucket_name,
        src_blob_name=f"{source_system}/landing/",
        dest_blob_name=f"{file_location}{strip_execution_date}/",
        extracted_file_name_pattern=file_name,
        execution_date=strip_execution_date,
    )
    move_file_to_working_folder.execute(dict(context))


def call_pre_validation(**context):
    """
    function to execute pre_validation task
    """
    file_name = context["task_output"][0]
    strip_execution_date = context["task_output"][2]
    updated_file_location = f"{file_location}{strip_execution_date}/"

    pre_validation_task = PreValidation(
        task_id="pre_validation_task",
        raw_bucket_name=raw_bucket_name,
        curated_project_name=curated_project_name,
        csv_ingestion_mysql_connection=csv_ingestion_mysql_connection,
        file_name_pattern=file_name_pattern,
        delimiter=delimiter,
        header_records=header_records,
        source_system=source_system,
        file_location=updated_file_location,
        curated_dataset_name=curated_dataset_name,
        external_table_name=external_table_name,
        curated_table_name=curated_table_name,
        is_mandatory=is_mandatory,
        table_id=external_table_id,
        curated_table_id=curated_table_id,
        file_name=file_name,
    )
    pre_validation_task.execute(dict(context))


def call_load_to_curated(**context):
    """
    function to execute load_to_curated task
    """
    file_name = context["task_output"][0]
    execution_date = context["task_output"][1]
    strip_execution_date = context["task_output"][2]
    updated_file_location = f"{file_location}{strip_execution_date}/"

    load_to_curated = LoadToCurated(
        task_id="load_to_curated",
        raw_bucket_name=raw_bucket_name,
        curated_project_name=curated_project_name,
        csv_ingestion_mysql_connection=csv_ingestion_mysql_connection,
        source_system=source_system,
        file_location=updated_file_location,
        curated_dataset_name=curated_dataset_name,
        external_table_name=external_table_name,
        curated_table_name=curated_table_name,
        is_incremental=is_incremental,
        table_id=external_table_id,
        curated_table_id=curated_table_id,
        file_name=file_name,
        execution_date=execution_date,
    )
    load_to_curated.execute(dict(context))


def get_table_count(query):
    """
    function to get count of records from
    external table and curated table
    """
    query_job = bigquery_client.query(query)
    rows = query_job.result()
    for row in rows:
        row_count = row["count"]
    return row_count


def post_validation_check_count(**context):
    """
    function to match count of records across
    csv file, external table and curated table
    """
    file_name = context["task_output"][0]
    execution_date = context["task_output"][1]
    strip_execution_date = context["task_output"][2]
    updated_file_location = f"{file_location}{strip_execution_date}/"

    bucket = storage_client.bucket(raw_bucket_name)
    blob = bucket.blob(f"{updated_file_location}{file_name}")
    read_file = blob.download_as_string().decode("unicode_escape")
    read_output = io.StringIO(read_file)
    file_content = list(
        csv.reader(
            (content.replace("\0", "") for content in read_output),
            delimiter="|",
        )
    )
    file_row_count = len(file_content)

    curated_table_count_query = f""" SELECT count(*) AS count
    FROM `{curated_table_id}`
    WHERE dlh_batch_ts = CAST('{execution_date}' AS DATETIME) """

    curated_table_count = get_table_count(curated_table_count_query)

    external_table_query = (
        f""" SELECT count(*) AS count FROM `{external_table_id}` """
    )

    external_table_count = get_table_count(external_table_query)

    if file_row_count == curated_table_count == external_table_count:
        print(
            f"file_row_count: {file_row_count}, curated_table_count:"
            f" {curated_table_count}, external_table_count:"
            f" {external_table_count}"
        )
        print("Records Count Match")
    else:
        raise AirflowException(
            "Count Mismatch",
            file_row_count,
            curated_table_count,
            external_table_count,
        )


with DAG(
    dag_id="in_agnt_grd_com",
    schedule_interval=None,
    start_date=datetime(2023, 2, 2),
    tags=["in_agnt_grd_com", "curated", "agnt", "csv", "daily"],
    catchup=False,
    max_active_runs=1,
) as dag:
    # Task to get execution date
    get_file_execution_date = PythonOperator(
        task_id="get_file_execution_date",
        python_callable=get_file_execution_date,
        provide_context=True,
    )

    # Task to check file in landing folder and
    # moving file from landing to working folder
    call_move_files = PythonOperator(
        task_id="call_move_files",
        python_callable=call_move_files,
        provide_context=True,
        op_kwargs={"task_output": get_file_execution_date.output},
    )

    # Pre Validation Task
    call_pre_validation = PythonOperator(
        task_id="call_pre_validation",
        python_callable=call_pre_validation,
        provide_context=True,
        op_kwargs={"task_output": get_file_execution_date.output},
    )

    # load curated table
    call_load_to_curated = PythonOperator(
        task_id="call_load_to_curated",
        python_callable=call_load_to_curated,
        provide_context=True,
        op_kwargs={"task_output": get_file_execution_date.output},
    )

    # validation of number of records in csv file,
    # external table and curated table
    post_validation_check = PythonOperator(
        task_id="post_validation_check",
        python_callable=post_validation_check_count,
        provide_context=True,
        op_kwargs={"task_output": get_file_execution_date.output},
    )

    # deleting external table
    delete_external_table = BigQueryDeleteTableOperator(
        task_id="delete_external_table",
        deletion_dataset_table=external_table_id,
    )

dag.doc_md = """
### DAG Documentation
- Job Description - Ingestion job to load AGNT GRDCOM file data from GCS to
Google Big Query for Hive tables in edhprod_data_lake.db
- For the Framework Details - Please refer to this
<a href="https://economical.atlassian.net/wiki/spaces/DAT/pages/43471996726/
EDH+Migration+Rel+1.0+-+AGNT+Migration+GCS+to+GBQ#Framework-Details"
target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href="https://economical.atlassian.net/wiki/spaces/DAT/pages/43471996726/
EDH+Migration+Rel+1.0+-+AGNT+Migration+GCS+to+GBQ#Troubleshooting"
 target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href="https://economical.atlassian.net/wiki/spaces/DAT/pages/43471996726/
EDH+Migration+Rel+1.0+-+AGNT+Migration+GCS+to+GBQ#Job-Schedule"
 target="_blank" style="color:blue"><u>link</u></a>
"""

(
    get_file_execution_date
    >> call_move_files
    >> call_pre_validation
    >> call_load_to_curated
    >> post_validation_check
    >> delete_external_table
)
