import json
import logging
import sys
from datetime import datetime
from airflow import models
from airflow.models import Variable
from airflow.providers.ftp.hooks.ftp import FTPHook
from airflow.operators.python_operator import PythonOperator
from airflow.exceptions import AirflowException
from airflow.providers.google.cloud.transfers.gcs_to_gcs import (
    GCSToGCSOperator,
)
from google.cloud import storage


ftp_conn_id = Variable.get("Mainframe_FTP")
run_environment = Variable.get("run_environment")
raw_bucket_name = Variable.get("raw_bucket_name")
raw_project_name = Variable.get("raw_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")


src_path = "data/temp_files/"
destination_path = "agnt/landing/"

file_pattern = []


class CloudLoggingFormatter(logging.Formatter):

    """Produces messages compatible with google cloud logging"""

    def format(self, record: logging.LogRecord) -> str:
        s = super().format(record)
        return json.dumps(
            {
                "message": s,
                "severity": record.levelname,
                "labels": record.args,
                "test": "test_log",
            }
        )


def get_custom_logger(name):
    cloud_logger = logging.getLogger(name)
    handler = logging.StreamHandler(sys.stdout)
    formatter = CloudLoggingFormatter(
        fmt="[%(asctime)s] {%(filename)s:%(lineno)d} - %(message)s"
    )
    handler.setFormatter(formatter)
    cloud_logger.addHandler(handler)
    cloud_logger.setLevel(logging.DEBUG)
    return cloud_logger


def get_execution_date(**kwargs):
    """
    function to get execution date
    """
    execution_date = (
        kwargs['dag_run'].conf['run_date']
    )
    print("This is the order date from scheduler", execution_date)
    return execution_date


def send_data(ti, **context):
    """
    function to connect to Mainframe server and copy files to GCS
    """
    hook = FTPHook(ftp_conn_id=ftp_conn_id)
    hook.get_conn()
    hook.test_connection()

    execution_date = ti.xcom_pull(
        task_ids="get_execution_date", key="return_value"
    )
    execution_date = (datetime.strptime(str(execution_date), "%Y-%m-%d"))
    strip_execution_date = (execution_date).strftime("%Y-%m-%d")[2:].replace("-", "")
    execution_date = execution_date.strftime("%Y-%m-%d")

    file_pattern = [
        f"DHAGASCI.DHAGASCI.AGMAST.DH{strip_execution_date}",
        f"DHAGASCI.DHAGASCI.BRKCOM.DH{strip_execution_date}",
        f"DHAGASCI.DHAGASCI.AGPROF.DH{strip_execution_date}",
        f"DHAGASCI.DHAGASCI.GRDCOM.DH{strip_execution_date}",
        f"DHAGASCI.DHAGASCI.DHAGBAL.DH{strip_execution_date}",
    ]

    for file_name in file_pattern:
        try:
            hook.retrieve_file(
                f"/'{run_environment}{file_name}'",
                f"/home/airflow/gcs/data/temp_files/{file_name}",
            )
            move_files_to_landing = GCSToGCSOperator(
                task_id="move_files_to_landing",
                source_bucket=composer_bucket_name,
                source_object=f"{src_path}{file_name}",
                destination_bucket=raw_bucket_name,
                destination_object=f"{destination_path}{file_name}",
                move_object=True,
            )
            move_files_to_landing.execute(dict(context))
        except Exception:
            logging.error(f"/'{run_environment}{file_name}' not found")
            raise AirflowException(
                f"/'{run_environment}{file_name}' not found"
            )

    return str(execution_date)


def check_file_existence(ti):
    """
    function to check whether all files are copied to GCS bucket or not
    """
    list_filename = []
    prefix = destination_path
    count = 0
    storage_client = storage.Client(project=raw_project_name)
    bucket = storage_client.bucket(raw_bucket_name)
    for blob in list(bucket.list_blobs(prefix=prefix)):
        list_filename.append(str(blob.name[len(prefix):]))

    execution_date = ti.xcom_pull(
        task_ids="get_execution_date", key="return_value"
    )
    execution_date = (datetime.strptime(str(execution_date), "%Y-%m-%d"))
    strip_execution_date = (execution_date).strftime("%Y-%m-%d")[2:].replace("-", "")
    file_pattern = [
        f"DHAGASCI.DHAGASCI.AGMAST.DH{strip_execution_date}",
        f"DHAGASCI.DHAGASCI.BRKCOM.DH{strip_execution_date}",
        f"DHAGASCI.DHAGASCI.AGPROF.DH{strip_execution_date}",
        f"DHAGASCI.DHAGASCI.GRDCOM.DH{strip_execution_date}",
        f"DHAGASCI.DHAGASCI.DHAGBAL.DH{strip_execution_date}",
    ]

    for file in file_pattern:
        if file in list_filename:
            logging.info(file)
            count += 1
        else:
            logging.error(f"{file} is not found in bucket")
            raise AirflowException(f"{file} is not found in bucket")

    if count == 0:
        logging.error("files with current date not found in bucket")
        raise AirflowException(
            "files with current date not found in bucket"
        )
    else:
        logging.info(
            "Files are transferred in GCS Landing folder and the count"
            f" is: {count}"
        )


with models.DAG(
    "im_agnt_raw",
    start_date=datetime(2023, 3, 16),
    schedule_interval=None,
    catchup=False,
    max_active_runs=1,
) as dag:
    get_execution_date = PythonOperator(
        task_id="get_execution_date",
        python_callable=get_execution_date,
        dag=dag,
    )

    ftp_to_gcs = PythonOperator(
        task_id="ftp_to_gcs", python_callable=send_data, dag=dag
    )

    check_file_existence = PythonOperator(
        task_id="check_file_existence",
        python_callable=check_file_existence,
    )

dag.doc_md = """
### DAG Documentation
- Job Description - Ingestion job to fetch AGNT files
from FTP to GCS and trigger ingestion jobs.
- For the Framework Details - Please refer to this
<a href="https://economical.atlassian.net/wiki/spaces/DAT/pages/43471996726/
EDH+Migration+Rel+1.0+-+AGNT+Migration+GCS+to+GBQ#Framework-Details"
target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href="https://economical.atlassian.net/wiki/spaces/DAT/pages/43471996726/
EDH+Migration+Rel+1.0+-+AGNT+Migration+GCS+to+GBQ#Troubleshooting"
 target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href="https://economical.atlassian.net/wiki/spaces/DAT/pages/43471996726/
EDH+Migration+Rel+1.0+-+AGNT+Migration+GCS+to+GBQ#Job-Schedule"
 target="_blank" style="color:blue"><u>link</u></a>
"""
(
    get_execution_date
    >> ftp_to_gcs
    >> check_file_existence
)
