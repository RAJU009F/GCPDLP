# Importing Modules
from datetime import datetime
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.models import Variable
from airflow.exceptions import AirflowException
from google.cloud import bigquery, storage

deployment_bucket_name = Variable.get("deployment_bucket_name")
curated_project_name = Variable.get("curated_project_name")
curated_dataset_name = Variable.get("agnt_dataset")
bal_temp_curated_table_id = (
    f"{curated_project_name}.{curated_dataset_name}.bal_daily_temp"
)
bal_final_curated_table_id = (
    f"{curated_project_name}.{curated_dataset_name}.bal_final"
)

bigquery_client = bigquery.Client(project=curated_project_name)
storage_client = storage.Client()
bucket = storage_client.bucket(deployment_bucket_name)
query_path = "ingestion_pipeline/agnt/bigquery/dml"


def load_to_bal_daily_temp_fn(**kwargs):
    """
    function to read sql file from GCS and execute in Bigquery
    """
    execution_date = kwargs['dag_run'].conf['run_date']
    blob = bucket.get_blob(
        f"{query_path}/extract_and_load_agnt_bal_daily_temp.sql"
    )
    contents = blob.download_as_string().decode("utf-8")
    contents = (
        contents.replace("@execution_date", execution_date)
        .replace("@curated_project_name", curated_project_name)
    )
    bigquery_client.query(contents)
    return execution_date


def load_to_bal_final_fn(**kwargs):
    """
    function to read sql file from GCS and execute in Bigquery
    """
    execution_date = kwargs['dag_run'].conf['run_date']
    blob = bucket.get_blob(
        f"{query_path}/extract_and_load_bal_final.sql"
    )
    contents = blob.download_as_string().decode("utf-8")
    contents = (
        contents.replace("@execution_date", execution_date)
        .replace("@curated_project_name", curated_project_name)
    )
    bigquery_client.query(contents)


def get_table_count(query):
    """
    function to get count of records from
    external table and curated table
    """
    query_job = bigquery_client.query(query)
    rows = query_job.result()
    for row in rows:
        row_count = row["count"]
    return row_count


def post_validation_check_count(**context):
    """
    function to match count of records across
    csv file, external table and curated table
    """
    execution_date = context["task_output"]
    bal_final_curated_table_query = f""" SELECT count(*) AS count
    FROM `{bal_final_curated_table_id}`
    WHERE dlh_batch_ts = CAST('{execution_date}' AS DATETIME) """
    bal_final_curated_table_count = get_table_count(
        bal_final_curated_table_query
    )
    bal_temp_curated_table_query = f"""
    SELECT count(*) AS count FROM `{bal_temp_curated_table_id}` """
    bal_temp_curated_table_count = get_table_count(
        bal_temp_curated_table_query
    )
    if bal_final_curated_table_count == bal_temp_curated_table_count:
        print(
            "bal_final_curated_table_count:"
            f" {bal_final_curated_table_count},"
            " bal_temp_curated_table_count:"
            f" {bal_temp_curated_table_count}"
        )
        print("Records Count Match")
    else:
        raise AirflowException(
            "Count Mismatch",
            bal_final_curated_table_count,
            bal_temp_curated_table_count,
        )


with DAG(
    dag_id="in_agnt_bal_final",
    schedule_interval=None,
    start_date=datetime(2023, 2, 21),
    tags=["in_agnt_bal_final", "curated", "agnt", "csv", "daily"],
    catchup=False,
    max_active_runs=1,
) as dag:
    load_to_bal_daily_temp = PythonOperator(
        task_id="load_to_bal_daily_temp",
        python_callable=load_to_bal_daily_temp_fn,
    )

    load_to_bal_final = PythonOperator(
        task_id="load_to_bal_final",
        python_callable=load_to_bal_final_fn,
    )

    post_validation_check = PythonOperator(
        task_id="post_validation_check",
        python_callable=post_validation_check_count,
        provide_context=True,
        op_kwargs={"task_output": load_to_bal_daily_temp.output},
    )

dag.doc_md = """
### DAG Documentation
-Job Description - Job to trigger multiple custom SQL's to load
bal_daily_temp, bal_final table for AGNT
- For the Framework Details - Please refer to this
<a href="https://economical.atlassian.net/wiki/spaces/DAT/pages/43471996726/
EDH+Migration+Rel+1.0+-+AGNT+Migration+GCS+to+GBQ#Framework-Details"
target="_blank" style="color:blue"><u>link</u></a>
- For Troubleshooting - Please refer to this
<a href="https://economical.atlassian.net/wiki/spaces/DAT/pages/43471996726/
EDH+Migration+Rel+1.0+-+AGNT+Migration+GCS+to+GBQ#Troubleshooting"
 target="_blank" style="color:blue"><u>link</u></a>
- For Job Book - Please refer to this
<a href="https://economical.atlassian.net/wiki/spaces/DAT/pages/43471996726/
EDH+Migration+Rel+1.0+-+AGNT+Migration+GCS+to+GBQ#Job-Schedule"
 target="_blank" style="color:blue"><u>link</u></a>
"""

load_to_bal_daily_temp >> load_to_bal_final >> post_validation_check
