INSERT INTO
  `@curated_project_name.agnt.bal_final`
SELECT CAST ('@execution_date' AS DATETIME),
DATETIME(TIMESTAMP(FORMAT_DATETIME("%Y-%m-%d %H:%M:%S",CURRENT_DATETIME("America/Toronto")))), 
    combined.*
FROM (
  SELECT
    temp5.process_name,
    temp5.agnt_file,
    temp5.cnt_type_cd,
    temp5.cnt_before,
    temp5.cnt_after,
    temp5.balance_ind,
    temp5.process_dt
  FROM (
    SELECT
      bal_daily_temp.process_name,
      bal_daily_temp.agnt_file,
      bal_daily_temp.cnt_type_cd,
      bal_daily_temp.cnt_before,
      bal_daily_temp.cnt_after,
      bal_daily_temp.balance_ind,
      bal_daily_temp.process_dt
    FROM
      `@curated_project_name.agnt.bal_daily_temp` AS bal_daily_temp
    WHERE
      bal_daily_temp.process_dt BETWEEN CAST ('@execution_date' AS DATETIME)
      AND CAST ('@execution_date' AS DATETIME) ) AS temp5
  ORDER BY
    temp5.process_dt,
    temp5.agnt_file,
    temp5.cnt_type_cd ) AS combined ;