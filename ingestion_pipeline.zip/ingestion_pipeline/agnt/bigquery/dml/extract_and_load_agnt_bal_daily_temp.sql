TRUNCATE TABLE
  `@curated_project_name.agnt.bal_daily_temp`;
INSERT INTO
  `@curated_project_name.agnt.bal_daily_temp` (
  SELECT
    CAST ('@execution_date' AS DATETIME),
    DATETIME(TIMESTAMP(FORMAT_DATETIME("%Y-%m-%d %H:%M:%S",CURRENT_DATETIME("America/Toronto")))),
    combined.*
  FROM (
    SELECT
      temp6.process_name,
      temp6.table_name,
      temp6.agnt_file,
      temp6.cnt_type_cd,
      temp6.cnt_before,
      temp6.cnt_after,
      temp6.balance_ind,
      temp6.process_dt
    FROM (
      SELECT
        temp5.process_name,
        temp5.table_name,
        temp5.agnt_file,
        temp5.cnt_type_cd,
        temp5.cnt_before,
        temp5.cnt_after,
        temp5.balance_ind,
        temp5.process_dt
      FROM (
        SELECT
          'DH_AGNT' AS process_name,
          'agent_master' AS table_name,
          'AGNT_MASTER' AS agnt_file,
          'AGNT_MASTER_CNT' AS cnt_type_cd,
          CAST(agnt.count_ag_mast AS STRING) AS cnt_before,
          CAST(agnt_table.count_ag_mast AS STRING) AS cnt_after,
          CASE TRUE
            WHEN CAST(agnt.count_ag_mast AS STRING) = CAST(agnt_table.count_ag_mast AS STRING) THEN 'Y'
          ELSE
          'N'
        END
          AS balance_ind,
          CAST ('@execution_date' AS DATETIME) AS process_dt
        FROM (
          SELECT
            bal_daily_mf_temp.bal_cnt AS count_ag_mast
          FROM
            `@curated_project_name.agnt.bal_daily_mf_temp` AS bal_daily_mf_temp
          WHERE
            bal_daily_mf_temp.bal_process_file = 'AGMASTDC AGNT-MASTER'
            AND bal_daily_mf_temp.bal_cnt_type_cd = 'RECORDS-CNT' ) AS agnt
        CROSS JOIN (
          SELECT
            COUNT(*) AS count_ag_mast
          FROM
            `@curated_project_name.agnt.agent_master` AS agent_master
          WHERE
            DATE(agent_master.processed_date) <= cast('@execution_date' as date)
            AND DATE(agent_master.processed_date) >= cast('@execution_date' as date) ) AS agnt_table
        UNION ALL
        SELECT
          'DH_AGNT' AS process_name,
          'brk_profile' AS table_name,
          'BRK_PROFILE' AS agnt_file,
          'BRK_PROFILE_CNT' AS cnt_type_cd,
          CAST(agnt.count_brk_profile AS STRING) AS cnt_before,
          CAST(agnt_table.count_brk_profile AS STRING) AS cnt_after,
          CASE TRUE
            WHEN CAST(agnt.count_brk_profile AS STRING) = CAST(agnt_table.count_brk_profile AS STRING) THEN 'Y'
          ELSE
          'N'
        END
          AS balance_ind,
          CAST ('@execution_date' AS DATETIME) AS process_dt
        FROM (
          SELECT
            bal_daily_mf_temp.bal_cnt AS count_brk_profile
          FROM
            `@curated_project_name.agnt.bal_daily_mf_temp` AS bal_daily_mf_temp
          WHERE
            bal_daily_mf_temp.bal_process_file = 'EC1121DC BRK-PROFILE'
            AND bal_daily_mf_temp.bal_cnt_type_cd = 'RECORDS-CNT' ) AS agnt
        CROSS JOIN (
          SELECT
            COUNT(*) AS count_brk_profile
          FROM
            `@curated_project_name.agnt.brk_profile` AS brk_profile
          WHERE
            DATE(brk_profile.processed_date) <= cast('@execution_date' as date)
            AND DATE(brk_profile.processed_date) >= cast('@execution_date' as date) ) AS agnt_table
        UNION ALL
        SELECT
          'DH_AGNT' AS process_name,
          'brk_com' AS table_name,
          'BRK_COMMS' AS agnt_file,
          'BRK_COMMS_CNT' AS cnt_type_cd,
          CAST(agnt.count_brk_com AS STRING) AS cnt_before,
          CAST(agnt_table.count_brk_com AS STRING) AS cnt_after,
          CASE TRUE
            WHEN CAST(agnt.count_brk_com AS STRING) = CAST(agnt_table.count_brk_com AS STRING) THEN 'Y'
          ELSE
          'N'
        END
          AS balance_ind,
          CAST ('@execution_date' AS DATETIME) AS process_dt
        FROM (
          SELECT
            bal_daily_mf_temp.bal_cnt AS count_brk_com
          FROM
            `@curated_project_name.agnt.bal_daily_mf_temp` AS bal_daily_mf_temp
          WHERE
            bal_daily_mf_temp.bal_process_file = 'BRKCOMDC BRK-COMMIS'
            AND bal_daily_mf_temp.bal_cnt_type_cd = 'RECORDS-CNT' ) AS agnt
        CROSS JOIN (
          SELECT
            COUNT(*) AS count_brk_com
          FROM
            `@curated_project_name.agnt.brk_com` AS brk_com
          WHERE
            DATE(brk_com.processed_date) <= cast('@execution_date' as date)
            AND DATE(brk_com.processed_date) >= cast('@execution_date' as date) ) AS agnt_table
        UNION ALL
        SELECT
          'DH_AGNT' AS process_name,
          'grd_com' AS table_name,
          'GRD_COMMS' AS agnt_file,
          'GRD_COMMS_CNT' AS cnt_type_cd,
          CAST(agnt.count_grd_com AS STRING) AS cnt_before,
          CAST(agnt_table.count_grd_com AS STRING) AS cnt_after,
          CASE TRUE
            WHEN CAST(agnt.count_grd_com AS STRING) = CAST(agnt_table.count_grd_com AS STRING) THEN 'Y'
          ELSE
          'N'
        END
          AS balance_ind,
          CAST ('@execution_date' AS DATETIME) AS process_dt
        FROM (
          SELECT
            bal_daily_mf_temp.bal_cnt AS count_grd_com
          FROM
            `@curated_project_name.agnt.bal_daily_mf_temp` AS bal_daily_mf_temp
          WHERE
            bal_daily_mf_temp.bal_process_file = 'GRDCOMDC GRADE-COMMS'
            AND bal_daily_mf_temp.bal_cnt_type_cd = 'RECORDS-CNT' ) AS agnt
        CROSS JOIN (
          SELECT
            COUNT(*) AS count_grd_com
          FROM
            `@curated_project_name.agnt.grd_com` AS grd_com
          WHERE
            DATE(grd_com.processed_date) <= cast('@execution_date' as date)
            AND DATE(grd_com.processed_date) >= cast('@execution_date' as date) ) AS agnt_table ) AS temp5
      GROUP BY
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8
      ORDER BY
        temp5.agnt_file ) AS temp6
    ORDER BY
      temp6.process_dt,
      temp6.agnt_file,
      temp6.cnt_type_cd ) AS combined
      ) ;
