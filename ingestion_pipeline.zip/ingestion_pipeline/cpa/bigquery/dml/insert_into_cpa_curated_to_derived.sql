truncate table `@derived_project.@derived_dataset_name.financial_institutions_file`;
INSERT INTO `@derived_project.@derived_dataset_name.financial_institutions_file` (
  SELECT 
  *
  FROM `@curated_project.@curated_dataset_name.financial_institutions_file`);

INSERT INTO `@derived_project.@derived_dataset_name.financial_institutions_file_update_history` (
SELECT
    CAST('@execution_date' AS DATETIME) AS dlh_batch_ts,
    DATETIME(TIMESTAMP(FORMAT_DATETIME("%Y-%m-%d %H:%M:%S",CURRENT_DATETIME("America/Toronto")))) AS dlh_process_ts,
    shortfilename,
   -- CAST(FORMAT_DATETIME('%Y-%m-%d %H:%M:%S', CAST(TIMESTAMP_SECONDS(UNIX_SECONDS(SAFE.PARSE_TIMESTAMP('%Y-%m-%d', '@execution_date'))) AS DATETIME)) AS DATETIME) AS updstamp
   CURRENT_DATETIME as updstamp
FROM (
    SELECT 
        REGEXP_EXTRACT(_FILE_NAME, r'[^/]*$') AS shortfilename
    FROM `@curated_project.@curated_dataset_name.@external_table_name`
    GROUP BY shortfilename
));