from airflow import models
from airflow.models import Variable
from airflow.providers.apache.beam.operators.beam import (
    BeamRunJavaPipelineOperator,
)
from airflow.providers.google.cloud.transfers.gcs_to_local import (
    GCSToLocalFilesystemOperator,
)

from datetime import datetime
from urllib.parse import urlparse

env = Variable.get("env")
raw_bucket_name = Variable.get("raw_bucket_name")
processing_project_name = Variable.get("processing_project_name")
raw_project_name = Variable.get("raw_project_name")
MqToGCSIngestion_config = Variable.get("MqToGCSIngestion_config", deserialize_json=True)
mqLbEnvFlag = Variable.get("mqLbEnv")
batchEnableFlag = False

mqChannel = MqToGCSIngestion_config["mqChannel"]
mqHost = MqToGCSIngestion_config["mqHost"]
mqManager = MqToGCSIngestion_config["mqManager"]
mqPort = MqToGCSIngestion_config["mqPort"]

mqChannelLb = MqToGCSIngestion_config["mqChannelLb"]
mqHostLb = MqToGCSIngestion_config["mqHostLb"]
mqManagerLb = MqToGCSIngestion_config["mqManagerLb"]
mqPortLb = MqToGCSIngestion_config["mqPortLb"]

windowDuration = MqToGCSIngestion_config["windowDuration"]
numOfShards = MqToGCSIngestion_config["numOfShards"]
tempLocation = MqToGCSIngestion_config["tempLocation"]
stagingLocation = MqToGCSIngestion_config["stagingLocation"]

mqUserSecret = MqToGCSIngestion_config["mqUserSecret"]
mqPasswordSecret = MqToGCSIngestion_config["mqPasswordSecret"]
mqUserSecretLb = MqToGCSIngestion_config["mqUserSecretLb"]
mqPasswordSecretLb = MqToGCSIngestion_config["mqPasswordSecretLb"]
subnetwork = MqToGCSIngestion_config["subnetwork"]

# dag level setup
mqQueue = "CHQ.CHQ_DISBURSEMENTS_VERSION_2.DATAHUB.DGM.Q"
mqQueueLb = "CHQ.CHQ_DISBURSEMENTS_VERSION_2.DATAHUB.DGM.Q"
gcsOutput = "chq/disbursements/landing/gcp.{}01.chq.fct.disbursements.0/chq_disbursements-".format(env)
if batchEnableFlag:
    gcsOutput = "gs://{}/{}".format(raw_bucket_name, gcsOutput)

JAR_FILE_NAME = MqToGCSIngestion_config["jar_file"]
MqToGCSIngestion_jar_path = "gs://{}/jars/{}".format(Variable.get("deployment_bucket_name"), JAR_FILE_NAME)
GCS_JAR_DATAFLOW_RUNNER_PARTS = urlparse(MqToGCSIngestion_jar_path)
GCS_JAR_DATAFLOW_RUNNER_BUCKET_NAME = GCS_JAR_DATAFLOW_RUNNER_PARTS.netloc
DATAFLOW_JAR_OBJECT_NAME = GCS_JAR_DATAFLOW_RUNNER_PARTS.path[1:]
service_Account = MqToGCSIngestion_config["serviceAccount"]

PIPELINE_OPTIONS = {
    "tempLocation": tempLocation,
    "stagingLocation": stagingLocation,
    "gcsOutput": gcsOutput,
    "bucketName": raw_bucket_name,
    "mqQueue": mqQueue,
    "mqChannel": mqChannel,
    "mqHost": mqHost,
    "mqManager": mqManager,
    "mqPort": mqPort,
    "mqUserSecret": mqUserSecret,
    "mqPasswordSecret": mqPasswordSecret,
    "windowDuration": windowDuration,
    "numOfShards": numOfShards,
    "subnetwork": subnetwork,
    "serviceAccount": service_Account,
    "dataflowServiceOptions": "enable_prime",
    "env": env,
    "mqLbEnvFlag": mqLbEnvFlag,
    "batchEnableFlag": batchEnableFlag
}
if mqLbEnvFlag:
    PIPELINE_OPTIONS["mqQueueLb"] = mqQueueLb
    PIPELINE_OPTIONS["mqChannelLb"] = mqChannelLb
    PIPELINE_OPTIONS["mqHostLb"] = mqHostLb
    PIPELINE_OPTIONS["mqManagerLb"] = mqManagerLb
    PIPELINE_OPTIONS["mqPortLb"] = mqPortLb
    PIPELINE_OPTIONS["mqUserSecretLb"] = mqUserSecretLb
    PIPELINE_OPTIONS["mqPasswordSecretLb"] = mqPasswordSecretLb

params_list = {"env": env, "raw_bucket_name": raw_bucket_name}

default_args = {
    "default_pipeline_options": {
        "output": gcsOutput,
    },
    "trigger_rule": "all_done",
}

with models.DAG(
        "in__raw_chq_disbursements",
        tags=["mqtogcsconnector", "raw", "chqchqdisbursements", "streaming"],
        start_date=datetime(2023, 8, 10),
        schedule_interval='@once',
        catchup=False,
        max_active_runs=1,
) as dag_native_java_dataflow_runner:
    copy_mqconnector_jar_gcs_to_local = GCSToLocalFilesystemOperator(
        task_id="copy_mqconnector_jar_gcs_to_local",
        bucket=GCS_JAR_DATAFLOW_RUNNER_BUCKET_NAME,
        object_name=DATAFLOW_JAR_OBJECT_NAME,
        filename="/tmp/{}".format(JAR_FILE_NAME),
    )

    start_mq_to_gcs_ingestion_pipeline = BeamRunJavaPipelineOperator(
        task_id="start_mq_to_gcs_ingestion_pipeline",
        runner="DataflowRunner",
        jar="/tmp/{}".format(JAR_FILE_NAME),
        pipeline_options=PIPELINE_OPTIONS,
        job_class="com.economical.sdp.mq.MqToGcsIngestion",
        dataflow_config={
            "job_name": "in__raw_chq_disbursements",
            "location": "northamerica-northeast1",

        },
    )
    copy_mqconnector_jar_gcs_to_local >> start_mq_to_gcs_ingestion_pipeline
