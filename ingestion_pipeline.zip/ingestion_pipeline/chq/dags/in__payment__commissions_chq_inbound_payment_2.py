import logging
from datetime import datetime
from google.cloud import storage, bigquery
from airflow import DAG
import pytz
from airflow.exceptions import AirflowException
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.providers.google.cloud.operators.bigquery import (
    BigQueryDeleteTableOperator,
)
from airflow.providers.google.cloud.hooks.gcs import GCSHook

# Pulling Values from the Variables defined in Airflow

curated_project = Variable.get("curated_project_name")
composer_bucket_name = Variable.get("composer_bucket_name")
deployment_bucket_name = Variable.get("deployment_bucket_name")
processing_bucket_name = Variable.get("composer_bucket_name")
raw_bucket_name = Variable.get("raw_bucket_name")
raw_project_name = Variable.get("raw_project_name")

chq_payment_variables = Variable.get(
    "chq_payment_variables", deserialize_json=True
)
base_folder_path = chq_payment_variables["base_folder_path"]
curated_dataset_name = chq_payment_variables["curated_dataset_name"]
curated_query_file = chq_payment_variables["curated_query_file"]
external_table_name = chq_payment_variables["external_table_name"]
get_list_error_file_names = chq_payment_variables["get_list_error_file_names"]
query_path = chq_payment_variables["query_path"]
staging_query_file = chq_payment_variables["staging_query_file"]
topic_name = chq_payment_variables["topic_name"]
validation_result_file = chq_payment_variables["validation_result_file"]


# GCS client
storage_client = storage.Client(project=raw_project_name)

# Bigquery client
bigquery_client = bigquery.Client(project=curated_project)
hook = GCSHook()
est_tz = pytz.timezone("America/Toronto")


def get_execution_date_time(**context):
    try:
        execution_date = (context['dag_run'].conf['run_date'])
        print("This is the execution date from CTRL-M Scheduler", execution_date)

    except Exception:
        execution_date = (context["execution_date"].astimezone(est_tz)).strftime("%Y-%m-%d")
        print("This is the execution date from Airflow", execution_date)

    execution_time = (datetime.now().astimezone(est_tz).strftime("%Y%m%d%H%M%S%f")[:-3])

    return str(execution_date), str(execution_time)


def check_file_existence(**context):
    execution_date = context["execution_date_time_output"][0]
    file_path = f"{base_folder_path}/landing/{topic_name}/"
    bucket = storage_client.bucket(raw_bucket_name)
    print("bucket : ", bucket)
    file_list = list(bucket.list_blobs(prefix=file_path))
    print("file_path :", file_path)
    print("file_list :", file_list)
    fixed_width_file = [
        file.name
        for file in file_list
        if (
            file.name != file_path
            and (file.name).endswith(".xml")
            or (file.name).endswith(".txt")
            or (file.name).endswith("")
        )
    ]
    print("Fixed width file : ", fixed_width_file)
    print("execution_date : ", execution_date)
    if len(fixed_width_file) == 0:
        raise AirflowException("No files found, fail the DAG")

    return fixed_width_file


def get_execute_query(sql_file, **kwargs):
    """
    function to read and execute query in Bigquery
    """
    try:
        execution_date = kwargs["execution_date"]
        execution_time = kwargs["execution_time"]
        dag_path = kwargs.get("dag_path", "")
        dag_id = kwargs.get("dag_id", "")
        print(execution_date, execution_time, dag_path, dag_id)
        bucket = storage_client.bucket(deployment_bucket_name)
        blob = bucket.get_blob(sql_file)
        query = blob.download_as_string().decode("utf-8")
        print(query)
        query = (
            query.replace("@curated_dataset_name", curated_dataset_name)
            .replace("@curated_project", curated_project)
            .replace("@execution_date", execution_date)
            .replace("@execution_time", execution_time)
            .replace("@dag_path", dag_path)
            .replace("@dag_id", dag_id)
            .replace("@raw_bucket_name", raw_bucket_name)
            .replace("@external_table_name", external_table_name)
        )
        print("Query submitted for execution in BigQuery")
        query_job = bigquery_client.query(query)
        result = query_job.result()
        return result

    except Exception:
        logging.error("Error in reading/executing query")
        raise AirflowException("Error in reading/executing query")


def move_files(
    src_bucket_name, src_blob_name, dest_bucket_name, dest_blob_name
):
    """
    Function to move files from one folder to another
    """
    try:
        source_bucket = storage_client.get_bucket(src_bucket_name)
        source_blob = source_bucket.blob(src_blob_name)
        destination_bucket = storage_client.get_bucket(dest_bucket_name)
        dest_blob = source_bucket.copy_blob(
            source_blob, destination_bucket, dest_blob_name
        )
        source_blob.delete()

        logging.info(f"File copied to {dest_blob}")
        logging.info(
            f"File copied/moved from {source_blob} to {dest_blob_name}"
        )
    except Exception:
        logging.error(f"Error in copying/moving file {src_blob_name}")
        raise AirflowException(
            f"Error in copying/moving file {src_blob_name}"
        )


def create_external_table(uri, curated_dataset_name, external_table_name):
    dataset_ref = bigquery.DatasetReference(
        curated_project, curated_dataset_name
    )
    table = bigquery.Table(dataset_ref.table(external_table_name))
    external_config = bigquery.ExternalConfig("CSV")
    external_config.source_uris = [uri]
    external_config.options.skip_leading_rows = 0
    external_config.autodetect = True
    external_config.csv_options._properties[
        "preserveAsciiControlCharacters"
    ] = True
    external_config.options.field_delimiter = "~"
    table.external_data_configuration = external_config
    table = bigquery_client.create_table(table)


""" Function to check if external table exists """


def check_table_exists(external_table_id):
    try:
        bigquery_client.get_table(external_table_id)
        return True
    except Exception:
        return False


""" Function to drop external table if it exists """


def drop_table_if_exists(external_table_id):
    try:
        bigquery_client.delete_table(external_table_id, not_found_ok=True)
    except Exception:
        print(f"Error while dropping the table {external_table_id}")
        raise AirflowException(
            f"Error while dropping the table {external_table_id}"
        )


def landing_to_working(**context):
    """
    function to check whether file is present in GCS bucket or not
    and copy files from landing folder to working folder
    """
    execution_time = context["execution_date_time_output"][1]
    fixed_width_file = context["task_output"]
    external_table_id = f"{curated_project}.{curated_dataset_name}.{external_table_name}"
    print("External_Table_Name is : ", external_table_name)
    file_path = f"{base_folder_path}/landing/{topic_name}/"
    print("execution_time : ", execution_time)
    print("Fixed width file : ", fixed_width_file)
    if len(fixed_width_file) == 0:
        raise AirflowException("No files found, skip the DAG")
    else:
        file_name_list = []
        for file in fixed_width_file:
            print(file)
            file_name = file.rsplit("/", maxsplit=1)[-1]
            file_name_list.append(file_name)
            print("file_name : ", file_name)
            hook.copy(
                raw_bucket_name,
                f"{file_path}{file_name}",
                raw_bucket_name,
                f"{base_folder_path}/runtime_{execution_time}/archive/{file_name}")
            move_files(
                raw_bucket_name,
                f"{file_path}{file_name}",
                raw_bucket_name,
                f"{base_folder_path}/runtime_{execution_time}/working/{file_name}",
            )
        uri = f"gs://{raw_bucket_name}/{base_folder_path}/runtime_{execution_time}/working/*"
        check_table_exists(external_table_id)
        drop_table_if_exists(external_table_id)
        create_external_table(uri, curated_dataset_name, external_table_name)
    return file_name_list


def read_file_execute_query(sql_file_path, **context):
    """
    function to read query from sql file and execute in Bigquery
    """
    try:
        execution_date = context["execution_date_time_output"][0]
        execution_time = context["execution_date_time_output"][1]
        get_execute_query(
            f"{sql_file_path}",
            execution_date=execution_date,
            execution_time=execution_time,
        )
    except Exception:
        working_path = (
                f"{base_folder_path}/runtime_{execution_time}/working"
            )
        success_path = (
                f"{base_folder_path}/runtime_{execution_time}/success"
            )
        bucket = storage_client.bucket(raw_bucket_name)
        working_file_list = list(bucket.list_blobs(prefix=working_path))
        print(working_file_list)
        success_file_list = list(bucket.list_blobs(prefix=success_path))
        print(success_file_list)
        if len(working_file_list) != 0:
            for working_file_name in working_file_list:
                working_file_name = working_file_name.name.rsplit("/")[-1]
                move_files(
                    raw_bucket_name,
                    f"{base_folder_path}/runtime_{execution_time}/working/{working_file_name}",
                    raw_bucket_name,
                    f"{base_folder_path}/runtime_{execution_time}/failed/{working_file_name}",
                )
        elif len(success_file_list) != 0:
            for success_file_name in success_file_list:
                success_file_name = success_file_name.name.rsplit("/")[-1]
                move_files(
                    raw_bucket_name,
                    f"{base_folder_path}/runtime_{execution_time}/success/{success_file_name}",
                    raw_bucket_name,
                    f"{base_folder_path}/runtime_{execution_time}/failed/{success_file_name}",
                )
        else:
            print("No Files Present in Either Working or Success")
        raise AirflowException("Query Execution Failed")


def validate_incoming_files(validation_file_path, **context):
    """
    function to validate file
    """
    try:
        ti = context["ti"]
        execution_date = context["execution_date_time_output"][0]
        execution_time = context["execution_date_time_output"][1]
        file_name = context["task_output"]

        dag_path = (dag.fileloc).replace(
            "/home/airflow/gcs", f"gs://{composer_bucket_name}"
        )
        bucket = storage_client.bucket(deployment_bucket_name)
        file_list = list(bucket.list_blobs(prefix=validation_file_path))
        sql_file = [
            file.name
            for file in file_list
            if file.name != validation_file_path
            and (file.name).endswith(".sql")
            and file.name.split("/")[-1].startswith("chq_payment_2_insert_into_ingestion")
        ]
        for file in sql_file:
            get_execute_query(
                file,
                execution_date=execution_date,
                execution_time=execution_time[:-3],
                dag_path=dag_path,
                dag_id=ti.dag_id,
            )
            print(f"validated file: {file}")
    except Exception:
        # Construct the source and destination paths
        for name in file_name:
            working_path = (
                f"{base_folder_path}/runtime_{execution_time}/working/{name}"
            )
            failed_path = (
                f"{base_folder_path}/runtime_{execution_time}/failed/{name}"
            )
            print(working_path, failed_path)
            # Move the file from working to failed

            bucket = storage_client.bucket(raw_bucket_name)

            blob_working = bucket.blob(working_path)
            blob_failed = bucket.blob(failed_path)
            blob_failed.content_type = blob_working.content_type
            blob_failed.upload_from_string(blob_working.download_as_string())
            blob_working.delete()
        raise AirflowException(
            f"Error in validating files in {validation_file_path}"
        )


def get_warning_error_row_counts(**context):
    """
    function to get count of warning and error rows
    """
    print("Executing get_warning_error_row_counts function")
    execution_date = context["execution_date_time_output"][0]
    execution_time = context["execution_date_time_output"][1]
    file_name = context["task_output"]
    warning_error_count = ""
    moved_files_list = []
    print(file_name)
    result = get_execute_query(
        f"{query_path}/{validation_result_file}",
        execution_date=execution_date,
        execution_time=execution_time[:-3],
    )
    rows = result.to_dataframe()
    print("length of dataframe: ", len(rows.index))
    if len(rows.index) != 0:
        for index, i in rows.iterrows():
            warning_error_count = i[
                "warning_error_rows_present_for_current_run"
            ]
            file_name_folder = (i["incoming_file_full_name"]).split(
                f"{raw_bucket_name}/"
            )[1]
            file_name_ = file_name_folder.split("/")[-1]
            print("Filename giving warning: ", file_name_)
            if warning_error_count == "W":
                print("WARNING , moving file to success folder")
            elif warning_error_count == "E":
                print("ERROR returned from ingestion_file_validation_result")
                error_rows_result = get_execute_query(
                    f"{query_path}/{get_list_error_file_names}",
                    execution_date=execution_date,
                    execution_time=execution_time[:-3],
                )
                error_rows = error_rows_result.to_dataframe()
                if len(error_rows.index) != 0:
                    for indexes, row in error_rows.iterrows():
                        error_files = row["incoming_files_with_error"]
                        error_file_name = error_files.split(
                            f"{raw_bucket_name}/"
                        )[1]
                        file_name_ = error_file_name.split("/")[-1]
                        if file_name_ not in moved_files_list:
                            moved_files_list.append(file_name_)
        print(moved_files_list)
        if len(moved_files_list) != 0:
            for failed_file_name in moved_files_list:
                move_files(
                    raw_bucket_name,
                    f"{base_folder_path}/runtime_{execution_time}/working/{failed_file_name}",
                    raw_bucket_name,
                    f"{base_folder_path}/runtime_{execution_time}/failed/{failed_file_name}"
                )
        for name in file_name:
            output_file_name = name.rsplit("/")[-1]
            try:
                if output_file_name not in moved_files_list:
                    move_files(
                        raw_bucket_name,
                        f"{base_folder_path}/runtime_{execution_time}/working/{output_file_name}",
                        raw_bucket_name,
                        f"{base_folder_path}/runtime_{execution_time}/success/{output_file_name}"
                    )
            except Exception:
                print("File Not Found in Working Folder")
    else:
        print("No Warnings or Errors")
        for name in file_name:
            print(name)
            output_file_name = name.rsplit("/")[-1]
            move_files(
                raw_bucket_name,
                f"{base_folder_path}/runtime_{execution_time}/working/{output_file_name}",
                raw_bucket_name,
                f"{base_folder_path}/runtime_{execution_time}/success/{output_file_name}",
            )
    return warning_error_count


def error_evaluation(**context):
    error_evaluation = context["error_evaluation"]
    print("The error value is ", error_evaluation)
    if error_evaluation == "E":
        raise AirflowException("Error rows present for current run")
    elif error_evaluation == "W":
        print("Warning Rows Present, Marking the dag as Success")
    else:
        print("No Error or Warning rows Present, Marking the dag as Success")


with DAG(
    dag_id="in__payment__commissions_chq_inbound_payment_2",
    start_date=datetime(2023, 6, 28),
    tags=[
        "in__payment__commissions_chq_inbound_payment_2",
        "curated",
        "payment",
        "Fixed width",
        "daily",
    ],
    schedule_interval=None,
    render_template_as_native_obj=True,
    catchup=False,
    max_active_runs=1,
) as dag:

    get_execution_date_time = PythonOperator(
        task_id="get_execution_date_time",
        python_callable=get_execution_date_time,
        dag=dag,
    )

    check_file_existence = PythonOperator(
        task_id="check_file_existence",
        python_callable=check_file_existence,
        op_kwargs={
            "execution_date_time_output": get_execution_date_time.output,
        },
        dag=dag,
    )

    landing_to_working = PythonOperator(
        task_id="landing_to_working",
        python_callable=landing_to_working,
        op_kwargs={
            "execution_date_time_output": get_execution_date_time.output,
            "task_output": check_file_existence.output
        },
        dag=dag,
    )

    load_to_staging_table = PythonOperator(
        task_id="load_to_staging_table",
        python_callable=read_file_execute_query,
        op_kwargs={
            "execution_date_time_output": get_execution_date_time.output,
            "sql_file_path": f"{query_path}/{staging_query_file}",
            "task_output": landing_to_working.output,
        },
        dag=dag,
    )

    validate_incoming_files = PythonOperator(
        task_id="validate_incoming_files",
        python_callable=validate_incoming_files,
        op_kwargs={
            "execution_date_time_output": get_execution_date_time.output,
            "validation_file_path": f"{query_path}/",
            "task_output": landing_to_working.output,
        },
        dag=dag,
    )
    get_warning_error_row_counts = PythonOperator(
        task_id="get_warning_error_row_counts",
        python_callable=get_warning_error_row_counts,
        op_kwargs={
            "execution_date_time_output": get_execution_date_time.output,
            "task_output": landing_to_working.output,
        },
        dag=dag,
    )
    error_evaluation = PythonOperator(
        task_id="error_evaluation",
        python_callable=error_evaluation,
        op_kwargs={
            "error_evaluation": get_warning_error_row_counts.output,
        },
    )

    load_to_curated_table = PythonOperator(
        task_id="load_to_curated_table",
        python_callable=read_file_execute_query,
        op_kwargs={
            "execution_date_time_output": get_execution_date_time.output,
            "sql_file_path": f"{query_path}/{curated_query_file}",
            "task_output": landing_to_working.output,
        },
        dag=dag,
    )

    delete_external_table = BigQueryDeleteTableOperator(
        task_id="delete_external_table",
        deletion_dataset_table=(
            f"{curated_project}.{curated_dataset_name}.{external_table_name}"
        ),
    )

# Define task dependencies
(
    get_execution_date_time
    >> check_file_existence
    >> landing_to_working
    >> load_to_staging_table
    >> validate_incoming_files
    >> get_warning_error_row_counts
    >> error_evaluation
    >> load_to_curated_table
    >> delete_external_table
)
