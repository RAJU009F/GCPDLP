TRUNCATE TABLE
  `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging` ;
INSERT INTO
  `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging`  
  SELECT    
    CAST('@execution_date' AS DATETIME) AS dlh_batch_ts,
    DATETIME(TIMESTAMP(FORMAT_DATETIME("%Y-%m-%d %H:%M:%S",CURRENT_DATETIME("America/Toronto")))) AS dlh_process_ts,
    string_field_0 AS file_data,
      REGEXP_EXTRACT(_FILE_NAME, r'[^/]*$') AS file_name,
    _FILE_NAME AS  incoming_file_full_name,
   ROW_NUMBER() OVER() AS row_num
  FROM
    `@curated_project.@curated_dataset_name.@external_table_name`