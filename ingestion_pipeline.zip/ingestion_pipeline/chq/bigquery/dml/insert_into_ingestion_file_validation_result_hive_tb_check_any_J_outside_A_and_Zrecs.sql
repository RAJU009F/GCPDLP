INSERT INTO  `@curated_project.centralise_ref_tables.ingestion_file_validation_result`
  SELECT
      substr('@execution_time', 1, 17) AS job_id,
      '@dag_id' AS job_name,
      '@dag_path' AS job_full_name,
      g.file_name AS incoming_file_name,
      fd_rwn_j_no_az.file_full_name AS incoming_file_full_name,
      'E' AS validation_result_type,
      'There are J records in the file which does not have corresponding A and Z records' AS log_remarks,
      CAST(concat(substr('@execution_time', 1, 4), '-', substr('@execution_time', 5, 2), '-', substr('@execution_time', 7, 2), ' ', substr('@execution_time', 9, 2), ':', substr('@execution_time', 11, 2), ':', substr('@execution_time', 13, 2)) as DATETIME) AS edh_process_time
    FROM
      -- select distinct RS1.incoming_file_name,RS1.incoming_file_full_name
      (
        SELECT
            a_and_j_comb.file_name AS file_name,
            count(1) AS count_of_js
          FROM
            (
              SELECT
                  -- trim(FD_RWN_A.file_data) as  a_data,
                  -- trim(FD_RWN_Z.file_data) as z_data,
                  fd_rwn_a.row_number AS a_rown,
                  fd_rwn_z.row_number AS z_rown,
                  fd_rwn_a.actual_rownum AS a_actual_row,
                  fd_rwn_z.actual_rownum AS z_actual_row,
                  fd_rwn_a.file_name,
                  fl_nam.file_name AS fl_file_name
                FROM
                  (
                    SELECT
                        -- CICHQ1.file_data,
                        cichq1.file_name,
                        cichq1.row_num AS actual_rownum,
                        row_number() OVER (PARTITION BY cichq1.file_name ORDER BY cichq1.row_num) AS row_number
                      FROM
                        `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging` AS cichq1
                      WHERE substr(cichq1.file_data, 1, 1) = 'A'
                  ) AS fd_rwn_a
                  INNER JOIN -- group by CICHQ1.file_name, CICHQ1.row_num
                  (
                    SELECT
                        -- CICHQ2.file_data,
                        cichq2.file_name,
                        cichq2.row_num AS actual_rownum,
                        row_number() OVER (PARTITION BY cichq2.file_name ORDER BY cichq2.row_num) AS row_number
                      FROM
                        `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging` AS cichq2
                      WHERE substr(cichq2.file_data, 1, 1) = 'Z'
                  ) AS fd_rwn_z ON fd_rwn_a.file_name = fd_rwn_z.file_name
                  INNER JOIN -- group by 	CICHQ2.file_name --,CICHQ2.row_num
                  (
                    SELECT DISTINCT
                        file_name
                      FROM
                        `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging`
                  ) AS fl_nam ON fl_nam.file_name = fd_rwn_z.file_name
                   AND fl_nam.file_name = fd_rwn_a.file_name
                WHERE fd_rwn_a.file_name = fd_rwn_z.file_name
                 AND fl_nam.file_name = fd_rwn_a.file_name
                 AND fl_nam.file_name = fd_rwn_z.file_name
                 AND fd_rwn_a.row_number = fd_rwn_z.row_number
            ) AS a_and_j_comb
            INNER JOIN (
              SELECT
                  -- CICHQ3.file_data,
                  cichq3.file_name AS file_name,
                  cichq3.row_num AS actual_rownum,
                  row_number() OVER (PARTITION BY cichq3.file_name ORDER BY cichq3.row_num) AS row_number
                FROM
                  `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging` AS cichq3
                WHERE substr(cichq3.file_data, 1, 1) = 'J'
                GROUP BY 1, 2
            ) AS fd_rwn_j ON fd_rwn_j.file_name = a_and_j_comb.file_name
            INNER JOIN (
              SELECT DISTINCT
                  file_name from
                  `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging`
            ) AS fl_nam2 ON fl_nam2.file_name = fd_rwn_j.file_name
             AND fl_nam2.file_name = a_and_j_comb.file_name
            INNER JOIN (
              SELECT
                  cichq4.file_data,
                  cichq4.file_name,
                  cichq4.row_num AS actual_rownum,
                  row_number() OVER (PARTITION BY cichq4.file_name ORDER BY cichq4.row_num) AS row_number
                FROM
                  `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging` AS cichq4
                WHERE substr(cichq4.file_data, 1, 1) = 'T'
            ) AS fd_rwn_t ON fd_rwn_t.file_name = a_and_j_comb.file_name
             AND fd_rwn_j.file_name = fd_rwn_t.file_name
             AND fl_nam2.file_name = fd_rwn_t.file_name
          WHERE fd_rwn_j.actual_rownum BETWEEN a_and_j_comb.a_actual_row AND a_and_j_comb.z_actual_row
           AND a_and_j_comb.file_name = fd_rwn_t.file_name
           AND fd_rwn_j.file_name = a_and_j_comb.file_name
           AND fd_rwn_j.file_name = fd_rwn_t.file_name
          GROUP BY 1
      ) AS g
      INNER JOIN (
        SELECT
            cichq3.file_name AS file_name,
            cichq3.incoming_file_full_name AS file_full_name,
            count(1) AS count_j
          FROM
            `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging` AS cichq3
          WHERE substr(cichq3.file_data, 1, 1) = 'J'
          GROUP BY 1, 2
      ) AS fd_rwn_j_no_az ON fd_rwn_j_no_az.file_name = g.file_name
      INNER JOIN -- AND CICHQ3.incoming_file_full_name =
      (
        SELECT DISTINCT
            file_name
          FROM
            `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging`
      ) AS fl_nam3 ON fl_nam3.file_name = g.file_name
       AND fd_rwn_j_no_az.file_name = fl_nam3.file_name
    WHERE g.count_of_js <> fd_rwn_j_no_az.count_j
     AND fd_rwn_j_no_az.file_name = g.file_name
     AND fl_nam3.file_name = g.file_name
;
