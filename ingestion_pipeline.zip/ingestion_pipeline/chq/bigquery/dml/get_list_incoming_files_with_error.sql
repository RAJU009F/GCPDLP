SELECT incoming_file_full_name as incoming_files_with_error 
FROM `@curated_project.centralise_ref_tables.ingestion_file_validation_result`
WHERE job_id = '@execution_time'
and validation_result_type = 'E'
group by incoming_file_full_name