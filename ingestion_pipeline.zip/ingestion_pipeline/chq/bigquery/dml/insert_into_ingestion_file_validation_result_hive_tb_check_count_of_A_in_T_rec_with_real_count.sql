INSERT INTO `@curated_project.centralise_ref_tables.ingestion_file_validation_result`
  SELECT
      substr('@execution_time', 1, 17) AS job_id,
      '@dag_id' AS job_name,
      '@dag_path' AS job_full_name,
      fd_rwn_t.file_name AS incoming_file_name,
      fd_rwn_j.file_full_name AS incoming_file_full_name,
      'E' AS validation_result_type,
      'Total header records(A)count mentioned in T record not equal to the actual count of A records' AS log_remarks,
      CAST(concat(substr('@execution_time', 1, 4), '-', substr('@execution_time', 5, 2), '-', substr('@execution_time', 7, 2), ' ', substr('@execution_time', 9, 2), ':', substr('@execution_time', 11, 2), ':', substr('@execution_time', 13, 2)) as DATETIME) AS edh_process_time
    FROM
      (
        SELECT
            count(1) AS actual_a_count,
            cichq3.file_name,
            cichq3.incoming_file_full_name AS file_full_name
          FROM
           `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging` AS cichq3
          WHERE substr(cichq3.file_data, 1, 1) = 'A'
          GROUP BY 2, 3
      ) AS fd_rwn_j
      INNER JOIN (
        SELECT
            cichq2.file_name,
            CAST(substr(cichq2.file_data, 2, 5) as INT64) AS a_count_in_t
          FROM
           `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging` AS cichq2
          WHERE substr(cichq2.file_data, 1, 1) = 'T'
          GROUP BY 1, 2
      ) AS fd_rwn_t ON fd_rwn_j.file_name = fd_rwn_t.file_name
    WHERE fd_rwn_t.a_count_in_t <> fd_rwn_j.actual_a_count
;
