truncate table `@curated_project.payment.commissions_chq_inbound_payment_2_staging`;
INSERT INTO
  `@curated_project.payment.commissions_chq_inbound_payment_2_staging`(
  SELECT
  string_field_0 as file_data,
  REGEXP_EXTRACT(_FILE_NAME, r'[^/]*$') AS file_name,
  _FILE_NAME AS incoming_file_full_name,
  row_number() over() as row_num,
  CAST('@execution_date' AS DATETIME) as dlh_batch_ts,
  DATETIME(TIMESTAMP(FORMAT_DATETIME("%Y-%m-%d %H:%M:%S",CURRENT_DATETIME("America/Toronto")))) AS dlh_process_ts
 
FROM `@curated_project.payment.commissions_chq_inbound_payment_2_ext`);