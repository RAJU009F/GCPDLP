INSERT INTO `@curated_project.payment.billing_cheque_disbursements_inbound_v2` 
  SELECT
    CAST('@execution_date' AS DATETIME) AS dlh_batch_ts,
    DATETIME(TIMESTAMP(FORMAT_DATETIME("%Y-%m-%d %H:%M:%S",CURRENT_DATETIME("America/Toronto")))) AS dlh_process_ts,
      substr(a_and_j_comb.a_data, 1, 1) AS header_record_type,
      substr(a_and_j_comb.a_data, 2, 2) AS header_customer_region,
      substr(a_and_j_comb.a_data, 4, 10) AS header_customer_number,
      substr(a_and_j_comb.a_data, 14, 5) AS header_transit_number,
      substr(a_and_j_comb.a_data, 19, 8) AS header_account_number,
      substr(a_and_j_comb.a_data, 27, 5) AS header_from_date,
      substr(a_and_j_comb.a_data, 32, 5) AS header_to_date,
      substr(fd_rwn_j.file_data, 1, 1) AS detail_record_type,
      substr(fd_rwn_j.file_data, 2, 2) AS detail_customer_region,
      substr(fd_rwn_j.file_data, 4, 10) AS detail_customer_number,
      substr(fd_rwn_j.file_data, 14, 5) AS detail_transit_number,
      substr(fd_rwn_j.file_data, 19, 14) AS detail_account_number,
      substr(fd_rwn_j.file_data, 33, 14) AS detail_serial_number,
      substr(fd_rwn_j.file_data, 47, 10) AS detail_paid_amount,
      substr(fd_rwn_j.file_data, 57, 1) AS detail_currency,
      substr(fd_rwn_j.file_data, 58, 6) AS detail_paid_date,
      substr(fd_rwn_j.file_data, 64, 1) AS detail_status,
      substr(fd_rwn_j.file_data, 65, 10) AS detail_locator_number,
      substr(fd_rwn_j.file_data, 75, 1) AS detail_representment_flag,
      substr(fd_rwn_j.file_data, 76, 1) AS detail_reject_repair_flag,
      substr(fd_rwn_j.file_data, 77, 1) AS detail_non_micr_flag,
      substr(fd_rwn_j.file_data, 78, 1) AS detail_truncation_flag,
      substr(a_and_j_comb.z_data, 1, 1) AS trailer_record_type,
      substr(a_and_j_comb.z_data, 2, 11) AS trailer_customer_number,
      substr(a_and_j_comb.z_data, 13, 8) AS trailer_total_record_count,
      substr(a_and_j_comb.z_data, 22, 14) AS trailer_total_amount,
      substr(a_and_j_comb.z_data, 36, 8) AS trailer_record_count_cad,
      substr(a_and_j_comb.z_data, 44, 14) AS trailer_amount_cad,
      substr(a_and_j_comb.z_data, 58, 8) AS trailer_record_usd,
      substr(a_and_j_comb.z_data, 66, 14) AS trailer_amount_usd,
      substr(fd_rwn_t.file_data, 1, 1) AS balancing_record_type,
      substr(fd_rwn_t.file_data, 2, 5) AS balancing_header_count,
      substr(fd_rwn_t.file_data, 7, 6) AS balancing_detail_count,
      substr(fd_rwn_t.file_data, 13, 5) AS balancing_trailer_count,
      substr(fd_rwn_t.file_data, 19, 8) AS balancing_sender_job_id,
      CAST(round(SAFE_CAST(substr(fd_rwn_j.file_data, 47, 10) AS NUMERIC) / 100, 2) as NUMERIC) AS detail_paid_amount_drvd,
      CAST(round(SAFE_CAST(substr(a_and_j_comb.z_data, 22, 14) AS NUMERIC) / 100, 2) as NUMERIC) AS trailer_total_amount_drvd,
      date_add(CAST(concat(CAST(2000 + CAST(substr(a_and_j_comb.a_data, 27, 2) as INT64) as STRING), '-01-01') as DATE), interval CAST(substr(a_and_j_comb.a_data, 29, 3) as INT64) - 1 DAY) AS header_from_date_drvd,
      date_add(CAST(concat(CAST(2000 + CAST(substr(a_and_j_comb.a_data, 32, 2) as INT64) as STRING), '-01-01') as DATE), interval CAST(substr(a_and_j_comb.a_data, 34, 3) as INT64) - 1 DAY) AS header_to_date_drvd,
      CAST(format_datetime('%Y-%m-%d %H:%M:%S', CAST(timestamp_seconds(unix_seconds(safe.parse_timestamp('%d%m%y', substr(fd_rwn_j.file_data, 58, 6)))) as DATETIME))AS DATETIME) AS detail_paid_date_drvd,
      fd_rwn_t.file_name AS incoming_file_name,
      CAST(concat(substr('@execution_time', 1, 4), '-', substr('@execution_time', 5, 2), '-', substr('@execution_time', 7, 2), ' ', substr('@execution_time', 9, 2), ':', substr('@execution_time', 11, 2), ':', substr('@execution_time', 13, 2)) as DATETIME) AS edh_process_date,
      CAST(format_datetime('%Y-%m-%d %H:%M:%S', CAST(timestamp_seconds(unix_seconds(safe.parse_timestamp('%Y-%m-%d', '@execution_date'))) as DATETIME))AS DATETIME) AS job_scheduler_timestamp,
      '@execution_time' AS job_id,
      '@execution_date' AS job_scheduler_date
    FROM
      (
        SELECT
            trim(fd_rwn_a.file_data) AS a_data,
            trim(fd_rwn_z.file_data) AS z_data,
            fd_rwn_a.row_number AS a_rown,
            fd_rwn_z.row_number AS z_rown,
            fd_rwn_a.actual_rownum AS a_actual_row,
            fd_rwn_z.actual_rownum AS z_actual_row,
            fd_rwn_a.file_name
          FROM
            (
              SELECT
                  cichq1.file_data,
                  cichq1.file_name,
                  cichq1.row_num AS actual_rownum,
                  row_number() OVER (ORDER BY cichq1.row_num) AS row_number
                FROM
                  `@curated_project.payment.billing_cheque_disbursements_inbound_v2_staging` AS cichq1
                WHERE substr(cichq1.file_data, 1, 1) = 'A'
                 AND cichq1.file_name NOT IN(
                  SELECT
                      incoming_file_name
                    FROM
                      `@curated_project.centralise_ref_tables.ingestion_file_validation_result`
                    WHERE validation_result_type = 'E'
                     AND job_id = '@execution_time'
                )
            ) AS fd_rwn_a
            CROSS JOIN (
              SELECT
                  cichq2.file_data,
                  cichq2.file_name,
                  cichq2.row_num AS actual_rownum,
                  row_number() OVER (ORDER BY cichq2.row_num) AS row_number
                FROM
                  `@curated_project.payment.billing_cheque_disbursements_inbound_v2_staging` AS cichq2
                WHERE substr(cichq2.file_data, 1, 1) = 'Z'
                 AND cichq2.file_name NOT IN(
                  SELECT
                      incoming_file_name
                    FROM
                     `@curated_project.centralise_ref_tables.ingestion_file_validation_result`
                    WHERE validation_result_type = 'E'
                     AND job_id = '@execution_time'
                )
            ) AS fd_rwn_z
          WHERE fd_rwn_a.file_name = fd_rwn_z.file_name
           AND fd_rwn_a.row_number = fd_rwn_z.row_number
      ) AS a_and_j_comb
      INNER JOIN (
        SELECT
            cichq3.file_data,
            cichq3.file_name,
            cichq3.row_num AS actual_rownum,
            row_number() OVER (ORDER BY cichq3.row_num) AS row_number
          FROM
            `@curated_project.payment.billing_cheque_disbursements_inbound_v2_staging` AS cichq3
          WHERE substr(cichq3.file_data, 1, 1) = 'J'
           AND cichq3.file_name NOT IN(
            SELECT
                incoming_file_name
              FROM
               `@curated_project.centralise_ref_tables.ingestion_file_validation_result`
              WHERE validation_result_type = 'E'
               AND job_id = '@execution_time'
          )
      ) AS fd_rwn_j ON fd_rwn_j.file_name = a_and_j_comb.file_name
      INNER JOIN (
        SELECT
            cichq4.file_data,
            cichq4.file_name,
            cichq4.row_num AS actual_rownum,
            row_number() OVER (ORDER BY cichq4.row_num) AS row_number
          FROM
            `@curated_project.payment.billing_cheque_disbursements_inbound_v2_staging` AS cichq4
          WHERE substr(cichq4.file_data, 1, 1) = 'T'
           AND cichq4.file_name NOT IN(
            SELECT
                incoming_file_name
              FROM
               `@curated_project.centralise_ref_tables.ingestion_file_validation_result`
              WHERE validation_result_type = 'E'
               AND job_id = '@execution_time'
          )
      ) AS fd_rwn_t ON fd_rwn_t.file_name = a_and_j_comb.file_name
       AND fd_rwn_j.file_name = fd_rwn_t.file_name
    WHERE fd_rwn_j.actual_rownum BETWEEN a_and_j_comb.a_actual_row AND a_and_j_comb.z_actual_row
;