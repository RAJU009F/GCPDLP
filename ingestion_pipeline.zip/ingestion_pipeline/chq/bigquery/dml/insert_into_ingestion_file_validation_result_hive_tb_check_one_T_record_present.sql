INSERT INTO `@curated_project.centralise_ref_tables.ingestion_file_validation_result`
  SELECT
      substr('@execution_time', 1, 17) AS job_id,
      '@dag_id' AS job_name,
      '@dag_path' AS job_full_name,
      reverse(substr(reverse(trim(h_rows.incoming_file_full_name)), 1, strpos(reverse(trim(h_rows.incoming_file_full_name)), '/') - 1)) AS incoming_file_name,
      h_rows.incoming_file_full_name AS incoming_file_full_name,
      'E' AS validation_result_type,
      'There is no T record present or multiple T records present in the file' AS log_remarks,
      CAST(concat(substr('@execution_time', 1, 4), '-', substr('@execution_time', 5, 2), '-', substr('@execution_time', 7, 2), ' ', substr('@execution_time', 9, 2), ':', substr('@execution_time', 11, 2), ':', substr('@execution_time', 13, 2)) as DATETIME) AS edh_process_time
    FROM
      (
        SELECT DISTINCT
            incoming_file_full_name AS incoming_file_full_name
          FROM
            `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging` 
          WHERE incoming_file_full_name NOT IN(
            SELECT
                incoming_file_full_name
              FROM
                `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging`  
              WHERE substr(file_data, 1, 1) = 'T'
              GROUP BY incoming_file_full_name
          )
        UNION ALL
        SELECT DISTINCT
            incoming_file_full_name
          FROM
            `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging` 
          WHERE incoming_file_full_name IN(
            SELECT
                incoming_file_full_name
              FROM
                `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging`  
              WHERE substr(file_data, 1, 1) = 'T'
              GROUP BY incoming_file_full_name
              HAVING count(1) <> 1
          )
      ) AS h_rows
;
