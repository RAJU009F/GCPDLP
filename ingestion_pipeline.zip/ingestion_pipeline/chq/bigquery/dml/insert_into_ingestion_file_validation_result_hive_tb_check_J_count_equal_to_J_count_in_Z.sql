INSERT INTO `@curated_project.centralise_ref_tables.ingestion_file_validation_result` 
  SELECT
      substr('@execution_time', 1, 17) AS job_id,
      '@dag_id' AS job_name,
      '@dag_path' AS job_full_name,
      j_count_on_z.file_name AS incoming_file_name,
      j_count_on_z.file_full_name AS incoming_file_full_name,
      'E' AS validation_result_type,
      'The actual J record count is different from the detail record count mentioned in Z' AS log_remarks,
      CAST(concat(substr('@execution_time', 1, 4), '-', substr('@execution_time', 5, 2), '-', substr('@execution_time', 7, 2), ' ', substr('@execution_time', 9, 2), ':', substr('@execution_time', 11, 2), ':', substr('@execution_time', 13, 2)) as DATETIME) AS edh_process_time
    FROM
      (
        SELECT
            trim(fd_rwn_a.file_data) AS a_data,
            trim(fd_rwn_z.file_data) AS z_data,
            fd_rwn_a.row_number AS a_rown,
            fd_rwn_z.row_number AS z_rown,
            fd_rwn_a.actual_rownum AS a_actual_row,
            fd_rwn_z.actual_rownum AS z_actual_row,
            fd_rwn_z.j_count_in_z AS j_count_in_z,
            fd_rwn_a.file_name AS file_name,
            fd_rwn_j.file_full_name AS file_full_name
          FROM
            (
              SELECT
                  cichq1.file_data,
                  cichq1.file_name,
                  cichq1.row_num AS actual_rownum,
                  row_number() OVER (PARTITION BY cichq1.file_name ORDER BY cichq1.row_num) AS row_number
                FROM
                  `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging`  AS cichq1
                WHERE substr(cichq1.file_data, 1, 1) = 'A'
            ) AS fd_rwn_a
            INNER JOIN (
              SELECT
                  cichq2.file_data,
                  cichq2.file_name,
                  cichq2.row_num AS actual_rownum,
                  CAST(substr(cichq2.file_data, 13, 8) as INT64) AS j_count_in_z,
                  row_number() OVER (PARTITION BY cichq2.file_name ORDER BY cichq2.row_num) AS row_number
                FROM
                  `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging`  AS cichq2
                WHERE substr(cichq2.file_data, 1, 1) = 'Z'
            ) AS fd_rwn_z ON fd_rwn_a.file_name = fd_rwn_z.file_name
            INNER JOIN (
              SELECT
                  cichq3.file_data,
                  cichq3.file_name,
                  cichq3.incoming_file_full_name AS file_full_name,
                  cichq3.row_num AS j_actual_rownum
                FROM
                  `@curated_project.@curated_dataset_name.billing_cheque_disbursements_inbound_v2_staging`  AS cichq3
                WHERE substr(cichq3.file_data, 1, 1) = 'J'
            ) AS fd_rwn_j ON fd_rwn_j.file_name = fd_rwn_a.file_name
             AND fd_rwn_j.file_name = fd_rwn_z.file_name
             AND fd_rwn_j.j_actual_rownum BETWEEN fd_rwn_a.actual_rownum AND fd_rwn_z.actual_rownum
          WHERE fd_rwn_a.file_name = fd_rwn_z.file_name
           AND fd_rwn_j.file_name = fd_rwn_a.file_name
           AND fd_rwn_j.file_name = fd_rwn_z.file_name
           AND fd_rwn_a.row_number = fd_rwn_z.row_number
      ) AS j_count_on_z
    GROUP BY 4, j_count_on_z.a_actual_row, j_count_on_z.z_actual_row, j_count_on_z.j_count_in_z, 5
    HAVING j_count_on_z.z_actual_row - (j_count_on_z.a_actual_row + 1) <> j_count_on_z.j_count_in_z
;
