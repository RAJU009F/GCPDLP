select 
distinct final_result.final_val_result as warning_error_rows_present_for_current_run,
final_result.incoming_file_full_name as incoming_file_full_name
from
(
select error_warning.incoming_file_full_name as incoming_file_full_name,
 case when error_warning.error_warning_count > 1
      then 'E'
      when error_warning.error_warning_count = 1
      then case when validation_result.distinct_result_type ='W'
                then 'W'
           else 'E'  
           end
      else
      NULL
      end as final_val_result 
 from
(select count(distinct validation_result_type) as error_warning_count, incoming_file_full_name as incoming_file_full_name
from `@curated_project.centralise_ref_tables.ingestion_file_validation_result`
   where job_id = '@execution_time'
    group by incoming_file_full_name
     ) error_warning,
   
 (select distinct validation_result_type as distinct_result_type , incoming_file_full_name as incoming_file_full_name       
   from `@curated_project.centralise_ref_tables.ingestion_file_validation_result`
   where job_id = '@execution_time'
 
  ) validation_result
  ) final_result