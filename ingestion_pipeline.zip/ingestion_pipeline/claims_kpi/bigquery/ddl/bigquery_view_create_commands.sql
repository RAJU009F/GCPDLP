create or replace view  `dp-prod-derived-2072.product_common_claim.claims_cds_eclm_family_kpi_vw`
as 
select * from  `dp-prod-derived-2072.product_common_claim.claims_cds_eclm_kpi_mv`
union all
select * from  `dp-prod-derived-2072.product_common_claim.claims_family_kpi_mv`;