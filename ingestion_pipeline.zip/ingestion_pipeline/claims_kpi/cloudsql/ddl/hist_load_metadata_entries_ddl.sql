CREATE TABLE IF NOT EXISTS csv_ingestion.hist_migration_load_details
(
    id                        INTEGER PRIMARY KEY,
    source_type               VARCHAR(20),
    target_type               VARCHAR(20),
    sm_project_level_details  VARCHAR(50),
    source_table_name         VARCHAR(200),
    target_dataset_name       VARCHAR(50),
    target_table_name         VARCHAR(200),
    partition_column          VARCHAR(20),
    is_active                 BOOLEAN
)
;
