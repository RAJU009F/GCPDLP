from airflow import DAG
from airflow.exceptions import AirflowException
from datetime import datetime
from airflow.models import Variable
from airflow.operators.python import PythonOperator
from airflow.providers.mysql.hooks.mysql import MySqlHook
from airflow.providers.ssh.hooks.ssh import SSHHook
from airflow.providers.ssh.operators.ssh import SSHOperator
from google.cloud import bigquery

csv_ingestion_mysql_connection = Variable.get("csv_ingestion_mysql_connection")
hist_load_project_name = Variable.get("hist_load_project_name")
sshHook = SSHHook(ssh_conn_id="edh_ssh_connection_id")


def execute_read_query(query):
    try:
        mysql_hook = MySqlHook(mysql_conn_id=csv_ingestion_mysql_connection,
                               schema='csv_ingestion')
        connection = mysql_hook.get_conn()
        cursor = connection.cursor()
        cursor.execute(query)
        output = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        print(output)
        return output
    except Exception:
        raise AirflowException(
            f"Error while running query {query} "
            f"using MySQL connection {csv_ingestion_mysql_connection}"
        )


def table_query(bigquery_client, query):
    query_job = bigquery_client.query(query)
    try:
        # API request
        _ = query_job.result()  # Waits for query to finish
    except Exception:
        raise AirflowException(
            f"{query_job.job_id} job executed by {query_job.user_email} "
            f"has failed for query {query}"
        )


def load_temp_to_act(ti, **kwargs):
    target_dataset_name = kwargs['target_dataset_name']
    target_table_name = kwargs['target_table_name']

    try:
        bigquery_client = bigquery.Client()
        curated_table_id = hist_load_project_name + "." \
            + target_dataset_name + "." \
            + target_table_name
        query_cols = ''
        fields = bigquery_client.get_table(curated_table_id).schema
        for field in fields:
            if field.field_type == 'DATETIME':
                query_cols = query_cols + \
                             f'DATETIME({field.name}, "America/Toronto"),'
            else:
                query_cols = query_cols + f'{field.name},'

        query_cols = query_cols[:-1]
        print(f'{query_cols}')

        # Truncate table to avoid duplicate data
        table_query(bigquery_client,
                    f'TRUNCATE TABLE `{curated_table_id}`')

        # Insert Data from temphist to Curated table
        table_query(bigquery_client,
                    f'INSERT INTO `{curated_table_id}` '
                    f'SELECT {query_cols} '
                    f'FROM `{curated_table_id}_temphist`'
                    )

        # Drop temphist table
        table_query(bigquery_client,
                    f'DROP TABLE `{curated_table_id}_temphist`')
    except Exception:
        raise AirflowException(
            "The process to load data from temphist "
            f"to {target_dataset_name}.{target_table_name} failed"
        )


with DAG(
        dag_id='in__claims_kpi__daily_load',
        schedule_interval='0 8 * * *',
        start_date=datetime(2022, 11, 15),
        tags=['claims_kpi'],
        catchup=False,
) as dag:
    query = "SELECT * FROM csv_ingestion.hist_migration_load_details " \
            "WHERE " \
            "target_dataset_name='product_common_claim' " \
            "and " \
            "is_active = 1;"
    files = execute_read_query(query)
    first_task_bool = True
    curr_task = None

    for file in files:
        key, src_type, target_type, project_details, source_table_name, \
            target_database_name, target_table_name, part_col, is_active = file
        run_load_temp = SSHOperator(
            ssh_hook=sshHook,
            task_id="create_{}_temphist_table".format(target_table_name),
            command="cd apps/eclm/hist_load/ && sh run_eclm_hist_load.sh "
                    f"{src_type} {target_type} {project_details} "
                    f"{source_table_name} {target_database_name} "
                    f"{target_table_name} {part_col}",
            dag=dag,
            trigger_rule="all_done",
            cmd_timeout=10800
        )

        run_load = PythonOperator(
            task_id='load_temp_to_curated_' + file[6],
            provide_context=True,
            python_callable=load_temp_to_act,
            op_kwargs={
                'target_dataset_name': target_database_name,
                'target_table_name': target_table_name
            }
        )

        if first_task_bool:
            first_task_bool = False
            prev_task = run_load
            run_load_temp >> run_load
        else:
            curr_task = prev_task
            prev_task = run_load
            curr_task >> run_load_temp >> run_load
