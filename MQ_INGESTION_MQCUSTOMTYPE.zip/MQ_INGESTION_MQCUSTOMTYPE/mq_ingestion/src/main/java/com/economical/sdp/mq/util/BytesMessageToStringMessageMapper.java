package com.economical.sdp.mq.util;

import org.apache.beam.sdk.io.jms.JmsIO;
import com.economical.sdp.mq.util.JmsMessageDetails;
import javax.jms.BytesMessage;
import javax.jms.Message;
import javax.jms.TextMessage;

public class BytesMessageToStringMessageMapper implements JmsIO.MessageMapper<JmsMessageDetails> {

    @Override
    public JmsMessageDetails mapMessage(Message message) throws Exception {
        Object bytesMessage = (Object) message;

        //System.out.println(bytesMessage.getClass());
        if (bytesMessage instanceof com.ibm.jms.JMSTextMessage) {
            TextMessage msg = (TextMessage) bytesMessage;
            //System.out.println("Text msg:" + msg.getText());
            return new JmsMessageDetails(msg.getText(), true);
        } else if (bytesMessage instanceof com.ibm.jms.JMSBytesMessage) {
            BytesMessage byteMessage = (BytesMessage) message;
            byte[] byteData = null;
            byteData = new byte[(int) byteMessage.getBodyLength()];
            byteMessage.readBytes(byteData);
            byteMessage.reset();
            String str = new String(byteData);

            //System.out.println("Bytes msg:" + str);
            return new JmsMessageDetails(str, true);
        }
        return new JmsMessageDetails(bytesMessage.toString(), false);
    }
}
