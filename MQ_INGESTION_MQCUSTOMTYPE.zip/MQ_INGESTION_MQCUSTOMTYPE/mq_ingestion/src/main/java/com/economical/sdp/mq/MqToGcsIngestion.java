package com.economical.sdp.mq;

import com.economical.sdp.mq.util.BytesMessageToStringMessageMapper;
import com.economical.sdp.mq.util.FetchMqSecretsFromSecretManager;
import com.economical.sdp.mq.options.MqToGcsOptions;
import com.economical.sdp.mq.util.JmsMessageDetails;
import com.economical.sdp.mq.util.MQConnectionFactoryUtil;
import com.google.cloud.storage.*;
import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.SerializableCoder;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.jms.JmsIO;
import org.apache.beam.sdk.io.jms.JmsRecord;
import org.apache.beam.sdk.metrics.MetricNameFilter;
import org.apache.beam.sdk.metrics.MetricQueryResults;
import org.apache.beam.sdk.metrics.MetricsFilter;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.beam.runners.dataflow.DataflowRunner;
import org.apache.beam.sdk.PipelineResult;
import org.springframework.objenesis.strategy.SingleInstantiatorStrategy;

import static java.nio.charset.StandardCharsets.UTF_8;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import java.io.IOException;

public class MqToGcsIngestion {
    private static final Logger LOG = LoggerFactory.getLogger(MqToGcsIngestion.class);

    public static void main(String[] args) {

        final String MQTOGC_SMETRIC_NAMESPACE = "MQTOGC_SMETRIC_NAMESPACE";
        try {
            MqToGcsOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(MqToGcsOptions.class);

            options.setRunner(DataflowRunner.class);
            options.setUsePublicIps(false);
            options.setStreaming(true);


            options.setRegion(String.valueOf(options.getRegion()));
            options.setGcpTempLocation(String.valueOf(options.getTempLocation()));
            options.setStagingLocation(String.valueOf(options.getStagingLocation()));
            options.setSubnetwork(String.valueOf(options.getSubnetwork()));
            options.setJobName(options.getJobName());
            options.setServiceAccount(options.getServiceAccount());
            options.setDataflowServiceOptions(options.getDataflowServiceOptions());

            PipelineResult result;

            if (options.getBatchEnableFlag().toString().equalsIgnoreCase("true")) {

                if (options.getMqLbEnvFlag().toString().equalsIgnoreCase("true")) {
                    result = runMultipleSources(options);

                } else {
                    result = run(options);
                }

            } else {
                if (options.getMqLbEnvFlag().toString().equalsIgnoreCase("true")) {
                    result = runMultipleSourcesStream(options);

                } else {
                    result = runStream(options);
                }

            }
            result.waitUntilFinish();

            // Dataflow Job metrics of events
            MetricQueryResults metrics = result.metrics()
                    .queryMetrics(
                            MetricsFilter.builder()
                                    .addNameFilter(MetricNameFilter.named("MQTOGC_SMETRIC_NAMESPACE", "MQTOGCS_SUCCESS"))
                                    .addNameFilter(MetricNameFilter.named("MQTOGC_SMETRIC_NAMESPACE", "MQTOGCS_FAILURE"))
                                    .build());

        } catch (Exception e) {

            if (e instanceof IllegalArgumentException) {
                LOG.error("ERROR MQTOGCS -Please Provide the correct parameter and values ", e.getMessage());
                e.printStackTrace();
                System.exit(1);
            } else {
                LOG.error("ERROR MQTOGCS -Please check the google runtime error log", e.getMessage(), e);
                e.printStackTrace();
                System.exit(1);

            }
        }
    }


    public static PipelineResult runMultipleSources(MqToGcsOptions options) throws JMSException {

        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);
        LOG.info("start Reading from MQ");

        try {
            ConnectionFactory connectionFactory = new MQConnectionFactoryUtil().init(options.getMqHost().toString(), options.getMqPort().toString(), options.getMqManager().toString(), options.getMqChannel().toString(), options.getMqUserSecret().toString(), options.getMqPasswordSecret().toString(), options.getProject());

            ConnectionFactory connectionFactoryLb = new MQConnectionFactoryUtil().init(options.getMqHostLb().toString(), options.getMqPortLb().toString(), options.getMqManagerLb().toString(), options.getMqChannelLb().toString(), options.getMqUserSecretLb().toString(), options.getMqPasswordSecretLb().toString(), options.getProject());

            PCollection<JmsMessageDetails> JmsRecordMQ = pipeline.apply("Read From MQ", JmsIO.<JmsMessageDetails>readMessage()
                    .withConnectionFactory(connectionFactory)
                    .withQueue(String.valueOf(options.getMqQueue()))
                    .withCoder(SerializableCoder.of(JmsMessageDetails.class))
                    .withMessageMapper(new BytesMessageToStringMessageMapper()));

            PCollection<String> JmsRecordMQStrings = JmsRecordMQ.apply("extract payloads", ParDo.of(new DoFn<JmsMessageDetails, String>() {    // a DoFn as an anonymous inner class instance
                @ProcessElement
                public void processElement(@Element JmsMessageDetails message, OutputReceiver<String> out) {

                    out.output(message.getMessageBody());
                }
            }));
            PCollection<JmsMessageDetails> JmsRecordMQLb = pipeline.apply("Read From MQLB", JmsIO.<JmsMessageDetails>readMessage()
                    .withConnectionFactory(connectionFactoryLb)
                    .withQueue(String.valueOf(options.getMqQueueLb()))
                    .withCoder(SerializableCoder.of(JmsMessageDetails.class))
                    .withMessageMapper(new BytesMessageToStringMessageMapper()));


            PCollection<String> JmsRecordMQLbStrings = JmsRecordMQLb.apply("extract payloads", ParDo.of(new DoFn<JmsMessageDetails, String>() {    // a DoFn as an anonymous inner class instance
                @ProcessElement
                public void processElement(@Element JmsMessageDetails message, OutputReceiver<String> out) {

                    out.output(message.getMessageBody());
                }
            }));


            PCollectionList<String> collectionList = PCollectionList.of(JmsRecordMQStrings).and(JmsRecordMQLbStrings);
            PCollection<String> mergedCollectionWithFlatten = collectionList
                    .apply(Flatten.<String>pCollections());

            mergedCollectionWithFlatten.apply("Fire Every Ns", Window.<String>configure().triggering(
                    Repeatedly.forever(
                            AfterProcessingTime.pastFirstElementInPane()
                                    .plusDelayOf(Duration.standardSeconds(options.getWindowDuration()))))
                    .discardingFiredPanes())
                    .apply("Write to GCS", TextIO.write()
                            .to(options.getGcsOutput())
                            .withWindowedWrites()
                            .withNumShards(options.getNumOfShards()));

        } catch (Exception e) {
            LOG.error("ERROR MQTOGCS-Unable to process the pipeline", e.getMessage());
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());

        }

        return pipeline.run();//.waitUntilFinish();
    }

    public static PipelineResult run(MqToGcsOptions options) throws JMSException {

        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);
        LOG.info("start Reading from MQ");

        try {
            MQConnectionFactory connectionFactory = new MQConnectionFactoryUtil().init(options.getMqHost().toString(), options.getMqPort().toString(), options.getMqManager().toString(), options.getMqChannel().toString(), options.getMqUserSecret().toString(), options.getMqPasswordSecret().toString(), options.getProject());


            pipeline.apply("Read From MQ", JmsIO.<JmsMessageDetails>readMessage()
                    .withConnectionFactory(connectionFactory)
                    .withQueue(String.valueOf(options.getMqQueue()))
                    .withCoder(SerializableCoder.of(JmsMessageDetails.class))
                    .withMessageMapper(new BytesMessageToStringMessageMapper()))

                    .apply("extract payloads", ParDo.of(new DoFn<JmsMessageDetails, String>() {    // a DoFn as an anonymous inner class instance
                        @ProcessElement
                        public void processElement(@Element JmsMessageDetails message, OutputReceiver<String> out) {

                            out.output(message.getMessageBody());
                        }
                    }))
                    .apply("Fire Every Ns", Window.<String>configure().triggering(
                            Repeatedly.forever(
                                    AfterProcessingTime.pastFirstElementInPane()
                                            .plusDelayOf(Duration.standardSeconds(options.getWindowDuration()))))
                            .discardingFiredPanes())
                    .apply("Write to GCS", TextIO.write()
                            .to(options.getGcsOutput())
                            .withWindowedWrites()
                            .withNumShards(options.getNumOfShards()));


        } catch (Exception e) {
            LOG.error("ERROR MQTOGCS-Unable to process the pipeline", e.getMessage());
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());

        }


        return pipeline.run();//.waitUntilFinish();
    }

    public static PipelineResult runMultipleSourcesStream(MqToGcsOptions options) throws JMSException {

        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);
        LOG.info("start Reading from MQ");

        try {
            ConnectionFactory connectionFactory = new MQConnectionFactoryUtil().init(options.getMqHost().toString(), options.getMqPort().toString(), options.getMqManager().toString(), options.getMqChannel().toString(), options.getMqUserSecret().toString(), options.getMqPasswordSecret().toString(), options.getProject());

            ConnectionFactory connectionFactoryLb = new MQConnectionFactoryUtil().init(options.getMqHostLb().toString(), options.getMqPortLb().toString(), options.getMqManagerLb().toString(), options.getMqChannelLb().toString(), options.getMqUserSecretLb().toString(), options.getMqPasswordSecretLb().toString(), options.getProject());


            PCollection<JmsMessageDetails> JmsStringMQ = pipeline.apply("Read From MQ", JmsIO.<JmsMessageDetails>readMessage()
                    .withConnectionFactory(connectionFactory)
                    .withQueue(String.valueOf(options.getMqQueue()))
                    .withCoder(SerializableCoder.of(JmsMessageDetails.class))
                    .withMessageMapper(new BytesMessageToStringMessageMapper()));


            PCollection<JmsMessageDetails> JmsStringMQLb = pipeline.apply("Read From MQLB", JmsIO.<JmsMessageDetails>readMessage()
                    .withConnectionFactory(connectionFactoryLb)
                    .withQueue(String.valueOf(options.getMqQueueLb()))
                    .withCoder(SerializableCoder.of(JmsMessageDetails.class))
                    .withMessageMapper(new BytesMessageToStringMessageMapper()));


            PCollectionList<JmsMessageDetails> collectionList = PCollectionList.of(JmsStringMQ).and(JmsStringMQLb);
            PCollection<JmsMessageDetails> mergedCollectionWithFlatten = collectionList
                    .apply(Flatten.<JmsMessageDetails>pCollections());

            mergedCollectionWithFlatten.apply("Extract N Write To GCS", ParDo.of(new DoFn<JmsMessageDetails, String>() {    // a DoFn as an anonymous inner class instance
                @ProcessElement
                public void processElement(ProcessContext c, OutputReceiver<String> out) {

                    MqToGcsOptions options = c.getPipelineOptions().as(MqToGcsOptions.class);

                    // Create your service object
                    Storage storage = (Storage) StorageOptions.getDefaultInstance().getService();
                    if (!c.element().getIsvalidFileType()) {
                        long currentTimeMillis = System.currentTimeMillis();

                        String gcsFailPath = options.getGcsOutput().toString().split("landing")[0] + "failure/" + options.getGcsOutput().toString().substring(options.getGcsOutput().toString().lastIndexOf('/') + 1);

                        BlobId blobId = BlobId.of(options.getBucketName().toString(), gcsFailPath + currentTimeMillis);
                        BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("text/plain").build();
                        Blob blob = storage.create(blobInfo, c.element().getMessageBody().getBytes(UTF_8));
                    } else {
                        long currentTimeMillis = System.currentTimeMillis();

                        BlobId blobId = BlobId.of(options.getBucketName().toString(), options.getGcsOutput().toString() + currentTimeMillis);

                        BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("text/plain").build();
                        @SuppressWarnings("unused")
                        Blob blob = storage.create(blobInfo, c.element().getMessageBody().getBytes(UTF_8));
                    }
                }
            }));


        } catch (Exception e) {
            LOG.error("ERROR MQTOGCS-Unable to process the pipeline", e.getMessage());
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());

        }

        return pipeline.run();//.waitUntilFinish();
    }

    public static PipelineResult runStream(MqToGcsOptions options) throws JMSException {

        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);
        LOG.info("start Reading from MQ");

        try {
            MQConnectionFactory connectionFactory = new MQConnectionFactoryUtil().init(options.getMqHost().toString(), options.getMqPort().toString(), options.getMqManager().toString(), options.getMqChannel().toString(), options.getMqUserSecret().toString(), options.getMqPasswordSecret().toString(), options.getProject());

            pipeline.apply("Read From MQ", JmsIO.<JmsMessageDetails>readMessage()
                    .withConnectionFactory(connectionFactory)
                    .withQueue(String.valueOf(options.getMqQueue()))
                    .withCoder(SerializableCoder.of(JmsMessageDetails.class))
                    .withMessageMapper(new BytesMessageToStringMessageMapper()))

                    .apply("Extract N Write To GCS", ParDo.of(new DoFn<JmsMessageDetails, String>() {    // a DoFn as an anonymous inner class instance
                        @ProcessElement
                        public void processElement(ProcessContext c, OutputReceiver<String> out) {

                            MqToGcsOptions options = c.getPipelineOptions().as(MqToGcsOptions.class);

                            // Create your service object
                            Storage storage = (Storage) StorageOptions.getDefaultInstance().getService();

                            // Upload a blob to the newly created bucket
                            if (!c.element().getIsvalidFileType()) {
                                long currentTimeMillis = System.currentTimeMillis();

                                String gcsFailPath = options.getGcsOutput().toString().split("landing")[0] + "failure/" + options.getGcsOutput().toString().substring(options.getGcsOutput().toString().lastIndexOf('/') + 1);

                                BlobId blobId = BlobId.of(options.getBucketName().toString(), gcsFailPath + currentTimeMillis);
                                BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("text/plain").build();
                                Blob blob = storage.create(blobInfo, c.element().getMessageBody().getBytes(UTF_8));
                            } else {
                                long currentTimeMillis = System.currentTimeMillis();

                                BlobId blobId = BlobId.of(options.getBucketName().toString(), options.getGcsOutput().toString() + currentTimeMillis);

                                BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("text/plain").build();
                                @SuppressWarnings("unused")
                                Blob blob = storage.create(blobInfo, c.element().getMessageBody().getBytes(UTF_8));
                            }
                        }
                    }));

        } catch (Exception e) {
            LOG.error("ERROR MQTOGCS-Unable to process the pipeline", e.getMessage());
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());

        }

        return pipeline.run();//.waitUntilFinish();
    }

}
