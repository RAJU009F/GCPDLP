package com.economical.sdp.mq.util;

import java.io.Serializable;

public class JmsMessageDetails implements Serializable {
    public JmsMessageDetails(String messageBody, Boolean isvalidFileType) {
        this.messageBody = messageBody;
        this.isvalidFileType = isvalidFileType;
    }

    public void setMessageBody(String messageBody) {
        this.messageBody = messageBody;
    }

    public void setIsvalidFileType(Boolean isvalidFileType) {
        this.isvalidFileType = isvalidFileType;
    }

    public String getMessageBody() {
        return messageBody;
    }

    public Boolean getIsvalidFileType() {
        return isvalidFileType;
    }

    private String messageBody;
    private Boolean isvalidFileType;


}
