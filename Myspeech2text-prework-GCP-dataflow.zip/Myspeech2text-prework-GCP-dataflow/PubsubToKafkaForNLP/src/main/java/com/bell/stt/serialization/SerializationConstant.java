/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
package com.bell.stt.serialization;

public class SerializationConstant {
    public  static String CLIENT_ID="com.bell.stt.transcription.gcp-producer";
    public  static String RETRY_VALUE="50";
    public  static String RETRY_BACKOFF_VALUE="200";
    public  static String MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION_VALUE="20";
    public  static String LINGER_VALUE="10";
    public  static String COMPRESSION_TYPE_VALUE="lz4";
    public  static String JASSCONFIG="com.sun.security.auth.module.Krb5LoginModule required useKeyTab=true storeKey=true keyTab=\"%s\" principal=\"%s\";";
    public  static String KAFKA_KEYTAB="/kafka.keytab";
}
