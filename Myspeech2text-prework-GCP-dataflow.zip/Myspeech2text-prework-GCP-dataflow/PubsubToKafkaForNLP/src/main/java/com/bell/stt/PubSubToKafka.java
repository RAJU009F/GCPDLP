/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.stt;


import com.bell.stt.avro.NLPSentimentAndEntityAnalysisTranscriptionOutput;
import com.bell.stt.kafka.KafkaHelper;
import com.bell.stt.options.PubSubToKafkaOptions;
import com.bell.stt.proto.TranscriptionMessage;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.StorageOptions;
import com.bell.stt.transformers.KafkaToAvroParDo;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.beam.runners.dataflow.DataflowRunner;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.kafka.KafkaIO;
import org.apache.beam.sdk.metrics.MetricNameFilter;
import org.apache.beam.sdk.metrics.MetricQueryResults;
import org.apache.beam.sdk.metrics.MetricResult;
import org.apache.beam.sdk.metrics.MetricsFilter;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.kafka.common.serialization.StringSerializer;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

/**
 * Class for reading the Transcription from pubsub
 * Transform to Avro
 * Write to Output Kafka
 */
public class PubSubToKafka {


   private static final Logger LOG = LoggerFactory.getLogger(PubSubToKafka.class);


    /**
     * Entry point for the data flow job
     * @param args pipeline arguments
     */
    public static void main(String[] args) {


        try {
            PubSubToKafkaOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(PubSubToKafkaOptions.class);

            options.setStreaming(true);
            ResourceBundle resourceBundle = getResourceBundle(options);
            options.setRegion(String.valueOf(resourceBundle.getString("region")));
            options.setGcpTempLocation(String.valueOf(resourceBundle.getString("tempLocation")));
            options.setStagingLocation(String.valueOf(resourceBundle.getString("stagingLocation")));
            options.setServiceAccount(String.valueOf(resourceBundle.getString("serviceAccount")));
            options.setRunner(DataflowRunner.class);
            options.setUsePublicIps(false);
            options.setSubnetwork(String.valueOf(resourceBundle.getString("subnetwork")));
            options.setInputSubscription(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("inputSubscription"))));
            options.setOutputTopic(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("outputTopic"))));
            options.setDeadLetterTopic(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("deadLetterTopic"))));
            options.setBootstrapServers(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("bootstrapServers"))));
            LOG.info("Bootstrapserver value" +"*****"+resourceBundle.getString("bootstrapServers")+"*****");
            options.setschemaRegistryUrl(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("schemaRegistryUrl"))));
            LOG.info("schemaRegistryUrl value" + "*****"+resourceBundle.getString("schemaRegistryUrl")+"*****");
            options.setProjectIdForSecret(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("projectIdForSecret"))));
            LOG.info("projectIdForSecret value" + "*****"+resourceBundle.getString("projectIdForSecret")+"*****");
            options.setTrustStoreNameInSecretManager(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("trustStoreNameInSecretManager"))));
            LOG.info("trustStoreNameInSecretManager value" + "*****"+resourceBundle.getString("trustStoreNameInSecretManager")+"*****");

            options.setTrustStorePasswordInSecretManager(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("trustStorePasswordInSecretManager"))));
            LOG.info("trustStorePasswordInSecretManager value" +"*****"+resourceBundle.getString("trustStorePasswordInSecretManager")+"*****");
            options.setKeytabNameInSecretManager(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("keytabNameInSecretManager"))));
            LOG.info("keytabNameInSecretManager value" + "*****"+resourceBundle.getString("keytabNameInSecretManager")+"*****");
            options.setKrb5ConfNameInSecretManager(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("krb5ConfNameInSecretManager"))));
            LOG.info("krb5ConfNameInSecretManager value" + "*****"+resourceBundle.getString("krb5ConfNameInSecretManager")+"*****");
            options.setKafkaServiceName(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("kafkaServiceName"))));
            LOG.info("kafkaServiceName value" + "*****"+resourceBundle.getString("kafkaServiceName")+"*****");
            options.setPrincipal(ValueProvider.StaticValueProvider.of(
                String.valueOf(resourceBundle.getString("principal"))));
            LOG.info("principal value" + "*****" +resourceBundle.getString("principal")+"*****");
            options.setSecurityProtocol(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("securityProtocol"))));
            LOG.info("securityProtocol value" + "*****"+resourceBundle.getString("securityProtocol")+"*****");
            options.setJobName(resourceBundle.getString("jobname"));



            PipelineResult result = run(options);


            // request the metric called "counter1" in namespace called "namespace"
            MetricQueryResults metrics =
                    result
                            .metrics()
                            .queryMetrics(
                                    MetricsFilter.builder()
                                            .addNameFilter(MetricNameFilter.named("NLP-PubsubToKafka", "PUBSUBTOKAFKA_NLP_SUCCESS"))
                                            .addNameFilter(MetricNameFilter.named("NLP-PubsubToKafka", "PUBSUBTOKAFKA_NLP_FAILURE"))
                                            .build());


            for (MetricResult<Long> counter : metrics.getCounters()) {
                LOG.error(counter.getName() + ":" + counter.getAttempted());
            }
        }catch (Exception e) {
            if (e instanceof IllegalArgumentException) {
                LOG.error("ERR206-Please provide the correct parameter and values\n" +
                        "The Usage is follow below :\n" +
                        "java -Dsun.security.krb5.debug=<boolean> -Djava.security.krb5.conf=<configvalue>" +
                        "-cp <target jar> --runner=<dataflow> --templocation<gcspath> --region<region> " +
                        "--staginglocation<gcspath> --project=<projectid> --inputSubscription=<inputsubscriptionpath>" +
                        "--bootstrapservers=<value> --schemaReistryUrl=<URL> --outputTopic=<value> " +
                        "--deadLetterTopic=<topic path> --serivice account=<service account> --usePublicIps=<Boolean>" +
                        "--subnetwork=<URL> --projectIdForSecret=<projectid> --trustStorePasswordInSecretManage<trustvalue>" +
                        "--trustStoreNameInSecretManager=<secertManagervalue> --keytabNameInSecretManager<keyvalue>" +
                        "--krb5ConfNameInSecretManager=<value> --kafkaServiceName=<name> --principal=<value> " +
                        "--securityProtocol=<value> --jobName=<dataflow jobname");
            } else {
               LOG.error("ERR207-Please check the logs for google run time exception" + e.getMessage(),e);
            }
        }
    }



    /**
     * This Resource Bundle will take as option as parameter and read the file from the GCS bucket.
     * @param options
     * @return  PropertyResourceBundle(new InputStreamReader(new ByteArrayInputStream(blob.getContent())))
     * @throws IOException
     */
    private static ResourceBundle getResourceBundle(PubSubToKafkaOptions options) throws IOException {
        Storage storage = StorageOptions.newBuilder().setProjectId(options.getProject()).build().getService();
        Blob blob = storage.get(BlobId.of(options.getBucketName().get(), options.getConfigFileName().get()));
        return new PropertyResourceBundle(new InputStreamReader(new ByteArrayInputStream(blob.getContent())));
    }
    /**
     * The pipeline run method containing the DAG .
     * @param options pipeline options
     * @return pipeline result
     */
    public static PipelineResult run(PubSubToKafkaOptions options) {
        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);
        final TupleTag<TranscriptionMessage.ConversationEvent> DLQ =new TupleTag<TranscriptionMessage.ConversationEvent>(){};
        final TupleTag<KV<String, NLPSentimentAndEntityAnalysisTranscriptionOutput>> SUCCESS =new TupleTag<KV<String, NLPSentimentAndEntityAnalysisTranscriptionOutput>>(){};

        /**
         * Steps:
         *      1) Read PubSubMessage from input PubSub subscription.
         *      2) Build Key value pair of conversationId, Transcription
         *      3) Write each PubSubMessage to output PubSub topic.
         *      4) Write each failure PubSubMessage to deadletter topic
         */
        try {
            LOG.info("Reading the RedactedNLP conversation from the subscription");
            PubsubIO.Read<TranscriptionMessage.ConversationEvent> messages =
                    PubsubIO.readProtos(TranscriptionMessage.ConversationEvent.class).fromSubscription(options.getInputSubscription());

            LOG.info("Writing the output in Kafka Topic");
            PCollectionTuple stringMessages =
                    pipeline.apply(messages).apply(ParDo.of(new KafkaToAvroParDo(DLQ,SUCCESS)).withOutputTags(SUCCESS, TupleTagList.of(DLQ)));

            stringMessages.get(SUCCESS).apply("Write to Kafka Topic", KafkaIO.<String, NLPSentimentAndEntityAnalysisTranscriptionOutput>write().
                    withProducerFactoryFn(KafkaHelper.serializationBuilder(options).createKafkaProducer())
                    .withBootstrapServers(options.getBootstrapServers().get())
                    .withTopic(options.getOutputTopic().get())
                    .withKeySerializer(StringSerializer.class)
                    .withValueSerializer((Class) KafkaAvroSerializer.class));

            LOG.info("Writing the failed messgae in DLQ topics");
            stringMessages.get(DLQ).apply("DLQ Kafka Events",PubsubIO.writeProtos(TranscriptionMessage.ConversationEvent.class)
                    .to(options.getDeadLetterTopic()));

        } catch (Exception e) {
            LOG.error("ERRNLP201 - Error processing the pipeline ", e);
        }
        // Execute the pipeline and return the result.
        return pipeline.run();
    }
}