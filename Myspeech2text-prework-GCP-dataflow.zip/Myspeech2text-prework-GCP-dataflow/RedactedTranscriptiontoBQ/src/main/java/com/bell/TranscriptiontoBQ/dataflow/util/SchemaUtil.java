/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.TranscriptiontoBQ.dataflow.util;

import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.TableSchema;

import java.util.ArrayList;
import java.util.List;

public class SchemaUtil {
    /**
     * This class provides the details of the  BigQuery table schema
     * @return Schema
     */

    public static TableSchema getSchema(){


           List<TableFieldSchema> fields = new ArrayList<>();
           fields.add(new TableFieldSchema().setName(PayloadSchema.CONVERSATION).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.NAME).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.CONTENT).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.LANGUAGE_CODE).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.PARTICIPANT).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.PARTICIPANT_ROLE).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.CREATE_TIME).setType("TIMESTAMP"));
           //fields.add(new TableFieldSchema().setName(PayloadSchema.NLPAPISTARTTIME).setType("TIMESTAMP"));
           //fields.add(new TableFieldSchema().setName(PayloadSchema.GCPENDTIME).setType("TIMESTAMP"));
           //fields.add(new TableFieldSchema().setName(PayloadSchema.WORDCOUNT).setType("INTEGER"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.STREAM_START_TIME).setType("TIMESTAMP"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.UTTERANCE_START_OFFSET).setType("INTEGER"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.UTTERANCE_END_OFFSET).setType("INTEGER"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.CONFIDENCE).setType("INTEGER"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.START_OFFSET).setType("INTEGER"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.END_OFFSET).setType("INTEGER"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.WORD).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.SCORE).setType("FLOAT"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.MAGNITUDE).setType("FLOAT"));

        /* ================================= THIS SECTION CAN BE REUSED IF NESTED NATURE OF FIELDS FOR SPEECHTOTEXTINFO AND SENTIMENT REQUIRED

           fields.add(new TableFieldSchema().setName(PayloadSchema.SPEECHTOTEXTINFO).setType("RECORD")
                   .setFields(new ArrayList<TableFieldSchema>() {
                       {
                           add(new TableFieldSchema().setName(PayloadSchema.STREAM_START_TIME).setType("INTEGER"));
                           add(new TableFieldSchema().setName(PayloadSchema.UTTERANCE_START_OFFSET).setType("INTEGER"));
                           add(new TableFieldSchema().setName(PayloadSchema.UTTERANCE_END_OFFSET).setType("INTEGER"));
                           add(new TableFieldSchema().setName(PayloadSchema.CONFIDENCE).setType("INTEGER"));
                           add(new TableFieldSchema().setName(PayloadSchema.SPEECHWORDINFO).setType("RECORD")
                                   .setFields(new ArrayList<TableFieldSchema>() {{
                                                  add(new TableFieldSchema().setName(PayloadSchema.START_OFFSET).setType("INTEGER"));
                                                  add(new TableFieldSchema().setName(PayloadSchema.END_OFFSET).setType("INTEGER"));
                                                  add(new TableFieldSchema().setName(PayloadSchema.WORD).setType("STRING"));
                                                  add(new TableFieldSchema().setName(PayloadSchema.CONFIDENCE).setType("INTEGER"));
                                              }}
                                   ));
                       }
                   }));
           fields.add(new TableFieldSchema().setName(com.bell.TranscriptiontoBQ.dataflow.util.PayloadSchema.SENTIMENT_ANALYSIS_RESULT).setType("RECORD")
           .setFields(new ArrayList<TableFieldSchema>() {{
               add(new TableFieldSchema().setName(PayloadSchema.SENTIMENT).setType("RECORD")
               .setFields(new ArrayList<TableFieldSchema>() {{
                   add(new TableFieldSchema().setName(PayloadSchema.SCORE).setType("FLOAT"));
                   add(new TableFieldSchema().setName(PayloadSchema.MAGNITUDE).setType("FLOAT"));
               }}));
           }}));

   ============================================        */


//           fields.add(new TableFieldSchema().setName(PayloadSchema.NLP_SENTIMENT_ANALYSIS_RESPONSE).setType("RECORD")
//                   .setFields(new ArrayList<TableFieldSchema>() {{
//                                  add(new TableFieldSchema().setName(SentimentSchema.LANGUAGE).setType("STRING"));
//                                  add(new TableFieldSchema().setName(SentimentSchema.DOCUMENT).setType("RECORD")
//                                          .setFields(new ArrayList<TableFieldSchema>() {{
//                                                         add(new TableFieldSchema().setName(SentimentSchema.SCORE).setType("FLOAT"));
//                                                         add(new TableFieldSchema().setName(SentimentSchema.MAGNITUDE).setType("FLOAT"));
//                                                     }}
//
//                                          ));
//                                  add(new TableFieldSchema().setName(SentimentSchema.SENTENCES).setType("RECORD").setMode("REPEATABLE")
//                                          .setFields(new ArrayList<TableFieldSchema>() {{
//                                                         add(new TableFieldSchema().setName(SentimentSchema.TEXT).setType("RECORD")
//                                                                 .setFields(new ArrayList<TableFieldSchema>() {{
//                                                                                add(new TableFieldSchema().setName(SentimentSchema.CONTENT).setType("FLOAT"));
//                                                                                add(new TableFieldSchema().setName(SentimentSchema.BEGINOFFSET).setType("FLOAT"));
//                                                                            }}
//
//                                                                 ));
//                                                         add(new TableFieldSchema().setName(SentimentSchema.SENTENCES_SENTIMENT).setType("RECORD")
//                                                                 .setFields(new ArrayList<TableFieldSchema>() {{
//
//                                                                                add(new TableFieldSchema().setName(SentimentSchema.SCORE).setType("FLOAT"));
//                                                                                add(new TableFieldSchema().setName(SentimentSchema.MAGNITUDE).setType("FLOAT"));
//                                                                            }}
//                                                                 ));
//                                                     }}
//                                          ));
//                              }}
//                   ));
//
//
//           fields.add(new TableFieldSchema().setName(PayloadSchema.NLP_ENTITY_ANALYSIS_RESPONSE).setType("RECORD")
//                   .setFields(new ArrayList<TableFieldSchema>() {{
//                                  add(new TableFieldSchema().setName(EntitySchema.LANGUAGE).setType("STRING"));
//                                  add(new TableFieldSchema().setName(EntitySchema.ENTITIES).setType("RECORD").setMode("REPEATED")
//                                          .setFields(new ArrayList<TableFieldSchema>() {{
//                                                         add(new TableFieldSchema().setName(EntitySchema.NAME).setType("STRING"));
//                                                         add(new TableFieldSchema().setName(EntitySchema.TYPE_NLP).setType("STRING"));
//                                                         add(new TableFieldSchema().setName(EntitySchema.SALIENCE).setType("FLOAT"));
//
//                                                         add(new TableFieldSchema().setName(EntitySchema.METADATA).setType("RECORD")
//                                                                 .setFields(new ArrayList<TableFieldSchema>() {{
//                                                                                add(new TableFieldSchema().setName(EntitySchema.MID).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.WIKIPEDIA_URL).setType("FLOAT"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.PHONE_NUMBER).setType("INTEGER"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.NATIONAL_PREFIX).setType("INTEGER"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.AREA_CODE).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.EXTENSION).setType("INTEGER"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.STREET_NUMBER).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.LOCALITY).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.STREET_NAME).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.POSTAL_CODE).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.COUNTRY).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.BROAD_REGION).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.NARROW_REGION).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.SUBLOCALITY).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.NUMBER).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.YEAR).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.MONTH).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.DAY).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.CURRENCY).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.VALUE).setType("STRING"));
//
//                                                                            }}
//                                                                 ));
//                                                     }}
//                                          ));
//
//                                  add(new TableFieldSchema().setName(EntitySchema.MENTIONS).setType("RECORD")//.setMode("REPEATED")
//                                          .setFields(new ArrayList<TableFieldSchema>() {{
//                                                         add(new TableFieldSchema().setName(EntitySchema.TYPE).setType("STRING"));
//                                                         add(new TableFieldSchema().setName(EntitySchema.TEXT).setType("RECORD")
//                                                                 .setFields(new ArrayList<TableFieldSchema>() {{
//                                                                                add(new TableFieldSchema().setName(EntitySchema.CONTENT).setType("STRING"));
//                                                                                add(new TableFieldSchema().setName(EntitySchema.BEGINOFFSET).setType("INTEGER"));
//                                                                            }}
//                                                                 ));
//                                                     }}
//                                          ));
//                              }}
//                   ));

           TableSchema schema = new TableSchema().setFields(fields);//schema.toPrettyString();

        return schema;

    }
}