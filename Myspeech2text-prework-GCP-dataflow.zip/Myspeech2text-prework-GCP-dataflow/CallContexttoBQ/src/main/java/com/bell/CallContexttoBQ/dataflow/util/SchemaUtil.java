/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.CallContexttoBQ.dataflow.util;

import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.TableSchema;

import java.util.ArrayList;
import java.util.List;

public class SchemaUtil {
    /**
     * This class provides the details of the  BigQuery table schema
     * @return Schema
     */

    public static TableSchema getSchema(){


           List<TableFieldSchema> fields = new ArrayList<>();
           fields.add(new TableFieldSchema().setName(PayloadSchema.EVENT_TYPE).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.ACDID).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.UUI).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.UCID).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.CALLID).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.AGENT_LOGINID).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.AGENT_EXTENSION).setType("STRING"));
           fields.add(new TableFieldSchema().setName(PayloadSchema.EVENT_TIMESTAMP).setType("TIMESTAMP"));
           //fields.add(new TableFieldSchema().setName(PayloadSchema.GCPENDTIME).setType("TIMESTAMP"));
           //fields.add(new TableFieldSchema().setName(PayloadSchema.WORDCOUNT).setType("INTEGER"));

           fields.add(new TableFieldSchema().setName(PayloadSchema.EXTRA_CONEXTINFO).setType("RECORD")
                   .setFields(new ArrayList<TableFieldSchema>() {
                       {
                           add(new TableFieldSchema().setName(ExtraContextInfo.KEY).setType("STRING"));
                           add(new TableFieldSchema().setName(ExtraContextInfo.VALUE).setType("VALUE"));

                       }
                   }));


           TableSchema schema = new TableSchema().setFields(fields);//schema.toPrettyString();

        return schema;

    }
}