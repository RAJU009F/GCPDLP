/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.LabeltoBQ.dataflow.util;


import com.bell.stt.proto.TranscriptionMessage;
import com.google.api.services.bigquery.model.TableRow;
import com.google.protobuf.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BQTableRow {
    /**
     * This BQTable row build the row and add the value into the correponding fields.
     */
    static final Logger LOG = LoggerFactory.getLogger(BQTableRow.class);

    public static TableRow buildTableRows(TranscriptionMessage.ConversationEvent event,long gcpEndTime, String actor, String label,String name ) {

        TableRow row = new TableRow();
        String conversationId =event.getConversation();
        String ParticipantId =event.getNewMessagePayload().getParticipant();
        //String utteranceWordCount = event.getNewMessagePayload().getWordCount();
        com.google.protobuf.Timestamp stream_start_time =event.getNewMessagePayload().getSpeechToTextInfo().getStreamStartTime();
        com.google.protobuf.Duration utterance_start_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceStartOffset();
        com.google.protobuf.Duration utterance_end_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceEndOffset();
        long nlpStartTime = System.currentTimeMillis();

        try {
            long startTime = System.currentTimeMillis();
            log("The BQPardo calling for  conversation :", conversationId, ParticipantId,
                    stream_start_time, utterance_start_offset, utterance_end_offset,"Start Time ",
                    nlpStartTime);
            String conversation = event.toBuilder().getConversation();
            row.set(PayloadSchema.CONVERSATION,conversation.substring(conversation.lastIndexOf('/')+1)) ;
            row.set(PayloadSchema.NAME, name);
            //row.set(PayloadSchema.CONTENT, event.toBuilder().getNewMessagePayloadBuilder().getContent());
            //row.set(PayloadSchema.LANGUAGE_CODE, event.toBuilder().getNewMessagePayloadBuilder().getLanguageCode());
            String participant = event.toBuilder().getNewMessagePayloadBuilder().getParticipant();
            row.set(PayloadSchema.PARTICIPANT, participant.substring(participant.lastIndexOf('/')+1));
            //row.set(PayloadSchema.PARTICIPANT_ROLE, event.toBuilder().getNewMessagePayloadBuilder().getParticipantRole());
            //row.set(PayloadSchema.CREATE_TIME, new Timestamp(event.toBuilder().getNewMessagePayloadBuilder().getCreateTime().getSeconds()));
            //row.set(PayloadSchema.STREAM_START_TIME, new Timestamp(stream_start_time.getSeconds()));//row.set(PayloadSchema.STREAM_START_TIME, event.toBuilder().getNewMessagePayloadBuilder().getNLPAPIStartTime());
            //row.set(PayloadSchema.UTTERANCE_START_OFFSET, event.toBuilder().getNewMessagePayloadBuilder().getSpeechToTextInfo().getUtteranceStartOffset());
            //row.set(PayloadSchema.UTTERANCE_END_OFFSET, event.toBuilder().getNewMessagePayloadBuilder().getSpeechToTextInfo().getUtteranceEndOffset());
            //row.set(PayloadSchema.CONFIDENCE, event.toBuilder().getNewMessagePayloadBuilder().getSpeechToTextInfo().getConfidence());
            //row.set(PayloadSchema.START_OFFSET, event.toBuilder().getNewMessagePayloadBuilder().getSpeechToTextInfo().getSpeechWordInfo(0).getStartOffset());
            //row.set(PayloadSchema.END_OFFSET, event.toBuilder().getNewMessagePayloadBuilder().getSpeechToTextInfo().getSpeechWordInfo(0).getEndOffset());
            //row.set(PayloadSchema.WORD, event.toBuilder().getNewMessagePayloadBuilder().getSpeechToTextInfo().getSpeechWordInfo(0).getWord());
            row.set(PayloadSchema.ACTOR, actor);
            row.set(PayloadSchema.LABEL, label);

            //row.set(PayloadSchema.GCPENDTIME, gcpEndTime);
            //row.set(PayloadSchema.WORDCOUNT, event.toBuilder().getNewMessagePayloadBuilder().getWordCount());
            //row.set(PayloadSchema.NLP_SENTIMENT_ANALYSIS_RESPONSE, buildSentiment(event));
            //row.set(PayloadSchema.NLP_ENTITY_ANALYSIS_RESPONSE, buildEntity(event));
//            public  static String STREAM_START_TIME="stream_start_time";
//            public  static String UTTERANCE_START_OFFSET="utterance_start_offset";
//            public  static String UTTERANCE_END_OFFSET="utterance_end_offset";
//            public  static String CONFIDENCE="confidence";
//            public  static String SPEECHWORDINFO="SpeechWordInfo";
//            public  static String START_OFFSET="start_offset";
//            public  static String END_OFFSET="end_offset";
            // row.set(PayloadSchema.SENTIMENT_ANALYSIS_RESULT, event.toBuilder().getNewMessagePayloadBuilder().getSentimentAnalysis()) ;
            // row.set(PayloadSchema.SPEECHTOTEXTINFO, event.toBuilder().getNewMessagePayloadBuilder().getSpeechToTextInfo()) ;

            long endTime = System.currentTimeMillis();
            log("converting the Table row successfully ", conversationId, ParticipantId,
                    stream_start_time, utterance_start_offset, utterance_end_offset,
                    "Time taken ", endTime - startTime);
        }
        catch (Exception e)
        {
            logError("ERRNLP302-Unable to build table rows",e,conversationId,ParticipantId
                    ,stream_start_time,utterance_start_offset,utterance_end_offset);
        }
        return row;
    }


    //    private static Map<String, Object> buildSentiment(TranscriptionMessage.ConversationEvent event) {
//        Map<String, Object> sentimentFields = new HashMap<>();
//        String conversationId =event.getConversation();
//        String ParticipantId =event.getNewMessagePayload().getParticipant();
//        String utteranceWordCount = event.getNewMessagePayload().getWordCount();
//        com.google.protobuf.Timestamp stream_start_time =event.getNewMessagePayload().getSpeechToTextInfo().getStreamStartTime();
//        com.google.protobuf.Duration utterance_start_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceStartOffset();
//        com.google.protobuf.Duration utterance_end_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceEndOffset();
//        try {
//
//            long startTime = System.currentTimeMillis();
//            log("Entering into the sentiment build table row for sentiment response",
//                    conversationId, ParticipantId, utteranceWordCount, stream_start_time,
//                    utterance_start_offset,
//                    utterance_end_offset, "start time " ,startTime);
//
//            sentimentFields.put(SentimentSchema.LANGUAGE, event.getNewMessagePayload().getNLPSentimentAnalysisResponse().getLanguage());
//
//            TranscriptionMessage.NLPSentimentAnalysisResponse nlpSentimentAnalysisResponse =
//                    event.getNewMessagePayload().getNLPSentimentAnalysisResponse();
//
//            Map<String, Float> documentFields = new HashMap<>();
//            documentFields.put(SentimentSchema.SCORE, nlpSentimentAnalysisResponse.getDocument().getScore());
//            documentFields.put(SentimentSchema.MAGNITUDE, nlpSentimentAnalysisResponse.getDocument().getMagnitude());
//            sentimentFields.put(SentimentSchema.DOCUMENT, documentFields);
//
//            List<Object> sentencesListForBQ = new ArrayList<>();
//            List<TranscriptionMessage.Sentences> sentencesProto = nlpSentimentAnalysisResponse.getSentencesList();
//            for (TranscriptionMessage.Sentences sentence : sentencesProto) {
//
//                Map<String, Object> text = new HashMap<>();
//                text.put(SentimentSchema.CONTENT, sentence.getText().getContent());
//                text.put(SentimentSchema.BEGINOFFSET, sentence.getText().getBeginoffset());
//
//                Map<String, Object> sentiment = new HashMap<>();
//                sentiment.put(SentimentSchema.SCORE, sentence.getSentencesSentiment().getScore());
//                sentiment.put(SentimentSchema.MAGNITUDE, sentence.getSentencesSentiment().getMagnitude());
//
//                Map<String, Object> sentenceMap = new HashMap<>();
//                sentenceMap.put(SentimentSchema.TEXT, text);
//                sentenceMap.put(SentimentSchema.SENTENCES_SENTIMENT, sentiment);
//
//                sentencesListForBQ.add(sentenceMap);
//
//
//                sentimentFields.put(SentimentSchema.SENTENCES, sentencesListForBQ);
//                long endTime = System.currentTimeMillis();
//                log("Successfully converted sentiment Response into table row",
//                        conversationId, ParticipantId, stream_start_time,
//                        utterance_start_offset,
//                        utterance_end_offset, "Time taken " ,(endTime-startTime));
//            }
//        }
//        catch (Exception e)
//        {
//
//            logError("ERRNLP302-Unable to build sentiment rows",e,conversationId,ParticipantId
//                    ,utteranceWordCount,stream_start_time,utterance_start_offset,utterance_end_offset);
//        }
//        return sentimentFields;
//    }
//
//    /**
//     * This Build Entity build the entity fields and add values to the corresponding fields
//     * @param event
//     * @return entityFields
//     */
//
//
//    private static Map<String, Object> buildEntity(TranscriptionMessage.ConversationEvent event) {
//        Map<String, Object> entityFields = new HashMap<>();
//        String conversationId =event.getConversation();
//        String ParticipantId =event.getNewMessagePayload().getParticipant();
//        String utteranceWordCount = event.getNewMessagePayload().getWordCount();
//        com.google.protobuf.Timestamp stream_start_time =event.getNewMessagePayload().
//                getSpeechToTextInfo().getStreamStartTime();
//        com.google.protobuf.Duration utterance_start_offset=event.getNewMessagePayload().
//                getSpeechToTextInfo().getUtteranceStartOffset();
//        com.google.protobuf.Duration utterance_end_offset=event.getNewMessagePayload().
//                getSpeechToTextInfo().getUtteranceEndOffset();
//   try {
//       long startTime = System.currentTimeMillis();
//       LOG.debug("Entering the Build entities Rows");
//
//       entityFields.put(EntitySchema.LANGUAGE, event.getNewMessagePayload().getNLPEntityAnalysisResponse().getLanguage());
//
//       TranscriptionMessage.NLPEntityAnalysisResponse nlpEntityAnalysisResponse =
//               event.getNewMessagePayload().getNLPEntityAnalysisResponse();
//
//       List<Object> entitiesListForBQ = new ArrayList<>();
//       List<TranscriptionMessage.Entities> entitiesProto = nlpEntityAnalysisResponse.getEntitiesList();
//       for (TranscriptionMessage.Entities entity : entitiesProto) {
//
//           //Entities
//           Map<String, Object> entitiesFields = new HashMap<>();
//           entitiesFields.put(EntitySchema.NAME, entity.getName());
//           entitiesFields.put(EntitySchema.TYPE_NLP, entity.getTypeNlp());
//           entitiesFields.put(EntitySchema.SALIENCE, entity.getSalience());
//
//           //Mentions
//           TranscriptionMessage.Mentions mention = entity.getMentions();
//           Map<String, Object> mentions = new HashMap<>();
//           mentions.put(EntitySchema.TYPE, mention.getType());
//
//           Map<String, Object> mentions_text = new HashMap<>();
//           mentions_text.put(EntitySchema.BEGINOFFSET, mention.getText().getBeginoffset());
//           mentions_text.put(EntitySchema.CONTENT, mention.getText().getContent());
//           mentions.put(EntitySchema.TEXT, mentions_text);
//
//           entitiesFields.put(EntitySchema.MENTIONS, mentions);
//
//           //Metadata
//           TranscriptionMessage.Metadata metadataProto = entity.getMetadata();
//           Map<String, Object> metadata = new HashMap<>();
//           metadata.put(EntitySchema.MID, metadataProto.getMid());
//           metadata.put(EntitySchema.WIKIPEDIA_URL, metadataProto.getWikipediaUrl());
//           metadata.put(EntitySchema.PHONE_NUMBER, metadataProto.getPhoneNumber());
//           metadata.put(EntitySchema.NATIONAL_PREFIX, metadataProto.getNationalPrefix());
//           metadata.put(EntitySchema.AREA_CODE, metadataProto.getAreaCode());
//           metadata.put(EntitySchema.EXTENSION, metadataProto.getExtension());
//           metadata.put(EntitySchema.STREET_NUMBER, metadataProto.getStreetNumber());
//           metadata.put(EntitySchema.LOCALITY, metadataProto.getLocality());
//           metadata.put(EntitySchema.STREET_NAME, metadataProto.getStreetName());
//           metadata.put(EntitySchema.POSTAL_CODE, metadataProto.getPostalCode());
//           metadata.put(EntitySchema.COUNTRY, metadataProto.getCountry());
//           metadata.put(EntitySchema.BROAD_REGION, metadataProto.getBroadRegion());
//           metadata.put(EntitySchema.NARROW_REGION, metadataProto.getNarrowRegion());
//           metadata.put(EntitySchema.SUBLOCALITY, metadataProto.getSublocality());
//           metadata.put(EntitySchema.NUMBER, metadataProto.getNumber());
//           metadata.put(EntitySchema.YEAR, metadataProto.getYear());
//           metadata.put(EntitySchema.MONTH, metadataProto.getMonth());
//           metadata.put(EntitySchema.DAY, metadataProto.getDay());
//           metadata.put(EntitySchema.CURRENCY, metadataProto.getCurrency());
//           metadata.put(EntitySchema.VALUE, metadataProto.getValue());
//           entitiesFields.put(EntitySchema.METADATA, metadata);
//
//           entitiesListForBQ.add(entitiesFields);
//       }
//       entityFields.put(EntitySchema.ENTITIES, entitiesListForBQ);
//       long endTime = System.currentTimeMillis();
//       log("Successfully converted entity Response into table row",
//               conversationId, ParticipantId, stream_start_time,
//               utterance_start_offset,
//               utterance_end_offset, "Time taken " ,(endTime-startTime));
//   }
//     catch (Exception e)
//        {
//            logError("ERRNLP303-Unable to build entity rows",e,conversationId,ParticipantId
//                    ,utteranceWordCount,stream_start_time,utterance_start_offset,utterance_end_offset);
//        }
//        return entityFields;
//
//    }
    public static void log(String prefix,
                           String conversationId, String participantId,
                           com.google.protobuf.Timestamp stream_start_time,
                           Duration utterance_start_offset, Duration utterance_end_offset, String time , long timeTakenMs) {
        String logMessage=prefix + " ConversationId: " + conversationId + ", ParticipantId: " + participantId + ", Stream_Start_Time: " + stream_start_time +
                ", Utterance_start_offset: " + utterance_start_offset + ", utterance_end_offset: "
                + utterance_end_offset + ", "+time + timeTakenMs+"ms";

        LOG.debug(logMessage.replace("\r","").replace("\n",""));
    }

    public static void logError(String prefix,Exception e,
                                String conversationId, String participantId,
                                com.google.protobuf.Timestamp stream_start_time,
                                Duration utterance_start_offset, Duration utterance_end_offset){
        String logErrorMessage=prefix + e.getMessage() + ", ConversationId: " +conversationId
                + ", ParticipantId: " +participantId + ", Stream_Start_Time: "
                + stream_start_time + ", Utterance_start_offset: " +utterance_start_offset+  ", utterance_end_offset: "
                + utterance_end_offset;
        LOG.error(logErrorMessage.replace("\r","").replace("\n",""),e);
    }
}


