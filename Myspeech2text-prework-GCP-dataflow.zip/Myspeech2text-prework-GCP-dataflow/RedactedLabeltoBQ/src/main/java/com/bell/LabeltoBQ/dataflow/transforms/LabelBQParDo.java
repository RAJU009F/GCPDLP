/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.LabeltoBQ.dataflow.transforms;



import com.bell.LabeltoBQ.dataflow.util.BQTableRow;
import com.bell.stt.proto.TranscriptionMessage;
import com.google.api.services.bigquery.model.TableRow;
import com.google.protobuf.Duration;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.cloud.dialogflow.v2beta1.ParticipantsClient;
import com.google.cloud.dialogflow.v2beta1.Participant;
import com.google.cloud.dialogflow.v2beta1.stub.*;
import com.google.cloud.dialogflow.v2beta1.*;
import org.apache.beam.sdk.metrics.Distribution;
import org.apache.beam.sdk.metrics.Metrics;
import java.io.IOException;

/**
 * This BQ pardo function will do the transformation from event to table row.
 */

public class LabelBQParDo extends DoFn<TranscriptionMessage.ConversationEvent,TableRow> {

    static final Logger LOG = LoggerFactory.getLogger(com.bell.LabeltoBQ.dataflow.transforms.LabelBQParDo.class);
    private final Counter Success_counter = Metrics.counter("Label-PubsubToBigquery", "PUBSUBTOBIGQUERY_Label_SUCCESS");
    private final Counter failure_counter = Metrics.counter("Label-PubsubToBigquery", "PUBSUBTOBIGQUERY_Label_FAILURE");

    final TupleTag<TranscriptionMessage.ConversationEvent> DLQ;
    final TupleTag<TableRow> SUCCESS;
    private transient ParticipantsClient participantsClient;

    public LabelBQParDo(TupleTag<TranscriptionMessage.ConversationEvent> DLQ, TupleTag<TableRow> SUCCESS) {
        this.DLQ = DLQ;
        this.SUCCESS = SUCCESS;
    }

    /**
     * Template method to open any resources
     *
     * @throws IOException
     */

    @StartBundle
    public void startBundle() throws IOException
    {
        try
        {
            // long startTime=System.currentTimeMillis();
            LOG.debug("Creating the Language service client");

            this.participantsClient = ParticipantsClient.create();

        } catch (IOException e)
        {
            LOG.error("ERRLabel101 - Unable to start participantsClient  ", e.getMessage());
            throw  e;
        } catch (Exception e){
            LOG.error("ERRLabel101 - Unable to start participantsClient  ", e.getMessage());
            throw  e;
        }
    }

    /**
     * Template method to close any resources
     */

    @FinishBundle
    public void finishBundle()
    {
        if (this.participantsClient != null)
        {
            long startTime=System.currentTimeMillis();
            this.participantsClient.close();
            long endTime=System.currentTimeMillis();
            LOG.debug("Time taken to close the participantsClient " + (endTime -startTime)+"ms");
        }
    }


    @ProcessElement
    public void processElement(ProcessContext c,MultiOutputReceiver out) {

        TranscriptionMessage.ConversationEvent event = c.element();

        String conversationId =event.getConversation();
        String ParticipantId =event.getNewMessagePayload().getParticipant();
        String utteranceWordCount = event.getNewMessagePayload().getWordCount();
        com.google.protobuf.Timestamp stream_start_time =event.getNewMessagePayload().getSpeechToTextInfo().getStreamStartTime();
        com.google.protobuf.Duration utterance_start_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceStartOffset();
        com.google.protobuf.Duration utterance_end_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceEndOffset();
        long nlpStartTime = System.currentTimeMillis();
        // try to get the

        try{
            long startTime= System.currentTimeMillis();
            log("The LabelBQPardo calling for  conversation :", conversationId, ParticipantId, utteranceWordCount,
                    stream_start_time, utterance_start_offset, utterance_end_offset,"Start Time ",
                    nlpStartTime);
            Participant participant =  getParticipantUtil("projectID", conversationId,ParticipantId);
            //System.out.println("+++++++++Participant"+participant);

            String actor = participant.getRole().toString();
            String name = participant.getName().toString();
            String label = String.valueOf(participant.getRoleValue());
            //System.out.println("+++++name:"+name+",    actor:"+actor+"   label:"+label);


            TableRow table =BQTableRow.buildTableRows(event,System.currentTimeMillis(),actor,label,name);
            c.output(SUCCESS,table) ;

            long endTime= System.currentTimeMillis();
            log("The LabelBQPardo calling successfully completed for  conversation :",
                    conversationId, ParticipantId, utteranceWordCount, stream_start_time,
                    utterance_start_offset, utterance_end_offset,"Time taken ", (endTime-nlpStartTime));

            Success_counter.inc();

        } catch (Exception e) {
            LOG.error("ERRLABEL102 - Unable to Write into BigQuery and publish the failed message into DLQ topics"
                    +" Conversation id: " + conversationId + " Participantid: " +ParticipantId +", word_count: "
                    + utteranceWordCount + ", Stream_Start_Time: "+ stream_start_time + ", Utterance_start_offset: "
                    +utterance_start_offset+  ", Utterance_end_offset: " + utterance_end_offset,e);
            c.output(DLQ,c.element());
            failure_counter.inc();

        }
    }

    private void log(String prefix,
                     String conversationId, String participantId,
                     String utteranceWordCount, com.google.protobuf.Timestamp stream_start_time,
                     Duration utterance_start_offset, Duration utterance_end_offset, String time , long timeTakenMs) {

        String logMessage=prefix + " ConversationId: " + conversationId + ", ParticipantId: " + participantId +
                ", word_count: " + utteranceWordCount + ", Stream_Start_Time: " + stream_start_time +
                ", Utterance_start_offset: " + utterance_start_offset + ", utterance_end_offset: "
                + utterance_end_offset + ", "+time + timeTakenMs+"ms";

        LOG.debug(logMessage.replace("\r","").replace("\n",""));
    }

    private Participant getParticipantUtil(String projectID, String conversation, String participant)
    {
        Participant participantResponse = null;

        try {
            participantResponse = participantsClient.getParticipant(participant);

        }catch(Exception e)
        {
            System.out.println("IO Exception"+e.getMessage()+"Exception Name"+e.getStackTrace());
            LOG.error("ERRLABEL102 - Unable to retrieve the Label for participant: "+participant+" ERROR: "+e.getMessage() +" Trace: "+e.getStackTrace());
        }

        return participantResponse;

    }

}

