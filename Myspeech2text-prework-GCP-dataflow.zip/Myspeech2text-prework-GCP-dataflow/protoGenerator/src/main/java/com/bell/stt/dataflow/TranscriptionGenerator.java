/*
 * Copyright (C) 2018 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package com.bell.stt.dataflow;

import com.bell.stt.dataflow.Transformer.TranscriptionTransformer;
import com.bell.stt.dataflow.options.Options;
import com.bell.stt.proto.TranscriptionMessage.*;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;

import org.apache.beam.sdk.options.PipelineOptionsFactory;

import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;


/**
 * An template that copies messages from one Pubsub subscription to another Pubsub topic.
 */
public class TranscriptionGenerator {

    /**
     * Main entry point for executing the pipeline.
     *
     * @param args The command-line arguments to the pipeline.
     */
    public static void main(String[] args) {

        // Parse the user options passed from the command-line
        Options options = PipelineOptionsFactory.fromArgs(args).withValidation().as(Options.class);

        options.setStreaming(true);

        PipelineResult result = run(options);
        result.waitUntilFinish();

    }

    /**
     * Runs the pipeline with the supplied options.
     *
     * @param options The execution parameters to the pipeline.
     * @return The result of the pipeline execution.
     */
    public static PipelineResult run(Options options) {
        // Create the pipeline


        Pipeline pipeline = Pipeline.create(options);
        PCollection<String> input = pipeline.apply("Read Text Data", TextIO.read().from(options.getInputFile()));
        PCollection<ConversationEvent> proto =  input.apply("convert to proto", ParDo.of(new TranscriptionTransformer()));
        proto.apply("Write PubSub Events", PubsubIO.writeProtos((Class) ConversationEvent.class).to(options.getOutputTopic()));

        // Execute the pipeline and return the result.
        return pipeline.run();
    }


}
