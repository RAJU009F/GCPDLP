package com.bell.stt.dataflow.Transformer;

import com.google.protobuf.util.Durations;
import com.google.protobuf.util.Timestamps;
import org.apache.beam.sdk.transforms.DoFn;
import com.bell.stt.proto.ContextOuterClass.Context;

import java.util.Optional;


public class ContextTransformer extends DoFn<String, Context> {


    private Context createProtoRecord(int event, String ucid, String eventTimeStamp, String uui,
                                      String agentLoginId, String agentExtension,
                                      String acdNumber) {
        Context.Builder aes = Context.newBuilder();

        try{
            aes.setEventType(Context.EventType.forNumber(event));
            aes.setCallId("Call-ID");
            aes.setEventTimeStamp(Timestamps.parse(eventTimeStamp));
            aes.setUcid(ucid);
            aes.setUui(uui);
            aes.setAcdId(acdNumber);
            aes.setAgentLoginId(agentLoginId);
            aes.setAgentExtension(agentExtension);
            Context.ExtraContextInfo.Builder ecinfo = Context.ExtraContextInfo.newBuilder();
            ecinfo.setKey("Tes-key");
            ecinfo.setValue("Test-value");
            aes.setExtraContextInfo(ecinfo.build());


        }catch(Exception e){
            e.printStackTrace();
        }
        return aes.build();
    }



    @ProcessElement
    public void processElement(ProcessContext c) {
        try {

            String t = c.element();
            String[] values = t.split(",", -1);

            int event = Integer.parseInt(values[0]);
            String ucid = values[2];
            String eventTimeStamp = values[3];

            String uui = null;
            String agentLoginId;
            String agentExtension;
            String acdNumber;


           uui = Optional.ofNullable(values[1]).orElse("");
           agentLoginId = Optional.ofNullable(values[4]).orElse("");
           agentExtension = Optional.ofNullable(values[5]).orElse("");
           acdNumber = Optional.ofNullable(values[6]).orElse("");

            Context pt = createProtoRecord(event,ucid,eventTimeStamp,uui,agentLoginId,agentExtension,acdNumber);
            System.out.print(pt.toString());
            c.output(pt);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

