package com.bell.stt.dataflow.options;

import org.apache.beam.sdk.options.*;

public interface Options extends PipelineOptions, StreamingOptions {


    @Description("Test cases")
    @Validation.Required
    ValueProvider<String> getInputFile();
    void setInputFile(ValueProvider<String> inputFile);

    @Description(
            "The Cloud Pub/Sub topic to publish to. "
                    + "The name should be in the format of "
                    + "projects/<project-id>/topics/<topic-name>.")
    @Validation.Required
    ValueProvider<String> getOutputTopic();

    void setOutputTopic(ValueProvider<String> outputTopic);


    @Description(
            "The project id of the DLP service.")
    @Validation.Required
    ValueProvider<String> getProjectId();

    void setProjectId(ValueProvider<String> projectId);
}
