//package com.bell.stt.test;
//
//import com.bell.stt.proto.TranscriptionOuterClass;
//import com.bell.stt.transformers.KafkaToAvroParDo;
//import org.apache.beam.sdk.PipelineResult;
//import org.apache.beam.sdk.metrics.MetricNameFilter;
//import org.apache.beam.sdk.metrics.MetricQueryResults;
//import org.apache.beam.sdk.metrics.MetricResult;
//import org.apache.beam.sdk.metrics.MetricsFilter;
//import org.apache.beam.sdk.testing.PAssert;
//import org.apache.beam.sdk.testing.TestPipeline;
//import org.apache.beam.sdk.transforms.Create;
//import org.apache.beam.sdk.transforms.ParDo;
//import org.apache.beam.sdk.values.KV;
//import org.apache.beam.sdk.values.PCollection;
//import org.junit.Rule;
//import org.junit.Test;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class PubSubToKafkaTest {
//    @Rule
//    public TestPipeline pipeline = TestPipeline.create();
//
//
//    public void testProtoToAvroParDoFunction() {
//        long time = System.currentTimeMillis();
//        List<TranscriptionOuterClass.Transcription> testProtos = new ArrayList<TranscriptionOuterClass.Transcription>();
//        testProtos.add(createProtoRecord(11,time));
//        testProtos.add(createProtoRecord(12,time));
//        testProtos.add(createProtoRecord(13,time));
//        testProtos.add(createProtoRecord(14,time));
//        testProtos.add(createProtoRecord(15,time));
//        testProtos.add(createProtoRecord(16,time));
//        Map<String,com.bell.stt.avro.Transcription> avroLists = new HashMap<>();
//        avroLists.putAll(createAvroRecord(11, time));
//        avroLists.putAll(createAvroRecord(12, time));
//        avroLists.putAll(createAvroRecord(13, time));
//        avroLists.putAll(createAvroRecord(14, time));
//        avroLists.putAll(createAvroRecord(15, time));
//        avroLists.putAll(createAvroRecord(16, time));
//
//        PCollection<TranscriptionOuterClass.Transcription> input = pipeline.apply(Create.of(testProtos));
//        PCollection<KV<String,com.bell.stt.avro.Transcription>> output = input.apply(ParDo.of(new KafkaToAvroParDo()));
//        PAssert.that(output).containsInAnyOrder(avroLists);
//        PipelineResult result = pipeline.run();
//        result.waitUntilFinish();
//
//        MetricQueryResults metrics =
//                result
//                        .metrics()
//                        .queryMetrics(
//                                MetricsFilter.builder()
//                                        .addNameFilter(MetricNameFilter.named("STT-PubsubToKafka", "PUBSUBTOKAFKA_STT_SUCCESS"))
//                                        .addNameFilter(MetricNameFilter.named("STT-PubsubToKafka", "PUBSUBTOKAFKA_STT_FAILURE"))
//                                        .build());
//
//        for (MetricResult<Long> counter : metrics.getCounters()) {
//            System.out.println(counter.getName() + ":" + counter.getAttempted());
//        }
//    }
//
//
//    private TranscriptionOuterClass.Transcription createProtoRecord(int i, long time) {
//
//        TranscriptionOuterClass.Transcription.Builder transcription = TranscriptionOuterClass.Transcription.newBuilder();
//        transcription.setConversation("Test Conversation" + i);
//        transcription.setType("Test type" + i);
//        TranscriptionOuterClass.ErrorStatus.Builder es = transcription.getErrorStatusBuilder();
//        es.setAttr1("Error" + i);
//        transcription.setErrorStatus(es);
//        TranscriptionOuterClass.Message.Builder msg = TranscriptionOuterClass.Message.newBuilder();
//        TranscriptionOuterClass.Message.ParticipantRole.Builder pr = TranscriptionOuterClass.Message.ParticipantRole.newBuilder();
//        pr.setAttr1("pr" + i);
//        TranscriptionOuterClass.Message.SentimentAnalysis.Builder sa = TranscriptionOuterClass.Message.SentimentAnalysis.newBuilder();
//        sa.setAttr1("sa" + i);
//        TranscriptionOuterClass.Message.MessageAnnotation.Builder ma = TranscriptionOuterClass.Message.MessageAnnotation.newBuilder();
//        ma.setAttr1("ma" + i);
//        msg.setSentimentAnalysis(sa);
//        msg.setParticipantRole(pr);
//        msg.setMessageAnnotation(ma);
//        msg.setUtteranceEndOffset(time);
//        msg.setUtterenceStartOffset(time);
//        msg.setLanguageCode("en-US");
//        msg.setStreamStartTime(time);
//        msg.setParticipant("participant" + i);
//        msg.setName("project1/message1/" + i);
//        msg.setCreateTime(time);
//        msg.setContent("Welcome to bell!");
//        TranscriptionOuterClass.Message.Words.Builder wd1 = TranscriptionOuterClass.Message.Words.newBuilder();
//        wd1.setOffsetEndValue(10L).setOffsetStartvalue(10L).setConfidenceScore("0.5").setText("Welcome" + i);
//        TranscriptionOuterClass.Message.Words.Builder wd2 = TranscriptionOuterClass.Message.Words.newBuilder();
//        wd2.setOffsetEndValue(20L).setOffsetStartvalue(20L).setConfidenceScore("0.5").setText("to" + i);
//        TranscriptionOuterClass.Message.Words.Builder wd3 = TranscriptionOuterClass.Message.Words.newBuilder();
//        wd3.setOffsetEndValue(20L).setOffsetStartvalue(20L).setConfidenceScore("0.5").setText("bell" + i);
//        msg.addWords(wd1.build()).addWords(wd2.build()).addWords(wd3.build());
//        transcription.setMessage(msg);
//        return transcription.build();
//    }
//
//
//    private Map<String,Transcription> createAvroRecord(int i, long time) {
//        Transcription.Builder avroRecord = Transcription.newBuilder();
//        avroRecord.setConversation("Test Conversation" + i);
//        avroRecord.setType("Test type" + i);
//        com.bell.avro.call.error_status es = new com.bell.avro.call.error_status();
//        es.setAttr1("Error" + i);
//        avroRecord.setErrorStatus(es);
//        com.bell.avro.call.message msg = new com.bell.avro.call.message();
//        com.bell.avro.call.sentiment_analysis sa = new com.bell.avro.call.sentiment_analysis();
//        sa.setAttr1("sa" + i);
//        com.bell.avro.call.participant_role pr = new com.bell.avro.call.participant_role();
//        pr.setAttr1("pr" + i);
//        com.bell.avro.call.message_annotation ma = new com.bell.avro.call.message_annotation();
//        ma.setAttr1("ma" + i);
//        msg.setSentimentAnalysis(sa);
//        msg.setParticipant("participant" + i);
//        msg.setParticipantRole(pr);
//        msg.setMessageAnnotation(ma);
//        msg.setUtteranceEndOffset(time);
//        msg.setUtterenceStartOffset(time);
//        msg.setLanguageCode("en-US");
//        msg.setStreamStartTime(time);
//        msg.setName("project1/message1/" + i);
//        msg.setCreateTime(time);
//        msg.setContent("Welcome to bell!");
//        List<com.bell.avro.call.words> avroWordsList = new ArrayList<com.bell.avro.call.words>();
//        com.bell.avro.call.words wd1 = new com.bell.avro.call.words("Welcome" + i, "0.5", 10L, 10L);
//        com.bell.avro.call.words wd2 = new com.bell.avro.call.words("to" + i, "0.5", 20L, 20L);
//        com.bell.avro.call.words wd3 = new com.bell.avro.call.words("bell" + i, "0.5", 20L, 20L);
//        avroWordsList.add(wd1);
//        avroWordsList.add(wd2);
//        avroWordsList.add(wd3);
//        msg.setWords(avroWordsList);
//        avroRecord.setMessage(msg);
//        Map<String,Context> map = new HashMap<>();
//        return map.add("Test Conversation" + i,avroRecord.build());
//    }
//}
