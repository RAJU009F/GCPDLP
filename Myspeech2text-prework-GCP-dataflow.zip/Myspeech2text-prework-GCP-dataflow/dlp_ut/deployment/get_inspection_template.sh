#!/bin/bash
PROJECT_ID=$1
TEMPLATE_ID=$2
API_ROOT_URL="https://dlp.googleapis.com"
ALL_API_CALL_SUCCESS=0

API_KEY=$(gcloud auth print-access-token)
TEMPLATE_API="${API_ROOT_URL}/v2/projects/${PROJECT_ID}/locations/northamerica-northeast1/inspectTemplates/${TEMPLATE_ID}"
template_exists=$(curl -s -H "Content-Type: application/json" -H "Authorization: Bearer ${API_KEY}" "${TEMPLATE_API}" --write-out '%{http_code}' --silent -o ../inspect_templates/inspection_template_download.json)

if [[ $template_exists == "200" ]]; then
    content=$(cat ../inspect_templates/inspection_template_download.json | jq 'del(.name)' | jq 'del(.createTime)' | jq 'del(.updateTime)')
    echo "{\"templateId\":\"$TEMPLATE_ID\",\"inspectTemplate\": $content}" >../inspect_templates/inspect.json
    echo "Template Saved."
    $(rm -rf ../inspect_templates/inspection_template_download.json)
fi

if [[ ${template_exists} -gt 299 ]]; then
    echo "Template Not Found At: $TEMPLATE_API."
    ALL_API_CALL_SUCCESS=-1
fi

exit $ALL_API_CALL_SUCCESS
