#!/bin/bash
PROJECT_ID=$1
API_ROOT_URL="https://dlp.googleapis.com"
ALL_API_CALL_SUCCESS=0

for template in $(find ../inspect_templates -name *.json); do
    API_KEY=$(gcloud auth print-access-token)
    TEMPLATE_API="${API_ROOT_URL}/v2/projects/${PROJECT_ID}/locations/northamerica-northeast1/inspectTemplates"
    templateId=$(cat "$template" | jq '.templateId' | sed 's/"//g')
    template_exists=$(curl -s -H "Content-Type: application/json" -H "Authorization: Bearer ${API_KEY}" "${TEMPLATE_API}/$templateId" --write-out '%{http_code}' --silent --output /dev/null)
    method="POST"

    if [[ $template_exists == "200" ]]; then
        method="PATCH"
        TEMPLATE_API="${API_ROOT_URL}/v2/projects/${PROJECT_ID}/locations/northamerica-northeast1/inspectTemplates/$templateId"
        jq 'del(.templateId)' "$template" >"$template".tmp && mv "$template".tmp "$template"
        echo "Inspect Template Updated."
    fi

    INSPECT_TEMP="@${template}"

    api_status=$(
        curl -s -X $method -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${API_KEY}" "${TEMPLATE_API}" \
        -d "${INSPECT_TEMP}" --write-out '%{http_code}' --silent --output /dev/null
    )

    if [[ $api_status == "200" ]]; then
        echo "Inspect Template Deployed."
    fi

    if [[ ${api_status} -gt 299 ]]; then
        echo "Inspect Template Creation Failed: status_code : $api_status, template: $template"
        ALL_API_CALL_SUCCESS=-1
    fi
done

exit $ALL_API_CALL_SUCCESS
