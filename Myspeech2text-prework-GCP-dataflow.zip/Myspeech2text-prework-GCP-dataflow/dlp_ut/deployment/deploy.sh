#!/bin/bash
PROJECT_ID=$1
sh inspect_script.sh $PROJECT_ID
sh deidentify_script.sh $PROJECT_ID
