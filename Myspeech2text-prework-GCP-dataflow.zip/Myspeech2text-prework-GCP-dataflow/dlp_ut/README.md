## Python Test Suite

### To resoled python dependancies
    pip install -r requirements.txt

### To run the pytest test suite
    pytest -m smoke --project_id=itcx-bi-ccast-dev-01

### How to create templates in DLP
    Use below command in the cloud shell to create Inspection and DeIdentification templates in DLP, here the script below take projectId as command line argument, which can be used for multiple environments.

    @cloudshell > sh deploy.sh itcx-bi-ccast-dev-01

    Above command creates two templates i.e Inspection ['CUSTOM_MASKING_RULES_TEST'] and DeIdentification ['CUSTOM_DEID_RULES_TEST'] templates. To rename the template more relevent, replace the above names in the JSON files [inspect.json, deid.json].

### How to get DLP templates
    In order to get the DLP Template JSON files, we need to run below shell script command to get the templates.

    Scripts folder: dlp_ut\deployment
        Command to get the inspection template: 
            Command: sh get_inspection_template.sh projectID templateID
            Ex: sh get_inspection_template.sh itcx-bi-ccast-uat-01 CUSTOM_MASKING_RULES

        Command to get the deidentification template: 
            Command: sh get_deidentification_template.sh projectID templateID
            Ex: sh get_deidentification_template.sh itcx-bi-ccast-uat-01 CUSTOM_DEID_RULES

        Note: As requested default region is set to ‘northamerica-northeast1’

    Steps:
        1)	Open the code in source repository editor or Cloud shell in respective (DEV, QA, PROD) environment.
        2)	Set GOOGLE_APPLICATION_CREDENTIALS with the Service Account / Authorize the Cloud Shell for further execution.
        3)	Use above commands to get the JSON templates as a JSON files.
            a)	Inspection template JSON: dlp_ut\inspect_templates\inspection_template.json
            b)	Deidentification template JSON: dlp_ut\deidentify_templates\deidentification_template.json


## Node JS Test Suite

### Prerequisites
    Required to install node js > 12

### How to Build
    To resolve the dependancies of the applicaion, run below command in the application main folder
    $dlp_ut > npm install

### How to run test
    Need to set GOOGLE_APPLICATION_CREDENTIALS in the environment, for windows use below command with the updated json file location. 
    $dlp_ut > $env:GOOGLE_APPLICATION_CREDENTIALS="C:\Users\udaya.b.sivakoti\Documents\Workspace\BellWorkspace\itcx-bi-ccast-dev-01-fcf3cdf0d6b6.json"

    Execute below command to run the tests suite.
    $dlp_ut > npm run test -- --parentId="itcx-bi-ccast-dev-01" --inspectTemplate="projects/itcx-bi-ccast-dev-01/locations/global/inspectTemplates/CUSTOM_MASKING_RULES" --deIdentificationTemplate="projects/itcx-bi-ccast-dev-01/locations/global/deidentifyTemplates/CUSTOM_DEID_RULES"

### How to add addition test cases
    Copy below snippet and update the context as per the notes

    ```test('RULE: GIVE A GOOD NAME TO THE CASE', async () => {
        const table = {
            table: {
                headers: [{ "name": 'content' }],
                rows: [
                    { "values": [{ "stringValue": "YOUR INPUT TEXT ONE COMES HERE" }] }
                    { "values": [{ "stringValue": "YOUR INPUT TEXT TWO COMES HERE" }] }
                ]
            }
        };
        await dlp(table, metaObj, function (err, data) {
            expect(data.rows[0].values[0].stringValue).toBe("YOUR EXPECTED OUT PUT TEXT ONE COMES HERE");
            expect(data.rows[1].values[0].stringValue).toBe("YOUR EXPECTED OUT PUT TEXT TWO COMES HERE");
        });
    });```