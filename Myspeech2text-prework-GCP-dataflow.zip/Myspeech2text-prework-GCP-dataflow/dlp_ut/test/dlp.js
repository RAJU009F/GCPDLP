const DLP = require('@google-cloud/dlp');
const dlp = new DLP.DlpServiceClient();

/* This snipet is used to get the inspection template json */
/* let obj = dlp.getInspectTemplate({ name: inspectionTemplate })
obj.then(dlpobj => {
    console.log(JSON.stringify(dlpobj))
}) */

/* This snipet is used to get the deIdentify template json */
/* let obj = dlp.getDeidentifyTemplate({ name: deIdentifyTemplate })
obj.then(dlpobj => {
    console.log(JSON.stringify(dlpobj))
}) */

async function dlpMasking(table, paramObject, callback) {
    const request = {
        item: table,
        inspectTemplateName: paramObject.inspectTemplate,
        deidentifyTemplateName: paramObject.deIdentificationTemplate,
        parent: `projects/${paramObject.parentId}/locations/global`
    };

    const [response] = await dlp.deidentifyContent(request);
    return callback(null, response.item.table);
}

module.exports = dlpMasking;